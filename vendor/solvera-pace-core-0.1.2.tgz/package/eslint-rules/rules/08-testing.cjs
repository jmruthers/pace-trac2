/**
 * Testing Rules (Standard 8)
 * @package @solvera/pace-core
 * @module ESLintRules/rules/testing
 * 
 * Enforces testing patterns from Standard 8:
 * - Test file naming conventions (*.test.ts, *.test.tsx)
 * 
 * Reference: packages/core/docs/standards/8-testing-documentation-standards.md
 */

const path = require('path');
const fs = require('fs');
const { isPaceCoreSourceFile } = require('../utils/helpers.cjs');

module.exports = {
  rules: {
    /**
     * Enforce test file naming: *.test.ts or *.test.tsx
     */
    'test-file-naming': {
      meta: {
        type: 'suggestion',
        docs: {
          description: 'Enforce test file naming: *.test.ts or *.test.tsx (not *.spec.ts)',
          category: 'Best Practices',
          recommended: false,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/8-testing-documentation-standards.md'
        },
        messages: {
          invalidTestFileName: "Test file '{{filename}}' should be named '{{expectedName}}.test.{{ext}}' instead of '{{currentName}}'"
        },
        hasSuggestions: true
      },
      create(context) {
        const filename = context.getFilename();
        
        // Exclude pace-core source files - these rules are for consuming apps
        if (isPaceCoreSourceFile(filename)) {
          return {};
        }
        
        // Only check test files
        const isTestFile = filename.match(/\.(test|spec)\.(ts|tsx|js|jsx)$/);
        if (!isTestFile) {
          return {};
        }
        
        const basename = path.basename(filename);
        const ext = path.extname(filename);
        const nameWithoutExt = basename.replace(ext, '');
        
        // Check if it uses .spec instead of .test
        if (nameWithoutExt.endsWith('.spec')) {
          const sourceName = nameWithoutExt.replace('.spec', '');
          const expectedName = `${sourceName}.test${ext}`;
          
          return {
            Program(node) {
              context.report({
                node,
                messageId: 'invalidTestFileName',
                data: {
                  filename: basename,
                  expectedName,
                  currentName: basename
                },
                suggest: [{
                  desc: `Rename to ${expectedName}`,
                  fix(fixer) {
                    return null; // File rename requires filesystem operation
                  }
                }]
              });
            }
          };
        }
        
        // Check if test file is colocated with source file
        // This is a suggestion, not an error
        const sourceFile = filename.replace(/\.(test|spec)\.(ts|tsx|js|jsx)$/, '.$2');
        const sourceExists = fs.existsSync(sourceFile);
        const isInTestDir = filename.includes('/__tests__/') || filename.includes('/tests/');
        
        if (!sourceExists && !isInTestDir) {
          // Test file exists but source file doesn't - might be misnamed or in wrong location
          // This is just informational, not an error
        }
        
        return {};
      }
    },

    /**
     * Prefer setupUser() from @test-utils over bare userEvent.setup()
     */
    'prefer-setup-user': {
      meta: {
        type: 'problem',
        docs: {
          description: 'Use setupUser() from @test-utils instead of userEvent.setup() in tests',
          category: 'Best Practices',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/8-testing-documentation-standards.md'
        },
        messages: {
          preferSetupUser:
            'Use setupUser() from @test-utils instead of userEvent.setup() for fast, delay-free interactions (Standard 8).'
        },
        schema: []
      },
      create(context) {
        const filename = context.getFilename();

        if (isPaceCoreSourceFile(filename)) {
          return {};
        }

        const isTestFile = filename.match(/\.(test|spec)\.(ts|tsx|js|jsx)$/);
        if (!isTestFile) {
          return {};
        }

        function isBareUserEventSetup(node) {
          if (node.type !== 'CallExpression') return false;
          const callee = node.callee;
          if (callee.type !== 'MemberExpression') return false;
          if (callee.property.type !== 'Identifier' || callee.property.name !== 'setup') return false;
          const object = callee.object;
          if (object.type === 'Identifier' && object.name === 'userEvent') {
            if (node.arguments.length === 0) return true;
            if (node.arguments.length === 1 && node.arguments[0].type === 'ObjectExpression') {
              const hasDelayNull = node.arguments[0].properties.some(
                (prop) =>
                  prop.type === 'Property' &&
                  ((prop.key.type === 'Identifier' && prop.key.name === 'delay') ||
                    (prop.key.type === 'Literal' && prop.key.value === 'delay')) &&
                  prop.value.type === 'Literal' &&
                  prop.value.value === null
              );
              return !hasDelayNull;
            }
            return true;
          }
          return false;
        }

        return {
          CallExpression(node) {
            if (isBareUserEventSetup(node)) {
              context.report({ node, messageId: 'preferSetupUser' });
            }
          }
        };
      }
    }
  }
};
