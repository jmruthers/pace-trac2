import { describe, expect, it } from 'vitest';
import { Linter } from 'eslint';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const testingRules = require('./08-testing.cjs');

const RULE_ID = 'pace-core-compliance/prefer-setup-user';

function runPreferSetupUserRule(code: string, filename = 'src/components/Button.test.tsx') {
  const linter = new Linter({ configType: 'eslintrc' });
  linter.defineRules(
    Object.fromEntries(
      Object.entries(testingRules.rules).map(([name, rule]) => [
        `pace-core-compliance/${name}`,
        rule,
      ])
    )
  );

  return linter.verify(
    code,
    {
      parserOptions: {
        ecmaVersion: 2022,
        sourceType: 'module',
        ecmaFeatures: { jsx: true },
      },
      rules: {
        [RULE_ID]: 'error',
      },
    },
    filename
  );
}

describe('prefer-setup-user', () => {
  it('reports bare userEvent.setup()', () => {
    const messages = runPreferSetupUserRule(`
      import userEvent from '@testing-library/user-event';
      it('clicks', async () => {
        const user = userEvent.setup();
      });
    `);

    expect(messages.some((m) => m.ruleId === RULE_ID)).toBe(true);
  });

  it('does not report setupUser()', () => {
    const messages = runPreferSetupUserRule(`
      import { setupUser } from '@test-utils';
      it('clicks', async () => {
        const user = setupUser();
      });
    `);

    expect(messages.filter((m) => m.ruleId === RULE_ID)).toHaveLength(0);
  });

  it('allows userEvent.setup({ delay: null }) as temporary escape hatch', () => {
    const messages = runPreferSetupUserRule(`
      import userEvent from '@testing-library/user-event';
      it('clicks', async () => {
        const user = userEvent.setup({ delay: null });
      });
    `);

    expect(messages.filter((m) => m.ruleId === RULE_ID)).toHaveLength(0);
  });

  it('does not report in pace-core source files', () => {
    const messages = runPreferSetupUserRule(
      `
      import userEvent from '@testing-library/user-event';
      it('clicks', async () => {
        const user = userEvent.setup();
      });
    `,
      'packages/core/src/components/Button.test.tsx'
    );

    expect(messages.filter((m) => m.ruleId === RULE_ID)).toHaveLength(0);
  });
});
