import { describe, expect, it } from 'vitest';
import { Linter } from 'eslint';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const codeQualityRules = require('./04-code-quality.cjs');

const COMPONENT_NAMING_RULE = 'pace-core-compliance/component-naming';
const COMPONENT_FILENAME_RULE = 'pace-core-compliance/component-filename';

function runRule(
  ruleId: string,
  code: string,
  filename = 'packages/core/src/components/primitives/DateBadge.tsx',
) {
  const linter = new Linter({ configType: 'eslintrc' });
  const localRuleId = ruleId.replace('pace-core-compliance/', '');
  linter.defineRule(ruleId, codeQualityRules.rules[localRuleId]);

  return linter.verify(
    code,
    {
      parserOptions: {
        ecmaVersion: 2022,
        sourceType: 'module',
        ecmaFeatures: { jsx: true },
      },
      rules: {
        [ruleId]: 'error',
      },
    },
    filename,
  );
}

describe('component-naming', () => {
  it('accepts PascalCase exported component in pace-core components tree', () => {
    const messages = runRule(
      COMPONENT_NAMING_RULE,
      `
      export function DateBadge() {
        return <span>Jan</span>;
      }
    `,
    );
    expect(messages).toHaveLength(0);
  });

  it('reports lowercase exported component', () => {
    const messages = runRule(
      COMPONENT_NAMING_RULE,
      `
      export function dateBadge() {
        return <span>Jan</span>;
      }
    `,
    );
    expect(messages.length).toBeGreaterThan(0);
    expect(messages[0]?.ruleId).toBe(COMPONENT_NAMING_RULE);
    expect(messages[0]?.message).toContain('dateBadge');
  });

  it('ignores create* factory exports that return objects', () => {
    const messages = runRule(
      COMPONENT_NAMING_RULE,
      `
      export function createTextColumn(options) {
        return { id: options.key, header: options.header };
      }
    `,
      'packages/core/src/components/data-table/columnFactory.tsx',
    );
    expect(messages).toHaveLength(0);
  });

  it('ignores use* hook exports in component modules', () => {
    const messages = runRule(
      COMPONENT_NAMING_RULE,
      `
      export function useToastContext() {
        return { toast: () => {} };
      }
    `,
      'packages/core/src/components/forms-feedback/Toast.tsx',
    );
    expect(messages).toHaveLength(0);
  });

  it('checks exported components in pace-core rbac tree', () => {
    const messages = runRule(
      COMPONENT_NAMING_RULE,
      `
      export function pagePermissionGuard() {
        return <p>denied</p>;
      }
    `,
      'packages/core/src/rbac/PagePermissionGuard.tsx',
    );
    expect(messages.length).toBeGreaterThan(0);
    expect(messages[0]?.ruleId).toBe(COMPONENT_NAMING_RULE);
  });
});

describe('component-filename', () => {
  it('accepts PascalCase filename for exported component', () => {
    const messages = runRule(
      COMPONENT_FILENAME_RULE,
      `
      export function EventCard() {
        return <article>Event</article>;
      }
    `,
      'packages/core/src/components/advanced-ui/EventCard.tsx',
    );
    expect(messages).toHaveLength(0);
  });

  it('reports non-PascalCase filename when module exports a component', () => {
    const messages = runRule(
      COMPONENT_FILENAME_RULE,
      `
      export function EventCard() {
        return <article>Event</article>;
      }
    `,
      'packages/core/src/components/advanced-ui/eventCard.tsx',
    );
    expect(messages.length).toBeGreaterThan(0);
    expect(messages[0]?.ruleId).toBe(COMPONENT_FILENAME_RULE);
  });

  it('accepts PascalCase filename for split rbac guard modules', () => {
    const messages = runRule(
      COMPONENT_FILENAME_RULE,
      `
      export function PagePermissionGuard() {
        return <p>ok</p>;
      }
    `,
      'packages/core/src/rbac/PagePermissionGuard.tsx',
    );
    expect(messages).toHaveLength(0);
  });

  it('allowlists utility columnFactory filename without component exports', () => {
    const messages = runRule(
      COMPONENT_FILENAME_RULE,
      `
      export function createTextColumn(options) {
        return { id: options.key };
      }
    `,
      'packages/core/src/components/data-table/columnFactory.tsx',
    );
    expect(messages).toHaveLength(0);
  });

  it('does not apply outside component module scope', () => {
    const messages = runRule(
      COMPONENT_FILENAME_RULE,
      `
      export function eventCard() {
        return <article>Event</article>;
      }
    `,
      'packages/core/src/utils/eventCard.tsx',
    );
    expect(messages).toHaveLength(0);
  });
});
