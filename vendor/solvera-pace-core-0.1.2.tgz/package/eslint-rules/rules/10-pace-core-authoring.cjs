/**
 * pace-core package component authoring rules (packages/core/src/components only).
 */
const fs = require('fs');
const path = require('path');

const BUTTON_RECIPE =
  'inline-grid grid-flow-col gap-2 place-items-center focus:outline-none focus:ring-2 focus:ring-offset-2';

const COMPONENT_TEST_EXCLUDE = [
  /[/\\]internal[/\\]/,
  /[/\\]data-table[/\\]DataTable(Modals|Layout|CaptionToolbar|FilterRow|Body|PaginationFooter)\.tsx$/,
  /[/\\]data-table[/\\]columnFactory\.tsx$/,
];

function isComponentAuthoringFile(filename) {
  const normalized = filename.replace(/\\/g, '/');
  return /packages\/core\/src\/components\/.+\.(tsx?)$/.test(normalized)
    && !/\.(test|integration\.test)\.(tsx?)$/.test(normalized)
    && !/\/index\.ts$/.test(normalized);
}

function isComponentTsxFile(filename) {
  const normalized = filename.replace(/\\/g, '/');
  return /packages\/core\/src\/components\/.+\.tsx$/.test(normalized)
    && !/\.(test|integration\.test)\.tsx$/.test(normalized);
}

function isExcludedFromIntegrationTestRequirement(filename) {
  return COMPONENT_TEST_EXCLUDE.some((pattern) => pattern.test(filename));
}

function isButtonSourceFile(filename) {
  return filename.replace(/\\/g, '/').endsWith('packages/core/src/components/primitives/Button.tsx');
}

function hasColocatedIntegrationTest(filePath) {
  const dir = path.dirname(filePath);
  const base = path.basename(filePath, '.tsx');
  return fs.existsSync(path.join(dir, `${base}.integration.test.tsx`));
}

function fileHasNamedExport(programNode) {
  return programNode.body.some(
    (node) => node.type === 'ExportNamedDeclaration'
      && (node.declaration != null || (node.specifiers && node.specifiers.length > 0)),
  );
}

module.exports = {
  rules: {
    'prefer-cn-class-merge': {
      meta: {
        type: 'problem',
        docs: {
          description: 'Use cn() for className merging in pace-core components',
        },
        messages: {
          preferCn: 'Use cn() instead of manual array filter/join for className assembly.',
        },
      },
      create(context) {
        const filename = context.getFilename();
        if (!isComponentAuthoringFile(filename)) return {};

        return {
          CallExpression(node) {
            if (
              node.callee.type === 'MemberExpression'
              && node.callee.property.name === 'join'
              && node.callee.object.type === 'CallExpression'
              && node.callee.object.callee.type === 'MemberExpression'
              && node.callee.object.callee.property.name === 'filter'
              && node.arguments[0]?.value === ' '
            ) {
              context.report({ node, messageId: 'preferCn' });
            }
          },
        };
      },
    },
    'no-duplicate-button-classes': {
      meta: {
        type: 'problem',
        docs: {
          description: 'Do not duplicate Button variant class strings outside Button.tsx',
        },
        messages: {
          duplicate: 'Compose <Button> instead of duplicating button class strings.',
        },
      },
      create(context) {
        const filename = context.getFilename();
        if (!isComponentAuthoringFile(filename) || isButtonSourceFile(filename)) return {};

        return {
          Literal(node) {
            if (typeof node.value !== 'string') return;
            if (node.value.includes(BUTTON_RECIPE) || node.value.includes('bg-main-600 text-main-50 hover:bg-main-700 focus:ring-main-500 border border-main-600')) {
              context.report({ node, messageId: 'duplicate' });
            }
          },
          TemplateElement(node) {
            const raw = node.value?.raw ?? '';
            if (raw.includes(BUTTON_RECIPE)) {
              context.report({ node, messageId: 'duplicate' });
            }
          },
        };
      },
    },
    'component-test-naming': {
      meta: {
        type: 'problem',
        docs: {
          description: 'DOM component tests in pace-core must use *.integration.test.tsx',
        },
        messages: {
          invalidName: "Component test '{{name}}' must be named '*.integration.test.tsx'.",
        },
      },
      create(context) {
        const filename = context.getFilename().replace(/\\/g, '/');
        if (!/\/packages\/core\/src\/components\//.test(filename)) return {};
        if (!/\.test\.tsx$/.test(filename) || /\.integration\.test\.tsx$/.test(filename)) return {};

        const base = path.basename(filename);
        return {
          Program(node) {
            context.report({
              node,
              messageId: 'invalidName',
              data: { name: base },
            });
          },
        };
      },
    },
    'require-component-integration-test': {
      meta: {
        type: 'problem',
        docs: {
          description: 'Exported pace-core component .tsx files must have colocated *.integration.test.tsx',
        },
        messages: {
          missingTest: "Component '{{name}}' must have colocated '{{expected}}'.",
        },
      },
      create(context) {
        const filename = context.getFilename();
        if (!isComponentTsxFile(filename) || isExcludedFromIntegrationTestRequirement(filename)) {
          return {};
        }

        const base = path.basename(filename);
        const expected = `${path.basename(filename, '.tsx')}.integration.test.tsx`;

        return {
          Program(node) {
            if (!fileHasNamedExport(node)) return;
            if (hasColocatedIntegrationTest(filename)) return;
            context.report({
              node,
              messageId: 'missingTest',
              data: { name: base, expected },
            });
          },
        };
      },
    },
    'max-named-exports-package': {
      meta: {
        type: 'problem',
        docs: {
          description: 'Limit named exports in pace-core component source files',
        },
        schema: [{ type: 'object', properties: { max: { type: 'integer', minimum: 1 } } }],
        messages: {
          tooMany: 'File has {{count}} named exports (max {{max}}). Split into focused modules.',
        },
      },
      create(context) {
        const filename = context.getFilename();
        if (!isComponentAuthoringFile(filename)) return {};

        const options = context.options[0] || {};
        const max = options.max ?? 10;
        let count = 0;

        return {
          Program(node) {
            count = 0;
            for (const exportNode of node.body) {
              if (exportNode.type !== 'ExportNamedDeclaration') continue;
              if (exportNode.declaration) {
                count += 1;
              } else if (exportNode.specifiers?.length) {
                count += exportNode.specifiers.length;
              }
            }
            if (count > max) {
              context.report({
                node,
                messageId: 'tooMany',
                data: { count, max },
              });
            }
          },
        };
      },
    },
  },
};
