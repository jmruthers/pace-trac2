/**
 * Project Structure Rules (Standard 1)
 * @package @solvera/pace-core
 * @module ESLintRules/rules/project-structure
 *
 * Enforces import and file-location conventions from Standard 1.
 *
 * Reference: packages/core/docs/standards/1-project-structure-standards.md
 */

const path = require('path');
const { isPaceCoreSourceFile } = require('../utils/helpers.cjs');
const {
  validatePageName,
  validateRoutePath,
  isLegacyPageName,
} = require('../../naming/naming-by-layer.cjs');

function normalizePath(filename) {
  return filename.replace(/\\/g, '/');
}

function isSourceFile(filename) {
  const normalized = normalizePath(filename);
  return /(?:^|\/)src\/.+\.(tsx?|jsx?)$/.test(normalized);
}

function isBootstrapFile(filename) {
  const normalized = normalizePath(filename);
  const base = path.basename(normalized);
  if (base === 'main.tsx' || base === 'main.jsx' || base === 'App.tsx' || base === 'App.jsx') {
    return true;
  }
  // Consuming apps: shared Supabase bootstrap modules (see Standard 01 / portal-architecture).
  return (
    base === 'supabase.ts' ||
    base === 'supabase.js' ||
    base === 'supabaseAnonRpc.ts' ||
    base === 'eventSlugResolution.ts'
  );
}

function getPageFileStem(filename) {
  const normalized = normalizePath(filename);
  if (!/(?:^|\/)src\/pages\//.test(normalized)) return undefined;
  const base = path.basename(normalized).replace(/\.(tsx?|jsx?)$/, '');
  return /Page$/.test(base) ? base : undefined;
}

function getStringLiteralValue(node) {
  if (!node) return null;
  if (node.type === 'JSXExpressionContainer') {
    return getStringLiteralValue(node.expression);
  }
  if (node.type === 'Literal' && typeof node.value === 'string') return node.value;
  if (node.type === 'TemplateLiteral' && node.expressions.length === 0 && node.quasis.length === 1) {
    return node.quasis[0].value.cooked;
  }
  return null;
}

function isRouterPathJsxAttribute(node) {
  if (node.name.name !== 'path') return false;
  const opening = node.parent;
  if (!opening || opening.type !== 'JSXOpeningElement') return false;
  const tag = opening.name;
  if (tag.type === 'JSXIdentifier') {
    return tag.name === 'Route' || tag.name === 'NavLink';
  }
  if (tag.type === 'JSXMemberExpression' && tag.property.type === 'JSXIdentifier') {
    return tag.property.name === 'Route' || tag.property.name === 'NavLink';
  }
  return false;
}

module.exports = {
  rules: {
    /**
     * Prefer alias imports from @/ over deep relative imports.
     */
    'prefer-src-alias-imports': {
      meta: {
        type: 'suggestion',
        docs: {
          description: 'Prefer @/ alias imports over deep relative imports in src files',
          category: 'Best Practices',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/1-project-structure-standards.md'
        },
        schema: [],
        messages: {
          preferAlias: 'Prefer @/ alias imports instead of deep relative import "{{value}}".'
        }
      },
      create(context) {
        const filename = context.getFilename();
        if (isPaceCoreSourceFile(filename) || !isSourceFile(filename)) {
          return {};
        }

        return {
          ImportDeclaration(node) {
            const source = node.source.value;
            if (typeof source !== 'string') return;
            if (source.startsWith('../../') || source.startsWith('../../../')) {
              context.report({
                node: node.source,
                messageId: 'preferAlias',
                data: { value: source }
              });
            }
          }
        };
      }
    },

    /**
     * Prevent importing base Supabase client from app code outside bootstrap locations.
     */
    'no-base-supabase-import-outside-bootstrap': {
      meta: {
        type: 'problem',
        docs: {
          description: 'Base Supabase client import is only allowed in bootstrap files',
          category: 'Best Practices',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/1-project-structure-standards.md'
        },
        schema: [],
        messages: {
          noBaseClient: 'Do not import base Supabase client outside bootstrap files. Use useSecureSupabase() in app code.'
        }
      },
      create(context) {
        const filename = context.getFilename();
        if (isPaceCoreSourceFile(filename) || !isSourceFile(filename) || isBootstrapFile(filename)) {
          return {};
        }

        return {
          ImportDeclaration(node) {
            const source = node.source.value;
            if (typeof source !== 'string') return;
            if (
              source === '@/lib/supabase' ||
              source === './lib/supabase' ||
              source.endsWith('/lib/supabase')
            ) {
              context.report({
                node: node.source,
                messageId: 'noBaseClient'
              });
            }
          }
        };
      }
    },

    /**
     * RBAC pageName must be PascalCase (or registered legacy during transition).
     */
    'rbac-page-name-convention': {
      meta: {
        type: 'problem',
        docs: {
          description: 'pageName must be PascalCase matching page file stem or a registered legacy catalogue string',
          category: 'Best Practices',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/1-project-structure-standards.md#naming-by-layer'
        },
        schema: [],
        messages: {
          invalidPageName: '{{message}}'
        }
      },
      create(context) {
        const filename = context.getFilename();
        if (isPaceCoreSourceFile(filename) || !isSourceFile(filename)) {
          return {};
        }
        const fileStem = getPageFileStem(filename);

        function checkPageName(node, pageName) {
          if (!pageName) return;
          const result = validatePageName(pageName, { fileStem, legacyMode: 'reject' });
          if (!result.ok) {
            context.report({
              node,
              messageId: 'invalidPageName',
              data: { message: result.message }
            });
          }
        }

        return {
          JSXAttribute(node) {
            if (node.name.name !== 'pageName') return;
            const value = getStringLiteralValue(node.value);
            checkPageName(node, value);
          },
          CallExpression(node) {
            if (
              node.callee.type === 'Identifier' &&
              node.callee.name === 'useResourcePermissions' &&
              node.arguments[0]
            ) {
              checkPageName(node.arguments[0], getStringLiteralValue(node.arguments[0]));
            }
          }
        };
      }
    },

    /**
     * Warn when legacy RBAC pageName catalogue strings are still in use.
     */
    'legacy-rbac-page-name': {
      meta: {
        type: 'suggestion',
        docs: {
          description: 'Warn on legacy rbac_app_pages catalogue strings pending migration',
          category: 'Best Practices',
          recommended: true
        },
        schema: [],
        messages: {
          legacyPageName: 'Legacy pageName "{{name}}" — migrate to "{{target}}"'
        }
      },
      create(context) {
        const filename = context.getFilename();
        if (isPaceCoreSourceFile(filename) || !isSourceFile(filename)) {
          return {};
        }

        const { getLegacyMigrationTarget } = require('../../naming/naming-by-layer.cjs');

        function checkLegacy(node, pageName) {
          if (!pageName || !isLegacyPageName(pageName)) return;
          const target = getLegacyMigrationTarget(pageName) || `${pageName}Page`;
          context.report({
            node,
            messageId: 'legacyPageName',
            data: { name: pageName, target }
          });
        }

        return {
          JSXAttribute(node) {
            if (node.name.name !== 'pageName') return;
            checkLegacy(node, getStringLiteralValue(node.value));
          },
          CallExpression(node) {
            if (
              node.callee.type === 'Identifier' &&
              node.callee.name === 'useResourcePermissions' &&
              node.arguments[0]
            ) {
              checkLegacy(node.arguments[0], getStringLiteralValue(node.arguments[0]));
            }
          }
        };
      }
    },

    /**
     * React Router path values must use kebab-case static segments.
     */
    'route-path-kebab-case': {
      meta: {
        type: 'problem',
        docs: {
          description: 'Route path static segments must be lowercase kebab-case',
          category: 'Best Practices',
          recommended: true
        },
        schema: [],
        messages: {
          invalidRoute: '{{message}}'
        }
      },
      create(context) {
        const filename = context.getFilename();
        if (!isSourceFile(filename)) return {};

        function checkPath(node, pathValue) {
          if (!pathValue) return;
          const result = validateRoutePath(pathValue);
          if (!result.ok) {
            context.report({
              node,
              messageId: 'invalidRoute',
              data: { message: result.message }
            });
          }
        }

        return {
          JSXAttribute(node) {
            if (!isRouterPathJsxAttribute(node)) return;
            checkPath(node, getStringLiteralValue(node.value));
          }
        };
      }
    }
  }
};
