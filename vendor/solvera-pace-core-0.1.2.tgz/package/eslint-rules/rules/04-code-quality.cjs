/**
 * Code Quality Rules (Standard 6)
 * @package @solvera/pace-core
 * @module ESLintRules/rules/code-quality
 * 
 * Enforces code quality patterns from Standard 6:
 * - Naming conventions (hooks: use*, providers: *Provider)
 * - TypeScript best practices
 * 
 * Reference: packages/core/docs/standards/6-code-quality-standards.md
 */

const {
  getTsxFileStem,
  isComponentNamingScopeFile,
  isExportedDeclaration,
  isLegacyComponentFilename,
  isPaceCoreSourceFile,
  isPascalCaseIdentifier,
  isUtilityExportName,
  returnsJsx,
} = require('../utils/helpers.cjs');

function createComponentNamingVisitors(context) {
  function checkComponentName(node, name) {
    if (!name || isUtilityExportName(name)) return;
    if (!isPascalCaseIdentifier(name)) {
      context.report({
        node,
        messageId: 'componentNaming',
        data: { name },
        suggest: [{
          desc: `Rename to ${name.charAt(0).toUpperCase() + name.slice(1).replace(/[^a-zA-Z0-9]/g, '')}`,
          fix() {
            return null;
          },
        }],
      });
    }
  }

  function inspectFunctionComponent(node, functionName, bodyNode) {
    if (!functionName || isUtilityExportName(functionName)) return;
    if (!isExportedDeclaration(node)) return;

    const sourceCode = context.getSourceCode();
    const functionText = sourceCode.getText(bodyNode);
    if (returnsJsx(functionText)) {
      checkComponentName(node.id ?? node, functionName);
    }
  }

  return {
    FunctionDeclaration(node) {
      if (!node.id) return;
      inspectFunctionComponent(node, node.id.name, node.body);
    },

    VariableDeclarator(node) {
      if (!node.id || node.id.type !== 'Identifier' || !node.init) return;

      const varName = node.id.name;
      if (!varName || isUtilityExportName(varName)) return;
      if (!isExportedDeclaration(node)) return;

      if (node.init.type === 'ArrowFunctionExpression' || node.init.type === 'FunctionExpression') {
        const sourceCode = context.getSourceCode();
        const functionText = sourceCode.getText(node.init);
        if (returnsJsx(functionText)) {
          checkComponentName(node.id, varName);
        }
      }
    },
  };
}

function createComponentFilenameVisitors(context) {
  let hasExportedComponent = false;

  function markExportedComponent(node, functionName, bodyNode) {
    if (!functionName || isUtilityExportName(functionName)) return;
    if (!isExportedDeclaration(node)) return;

    const sourceCode = context.getSourceCode();
    const functionText = sourceCode.getText(bodyNode);
    if (returnsJsx(functionText)) {
      hasExportedComponent = true;
    }
  }

  return {
    FunctionDeclaration(node) {
      if (!node.id) return;
      markExportedComponent(node, node.id.name, node.body);
    },

    VariableDeclarator(node) {
      if (!node.id || node.id.type !== 'Identifier' || !node.init) return;
      const varName = node.id.name;
      if (!varName || isUtilityExportName(varName)) return;
      if (!isExportedDeclaration(node)) return;

      if (node.init.type === 'ArrowFunctionExpression' || node.init.type === 'FunctionExpression') {
        markExportedComponent(node, varName, node.init);
      }
    },

    'Program:exit'() {
      if (!hasExportedComponent) return;

      const filename = context.getFilename();
      const stem = getTsxFileStem(filename);
      if (isPascalCaseIdentifier(stem)) return;

      context.report({
        loc: { line: 1, column: 0 },
        messageId: 'componentFilename',
        data: { filename: stem },
      });
    },
  };
}

module.exports = {
  rules: {
    /**
     * Enforce naming conventions for hooks and providers
     */
    'naming-convention': {
      meta: {
        type: 'suggestion',
        docs: {
          description: 'Enforce naming conventions: hooks must start with "use", providers must end with "Provider"',
          category: 'Best Practices',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/6-code-quality-standards.md'
        },
        messages: {
          hookNaming: "Hook '{{name}}' must start with 'use' (e.g., useEventData, useUserProfile)",
          providerNaming: "Provider '{{name}}' must end with 'Provider' (e.g., AuthProvider, OrganisationProvider)"
        },
        hasSuggestions: true
      },
      create(context) {
        const filename = context.getFilename();
        
        // Exclude pace-core source files - these rules are for consuming apps
        if (isPaceCoreSourceFile(filename)) {
          return {};
        }
        
        return {
          FunctionDeclaration(node) {
            if (!node.id) return;
            
            const functionName = node.id.name;
            if (!functionName) return;
            
            const sourceCode = context.getSourceCode();
            const functionText = sourceCode.getText(node.body);
            
            // Check if function returns JSX (is a component)
            const returnsJSX = functionText.includes('return') && (functionText.includes('<') || functionText.includes('createElement'));
            
            // Check for hooks (functions that use React hooks but are NOT components)
            const usesReactHooks = /use(State|Effect|Callback|Memo|Ref|Context|Reducer|LayoutEffect|ImperativeHandle|DebugValue)/.test(functionText);
            
            // Only flag as hook if:
            // 1. It uses React hooks AND doesn't return JSX (not a component)
            // 2. OR it starts with 'use' but doesn't return JSX (likely a hook)
            // Components that use hooks are NOT hooks themselves
            if (usesReactHooks && !returnsJSX) {
              if (!functionName.startsWith('use')) {
                context.report({
                  node: node.id,
                  messageId: 'hookNaming',
                  data: { name: functionName },
                  suggest: [{
                    desc: `Rename to use${functionName.charAt(0).toUpperCase() + functionName.slice(1)}`,
                    fix(fixer) {
                      return null; // Complex rename
                    }
                  }]
                });
              }
            }
            
            // Check for providers (components that CREATE a Context.Provider, not just use/wrap one)
            // A provider component must:
            // 1. Use createContext (creates a context)
            // 2. Return <ContextName.Provider> (provides the context)
            // We don't flag components that just wrap other providers (like AppProviders wrapping QueryClientProvider)
            const createsContext = /createContext\s*\(/.test(functionText);
            const returnsContextProvider = /<[A-Z][a-zA-Z0-9]*\.Provider/.test(functionText) ||
                                         /\.Provider\s*>/.test(functionText);
            
            // Only flag if it actually creates a context AND returns a Context.Provider
            // AND doesn't already end with 'Provider'
            if (returnsJSX && createsContext && returnsContextProvider && !functionName.endsWith('Provider')) {
              context.report({
                node: node.id,
                messageId: 'providerNaming',
                data: { name: functionName },
                suggest: [{
                  desc: `Rename to ${functionName}Provider`,
                  fix(fixer) {
                    return null; // Complex rename
                  }
                }]
              });
            }
          },
          
          VariableDeclarator(node) {
            if (!node.id || node.id.type !== 'Identifier') return;
            if (!node.init) return;
            
            const varName = node.id.name;
            if (!varName) return;
            
            // Check for hook variables (arrow functions that use React hooks)
            if (node.init.type === 'ArrowFunctionExpression' || node.init.type === 'FunctionExpression') {
              const sourceCode = context.getSourceCode();
              const functionText = sourceCode.getText(node.init);
              
              // Check if it returns JSX (is a component)
              const returnsJSX = functionText.includes('return') && (functionText.includes('<') || functionText.includes('createElement'));
              const usesReactHooks = /use(State|Effect|Callback|Memo|Ref|Context|Reducer|LayoutEffect|ImperativeHandle|DebugValue)/.test(functionText);
              
              // Only flag as hook if it uses React hooks but doesn't return JSX (not a component)
              // Components that use hooks are NOT hooks themselves
              if (usesReactHooks && !returnsJSX && !varName.startsWith('use')) {
                context.report({
                  node: node.id,
                  messageId: 'hookNaming',
                  data: { name: varName },
                  suggest: [{
                    desc: `Rename to use${varName.charAt(0).toUpperCase() + varName.slice(1)}`,
                    fix(fixer) {
                      return null; // Complex rename
                    }
                  }]
                });
              }
            }
          }
        };
      }
    },

    /**
     * Enforce component naming: PascalCase
     */
    'component-naming': {
      meta: {
        type: 'suggestion',
        docs: {
          description: 'Enforce component naming: components must use PascalCase',
          category: 'Best Practices',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/6-code-quality-standards.md'
        },
        messages: {
          componentNaming: "Component '{{name}}' must use PascalCase (e.g., EventCard, UserProfile)"
        },
        hasSuggestions: true
      },
      create(context) {
        const filename = context.getFilename();

        if (!isComponentNamingScopeFile(filename)) {
          return {};
        }

        return createComponentNamingVisitors(context);
      }
    },

    /**
     * Enforce PascalCase .tsx filename stems for modules that export React components.
     */
    'component-filename': {
      meta: {
        type: 'problem',
        docs: {
          description: 'Enforce PascalCase .tsx filename stems for modules that export React components',
          category: 'Best Practices',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/1-project-structure-standards.md#react-component-module-filenames'
        },
        messages: {
          componentFilename: "Component module '{{filename}}.tsx' must use a PascalCase filename (e.g., EventCard.tsx)"
        }
      },
      create(context) {
        const filename = context.getFilename();

        if (!isComponentNamingScopeFile(filename)) {
          return {};
        }
        if (isLegacyComponentFilename(filename)) {
          return {};
        }

        return createComponentFilenameVisitors(context);
      }
    },

    /**
     * Enforce type/interface naming: PascalCase
     */
    'type-naming': {
      meta: {
        type: 'suggestion',
        docs: {
          description: 'Enforce type/interface naming: types and interfaces must use PascalCase',
          category: 'Best Practices',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/6-code-quality-standards.md'
        },
        messages: {
          typeNaming: "Type/interface '{{name}}' must use PascalCase (e.g., EventStatus, UserProfile)"
        },
        hasSuggestions: true
      },
      create(context) {
        const filename = context.getFilename();
        
        // Exclude pace-core source files - these rules are for consuming apps
        if (isPaceCoreSourceFile(filename)) {
          return {};
        }
        
        return {
          TSInterfaceDeclaration(node) {
            const interfaceName = node.id.name;
            if (!interfaceName) return;
            
            const isPascalCase = /^[A-Z][a-zA-Z0-9]*$/.test(interfaceName);
            if (!isPascalCase) {
              context.report({
                node: node.id,
                messageId: 'typeNaming',
                data: { name: interfaceName },
                suggest: [{
                  desc: `Rename to ${interfaceName.charAt(0).toUpperCase() + interfaceName.slice(1).replace(/[^a-zA-Z0-9]/g, '')}`,
                  fix(fixer) {
                    return null; // Complex rename
                  }
                }]
              });
            }
          },
          
          TSTypeAliasDeclaration(node) {
            const typeName = node.id.name;
            if (!typeName) return;
            
            const isPascalCase = /^[A-Z][a-zA-Z0-9]*$/.test(typeName);
            if (!isPascalCase) {
              context.report({
                node: node.id,
                messageId: 'typeNaming',
                data: { name: typeName },
                suggest: [{
                  desc: `Rename to ${typeName.charAt(0).toUpperCase() + typeName.slice(1).replace(/[^a-zA-Z0-9]/g, '')}`,
                  fix(fixer) {
                    return null; // Complex rename
                  }
                }]
              });
            }
          }
        };
      }
    }
  }
};
