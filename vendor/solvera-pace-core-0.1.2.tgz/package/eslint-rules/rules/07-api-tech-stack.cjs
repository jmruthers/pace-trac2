/**
 * API & Tech Stack Rules (Standard 4)
 * @package @solvera/pace-core
 * @module ESLintRules/rules/api-tech-stack
 * 
 * Enforces API and tech stack patterns from Standard 4:
 * - RPC naming conventions (data_*, app_*)
 * - React 19+ patterns (no class components)
 * - import.meta.env usage (Vite) instead of process.env
 * 
 * Reference: packages/core/docs/standards/4-api-tech-stack-standards.md
 */

const { isPaceCoreSourceFile } = require('../utils/helpers.cjs');

module.exports = {
  rules: {
    /**
     * Enforce RPC naming pattern: data_* for reads, app_* for writes
     */
    'rpc-naming-pattern': {
      meta: {
        type: 'problem',
        docs: {
          description: 'Enforce RPC naming pattern: data_* for read operations, app_* for write operations',
          category: 'Best Practices',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/4-api-tech-stack-standards.md'
        },
        messages: {
          invalidRpcNaming: "RPC '{{rpcName}}' does not follow naming pattern. Read operations must start with 'data_', write operations must start with 'app_' (e.g., data_events_list, app_event_create)",
          invalidRpcVerb: "RPC '{{rpcName}}' uses invalid verb '{{verb}}'. Use only: list, get, create, update, delete, read, check, upsert, ensure, grant, insert, remove, revoke, resolve, bulk_create, bulk_update, bulk_import",
          missingPrefix: "RPC '{{rpcName}}' must start with 'data_' (for read operations) or 'app_' (for write operations). Current name: '{{rpcName}}'. Suggested: '{{suggestedName}}'"
        },
        hasSuggestions: true
      },
      create(context) {
        const filename = context.getFilename();
        
        // Exclude pace-core source files - these rules are for consuming apps
        if (isPaceCoreSourceFile(filename)) {
          return {};
        }
        
        const validVerbs = ['list', 'get', 'create', 'update', 'delete', 'read', 'check', 'upsert', 'ensure', 'grant', 'insert', 'remove', 'revoke', 'resolve', 'set', 'reissue'];
        const readVerbs = ['list', 'get', 'read', 'check', 'resolve'];
        const writeVerbs = ['create', 'update', 'delete', 'upsert', 'bulk_create', 'bulk_update', 'bulk_import', 'ensure', 'grant', 'insert', 'remove', 'revoke', 'set', 'reissue'];
        // Common qualifier patterns that can appear after the verb (e.g., _by_code, _by_id, _by_slug)
        const qualifierPatterns = ['by_code', 'by_id', 'by_slug', 'by_name', 'by_email', 'by_uuid'];
        
        /**
         * Extract the verb from an RPC name, handling qualifiers like _by_code
         * @param {string} rpcName - The RPC name (e.g., 'data_event_get_by_code')
         * @returns {string|null} - The verb (e.g., 'get') or null if not found
         */
        function extractVerb(rpcName) {
          const parts = rpcName.split('_');
          
          // Remove prefix (data_ or app_)
          if (parts[0] === 'data' || parts[0] === 'app') {
            parts.shift();
          }
          
          // Look for valid verbs from the end, skipping qualifiers
          for (let i = parts.length - 1; i >= 0; i--) {
            // Check for bulk operations first (bulk_create, bulk_update, bulk_import)
            // These span 2 parts, so check if parts[i-1]_parts[i] forms a bulk verb
            if (i > 0) {
              const bulkCandidate = `${parts[i - 1]}_${parts[i]}`;
              if (writeVerbs.includes(bulkCandidate)) {
                return bulkCandidate;
              }
            }
            
            // Check for regular single-part verbs
            const candidate = parts[i];
            if (validVerbs.includes(candidate)) {
              return candidate;
            }
            
            // Check if we're in a qualifier pattern
            // Qualifiers like 'by_code' span multiple parts (e.g., 'by' + 'code')
            // Check if the suffix from this position (or including previous part) matches any qualifier
            const suffix = parts.slice(i).join('_');
            const suffixWithPrev = i > 0 ? parts.slice(i - 1).join('_') : suffix;
            
            if (qualifierPatterns.some(qp => 
              suffix === qp || 
              suffix.startsWith(qp + '_') ||
              suffixWithPrev === qp ||
              suffixWithPrev.startsWith(qp + '_')
            )) {
              // We're in a qualifier, continue searching backwards
              continue;
            }
          }
          
          return null;
        }
        
        // Updated pattern to allow verbs anywhere in the name (not just at the end)
        // Pattern: (data_|app_) + domain/verb parts + optional qualifiers
        // This allows patterns like: app_insert_event_app_access, app_ensure_page_permissions
        const rpcPattern = /^(data_|app_)[a-z0-9_]+$/;
        
        return {
          CallExpression(node) {
            // Check for supabase.rpc('rpc_name', ...)
            if (node.callee.type === 'MemberExpression' &&
                node.callee.property &&
                node.callee.property.name === 'rpc' &&
                node.arguments.length > 0) {
              
              const firstArg = node.arguments[0];
              if (firstArg.type === 'Literal' && typeof firstArg.value === 'string') {
                const rpcName = firstArg.value;
                
                // Skip if it's a variable (can't validate at lint time)
                if (firstArg.type !== 'Literal') {
                  return;
                }
                // Platform contract namespaces (base_*, rbac_*, pump_*); not app data_/app_ RPCs
                if (
                  rpcName.startsWith('base_') ||
                  rpcName.startsWith('rbac_') ||
                  rpcName.startsWith('pump_')
                ) {
                  return;
                }
                // Session-context RPC (platform setup, not app data surface)
                if (rpcName === 'set_organisation_context') {
                  return;
                }
                
                // Check if RPC starts with required prefix
                const hasDataPrefix = rpcName.startsWith('data_');
                const hasAppPrefix = rpcName.startsWith('app_');
                
                if (!hasDataPrefix && !hasAppPrefix) {
                  // RPC doesn't start with data_ or app_ prefix
                  // Try to determine the verb from the RPC name to suggest correct prefix
                  const parts = rpcName.split('_');
                  let verb = null;
                  let suggestedPrefix = 'data_'; // Default to data_ for read operations
                  
                  // Look for verbs in the RPC name (check from the end)
                  for (let i = parts.length - 1; i >= 0; i--) {
                    const candidate = parts[i];
                    const candidateWithBulk = i > 0 ? `${parts[i - 1]}_${candidate}` : null;
                    
                    // Check for bulk operations first
                    if (candidateWithBulk && writeVerbs.includes(candidateWithBulk)) {
                      verb = candidateWithBulk;
                      suggestedPrefix = 'app_';
                      break;
                    }
                    
                    // Check for regular verbs
                    if (validVerbs.includes(candidate)) {
                      verb = candidate;
                      if (readVerbs.includes(candidate)) {
                        suggestedPrefix = 'data_';
                      } else if (writeVerbs.includes(candidate)) {
                        suggestedPrefix = 'app_';
                      }
                      break;
                    }
                  }
                  
                  // Construct suggested name
                  // If we found a verb, suggest adding the prefix
                  // Otherwise, suggest data_ prefix (most common for read operations)
                  let suggestedName;
                  if (verb) {
                    // RPC already has a verb, just add the prefix
                    suggestedName = `${suggestedPrefix}${rpcName}`;
                  } else {
                    // Can't determine verb, suggest data_ as default
                    // User should review and adjust if it's a write operation
                    suggestedName = `data_${rpcName}`;
                  }
                  
                  context.report({
                    node: firstArg,
                    messageId: 'missingPrefix',
                    data: { 
                      rpcName,
                      suggestedName
                    },
                    suggest: [{
                      desc: `Rename to '${suggestedName}' (or 'app_${rpcName}' if it's a write operation)`,
                      fix(fixer) {
                        return null; // Complex fix - requires database migration
                      }
                    }]
                  });
                  return; // Don't check further if missing prefix
                }
                
                // Basic pattern check - just verify it starts with data_ or app_ and has valid characters
                if (!rpcPattern.test(rpcName)) {
                  context.report({
                    node: firstArg,
                    messageId: 'invalidRpcNaming',
                    data: { rpcName },
                    suggest: [{
                      desc: `RPC name must follow pattern: data_<domain>_<verb> or app_<domain>_<verb>`,
                      fix(fixer) {
                        return null; // Complex fix
                      }
                    }]
                  });
                  return;
                }
                
                // Extract verb and validate prefix matches operation type
                const verb = extractVerb(rpcName);
                
                if (!verb) {
                  // Couldn't extract verb - this is okay for some RPCs that don't follow standard verb patterns
                  // But we still require the prefix, which we've already validated
                  return;
                }
                
                // resolve: data_* (e.g. data_app_resolve) = read; app_* (e.g. app_resolve_member_request) = write
                if (verb === 'resolve') {
                  return;
                }

                const isReadOperation = readVerbs.includes(verb);
                const isWriteOperation = writeVerbs.includes(verb) || verb.startsWith('bulk_');
                
                // Check if prefix matches verb type
                const hasDataPrefixForVerb = rpcName.startsWith('data_');
                const hasAppPrefixForVerb = rpcName.startsWith('app_');
                
                if (hasDataPrefixForVerb && isWriteOperation) {
                  context.report({
                    node: firstArg,
                    messageId: 'invalidRpcNaming',
                    data: { rpcName },
                    suggest: [{
                      desc: `Use 'app_' prefix for write operations (${verb})`,
                      fix(fixer) {
                        return null; // Complex fix
                      }
                    }]
                  });
                } else if (hasAppPrefixForVerb && isReadOperation) {
                  context.report({
                    node: firstArg,
                    messageId: 'invalidRpcNaming',
                    data: { rpcName },
                    suggest: [{
                      desc: `Use 'data_' prefix for read operations (${verb})`,
                      fix(fixer) {
                        return null; // Complex fix
                      }
                    }]
                  });
                } else if (!isReadOperation && !isWriteOperation) {
                  // Verb not recognized - this might be a valid verb we haven't added yet
                  // Only report if it's clearly invalid
                  if (!validVerbs.includes(verb)) {
                    context.report({
                      node: firstArg,
                      messageId: 'invalidRpcVerb',
                      data: { rpcName, verb },
                      suggest: [{
                        desc: `Use valid verb: ${validVerbs.join(', ')}`,
                        fix(fixer) {
                          return null; // Complex fix
                        }
                      }]
                    });
                  }
                }
              }
            }
          }
        };
      }
    },

    /**
     * Enforce React 19+ patterns: no class components
     */
    'no-class-components': {
      meta: {
        type: 'problem',
        docs: {
          description: 'Disallow React class components. Use functional components with hooks (React 19+).',
          category: 'Best Practices',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/4-api-tech-stack-standards.md'
        },
        messages: {
          classComponent: "Class components are not allowed. Use functional components with hooks instead (React 19+)."
        },
        hasSuggestions: true
      },
      create(context) {
        const filename = context.getFilename();
        
        // Exclude pace-core source files - these rules are for consuming apps
        if (isPaceCoreSourceFile(filename)) {
          return {};
        }
        
        return {
          ClassDeclaration(node) {
            // Check if class extends React.Component or Component
            const hasReactExtends = node.superClass && (
              (node.superClass.type === 'MemberExpression' && 
               node.superClass.object?.name === 'React' && 
               node.superClass.property?.name === 'Component') ||
              (node.superClass.type === 'Identifier' && 
               node.superClass.name === 'Component')
            );
            
            if (hasReactExtends) {
              context.report({
                node,
                messageId: 'classComponent',
                suggest: [{
                  desc: 'Convert to functional component with hooks',
                  fix(fixer) {
                    return null; // Complex conversion
                  }
                }]
              });
            }
          }
        };
      }
    },

    /**
     * Enforce import.meta.env usage instead of process.env in client code
     */
    'prefer-import-meta-env': {
      meta: {
        type: 'problem',
        docs: {
          description: 'Enforce import.meta.env (Vite) instead of process.env in client code',
          category: 'Best Practices',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/4-api-tech-stack-standards.md'
        },
        messages: {
          processEnvUsage: "Use 'import.meta.env' (Vite) instead of 'process.env' in client code. process.env is Node.js and won't work in browser."
        },
        hasSuggestions: true
      },
      create(context) {
        const filename = context.getFilename();
        
        // Exclude pace-core source files - these rules are for consuming apps
        if (isPaceCoreSourceFile(filename)) {
          return {};
        }
        
        // Only check client code (not server/Node.js files)
        // Exclude: scripts/, server/, node/, config files, and .config. files
        const isNodeScript = filename.includes('/scripts/') || 
                            filename.includes('\\scripts\\') ||
                            filename.includes('/server/') || 
                            filename.includes('\\server\\') ||
                            filename.includes('/node/') ||
                            filename.includes('\\node\\') ||
                            filename.includes('config') ||
                            filename.match(/\.(config|server)\./);
        
        if (isNodeScript) {
          return {};
        }
        
        return {
          MemberExpression(node) {
            // Check for process.env usage
            if (node.object?.type === 'Identifier' && 
                node.object.name === 'process' &&
                node.property?.type === 'Identifier' &&
                node.property.name === 'env') {
              context.report({
                node,
                messageId: 'processEnvUsage',
                suggest: [{
                  desc: 'Replace with import.meta.env',
                  fix(fixer) {
                    // Replace process.env with import.meta.env
                    return fixer.replaceText(node, 'import.meta.env');
                  }
                }]
              });
            }
          }
        };
      }
    }
  }
};
