/**
 * Architecture Rules (Standard 2)
 * @package @solvera/pace-core
 * @module ESLintRules/rules/architecture
 *
 * Enforces SRP heuristics from Standard 2 (Architecture):
 * - Max named exports per file (encourage single responsibility)
 *
 * Reference: packages/core/docs/standards/2-architecture-standards.md
 */

const { isPaceCoreSourceFile } = require('../utils/helpers.cjs');

function normalizePath(filename) {
  return filename.replace(/\\/g, '/');
}

function isPageFile(filename) {
  const normalized = normalizePath(filename);
  return /\/pages\/.+\.(tsx?|jsx?)$/.test(normalized) || /Page\.(tsx?|jsx?)$/.test(normalized);
}

function isUiPrimitiveFile(filename) {
  const normalized = normalizePath(filename);
  const base = normalized.split('/').pop() || '';
  if (!/\/components\//.test(normalized)) return false;
  return /^(Button|Input|Card|Dialog|Select|Tabs|Table|Textarea|Checkbox|Switch|Label)\.(tsx?|jsx?)$/.test(base);
}

module.exports = {
  rules: {
    /**
     * Limit the number of named exports per file (SRP heuristic).
     */
    'max-named-exports': {
      meta: {
        type: 'suggestion',
        docs: {
          description: 'Limit named exports per file; consider splitting for single responsibility',
          category: 'Best Practices',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/2-architecture-standards.md'
        },
        schema: [
          {
            type: 'object',
            properties: {
              max: { type: 'integer', minimum: 1 }
            },
            additionalProperties: false
          }
        ],
        messages: {
          tooMany: 'File has {{count}} named exports (max {{max}}). Consider splitting; single responsibility.'
        }
      },
      create(context) {
        const filename = context.getFilename();
        if (isPaceCoreSourceFile(filename)) {
          return {};
        }
        const options = context.options[0] || {};
        const max = options.max ?? 10;

        let count = 0;
        return {
          Program(node) {
            count = 0;
            for (const n of node.body) {
              if (n.type === 'ExportNamedDeclaration') {
                if (n.declaration) {
                  count += 1;
                } else if (n.specifiers && n.specifiers.length > 0) {
                  count += n.specifiers.length;
                }
              }
            }
            if (count > max) {
              context.report({
                node,
                messageId: 'tooMany',
                data: { count, max }
              });
            }
          }
        };
      }
    },
    /**
     * Discourage rendering <main> inside page components.
     * The shell owns the primary <main> landmark in shell routes.
     */
    'no-main-in-pages': {
      meta: {
        type: 'suggestion',
        docs: {
          description: 'Page components should avoid rendering <main>; shell routes own the primary main landmark',
          category: 'Best Practices',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/2-architecture-standards.md'
        },
        schema: [],
        messages: {
          noMainInPages: 'Page component renders <main>. Keep the primary <main> in the app shell and use section/article for page content.'
        }
      },
      create(context) {
        const filename = context.getFilename();
        if (isPaceCoreSourceFile(filename) || !isPageFile(filename)) {
          return {};
        }
        return {
          JSXOpeningElement(node) {
            if (node.name && node.name.type === 'JSXIdentifier' && node.name.name === 'main') {
              context.report({
                node,
                messageId: 'noMainInPages'
              });
            }
          }
        };
      }
    },
    /**
     * UI primitives should not perform direct data fetching.
     */
    'no-data-fetch-in-ui-primitives': {
      meta: {
        type: 'problem',
        docs: {
          description: 'UI primitive components should not perform data fetching directly',
          category: 'Best Practices',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/2-architecture-standards.md'
        },
        schema: [],
        messages: {
          noFetch: 'UI primitive component should not fetch data directly. Move data access into hooks/services.'
        }
      },
      create(context) {
        const filename = context.getFilename();
        if (isPaceCoreSourceFile(filename) || !isUiPrimitiveFile(filename)) {
          return {};
        }
        return {
          CallExpression(node) {
            if (node.callee.type === 'Identifier' && node.callee.name === 'fetch') {
              context.report({ node, messageId: 'noFetch' });
              return;
            }
            if (node.callee.type === 'MemberExpression' && !node.callee.computed) {
              const prop = node.callee.property;
              if (prop.type === 'Identifier' && (prop.name === 'from' || prop.name === 'rpc')) {
                context.report({ node, messageId: 'noFetch' });
              }
            }
          }
        };
      }
    }
  }
};
