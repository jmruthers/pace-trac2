/**
 * Operations Rules (Standard 9)
 * @package @solvera/pace-core
 * @module ESLintRules/rules/operations
 *
 * Enforces practical error-handling and logging discipline.
 *
 * Reference: packages/core/docs/standards/9-operations-standards.md
 */

const { isPaceCoreSourceFile } = require('../utils/helpers.cjs');

module.exports = {
  rules: {
    /**
     * Disallow empty/silent catch blocks.
     */
    'no-silent-catch': {
      meta: {
        type: 'problem',
        docs: {
          description: 'Catch blocks must handle, log safely, or rethrow errors',
          category: 'Best Practices',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/9-operations-standards.md'
        },
        schema: [],
        messages: {
          silentCatch: 'Silent catch block detected. Handle the error explicitly, return an error result, or rethrow.'
        }
      },
      create(context) {
        const filename = context.getFilename();
        if (isPaceCoreSourceFile(filename)) return {};

        return {
          CatchClause(node) {
            if (!node.body || !Array.isArray(node.body.body)) return;
            if (node.body.body.length === 0) {
              context.report({ node, messageId: 'silentCatch' });
            }
          }
        };
      }
    },

    /**
     * Prevent logging known sensitive keys.
     */
    'no-sensitive-log-fields': {
      meta: {
        type: 'problem',
        docs: {
          description: 'Do not log sensitive fields like password/token/secret',
          category: 'Security',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/9-operations-standards.md'
        },
        schema: [],
        messages: {
          sensitiveLogField: 'Sensitive field "{{name}}" should not be logged.'
        }
      },
      create(context) {
        const filename = context.getFilename();
        if (isPaceCoreSourceFile(filename)) return {};

        const sensitive = new Set(['password', 'token', 'secret', 'apikey', 'api_key', 'ssn']);

        return {
          CallExpression(node) {
            if (node.arguments.length === 0) return;
            const callee = node.callee;
            if (callee.type !== 'MemberExpression' || callee.computed) return;
            if (callee.property.type !== 'Identifier') return;
            const method = callee.property.name;
            if (!['log', 'info', 'warn', 'error', 'debug'].includes(method)) return;

            node.arguments.forEach((arg) => {
              if (arg.type !== 'ObjectExpression') return;
              arg.properties.forEach((prop) => {
                if (prop.type !== 'Property') return;
                if (prop.key.type === 'Identifier') {
                  const key = prop.key.name.toLowerCase();
                  if (sensitive.has(key)) {
                    context.report({
                      node: prop.key,
                      messageId: 'sensitiveLogField',
                      data: { name: prop.key.name }
                    });
                  }
                }
              });
            });
          }
        };
      }
    }
  }
};
