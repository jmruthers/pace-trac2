import { describe, expect, it } from 'vitest';
import { Linter } from 'eslint';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const complianceRules = require('./01-pace-core-compliance.cjs');

const RULE_ID = 'pace-core-compliance/require-pace-app-layout-user-menu-props';

function runRule(code: string) {
  const linter = new Linter({ configType: 'eslintrc' });
  linter.defineRule(RULE_ID, complianceRules.rules['require-pace-app-layout-user-menu-props']);

  return linter.verify(
    code,
    {
      parserOptions: {
        ecmaVersion: 2022,
        sourceType: 'module',
        ecmaFeatures: { jsx: true },
      },
      rules: {
        [RULE_ID]: 'error',
      },
    },
    'src/App.tsx'
  );
}

describe('require-pace-app-layout-user-menu-props', () => {
  it('reports when authenticated user-menu props are missing', () => {
    const messages = runRule(`
      function App() {
        return (
          <PaceAppLayout appName="App" navItems={[]}>
            <p>Content</p>
          </PaceAppLayout>
        );
      }
    `);

    expect(messages).toHaveLength(1);
    expect(messages[0]?.ruleId).toBe(RULE_ID);
    expect(messages[0]?.message).toContain('userFullName');
    expect(messages[0]?.message).toContain('onUserMenuSignOut');
  });

  it('does not report when all required props are present', () => {
    const messages = runRule(`
      function App() {
        return (
          <PaceAppLayout
            appName="App"
            navItems={[]}
            userFullName={userDisplayName}
            userEmail={userEmail}
            onUserMenuSignOut={handleSignOut}
            onUserMenuChangePassword={handleChangePassword}
          >
            <p>Content</p>
          </PaceAppLayout>
        );
      }
    `);

    expect(messages).toHaveLength(0);
  });

  it('does not report when props are spread', () => {
    const messages = runRule(`
      function App() {
        return (
          <PaceAppLayout appName="App" navItems={[]} {...layoutProps}>
            <p>Content</p>
          </PaceAppLayout>
        );
      }
    `);

    expect(messages).toHaveLength(0);
  });
});
