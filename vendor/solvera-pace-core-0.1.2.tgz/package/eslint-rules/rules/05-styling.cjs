/**
 * Styling Rules (Standard 7) — source of truth for mechanical checks
 * @package @solvera/pace-core
 * @module ESLintRules/rules/styling
 *
 * Plugin prefix: pace-core-compliance/
 *
 * | Rule ID | Summary |
 * |---------|---------|
 * | no-inline-styles | Disallow `style={{...}}`; use pace-core or Tailwind. |
 * | no-typography-styling | Disallow typography, colour, and text-spacing utilities on typography elements (per Standard 7). |
 * | no-pace-core-style-override | Disallow className/style overrides on pace-core components from consuming apps. |
 * | prefer-semantic-html | Suggest semantic elements instead of div/span where className hints at structure. |
 * | no-nested-same-type-tags | Disallow redundant same-type semantic nesting (e.g. section in section). |
 * | no-flex-layout-classes | Disallow Tailwind flex display utilities in className (Part B: grid / flow only). |
 * | no-legacy-tailwind-color-classes | Disallow legacy Tailwind palette names; use main/sec/acc or semantic tokens. |
 * | persistence-save-label | Enforce primary persistence action text to be exactly "Save". |
 * | persistence-save-placement | Enforce Save actions in canonical footer-right containers. |
 * | no-redundant-card-subcomponent-wrapper | Disallow single wrapper elements inside CardHeader/CardContent/CardFooter for layout-only classes. |
 * | formfield-label-must-wrap-control | Enforce nested Label/control structure in FormField implementation. |
 * | login-form-hide-required-marker | Enforce showRequiredMarker={false} for required fields in LoginForm. |
 * | no-directory-card-list-grid | Disallow ul/ol with column grid classes for directory card grids (use section). |
 *
 * Scope: Structural styling rules target consuming app source and selected pace-core shell files.
 *        The pace-core style-override rule remains scoped to consuming apps.
 * Human-readable intent: packages/core/docs/standards/7-visual-standards.md (repository root). Do not duplicate rule definitions in the standard doc.
 */

const { isPaceCoreSourceFile } = require('../utils/helpers.cjs');

// Typography elements that should not have typography classes
const TYPOGRAPHY_ELEMENTS = new Set([
  'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
  'p', 'a', 'strong', 'em', 'u', 'pre', 'code',
  'blockquote', 'hr', 'small', 'ul', 'ol', 'li',
  'label', 'body'
]);

// Typography utility classes that are prohibited
const TYPOGRAPHY_CLASSES = [
  /^text-(xs|sm|base|lg|xl|2xl|3xl|4xl|5xl|6xl|7xl|8xl|9xl)$/,
  /^font-(thin|extralight|light|normal|medium|semibold|bold|extrabold|black)$/,
  /^leading-(none|tight|snug|normal|relaxed|loose|\d+)$/,
  /^tracking-(tighter|tight|normal|wide|wider|widest)$/,
  /^(uppercase|lowercase|capitalize|normal-case)$/
];

// Color classes that should not be on typography elements
const COLOR_CLASSES = [
  /^text-(main|sec|acc|gray|slate|zinc|neutral|stone|red|orange|amber|yellow|lime|green|emerald|teal|cyan|sky|blue|indigo|violet|purple|fuchsia|pink|rose|primary|secondary|accent)-\d+$/,
  /^text-(main|sec|acc|gray|slate|zinc|neutral|stone|red|orange|amber|yellow|lime|green|emerald|teal|cyan|sky|blue|indigo|violet|purple|fuchsia|pink|rose|primary|secondary|accent)$/
];

// Margin/padding classes that are typically used for text spacing
const SPACING_CLASSES = [
  /^(m|mx|my|mt|mr|mb|ml|p|px|py|pt|pr|pb|pl)-\d+$/
];

// pace-core component names (common ones)
const PACE_CORE_COMPONENTS = new Set([
  'Button', 'Card', 'Input', 'Select', 'Textarea', 'Checkbox',
  'Switch', 'Label', 'Alert', 'Dialog', 'Tabs', 'Toast',
  'Tooltip', 'Table', 'DataTable', 'Form', 'Field'
]);

// Elements that should not be nested as same-type parent/child
const PROHIBITED_NESTED_ELEMENTS = new Set([
  'section', 'div', 'span', 'p', 'main', 'article',
  'header', 'footer', 'nav', 'aside'
]);

// Elements that can legitimately nest (excluded from rule)
const ALLOWED_NESTED_ELEMENTS = new Set([
  'ul', 'ol', 'li', 'dl', 'dt', 'dd',
  'table', 'thead', 'tbody', 'tfoot', 'tr', 'td', 'th', 'form'
]);

const CARD_SUBCOMPONENTS = new Set(['CardHeader', 'CardContent', 'CardFooter']);
const SAVE_ACTION_CONTAINER_COMPONENTS = new Set(['CardFooter', 'DialogFooter']);
const SAVE_ACTION_CONTAINER_HTML_TAGS = new Set(['footer', 'fieldset']);
const LAYOUT_WRAPPER_TAGS = new Set(['section', 'div', 'main', 'article', 'header', 'footer']);
const LAYOUT_ONLY_CLASS_PATTERNS = [
  /^grid$/,
  /^grid-cols-.+$/,
  /^grid-rows-.+$/,
  /^grid-flow-.+$/,
  /^auto-(cols|rows)-.+$/,
  /^col-(auto|span-\d+|span-full|\d+)$/,
  /^row-(auto|span-\d+|span-full|\d+)$/,
  /^gap(-[xy])?-\d+$/,
  /^gap(-[xy])?-px$/,
  /^space-[xy]-\d+$/,
  /^space-[xy]-px$/,
  /^justify-[a-z-]+$/,
  /^justify-self-[a-z-]+$/,
  /^items-[a-z-]+$/,
  /^content-[a-z-]+$/,
  /^self-[a-z-]+$/,
  /^place-(items|content|self)-[a-z-]+$/,
];
const INSTANCE_LAYOUT_CLASS_PATTERNS = [
  ...LAYOUT_ONLY_CLASS_PATTERNS,
  /^(m|mx|my|mt|mr|mb|ml)-\d+$/,
  /^(m|mx|my|mt|mr|mb|ml)-px$/,
  /^(p|px|py|pt|pr|pb|pl)-\d+$/,
  /^(p|px|py|pt|pr|pb|pl)-px$/,
  /^w-(auto|full|fit|min|max|\d+\/\d+|\d+)$/,
  /^h-(auto|full|fit|min|max|\d+)$/,
  /^min-(w|h)-.+$/,
  /^max-(w|h)-.+$/,
  /^order-\d+$/,
  /^z-\d+$/,
];

const NON_PERSISTENCE_PRIMARY_LABELS = new Set([
  'Sign in',
  'Signing in…',
  'Log in',
  'Login',
  'Book',
  'Book with override',
  'Promote with override',
]);

/** Tailwind default colour names — use main/sec/acc only (7-visual-standards.md Part B/C) */
const LEGACY_TAILWIND_COLOR =
  'red|orange|amber|yellow|lime|green|emerald|teal|cyan|sky|blue|indigo|violet|purple|fuchsia|pink|rose|slate|gray|zinc|neutral|stone';

const LEGACY_COLOR_CLASS_REGEXES = [
  new RegExp(`^(bg|text|fill|stroke|from|via|to)-(${LEGACY_TAILWIND_COLOR})(-[0-9]+)?$`),
  new RegExp(`^border-(${LEGACY_TAILWIND_COLOR})(-[0-9]+)?$`),
  new RegExp(`^(ring|shadow|decoration|outline)-(${LEGACY_TAILWIND_COLOR})(-[0-9]+)?$`),
  new RegExp(`^ring-offset-(${LEGACY_TAILWIND_COLOR})(-[0-9]+)?$`),
  new RegExp(`^divide-(${LEGACY_TAILWIND_COLOR})(-[0-9]+)?$`),
];

/** pace-core component files where styling rules are enforced in package source */
const PACE_CORE_STYLING_TARGETS = [
  /packages[\\/]+core[\\/]+src[\\/]+components[\\/]+Header\.tsx$/,
  /packages[\\/]+core[\\/]+src[\\/]+components[\\/]+PaceAppLayout\.tsx$/,
  /packages[\\/]+core[\\/]+src[\\/]+components[\\/]+NavigationMenu\.tsx$/,
  /packages[\\/]+core[\\/]+src[\\/]+components[\\/]+UserMenu\.tsx$/,
  /packages[\\/]+core[\\/]+src[\\/]+components[\\/]+AppSwitcher\.tsx$/,
  /packages[\\/]+core[\\/]+src[\\/]+components[\\/]+Select\.tsx$/,
  /packages[\\/]+core[\\/]+src[\\/]+components[\\/]+ContextSelector\.tsx$/,
  /packages[\\/]+core[\\/]+src[\\/]+components[\\/]+LoginForm\.tsx$/,
  /packages[\\/]+core[\\/]+src[\\/]+components[\\/]+PaceLoginPage\.tsx$/,
  /packages[\\/]+core[\\/]+src[\\/]+components[\\/]+Form\.tsx$/,
  /packages[\\/]+core[\\/]+src[\\/]+components[\\/]+Toast\.tsx$/,
  /packages[\\/]+core[\\/]+src[\\/]+components[\\/]+Calendar\.tsx$/,
  /packages[\\/]+core[\\/]+src[\\/]+components[\\/]+Card\.tsx$/,
  /packages[\\/]+core[\\/]+src[\\/]+components[\\/]+PasswordChangeForm\.tsx$/,
  /packages[\\/]+core[\\/]+src[\\/]+components[\\/]+Dialog\.tsx$/,
];

function shouldApplyStylingRules(filename) {
  if (!isPaceCoreSourceFile(filename)) return true;
  return PACE_CORE_STYLING_TARGETS.some((re) => re.test(filename));
}

/**
 * @param {string} className
 * @returns {string | null} first offending token
 */
function findFlexLayoutClassToken(className) {
  if (!className || typeof className !== 'string') return null;
  for (const cls of className.split(/\s+/).filter(Boolean)) {
    if (cls === 'flex' || cls === 'inline-flex') return cls;
    if (cls.startsWith('flex-')) return cls;
  }
  return null;
}

const DIRECTORY_COLUMN_GRID_CLASS_REGEX =
  /^(?:sm:|md:|lg:|xl:|2xl:)?grid-cols-/;

/**
 * @param {string} className
 * @returns {string | null} first offending column-grid token on ul/ol
 */
function findDirectoryListColumnGridToken(className) {
  if (!className || typeof className !== 'string') return null;
  const tokens = className.split(/\s+/).filter(Boolean);
  const tokenSet = new Set(tokens);

  if (tokenSet.has('list-none') && tokenSet.has('ps-0')) return null;
  if (tokenSet.has('grid-flow-col') || tokens.some((cls) => cls.startsWith('auto-cols-'))) {
    return null;
  }
  if (tokens.some((cls) => cls === 'grid-cols-12' || cls.endsWith(':grid-cols-12'))) {
    return null;
  }

  for (const cls of tokens) {
    if (DIRECTORY_COLUMN_GRID_CLASS_REGEX.test(cls)) return cls;
  }
  return null;
}

/**
 * @param {string} className
 * @returns {string | null} first offending token
 */
function findLegacyColorClassToken(className) {
  if (!className || typeof className !== 'string') return null;
  for (const cls of className.split(/\s+/).filter(Boolean)) {
    for (const re of LEGACY_COLOR_CLASS_REGEXES) {
      if (re.test(cls)) return cls;
    }
  }
  return null;
}

/**
 * Check if a className string contains prohibited typography classes
 */
function hasTypographyClass(className) {
  if (!className || typeof className !== 'string') return false;
  const classes = className.split(/\s+/);
  return classes.some(cls => 
    TYPOGRAPHY_CLASSES.some(pattern => pattern.test(cls))
  );
}

/**
 * Check if a className string contains color classes
 */
function hasColorClass(className) {
  if (!className || typeof className !== 'string') return false;
  const classes = className.split(/\s+/);
  return classes.some(cls => 
    COLOR_CLASSES.some(pattern => pattern.test(cls))
  );
}

/**
 * Check if a className string contains spacing classes
 */
function hasSpacingClass(className) {
  if (!className || typeof className !== 'string') return false;
  const classes = className.split(/\s+/);
  return classes.some(cls => 
    SPACING_CLASSES.some(pattern => pattern.test(cls))
  );
}

/**
 * Get the JSX element name
 */
function getJSXElementName(node) {
  if (node.type === 'JSXIdentifier') {
    return node.name;
  }
  if (node.type === 'JSXMemberExpression') {
    return node.object.name + '.' + node.property.name;
  }
  return null;
}

/**
 * Check if a node is a pace-core component
 */
function isPaceCoreComponent(node) {
  const name = getJSXElementName(node.openingElement?.name || node.name);
  return name && PACE_CORE_COMPONENTS.has(name);
}

/**
 * Extract className value from JSX attribute
 */
function getClassNameValue(node) {
  if (!node.value) return null;
  
  if (node.value.type === 'Literal') {
    return node.value.value;
  }
  
  if (node.value.type === 'JSXExpressionContainer') {
    const expr = node.value.expression;
    if (expr.type === 'Literal') {
      return expr.value;
    }
    if (expr.type === 'TemplateLiteral' && expr.quasis.length === 1) {
      return expr.quasis[0].value.cooked;
    }
  }
  
  return null;
}

/**
 * Check if a JSX element name is a lowercase HTML element (not a React component)
 */
function isHTMLElement(elementName) {
  if (!elementName) return false;
  // React components start with uppercase, HTML elements are lowercase
  return elementName === elementName.toLowerCase();
}

/**
 * Get direct child JSXOpeningElement nodes from a JSXElement
 */
function getDirectChildJSXElements(node) {
  const children = [];
  
  if (!node.children) return children;
  
  for (const child of node.children) {
    // Skip text nodes, comments, and expressions
    if (child.type === 'JSXElement') {
      children.push(child.openingElement);
    } else if (child.type === 'JSXFragment') {
      // For fragments, recursively get children
      if (child.children) {
        for (const fragmentChild of child.children) {
          if (fragmentChild.type === 'JSXElement') {
            children.push(fragmentChild.openingElement);
          }
        }
      }
    }
  }
  
  return children;
}

/**
 * Get non-empty JSX element children.
 * @param {import('estree').Node & { children?: any[] }} node
 * @returns {any[]}
 */
function getMeaningfulJSXChildren(node) {
  if (!node.children) return [];
  return node.children.filter((child) => {
    if (child.type === 'JSXText') {
      return child.value.trim() !== '';
    }
    return child.type === 'JSXElement' || child.type === 'JSXFragment';
  });
}

/**
 * @param {any[]} attributes
 * @param {string} name
 * @returns {any | undefined}
 */
function getAttribute(attributes, name) {
  return attributes.find((attr) => attr.name && attr.name.name === name);
}

/**
 * @param {any} attr
 * @returns {string | null}
 */
function getAttributeLiteralValue(attr) {
  if (!attr || !attr.value) return null;
  if (attr.value.type === 'Literal') {
    return typeof attr.value.value === 'string' ? attr.value.value : null;
  }
  if (attr.value.type === 'JSXExpressionContainer') {
    const expr = attr.value.expression;
    if (expr.type === 'Literal') {
      return typeof expr.value === 'string' ? expr.value : null;
    }
    if (expr.type === 'TemplateLiteral' && expr.quasis.length === 1) {
      return expr.quasis[0].value.cooked;
    }
  }
  return null;
}

/**
 * @param {any} node JSXElement
 * @returns {string}
 */
function getFlatTextContent(node) {
  if (!node || !node.children) return '';
  const text = node.children
    .filter((child) => child.type === 'JSXText')
    .map((child) => child.value)
    .join(' ')
    .replace(/\s+/g, ' ')
    .trim();
  return text;
}

/**
 * @dnd-kit sortable rows use transform/transition inline styles (see WorkflowFormFieldEditor).
 * @param {any} expression
 * @returns {boolean}
 */
function isAllowedSortableStyleExpression(expression) {
  if (!expression) return false;
  if (expression.type === 'Identifier' && expression.name === 'style') {
    return true;
  }
  if (expression.type === 'ConditionalExpression') {
    const alternate = expression.alternate;
    const alternateAllowed =
      (alternate.type === 'Identifier' && alternate.name === 'undefined') ||
      isAllowedSortableStyleExpression(alternate);
    return isAllowedSortableStyleExpression(expression.consequent) && alternateAllowed;
  }
  if (expression.type === 'ObjectExpression') {
    const allowedKeys = new Set(['transform', 'transition']);
    if (expression.properties.length === 0) return false;
    return expression.properties.every((prop) => {
      if (prop.type !== 'Property' || prop.computed) return false;
      const key =
        prop.key.type === 'Identifier'
          ? prop.key.name
          : prop.key.type === 'Literal' && typeof prop.key.value === 'string'
            ? prop.key.value
            : null;
      return key != null && allowedKeys.has(key);
    });
  }
  return false;
}

/**
 * @param {any} node JSXElement
 * @returns {boolean}
 */
function isSubmitButtonElement(node) {
  if (!node || node.type !== 'JSXElement') return false;
  const name = getJSXElementName(node.openingElement.name);
  if (name !== 'Button' && name !== 'button') return false;
  const typeAttr = getAttribute(node.openingElement.attributes, 'type');
  const typeValue = getAttributeLiteralValue(typeAttr);
  return typeValue === 'submit';
}

/**
 * @param {any[]} ancestors
 * @returns {boolean}
 */
function hasApprovedSaveActionContainer(ancestors) {
  for (const ancestor of ancestors) {
    if (ancestor.type !== 'JSXElement') continue;
    const elementName = getJSXElementName(ancestor.openingElement.name);
    if (elementName == null) continue;

    if (SAVE_ACTION_CONTAINER_COMPONENTS.has(elementName)) {
      return true;
    }

    if (SAVE_ACTION_CONTAINER_HTML_TAGS.has(elementName)) {
      const classNameAttr = getAttribute(ancestor.openingElement.attributes, 'className');
      const className = getClassNameValue(classNameAttr);
      if (className == null) continue;
      if (
        className.includes('justify-end') ||
        className.includes('justify-items-end') ||
        className.includes('text-right')
      ) {
        return true;
      }
    }
  }
  return false;
}

/**
 * @param {any} context
 * @param {any} node
 * @returns {any[]}
 */
function getNodeAncestors(context, node) {
  if (context.sourceCode && typeof context.sourceCode.getAncestors === 'function') {
    return context.sourceCode.getAncestors(node);
  }
  if (typeof context.getAncestors === 'function') {
    return context.getAncestors();
  }
  return [];
}

/**
 * @param {string | null} className
 * @returns {boolean}
 */
function isLayoutOnlyClassList(className) {
  if (!className || typeof className !== 'string') return false;
  const classes = className
    .split(/\s+/)
    .map((cls) => cls.trim())
    .filter(Boolean)
    .map((cls) => {
      const noImportant = cls.startsWith('!') ? cls.slice(1) : cls;
      const parts = noImportant.split(':');
      return parts[parts.length - 1];
    });
  if (classes.length === 0) return false;
  return classes.every((cls) => LAYOUT_ONLY_CLASS_PATTERNS.some((re) => re.test(cls)));
}

/**
 * Allow instance-level layout/spacing classes on pace-core components,
 * but block visual overrides (typography, colors, borders, shadows, etc.).
 * @param {string | null} className
 * @returns {boolean}
 */
function isAllowedPaceCoreInstanceClassList(className) {
  if (!className || typeof className !== 'string') return false;
  const classes = className
    .split(/\s+/)
    .map((cls) => cls.trim())
    .filter(Boolean)
    .map((cls) => {
      const noImportant = cls.startsWith('!') ? cls.slice(1) : cls;
      const parts = noImportant.split(':');
      return parts[parts.length - 1];
    });
  if (classes.length === 0) return false;
  return classes.every((cls) => INSTANCE_LAYOUT_CLASS_PATTERNS.some((re) => re.test(cls)));
}

module.exports = {
  rules: {
    /**
     * Disallow inline styles
     */
    'no-inline-styles': {
      meta: {
        type: 'problem',
        docs: {
          description: 'Disallow inline styles. Use pace-core components or Tailwind classes instead.',
          category: 'Best Practices',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/7-visual-standards.md'
        },
        messages: {
          inlineStyle: 'Inline style detected. Use pace-core components or Tailwind classes instead.'
        },
        hasSuggestions: true
      },
      create(context) {
        const filename = context.getFilename();
        if (!shouldApplyStylingRules(filename)) {
          return {};
        }

        return {
          JSXAttribute(node) {
            if (node.name && node.name.name === 'style') {
              const valueExpression =
                node.value?.type === 'JSXExpressionContainer' ? node.value.expression : null;
              if (isAllowedSortableStyleExpression(valueExpression)) {
                return;
              }
              context.report({
                node,
                messageId: 'inlineStyle',
                suggest: [{
                  desc: 'Remove inline style and use pace-core component styling or Tailwind utility classes',
                  fix(fixer) {
                    // Remove the style attribute
                    return fixer.remove(node);
                  }
                }]
              });
            }
          }
        };
      }
    },

    /**
     * Disallow typography utility classes on typography elements
     */
    'no-typography-styling': {
      meta: {
        type: 'problem',
        docs: {
          description: 'Disallow typography utility classes (text-*, font-*, leading-*, tracking-*, uppercase, etc.) on typography elements. Typography is defined in pace-core core.css.',
          category: 'Best Practices',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/7-visual-standards.md'
        },
        messages: {
          typographyClass: 'Typography utility class "{{className}}" detected on {{element}} element. Typography is defined in pace-core core.css - remove the class.',
          colorClass: 'Color class "{{className}}" detected on {{element}} element. Typography colors are defined in pace-core core.css - remove the class.',
          spacingClass: 'Spacing class "{{className}}" detected on {{element}} element. Typography spacing is defined in pace-core core.css - remove the class unless needed for layout structure.'
        },
        hasSuggestions: true
      },
      create(context) {
        const filename = context.getFilename();
        if (!shouldApplyStylingRules(filename)) {
          return {};
        }

        return {
          JSXOpeningElement(node) {
            const elementName = getJSXElementName(node.name);
            
            // Only check typography elements
            if (!elementName || !TYPOGRAPHY_ELEMENTS.has(elementName.toLowerCase())) {
              return;
            }
            
            // Check className attribute
            const classNameAttr = node.attributes.find(
              attr => attr.name && attr.name.name === 'className'
            );
            
            if (!classNameAttr) return;
            
            const className = getClassNameValue(classNameAttr);
            if (!className) return;
            
            // Check for typography classes
            const classes = className.split(/\s+/);
            classes.forEach(cls => {
              if (TYPOGRAPHY_CLASSES.some(pattern => pattern.test(cls))) {
                context.report({
                  node: classNameAttr,
                  messageId: 'typographyClass',
                  data: {
                    className: cls,
                    element: elementName
                  },
                  suggest: [{
                    desc: `Remove typography class "${cls}" - typography is defined in pace-core core.css`,
                    fix(fixer) {
                      const newClasses = classes.filter(c => c !== cls).join(' ');
                      if (newClasses) {
                        return fixer.replaceText(
                          classNameAttr.value,
                          `"${newClasses}"`
                        );
                      } else {
                        return fixer.remove(classNameAttr);
                      }
                    }
                  }]
                });
              }
              
              // Check for color classes
              if (COLOR_CLASSES.some(pattern => pattern.test(cls))) {
                context.report({
                  node: classNameAttr,
                  messageId: 'colorClass',
                  data: {
                    className: cls,
                    element: elementName
                  },
                  suggest: [{
                    desc: `Remove color class "${cls}" - typography colors are defined in pace-core core.css`,
                    fix(fixer) {
                      const newClasses = classes.filter(c => c !== cls).join(' ');
                      if (newClasses) {
                        return fixer.replaceText(
                          classNameAttr.value,
                          `"${newClasses}"`
                        );
                      } else {
                        return fixer.remove(classNameAttr);
                      }
                    }
                  }]
                });
              }
              
              // Check for spacing classes (warn, not error, as they might be for layout)
              if (SPACING_CLASSES.some(pattern => pattern.test(cls))) {
                context.report({
                  node: classNameAttr,
                  messageId: 'spacingClass',
                  data: {
                    className: cls,
                    element: elementName
                  },
                  suggest: [{
                    desc: `Remove spacing class "${cls}" unless needed for layout structure - typography spacing is defined in pace-core core.css`,
                    fix(fixer) {
                      const newClasses = classes.filter(c => c !== cls).join(' ');
                      if (newClasses) {
                        return fixer.replaceText(
                          classNameAttr.value,
                          `"${newClasses}"`
                        );
                      } else {
                        return fixer.remove(classNameAttr);
                      }
                    }
                  }]
                });
              }
            });
          }
        };
      }
    },

    /**
     * Disallow overriding styles on pace-core components
     */
    'no-pace-core-style-override': {
      meta: {
        type: 'problem',
        docs: {
          description: 'Disallow overriding styles on pace-core components. Use component variants/props instead.',
          category: 'Best Practices',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/7-visual-standards.md'
        },
        messages: {
          styleOverride: 'Style override detected on pace-core component {{component}}. Use component variants/props instead, or override styles inside the component file if absolutely necessary.',
          dynamicClassNameOverride: 'Dynamic className on pace-core component {{component}} is not allowed here. Keep classes static and layout-only, or move visual styling into the component implementation.'
        }
      },
      create(context) {
        const filename = context.getFilename();
        
        // Exclude pace-core source files - these rules are for consuming apps
        if (isPaceCoreSourceFile(filename)) {
          return {};
        }
        
        return {
          JSXOpeningElement(node) {
            const elementName = getJSXElementName(node.name);
            
            // Only check pace-core components
            if (!elementName || !PACE_CORE_COMPONENTS.has(elementName)) {
              return;
            }
            
            // Check for className or style attributes
            const classNameAttr = node.attributes.find(
              attr => attr.name && attr.name.name === 'className'
            );
            const styleAttr = node.attributes.find(
              attr => attr.name && attr.name.name === 'style'
            );
            
            if (styleAttr) {
              context.report({
                node: styleAttr,
                messageId: 'styleOverride',
                data: {
                  component: elementName
                }
              });
            }

            if (!classNameAttr) return;

            const className = getClassNameValue(classNameAttr);
            if (!className) {
              context.report({
                node: classNameAttr,
                messageId: 'dynamicClassNameOverride',
                data: {
                  component: elementName
                }
              });
              return;
            }

            if (!isAllowedPaceCoreInstanceClassList(className)) {
              context.report({
                node: classNameAttr,
                messageId: 'styleOverride',
                data: {
                  component: elementName
                }
              });
            }
          }
        };
      }
    },

    /**
     * Enforce semantic HTML elements
     */
    'prefer-semantic-html': {
      meta: {
        type: 'suggestion',
        docs: {
          description: 'Prefer semantic HTML elements (h1-h6, p, ul, ol, li, a, etc.) instead of div/span wrappers.',
          category: 'Best Practices',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/7-visual-standards.md'
        },
        messages: {
          useSemanticElement: 'Use semantic HTML element ({{semantic}}) instead of {{current}} for {{purpose}}.'
        }
      },
      create(context) {
        const filename = context.getFilename();
        if (!shouldApplyStylingRules(filename)) {
          return {};
        }

        // Common patterns: div with className that suggests semantic element
        const semanticPatterns = [
          { pattern: /heading|title|h[1-6]/i, semantic: 'h1-h6', current: 'div' },
          { pattern: /paragraph|text|p(?:ara)?/i, semantic: 'p', current: 'div' },
          { pattern: /list|ul|ol/i, semantic: 'ul/ol', current: 'div' },
          { pattern: /item|li/i, semantic: 'li', current: 'div' },
          { pattern: /link|anchor|a/i, semantic: 'a', current: 'div' },
          { pattern: /nav|navigation/i, semantic: 'nav', current: 'div' },
          { pattern: /header/i, semantic: 'header', current: 'div' },
          { pattern: /footer/i, semantic: 'footer', current: 'div' },
          { pattern: /main|content/i, semantic: 'main', current: 'div' },
          { pattern: /section/i, semantic: 'section', current: 'div' },
          { pattern: /article/i, semantic: 'article', current: 'div' }
        ];
        
        return {
          JSXOpeningElement(node) {
            const elementName = getJSXElementName(node.name);
            
            // Only check div and span elements
            if (!elementName || (elementName !== 'div' && elementName !== 'span')) {
              return;
            }
            
            // Check className for semantic hints
            const classNameAttr = node.attributes.find(
              attr => attr.name && attr.name.name === 'className'
            );
            
            if (classNameAttr) {
              const className = getClassNameValue(classNameAttr);
              if (className) {
                for (const { pattern, semantic, current } of semanticPatterns) {
                  if (pattern.test(className)) {
                    context.report({
                      node,
                      messageId: 'useSemanticElement',
                      data: {
                        semantic,
                        current: elementName,
                        purpose: className
                      }
                    });
                    break;
                  }
                }
              }
            }
          }
        };
      }
    },

    /**
     * Disallow same-type element nesting (e.g., <section><section>...</section></section>)
     */
    'no-nested-same-type-tags': {
      meta: {
        type: 'problem',
        docs: {
          description: 'Disallow nesting semantic HTML elements of the same type as immediate parent/child (e.g., <section><section>...</section></section>). This violates semantic HTML structure.',
          category: 'Best Practices',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/7-visual-standards.md'
        },
        messages: {
          nestedSameTypeTag: '<{{tag}}> element contains a direct child <{{tag}}> element. This violates semantic HTML structure - {{tag}} elements should not be nested as immediate parent/child. Consider using a different semantic element or restructuring the markup.'
        },
        hasSuggestions: true
      },
      create(context) {
        const filename = context.getFilename();
        if (!shouldApplyStylingRules(filename)) {
          return {};
        }

        return {
          JSXElement(node) {
            const openingElement = node.openingElement;
            const parentElementName = getJSXElementName(openingElement.name);
            
            // Only check lowercase HTML elements (not React components)
            if (!parentElementName || !isHTMLElement(parentElementName)) {
              return;
            }
            
            const parentTagName = parentElementName.toLowerCase();
            
            // Only check prohibited elements
            if (!PROHIBITED_NESTED_ELEMENTS.has(parentTagName)) {
              return;
            }
            
            // Get direct child JSX elements
            const directChildren = getDirectChildJSXElements(node);
            
            // Check each direct child for same-type nesting
            for (const childOpeningElement of directChildren) {
              const childElementName = getJSXElementName(childOpeningElement.name);
              
              // Only check lowercase HTML elements
              if (!childElementName || !isHTMLElement(childElementName)) {
                continue;
              }
              
              const childTagName = childElementName.toLowerCase();
              
              // Check if child is the same type as parent
              if (childTagName === parentTagName) {
                context.report({
                  node: childOpeningElement,
                  messageId: 'nestedSameTypeTag',
                  data: {
                    tag: parentTagName
                  },
                  suggest: [{
                    desc: `Replace nested <${parentTagName}> with a different semantic element or restructure the markup`,
                    fix(fixer) {
                      // Auto-fix is complex and context-dependent, so we'll just report
                      return null;
                    }
                  }]
                });
              }
            }
          }
        };
      }
    },

    /**
     * Disallow single wrapper elements in Card subcomponents when wrapper is layout-only.
     */
    'no-redundant-card-subcomponent-wrapper': {
      meta: {
        type: 'problem',
        docs: {
          description:
            'Disallow redundant single wrapper elements inside CardHeader/CardContent/CardFooter when wrapper only applies grid/gap/layout utilities.',
          category: 'Best Practices',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/7-visual-standards.md#part-b-markup'
        },
        messages: {
          redundantWrapper:
            'Redundant wrapper <{{wrapper}}> inside <{{parent}}> detected. Apply layout classes to <{{parent}}> directly.'
        }
      },
      create(context) {
        const filename = context.getFilename();
        if (!shouldApplyStylingRules(filename)) {
          return {};
        }

        return {
          JSXElement(node) {
            const parentName = getJSXElementName(node.openingElement.name);
            if (!parentName || !CARD_SUBCOMPONENTS.has(parentName)) return;

            const meaningfulChildren = getMeaningfulJSXChildren(node);
            if (meaningfulChildren.length !== 1) return;

            const onlyChild = meaningfulChildren[0];
            if (onlyChild.type !== 'JSXElement') return;

            const wrapperName = getJSXElementName(onlyChild.openingElement.name);
            if (!wrapperName || !LAYOUT_WRAPPER_TAGS.has(wrapperName)) return;

            const classAttr = getAttribute(onlyChild.openingElement.attributes, 'className');
            const className = classAttr ? getClassNameValue(classAttr) : null;
            if (!isLayoutOnlyClassList(className)) return;

            context.report({
              node: onlyChild.openingElement,
              messageId: 'redundantWrapper',
              data: {
                wrapper: wrapperName,
                parent: parentName
              }
            });
          }
        };
      }
    },

    /**
     * Enforce nested Label structure in FormField implementation.
     */
    'formfield-label-must-wrap-control': {
      meta: {
        type: 'problem',
        docs: {
          description:
            'Enforce Label nesting pattern in FormField implementation (Label wraps control; avoid htmlFor/id-only association).',
          category: 'Best Practices',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/7-visual-standards.md#part-b-markup'
        },
        messages: {
          nestedLabel:
            'FormField should use nested Label/control association. Remove htmlFor on Label and wrap the control inside Label.'
        }
      },
      create(context) {
        const filename = context.getFilename();
        const isFormComponent =
          filename.includes('packages/core/src/components/Form.tsx') ||
          filename.includes('packages\\core\\src\\components\\Form.tsx');
        if (!isFormComponent) return {};

        return {
          JSXOpeningElement(node) {
            const elementName = getJSXElementName(node.name);
            if (elementName !== 'Label') return;
            const htmlForAttr = getAttribute(node.attributes, 'htmlFor');
            if (!htmlForAttr) return;

            context.report({
              node: htmlForAttr,
              messageId: 'nestedLabel'
            });
          }
        };
      }
    },

    /**
     * Enforce hidden required markers for LoginForm required FormFields.
     */
    'login-form-hide-required-marker': {
      meta: {
        type: 'problem',
        docs: {
          description:
            'Enforce showRequiredMarker={false} for required LoginForm fields.',
          category: 'Best Practices',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/docs/requirements/core/R06-forms-and-feedback.md'
        },
        messages: {
          missingHideRequired:
            'Required FormField in LoginForm must pass showRequiredMarker={false} (or equivalent false expression).'
        }
      },
      create(context) {
        const filename = context.getFilename();
        const isLoginFormFile =
          filename.includes('packages/core/src/components/LoginForm.tsx') ||
          filename.includes('packages\\core\\src\\components\\LoginForm.tsx');
        if (!isLoginFormFile) return {};

        return {
          JSXOpeningElement(node) {
            const elementName = getJSXElementName(node.name);
            if (elementName !== 'FormField') return;

            const requiredAttr = getAttribute(node.attributes, 'required');
            if (!requiredAttr) return;

            const markerAttr = getAttribute(node.attributes, 'showRequiredMarker');
            if (!markerAttr || !markerAttr.value || markerAttr.value.type !== 'JSXExpressionContainer') {
              context.report({ node, messageId: 'missingHideRequired' });
              return;
            }

            const expr = markerAttr.value.expression;
            if (expr.type !== 'Literal' || expr.value !== false) {
              context.report({ node: markerAttr, messageId: 'missingHideRequired' });
            }
          }
        };
      }
    },

    /**
     * Enforce persistence primary submit action label to be exactly "Save".
     */
    'persistence-save-label': {
      meta: {
        type: 'problem',
        docs: {
          description:
            'Enforce "Save" as the primary label for persistence/edit submit actions in footer-right action containers.',
          category: 'Best Practices',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/7-visual-standards.md#part-b-markup'
        },
        messages: {
          invalidSaveLabel:
            'Persistence submit action label must be "Save" in footer-right action containers. Found "{{label}}".'
        }
      },
      create(context) {
        const filename = context.getFilename();
        if (!shouldApplyStylingRules(filename)) {
          return {};
        }

        return {
          JSXElement(node) {
            if (!isSubmitButtonElement(node)) return;
            const label = getFlatTextContent(node);
            if (!label || label === 'Save') return;
            if (NON_PERSISTENCE_PRIMARY_LABELS.has(label)) return;
            const ancestors = getNodeAncestors(context, node);
            if (!hasApprovedSaveActionContainer(ancestors)) return;

            context.report({
              node: node.openingElement,
              messageId: 'invalidSaveLabel',
              data: { label }
            });
          }
        };
      }
    },

    /**
     * Enforce Save submit buttons to appear only in canonical footer-right action containers.
     */
    'persistence-save-placement': {
      meta: {
        type: 'problem',
        docs: {
          description:
            'Enforce Save submit action placement in CardFooter/DialogFooter or approved footer-right action containers.',
          category: 'Best Practices',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/7-visual-standards.md#part-b-markup'
        },
        messages: {
          invalidSavePlacement:
            'Save submit action must be inside CardFooter/DialogFooter or an approved footer-right action container.'
        }
      },
      create(context) {
        const filename = context.getFilename();
        if (!shouldApplyStylingRules(filename)) {
          return {};
        }

        if (
          filename.includes('packages/core/src/components/SaveActions.tsx') ||
          filename.includes('packages\\core\\src\\components\\SaveActions.tsx')
        ) {
          return {};
        }

        return {
          JSXElement(node) {
            if (!isSubmitButtonElement(node)) return;
            const label = getFlatTextContent(node);
            if (label !== 'Save') return;
            const ancestors = getNodeAncestors(context, node);
            if (hasApprovedSaveActionContainer(ancestors)) return;

            context.report({
              node: node.openingElement,
              messageId: 'invalidSavePlacement'
            });
          }
        };
      }
    },

    /**
     * Disallow Tailwind flex layout utilities (grid / native flow only per Standard 7 Part B)
     */
    'no-flex-layout-classes': {
      meta: {
        type: 'problem',
        docs: {
          description:
            'Disallow Tailwind flex display utilities (flex, inline-flex, flex-*). Use grid or native flow per Standard 7 Part B.',
          category: 'Best Practices',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/7-visual-standards.md#part-b-markup'
        },
        messages: {
          flexClass:
            'Flex layout utility "{{className}}" is not allowed. Use CSS Grid or native HTML flow (Standard 7 Part B — Layout).'
        }
      },
      create(context) {
        const filename = context.getFilename();
        if (!shouldApplyStylingRules(filename)) {
          return {};
        }

        function checkClassNameAttr(node) {
          const classNameAttr = node.attributes.find(
            attr => attr.name && attr.name.name === 'className'
          );
          if (!classNameAttr) return;
          const raw = getClassNameValue(classNameAttr);
          const bad = findFlexLayoutClassToken(raw);
          if (bad) {
            context.report({
              node: classNameAttr,
              messageId: 'flexClass',
              data: { className: bad }
            });
          }
        }

        return {
          JSXOpeningElement(node) {
            checkClassNameAttr(node);
          }
        };
      }
    },

    /**
     * Disallow legacy Tailwind palette colour utilities; use main/sec/acc or semantic tokens
     */
    'no-legacy-tailwind-color-classes': {
      meta: {
        type: 'problem',
        docs: {
          description:
            'Disallow standard Tailwind colour names (e.g. gray, blue). Use main, sec, acc or semantic tokens per Standard 7.',
          category: 'Best Practices',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/7-visual-standards.md#part-b-markup'
        },
        messages: {
          legacyColor:
            'Legacy Tailwind colour utility "{{className}}" is not allowed. Use main-*, sec-*, acc-* or semantic tokens (Standard 7 Part B/C).'
        }
      },
      create(context) {
        const filename = context.getFilename();
        if (!shouldApplyStylingRules(filename)) {
          return {};
        }

        return {
          JSXOpeningElement(node) {
            const classNameAttr = node.attributes.find(
              attr => attr.name && attr.name.name === 'className'
            );
            if (!classNameAttr) return;
            const raw = getClassNameValue(classNameAttr);
            const bad = findLegacyColorClassToken(raw);
            if (bad) {
              context.report({
                node: classNameAttr,
                messageId: 'legacyColor',
                data: { className: bad }
              });
            }
          }
        };
      }
    },

    /**
     * Disallow ul/ol column grids for directory card layouts (use section + Card fill / CardGrid)
     */
    'no-directory-card-list-grid': {
      meta: {
        type: 'problem',
        docs: {
          description:
            'Directory card grids must use <section className="grid …">, not <ul> or <ol> with column grid classes.',
          category: 'Best Practices',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/7-visual-standards.md#part-b-markup'
        },
        messages: {
          listColumnGrid:
            'Column grid class "{{className}}" on <{{tag}}> is not allowed for directory card grids. Use <section className="grid …"> with Card fill or CardGrid (Standard 7 Part B).'
        }
      },
      create(context) {
        const filename = context.getFilename();
        if (!shouldApplyStylingRules(filename)) {
          return {};
        }

        return {
          JSXOpeningElement(node) {
            if (node.name.type !== 'JSXIdentifier') return;
            const tag = node.name.name;
            if (tag !== 'ul' && tag !== 'ol') return;

            const classNameAttr = node.attributes.find(
              (attr) => attr.name && attr.name.name === 'className'
            );
            if (!classNameAttr) return;

            const raw = getClassNameValue(classNameAttr);
            const bad = findDirectoryListColumnGridToken(raw);
            if (bad) {
              context.report({
                node: classNameAttr,
                messageId: 'listColumnGrid',
                data: { className: bad, tag }
              });
            }
          }
        };
      }
    }
  }
};
