/**
 * Security & RBAC Rules (Standard 3)
 * @package @solvera/pace-core
 * @module ESLintRules/rules/security-rbac
 * 
 * Enforces security and RBAC patterns from Standard 3:
 * - Use secure Supabase client (useSecureSupabase)
 * - Use canonical DB page names for useResourcePermissions
 * - No wrapper components/functions around RBAC hooks
 * - Proper permission loading state handling
 * 
 * Note: This file contains TypeScript/JavaScript ESLint rules. For SQL migration
 * validation (including SECURITY DEFINER function checks), see the audit tool:
 * packages/core/audit-tool/audits/03-security-rbac.cjs
 * 
 * SECURITY DEFINER Requirements (for SQL functions):
 * - SECURITY DEFINER is REQUIRED when helper functions query RLS-protected tables
 * - All SECURITY DEFINER functions MUST have SET search_path TO public
 * - All table/function references MUST be schema-qualified
 * - Functions MUST document why SECURITY DEFINER is needed
 * 
 * Reference: packages/core/docs/standards/3-security-rbac-standards.md
 */

const { isPaceCoreSourceFile } = require('../utils/helpers.cjs');

function getPropertyName(node) {
  if (!node || node.type !== 'Property') return null;
  if (node.key.type === 'Identifier') return node.key.name;
  if (node.key.type === 'Literal' && typeof node.key.value === 'string') return node.key.value;
  return null;
}

function getStringLiteralValue(node) {
  if (!node) return null;
  if (node.type === 'Literal' && typeof node.value === 'string') return node.value;
  if (node.type === 'TemplateLiteral' && node.expressions.length === 0 && node.quasis.length === 1) {
    return node.quasis[0].value?.cooked ?? null;
  }
  return null;
}

function isCanonicalUppercaseAppName(appName) {
  return typeof appName === 'string' && /^[A-Z0-9_]+$/.test(appName);
}

module.exports = {
  rules: {
    /**
     * Disallow direct Supabase client creation - must use useSecureSupabase
     */
    'no-direct-supabase-client': {
      meta: {
        type: 'problem',
        docs: {
          description: 'Disallow direct createClient calls from @supabase/supabase-js. Use useSecureSupabase() from pace-core instead to ensure organisation context and RLS policies are enforced.',
          category: 'Security',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/3-security-rbac-standards.md'
        },
        messages: {
          directClientCreation: "Direct Supabase client creation detected. You MUST use useSecureSupabase() from '@solvera/pace-core/rbac' instead to ensure organisation context and RLS policies are enforced. This prevents cross-organisation data access.",
          directClientImport: "Direct import of createClient from @supabase/supabase-js is not allowed. Use useSecureSupabase() from '@solvera/pace-core/rbac' instead."
        },
        hasSuggestions: true
      },
      create(context) {
        const filename = context.getFilename();
        
        // Exclude pace-core source files - these rules are for consuming apps
        if (isPaceCoreSourceFile(filename)) {
          return {};
        }
        
        // Exclude Edge Functions - they run in Deno and cannot use React hooks
        // Edge Functions must use createClient() directly with service role keys
        const isEdgeFunction = filename.includes('supabase/functions/') || 
                              filename.includes('supabase\\functions\\');
        
        // Allow createClient in specific config files (supabaseClient.ts/js, etc.)
        const isConfigFile = /(supabase|client)\.(ts|js|tsx|jsx)$/i.test(filename) && 
                            (filename.includes('supabase') || filename.includes('client'));
        
        return {
          ImportDeclaration(node) {
            const importSource = node.source.value;
            
            // Check for @supabase/supabase-js import
            if (importSource === '@supabase/supabase-js') {
              // Check if createClient is imported
              const hasCreateClient = node.specifiers.some(spec => {
                if (spec.type === 'ImportSpecifier') {
                  return spec.imported.name === 'createClient';
                }
                if (spec.type === 'ImportNamespaceSpecifier') {
                  return true; // import * as supabase
                }
                return false;
              });
              
              if (hasCreateClient && !isConfigFile && !isEdgeFunction) {
                context.report({
                  node: node.source,
                  messageId: 'directClientImport',
                  suggest: [{
                    desc: 'Replace with useSecureSupabase hook',
                    fix(fixer) {
                      return fixer.remove(node);
                    }
                  }]
                });
              }
            }
          },
          
          CallExpression(node) {
            // Check for createClient() calls
            if (node.callee.type === 'Identifier' && node.callee.name === 'createClient') {
              if (!isConfigFile && !isEdgeFunction) {
                context.report({
                  node,
                  messageId: 'directClientCreation',
                  suggest: [{
                    desc: 'Use useSecureSupabase() hook instead',
                    fix(fixer) {
                      return null;
                    }
                  }]
                });
              }
            }
            
            // Check for supabase.createClient() or similar patterns
            if (node.callee.type === 'MemberExpression' && 
                node.callee.property?.name === 'createClient') {
              if (!isConfigFile && !isEdgeFunction) {
                context.report({
                  node,
                  messageId: 'directClientCreation',
                  suggest: [{
                    desc: 'Use useSecureSupabase() hook instead',
                    fix(fixer) {
                      return null;
                    }
                  }]
                });
              }
            }
          }
        };
      }
    },

    /**
     * Check RBAC permission loading state usage
     */
    'rbac-permission-loading': {
      meta: {
        type: 'problem',
        docs: {
          description: 'Require isLoading extraction from useResourcePermissions and check it before permission calls in mutations.',
          category: 'Security',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/3-security-rbac-standards.md'
        },
        messages: {
          missingIsLoading: "useResourcePermissions is used but 'isLoading' is not extracted. Permission checks may fail if scope resolution is still in progress.",
          missingLoadingCheck: "Permission check '{{permission}}()' is called without checking isLoading first. This can cause false negatives when scope resolution is still in progress."
        },
        hasSuggestions: true
      },
      create(context) {
        let useResourcePermissionsFound = false;
        let hasIsLoadingExtraction = false;
        let isLoadingVarName = null;
        
        return {
          CallExpression(node) {
            // Find useResourcePermissions calls
            if (node.callee.type === 'Identifier' && 
                node.callee.name === 'useResourcePermissions') {
              useResourcePermissionsFound = true;
              
              // Check parent to see if isLoading is destructured
              const parent = node.parent;
              if (parent && parent.type === 'VariableDeclarator' && 
                  parent.id && parent.id.type === 'ObjectPattern') {
                const properties = parent.id.properties;
                const isLoadingProp = properties.find(prop => {
                  if (prop.type === 'Property') {
                    const key = prop.key;
                    if (key.type === 'Identifier' && key.name === 'isLoading') {
                      return true;
                    }
                    // Also check for renamed: isLoading: permissionsLoading
                    if (key.type === 'Identifier' && key.name === 'isLoading') {
                      if (prop.value && prop.value.type === 'Identifier') {
                        isLoadingVarName = prop.value.name;
                      }
                      return true;
                    }
                  }
                  return false;
                });
                
                if (isLoadingProp) {
                  hasIsLoadingExtraction = true;
                  if (!isLoadingVarName) {
                    isLoadingVarName = 'isLoading';
                  }
                }
              }
            }
            
            // Check for permission function calls in mutations
            if (useResourcePermissionsFound && 
                node.callee.type === 'Identifier' &&
                ['canCreate', 'canUpdate', 'canDelete', 'canRead'].includes(node.callee.name)) {
              
              // Check if we're in a mutation context
              const sourceCode = context.sourceCode || context.getSourceCode();
              // ESLint 9: use sourceCode.getAncestors(node), ESLint 8: use context.getAncestors()
              const ancestors = sourceCode.getAncestors ? sourceCode.getAncestors(node) : (context.getAncestors ? context.getAncestors() : []);
              const isInMutation = ancestors.some(ancestor => {
                if (ancestor.type === 'Property' && ancestor.key) {
                  const keyName = ancestor.key.name || (ancestor.key.type === 'Identifier' && ancestor.key.name);
                  return keyName === 'mutationFn' || keyName === 'mutateAsync';
                }
                return false;
              });
              
              if (isInMutation) {
                // Check if isLoading is checked before this call
                const nodeText = sourceCode.getText(node);
                const beforeNode = sourceCode.getText().substring(0, sourceCode.getIndexFromLoc(node.loc.start));
                
                // Look for isLoading check before this call
                const hasLoadingCheck = new RegExp(
                  `(if\\s*\\(\\s*!?\\s*(${isLoadingVarName || 'isLoading'})|if\\s*\\(\\s*(${isLoadingVarName || 'isLoading'})\\s*===\\s*false|if\\s*\\(\\s*(${isLoadingVarName || 'isLoading'})\\s*!==\\s*true|await)`,
                  'i'
                ).test(beforeNode);
                
                if (!hasIsLoadingExtraction) {
                  context.report({
                    node,
                    messageId: 'missingIsLoading',
                    suggest: [{
                      desc: `Extract 'isLoading' from useResourcePermissions`,
                      fix(fixer) {
                        return null; // Complex fix
                      }
                    }]
                  });
                } else if (!hasLoadingCheck) {
                  context.report({
                    node,
                    messageId: 'missingLoadingCheck',
                    data: {
                      permission: node.callee.name
                    },
                    suggest: [{
                      desc: `Check ${isLoadingVarName || 'isLoading'} before calling permission function`,
                      fix(fixer) {
                        return null; // Complex fix
                      }
                    }]
                  });
                }
              }
            }
          }
        };
      }
    },

    /**
     * Disallow direct RPC calls to RBAC functions
     */
    'no-direct-rbac-rpc': {
      meta: {
        type: 'problem',
        docs: {
          description: 'Disallow direct calls to RBAC RPC functions. Use pace-core RBAC hooks instead.',
          category: 'Security',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/3-security-rbac-standards.md'
        },
        messages: {
          directRbacRpc: "Direct RPC call to '{{rpcName}}' detected. Use pace-core RBAC hooks from '@solvera/pace-core/rbac' instead."
        },
        hasSuggestions: true
      },
      create(context) {
        const filename = context.getFilename();
        
        // Exclude pace-core source files - these rules are for consuming apps
        if (isPaceCoreSourceFile(filename)) {
          return {};
        }
        
        const rbacRpcPatterns = ['rbac_check_permission_simplified', 'rbac_'];
        
        return {
          CallExpression(node) {
            // Check for supabase.rpc('rbac_*', ...)
            if (node.callee.type === 'MemberExpression' &&
                node.callee.property &&
                node.callee.property.name === 'rpc' &&
                node.arguments.length > 0) {
              
              const firstArg = node.arguments[0];
              if (firstArg.type === 'Literal' && typeof firstArg.value === 'string') {
                const rpcName = firstArg.value;
                if (rpcName.startsWith('rbac_')) {
                  context.report({
                    node: firstArg,
                    messageId: 'directRbacRpc',
                    data: {
                      rpcName
                    },
                    suggest: [{
                      desc: 'Use pace-core RBAC hooks instead',
                      fix(fixer) {
                        return null;
                      }
                    }]
                  });
                }
              }
            }
          }
        };
      }
    },

    /**
     * Disallow direct queries to RBAC tables
     */
    'no-direct-rbac-table': {
      meta: {
        type: 'problem',
        docs: {
          description: 'Disallow direct queries to RBAC tables. Use pace-core RBAC API functions or useSecureSupabase instead.',
          category: 'Security',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/3-security-rbac-standards.md'
        },
        messages: {
          directRbacTable: "Direct query to RBAC table '{{tableName}}' detected. Use pace-core RBAC API functions from '@solvera/pace-core/rbac' or useSecureSupabase hook instead."
        },
        hasSuggestions: true
      },
      create(context) {
        const filename = context.getFilename();
        
        // Exclude pace-core source files - these rules are for consuming apps
        if (isPaceCoreSourceFile(filename)) {
          return {};
        }
        
        const rbacTables = [
          'rbac_organisation_roles',
          'rbac_event_app_roles',
          'rbac_global_roles',
          'rbac_apps',
          'rbac_app_pages',
          'rbac_page_permissions',
          'rbac_user_profiles'
        ];
        
        let hasSecureSupabase = false;
        let secureSupabaseVarName = null;
        
        return {
          ImportDeclaration(node) {
            const importSource = node.source.value;
            if (importSource === '@solvera/pace-core/rbac' || 
                importSource.startsWith('@solvera/pace-core/rbac/')) {
              if (node.specifiers.some(spec => 
                spec.type === 'ImportSpecifier' && spec.imported.name === 'useSecureSupabase'
              )) {
                hasSecureSupabase = true;
              }
            }
          },
          VariableDeclarator(node) {
            if (node.init && 
                node.init.type === 'CallExpression' &&
                node.init.callee &&
                node.init.callee.name === 'useSecureSupabase') {
              if (node.id.type === 'Identifier') {
                secureSupabaseVarName = node.id.name;
              }
            }
          },
          CallExpression(node) {
            if (node.callee.type === 'MemberExpression' &&
                node.callee.property &&
                node.callee.property.name === 'from' &&
                node.arguments.length > 0) {
              
              // Check if this is called on secureSupabase
              let isSecureClient = false;
              if (node.callee.object.type === 'Identifier') {
                const objName = node.callee.object.name;
                if (objName === 'secureSupabase' || 
                    objName === secureSupabaseVarName ||
                    (hasSecureSupabase && objName.includes('secure'))) {
                  isSecureClient = true;
                }
              }
              
              // Allow queries through secureSupabase
              if (isSecureClient) {
                return;
              }
              
              const firstArg = node.arguments[0];
              if (firstArg.type === 'Literal' && typeof firstArg.value === 'string') {
                const tableName = firstArg.value;
                if (rbacTables.includes(tableName) || tableName.startsWith('rbac_')) {
                  context.report({
                    node: firstArg,
                    messageId: 'directRbacTable',
                    data: {
                      tableName
                    },
                    suggest: [{
                      desc: 'Use useSecureSupabase hook or pace-core RBAC API functions',
                      fix(fixer) {
                        return null;
                      }
                    }]
                  });
                }
              }
            }
          }
        };
      }
    },

    /**
     * Enforce strict setupRBAC contract for consuming apps:
     * - appName must be configured
     * - getAppId must be configured when appName is provided
     */
    'require-setup-rbac-get-app-id': {
      meta: {
        type: 'problem',
        docs: {
          description: 'Require setupRBAC to include both appName and getAppId in consuming-app bootstrap.',
          category: 'Security',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/3-security-rbac-standards.md'
        },
        messages: {
          missingConfigObject: 'setupRBAC must receive a config object as its second argument (with appName and getAppId).',
          missingAppName: 'setupRBAC config must include appName.',
          missingGetAppId: 'setupRBAC config must include getAppId when appName is configured.'
        },
        hasSuggestions: false
      },
      create(context) {
        const filename = context.getFilename();
        if (isPaceCoreSourceFile(filename)) {
          return {};
        }

        const setupRbacImportNames = new Set();

        return {
          ImportDeclaration(node) {
            if (node.source.value !== '@solvera/pace-core/rbac') return;
            for (const specifier of node.specifiers) {
              if (specifier.type === 'ImportSpecifier' && specifier.imported?.name === 'setupRBAC') {
                setupRbacImportNames.add(specifier.local?.name || 'setupRBAC');
              }
            }
          },
          CallExpression(node) {
            if (node.callee.type !== 'Identifier') return;
            if (!setupRbacImportNames.has(node.callee.name)) return;

            const configArg = node.arguments[1];
            if (!configArg || configArg.type !== 'ObjectExpression') {
              context.report({
                node,
                messageId: 'missingConfigObject'
              });
              return;
            }

            let appNameProperty = null;
            let getAppIdProperty = null;
            for (const property of configArg.properties) {
              if (property.type !== 'Property') continue;
              const keyName = getPropertyName(property);
              if (keyName === 'appName') appNameProperty = property;
              if (keyName === 'getAppId') getAppIdProperty = property;
            }

            if (!appNameProperty) {
              context.report({
                node: configArg,
                messageId: 'missingAppName'
              });
            }

            if (appNameProperty && !getAppIdProperty) {
              context.report({
                node: configArg,
                messageId: 'missingGetAppId'
              });
            }
          }
        };
      }
    },

    /**
     * Enforce canonical uppercase app-name literals and APP_NAME constant literals.
     * Dynamic values are validated by runtime/setup checks; this rule focuses on literals.
     */
    'canonical-app-name-uppercase': {
      meta: {
        type: 'problem',
        docs: {
          description: 'Require canonical uppercase app-name literals for appName and APP_NAME constants.',
          category: 'Security',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/3-security-rbac-standards.md'
        },
        messages: {
          nonCanonicalLiteral: "App name literal '{{appName}}' is not canonical uppercase. Use uppercase ASCII/underscore only (e.g. BASE, TEAM, PUMP).",
          nonCanonicalConstant: "APP_NAME literal '{{appName}}' is not canonical uppercase. Use uppercase ASCII/underscore only."
        },
        hasSuggestions: false
      },
      create(context) {
        const filename = context.getFilename();
        if (isPaceCoreSourceFile(filename)) {
          return {};
        }

        return {
          VariableDeclarator(node) {
            if (node.id.type !== 'Identifier' || node.id.name !== 'APP_NAME') return;
            const literalValue = getStringLiteralValue(node.init);
            if (literalValue == null) return;
            if (!isCanonicalUppercaseAppName(literalValue)) {
              context.report({
                node: node.init,
                messageId: 'nonCanonicalConstant',
                data: { appName: literalValue }
              });
            }
          },
          Property(node) {
            const keyName = getPropertyName(node);
            if (keyName !== 'appName') return;
            const literalValue = getStringLiteralValue(node.value);
            if (literalValue == null) return;
            if (!isCanonicalUppercaseAppName(literalValue)) {
              context.report({
                node: node.value,
                messageId: 'nonCanonicalLiteral',
                data: { appName: literalValue }
              });
            }
          },
          JSXAttribute(node) {
            if (node.name?.type !== 'JSXIdentifier' || node.name.name !== 'appName') return;
            if (!node.value) return;

            if (node.value.type === 'Literal' && typeof node.value.value === 'string') {
              if (!isCanonicalUppercaseAppName(node.value.value)) {
                context.report({
                  node: node.value,
                  messageId: 'nonCanonicalLiteral',
                  data: { appName: node.value.value }
                });
              }
              return;
            }

            if (node.value.type === 'JSXExpressionContainer') {
              const expr = node.value.expression;
              const literalValue = getStringLiteralValue(expr);
              if (literalValue != null && !isCanonicalUppercaseAppName(literalValue)) {
                context.report({
                  node: expr,
                  messageId: 'nonCanonicalLiteral',
                  data: { appName: literalValue }
                });
              }
            }
          }
        };
      }
    },

    /**
     * Disallow hardcoded role checks
     */
    'no-hardcoded-role-checks': {
      meta: {
        type: 'problem',
        docs: {
          description: 'Disallow hardcoded role checks. Use usePermissionLevel hook or getRoleContext API from pace-core instead.',
          category: 'Security',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/3-security-rbac-standards.md'
        },
        messages: {
          hardcodedRoleCheck: "Hardcoded role check detected. Use usePermissionLevel hook or getRoleContext API from '@solvera/pace-core/rbac' instead."
        },
        hasSuggestions: true
      },
      create(context) {
        const filename = context.getFilename();
        
        // Exclude pace-core source files - these rules are for consuming apps
        if (isPaceCoreSourceFile(filename)) {
          return {};
        }
        
        const roleNames = ['admin', 'org_admin', 'event_admin', 'user', 'member', 'viewer', 'editor'];
        const roleCheckPattern = new RegExp(
          `(?:role|user\\.role|userRole|currentRole|userRoleName)\\s*(?:===|!==|==|!=)\\s*['"](${roleNames.join('|')})['"]`,
          'i'
        );
        
        let hasPaceCoreImport = false;
        
        return {
          ImportDeclaration(node) {
            const importSource = node.source.value;
            if (importSource === '@solvera/pace-core/rbac' || 
                importSource.startsWith('@solvera/pace-core/rbac/')) {
              hasPaceCoreImport = true;
            }
          },
          BinaryExpression(node) {
            if (node.operator === '===' || node.operator === '!==' || node.operator === '==' || node.operator === '!=') {
              const sourceCode = context.getSourceCode();
              const leftText = sourceCode.getText(node.left);
              const rightText = sourceCode.getText(node.right);
              
              // Check if it's a role comparison
              if (roleCheckPattern.test(leftText + ' ' + node.operator + ' ' + rightText)) {
                // Check if using pace-core APIs
                if (!hasPaceCoreImport || 
                    (!leftText.includes('usePermissionLevel') && !leftText.includes('getRoleContext'))) {
                  context.report({
                    node,
                    messageId: 'hardcodedRoleCheck',
                    suggest: [{
                      desc: 'Use usePermissionLevel hook or getRoleContext API',
                      fix(fixer) {
                        return null;
                      }
                    }]
                  });
                }
              }
            }
          }
        };
      }
    },

    /**
     * Legacy rule retained as a no-op for backwards compatibility.
     * Runtime RBAC is DB-driven and useResourcePermissions now accepts canonical page-name strings.
     */
    'rbac-use-resource-names-constants': {
      meta: {
        type: 'suggestion',
        docs: {
          description: 'Legacy no-op rule: RESOURCE_NAMES constants were removed from runtime RBAC.',
          category: 'Best Practices',
          recommended: false,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/3-security-rbac-standards.md'
        },
        hasSuggestions: false
      },
      create(context) {
        return {};
      }
    },

    /**
     * Disallow wrapper components around PagePermissionGuard
     */
    'no-rbac-wrapper-components': {
      meta: {
        type: 'problem',
        docs: {
          description: 'Disallow wrapper components around PagePermissionGuard. Use PagePermissionGuard directly.',
          category: 'Security',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/3-security-rbac-standards.md'
        },
        messages: {
          wrapperComponent: "Wrapper component '{{componentName}}' detected around PagePermissionGuard. Must use PagePermissionGuard directly, not through wrappers."
        },
        hasSuggestions: true
      },
      create(context) {
        const filename = context.getFilename();
        
        // Allow in pace-core package itself
        if (filename.includes('packages/core/src/rbac') || filename.includes('packages\\core\\src\\rbac')) {
          return {};
        }
        
        let hasPagePermissionGuard = false;
        let wrapperComponentName = null;
        
        return {
          JSXOpeningElement(node) {
            if (node.name.type === 'JSXIdentifier' && node.name.name === 'PagePermissionGuard') {
              hasPagePermissionGuard = true;
              
              // Check if this is inside a wrapper component
              const sourceCode = context.sourceCode || context.getSourceCode();
              // ESLint 9: use sourceCode.getAncestors(node), ESLint 8: use context.getAncestors()
              const ancestors = sourceCode.getAncestors ? sourceCode.getAncestors(node) : (context.getAncestors ? context.getAncestors() : []);
              const componentAncestor = ancestors.find(ancestor => 
                ancestor.type === 'FunctionDeclaration' || 
                (ancestor.type === 'VariableDeclarator' && ancestor.init && 
                 (ancestor.init.type === 'ArrowFunctionExpression' || ancestor.init.type === 'FunctionExpression'))
              );
              
              if (componentAncestor) {
                let componentName = null;
                let componentParams = null;
                
                if (componentAncestor.type === 'FunctionDeclaration' && componentAncestor.id) {
                  componentName = componentAncestor.id.name;
                  componentParams = componentAncestor.params;
                } else if (componentAncestor.type === 'VariableDeclarator' && componentAncestor.id.type === 'Identifier') {
                  componentName = componentAncestor.id.name;
                  // For arrow functions and function expressions, get params from init
                  if (componentAncestor.init) {
                    if (componentAncestor.init.type === 'ArrowFunctionExpression' || 
                        componentAncestor.init.type === 'FunctionExpression') {
                      componentParams = componentAncestor.init.params;
                    }
                  }
                }
                
                // Check if component accepts pageName as a FUNCTION PARAMETER (not just uses it in JSX)
                // This distinguishes wrapper components from legitimate page components
                // Wrapper pattern: function Wrapper({ pageName }) { return <PagePermissionGuard pageName={pageName} operation="read"> }
                // Legitimate pattern: function Page() { return <PagePermissionGuard pageName={PAGE_NAMES.PAGE} operation="read"> }
                const acceptsPageNameAsParam = componentParams && componentParams.some(param => {
                  if (param.type === 'Identifier') {
                    return param.name === 'pageName';
                  }
                  // Handle destructured params: { pageName } or { pageName: pn }
                  if (param.type === 'ObjectPattern') {
                    return param.properties.some(prop => {
                      if (prop.type === 'Property') {
                        const key = prop.key;
                        if (key.type === 'Identifier') {
                          return key.name === 'pageName';
                        }
                      }
                      return false;
                    });
                  }
                  return false;
                });
                
                // Only flag if component accepts pageName as a parameter (wrapper pattern)
                // Legitimate page components use constants like PAGE_NAMES.CONTACTS, not accept it as prop
                if (acceptsPageNameAsParam) {
                  context.report({
                    node,
                    messageId: 'wrapperComponent',
                    data: {
                      componentName: componentName || 'Unknown'
                    },
                    suggest: [{
                      desc: 'Remove wrapper component and use PagePermissionGuard directly in pages',
                      fix(fixer) {
                        return null;
                      }
                    }]
                  });
                }
              }
            }
          }
        };
      }
    },

    /**
     * Disallow wrapper functions around permission hooks
     */
    'no-rbac-wrapper-functions': {
      meta: {
        type: 'problem',
        docs: {
          description: 'Disallow wrapper functions around pace-core permission hooks. Use hooks directly in components.',
          category: 'Security',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/3-security-rbac-standards.md'
        },
        messages: {
          wrapperFunction: "Permission wrapper function '{{functionName}}' detected. Use pace-core hooks (useCan, useResourcePermissions) directly in components instead of wrapping them."
        },
        hasSuggestions: true
      },
      create(context) {
        const filename = context.getFilename();
        
        // Exclude pace-core source files - these rules are for consuming apps
        if (isPaceCoreSourceFile(filename)) {
          return {};
        }
        
        const permissionHookNames = ['useCan', 'useResourcePermissions', 'usePermissions', 'useMultiplePermissions'];
        const permissionFunctionNames = ['canCreate', 'canUpdate', 'canDelete', 'canRead', 'can'];
        
        let hasPaceCoreRBACImport = false;
        
        return {
          ImportDeclaration(node) {
            const importSource = node.source.value;
            if (importSource === '@solvera/pace-core/rbac' || 
                importSource.startsWith('@solvera/pace-core/rbac/')) {
              hasPaceCoreRBACImport = true;
            }
          },
          FunctionDeclaration(node) {
            if (!node.id || !hasPaceCoreRBACImport) return;
            
            const functionName = node.id.name;
            if (!functionName) return;
            
            // Check if function body uses permission hooks/functions
            const sourceCode = context.getSourceCode();
            const functionText = sourceCode.getText(node.body);
            
            // Check if function uses permission hooks or functions
            const usesPermissionHooks = permissionHookNames.some(hook => functionText.includes(hook));
            const usesPermissionFunctions = permissionFunctionNames.some(fn => functionText.includes(fn));
            
            // Check if function has additional logic beyond permission checking
            const hasAdditionalLogic = (
              functionText.includes('&&') ||
              functionText.includes('||') ||
              functionText.includes('if') ||
              (functionText.match(/return/g) || []).length > 1 ||
              functionText.includes('.find') ||
              functionText.includes('.filter') ||
              functionText.includes('.map')
            );
            
            // Pattern: Functions that start with 'can' and use permission hooks/functions
            // and have additional logic
            const isPermissionWrapper = (
              (functionName.toLowerCase().startsWith('can') || 
               functionName.toLowerCase().includes('permission') ||
               functionName.toLowerCase().includes('access')) &&
              (usesPermissionHooks || usesPermissionFunctions) &&
              hasAdditionalLogic &&
              node.params.length > 0
            );
            
            if (isPermissionWrapper) {
              context.report({
                node: node.id,
                messageId: 'wrapperFunction',
                data: {
                  functionName
                },
                suggest: [{
                  desc: 'Use permission hooks directly in components',
                  fix(fixer) {
                    return null;
                  }
                }]
              });
            }
          },
          VariableDeclarator(node) {
            if (!hasPaceCoreRBACImport) return;
            if (node.id.type !== 'Identifier') return;
            
            const varName = node.id.name;
            if (!varName) return;
            
            // Only check arrow functions and function expressions
            if (!node.init || 
                (node.init.type !== 'ArrowFunctionExpression' && 
                 node.init.type !== 'FunctionExpression')) {
              return;
            }
            
            const sourceCode = context.getSourceCode();
            const functionText = sourceCode.getText(node.init);
            
            // Check if function uses permission hooks or functions
            const usesPermissionHooks = permissionHookNames.some(hook => functionText.includes(hook));
            const usesPermissionFunctions = permissionFunctionNames.some(fn => functionText.includes(fn));
            
            // Check if function has additional logic beyond permission checking
            const hasAdditionalLogic = (
              functionText.includes('&&') ||
              functionText.includes('||') ||
              functionText.includes('if') ||
              (functionText.match(/return/g) || []).length > 1 ||
              functionText.includes('.find') ||
              functionText.includes('.filter') ||
              functionText.includes('.map')
            );
            
            // Pattern: Variables that start with 'can' and use permission hooks/functions
            // and have additional logic
            const isPermissionWrapper = (
              (varName.toLowerCase().startsWith('can') || 
               varName.toLowerCase().includes('permission') ||
               varName.toLowerCase().includes('access')) &&
              (usesPermissionHooks || usesPermissionFunctions) &&
              hasAdditionalLogic &&
              node.init.params && node.init.params.length > 0
            );
            
            if (isPermissionWrapper) {
              context.report({
                node: node.id,
                messageId: 'wrapperFunction',
                data: {
                  functionName: varName
                },
                suggest: [{
                  desc: 'Use permission hooks directly in components',
                  fix(fixer) {
                    return null;
                  }
                }]
              });
            }
          }
        };
      }
    },

    /**
     * Require derived organisationId when both selectedOrganisation and selectedEvent are in scope.
     * Prevents incorrect org resolution when event is selected without an explicit org (e.g. RPCs
     * getting undefined instead of selectedEvent.organisation_id).
     */
    'require-derived-organisation-id': {
      meta: {
        type: 'problem',
        docs: {
          description: 'When both selectedOrganisation and selectedEvent are in scope, use a derived organisationId (selectedOrganisation?.id ?? selectedEvent?.organisation_id) for p_organisation_id, organisation_id, and selectedOrganisationId so org is resolved correctly when an event is selected without an explicit org.',
          category: 'Security',
          recommended: true,
          url: 'https://github.com/solvera/pace-core/blob/main/packages/core/docs/standards/3-security-rbac-standards.md'
        },
        messages: {
          useDerivedOrgId: "Organisation context ({{key}}) is set from selectedOrganisation?.id while selectedEvent is in scope. Use a derived organisationId (e.g. selectedOrganisation?.id ?? selectedEvent?.organisation_id) so org is resolved correctly when an event is selected without an explicit org."
        },
        schema: []
      },
      create(context) {
        const filename = context.getFilename();
        if (isPaceCoreSourceFile(filename)) {
          return {};
        }
        const sourceCode = context.getSourceCode();
        const fileText = sourceCode.getText();
        const hasOrg = /\bselectedOrganisation\b|useOrganisations\s*\(/.test(fileText);
        const hasEvent = /\bselectedEvent\b|useEvents\s*\(/.test(fileText);
        if (!hasOrg || !hasEvent) {
          return {};
        }

        const orgParamKeys = new Set(['p_organisation_id', 'organisation_id', 'selectedOrganisationId']);

        return {
          Property(node) {
            const keyName = node.key && (node.key.name || (node.key.type === 'Literal' && node.key.value));
            if (!keyName || !orgParamKeys.has(keyName)) return;
            const value = node.value;
            if (!value) return;
            let usesSelectedOrgId = false;
            if (value.type === 'MemberExpression' || value.type === 'OptionalMemberExpression') {
              const obj = value.object;
              const prop = value.property;
              if (obj.type === 'Identifier' && obj.name === 'selectedOrganisation' &&
                  prop && (prop.name === 'id' || (prop.type === 'Literal' && prop.value === 'id'))) {
                usesSelectedOrgId = true;
              }
            }
            if (value.type === 'LogicalExpression' && value.operator === '||') {
              const left = value.left;
              const right = value.right;
              const check = (n) => n.type === 'MemberExpression' && n.object.type === 'Identifier' &&
                n.object.name === 'selectedOrganisation' && n.property && n.property.name === 'id';
              if (check(left) || check(right)) usesSelectedOrgId = true;
            }
            if (usesSelectedOrgId) {
              context.report({
                node: value,
                messageId: 'useDerivedOrgId',
                data: { key: keyName },
                suggest: [{
                  desc: 'Use derived organisationId (selectedOrganisation?.id ?? selectedEvent?.organisation_id)',
                  fix(fixer) {
                    return null;
                  }
                }]
              });
            }
          }
        };
      }
    }
  }
};

