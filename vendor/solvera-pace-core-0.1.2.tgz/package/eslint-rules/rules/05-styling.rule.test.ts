import { describe, expect, it } from 'vitest';
import { Linter } from 'eslint';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const stylingRules = require('./05-styling.cjs');

const REDUNDANT_WRAPPER_RULE = 'pace-core-compliance/no-redundant-card-subcomponent-wrapper';
const PERSISTENCE_SAVE_LABEL_RULE = 'pace-core-compliance/persistence-save-label';
const PERSISTENCE_SAVE_PLACEMENT_RULE = 'pace-core-compliance/persistence-save-placement';
const DIRECTORY_CARD_LIST_GRID_RULE = 'pace-core-compliance/no-directory-card-list-grid';

function runRule(ruleId: string, code: string, filename = 'src/pages/UIShowcasePage.tsx') {
  const linter = new Linter({ configType: 'eslintrc' });
  const localRuleId = ruleId.replace('pace-core-compliance/', '');
  linter.defineRule(ruleId, stylingRules.rules[localRuleId]);

  return linter.verify(
    code,
    {
      parserOptions: {
        ecmaVersion: 2022,
        sourceType: 'module',
        ecmaFeatures: { jsx: true },
      },
      rules: {
        [ruleId]: 'error',
      },
    },
    filename
  );
}

describe('no-redundant-card-subcomponent-wrapper', () => {
  it('reports a single layout-only wrapper inside CardFooter', () => {
    const messages = runRule(REDUNDANT_WRAPPER_RULE, `
      function Demo() {
        return (
          <CardFooter>
            <section className="grid grid-flow-col auto-cols-max gap-2">
              <Avatar name="A" />
              <Avatar name="B" />
            </section>
          </CardFooter>
        );
      }
    `);

    expect(messages).toHaveLength(1);
    expect(messages[0]?.ruleId).toBe(REDUNDANT_WRAPPER_RULE);
  });

  it('supports variant-prefixed layout classes when detecting wrapper-only layouts', () => {
    const messages = runRule(REDUNDANT_WRAPPER_RULE, `
      function Demo() {
        return (
          <CardContent>
            <section className="grid md:grid-cols-2 gap-2">
              <Alert />
              <Alert />
            </section>
          </CardContent>
        );
      }
    `);

    expect(messages).toHaveLength(1);
    expect(messages[0]?.ruleId).toBe(REDUNDANT_WRAPPER_RULE);
  });

  it('does not report when layout classes are applied directly to CardFooter', () => {
    const messages = runRule(REDUNDANT_WRAPPER_RULE, `
      function Demo() {
        return (
          <CardFooter className="grid grid-flow-col auto-cols-max gap-2">
            <Avatar name="A" />
            <Avatar name="B" />
          </CardFooter>
        );
      }
    `);

    expect(messages).toHaveLength(0);
  });

  it('does not report wrappers that include non-layout styling classes', () => {
    const messages = runRule(REDUNDANT_WRAPPER_RULE, `
      function Demo() {
        return (
          <CardFooter>
            <section className="grid gap-2 bg-main-50">
              <Avatar name="A" />
            </section>
          </CardFooter>
        );
      }
    `);

    expect(messages).toHaveLength(0);
  });
});

describe('persistence-save-label', () => {
  it('reports non-Save labels in approved persistence containers', () => {
    const messages = runRule(PERSISTENCE_SAVE_LABEL_RULE, `
      function Demo() {
        return (
          <DialogFooter>
            <Button type="submit">Submit</Button>
          </DialogFooter>
        );
      }
    `);

    expect(messages).toHaveLength(1);
    expect(messages[0]?.ruleId).toBe(PERSISTENCE_SAVE_LABEL_RULE);
  });

  it('does not report when label is Save in approved containers', () => {
    const messages = runRule(PERSISTENCE_SAVE_LABEL_RULE, `
      function Demo() {
        return (
          <CardFooter>
            <Button type="submit">Save</Button>
          </CardFooter>
        );
      }
    `);

    expect(messages).toHaveLength(0);
  });

  it('does not report non-persistence auth labels in centered footer', () => {
    const messages = runRule(PERSISTENCE_SAVE_LABEL_RULE, `
      function Demo() {
        return (
          <CardFooter className="grid justify-items-center">
            <Button type="submit">Sign in</Button>
          </CardFooter>
        );
      }
    `);

    expect(messages).toHaveLength(0);
  });

  it('does not report Book submit labels in DialogFooter (booking flows)', () => {
    const messages = runRule(PERSISTENCE_SAVE_LABEL_RULE, `
      function Demo() {
        return (
          <DialogFooter>
            <Button type="submit">Book</Button>
          </DialogFooter>
        );
      }
    `);

    expect(messages).toHaveLength(0);
  });
});

const NO_INLINE_STYLES_RULE = 'pace-core-compliance/no-inline-styles';

describe('no-inline-styles', () => {
  it('allows @dnd-kit sortable style variable binding', () => {
    const messages = runRule(NO_INLINE_STYLES_RULE, `
      function Row({ style }) {
        return <article style={style}>Row</article>;
      }
    `);

    expect(messages).toHaveLength(0);
  });

  it('allows transform/transition-only inline objects', () => {
    const messages = runRule(NO_INLINE_STYLES_RULE, `
      function Row() {
        return <article style={{ transform: 'translateY(0)', transition: 'transform 200ms' }}>Row</article>;
      }
    `);

    expect(messages).toHaveLength(0);
  });

  it('reports arbitrary inline style objects', () => {
    const messages = runRule(NO_INLINE_STYLES_RULE, `
      function Row() {
        return <article style={{ color: 'red' }}>Row</article>;
      }
    `);

    expect(messages).toHaveLength(1);
    expect(messages[0]?.ruleId).toBe(NO_INLINE_STYLES_RULE);
  });
});

describe('persistence-save-placement', () => {
  it('reports Save submit actions outside approved footer-right containers', () => {
    const messages = runRule(PERSISTENCE_SAVE_PLACEMENT_RULE, `
      function Demo() {
        return (
          <form>
            <Button type="submit">Save</Button>
          </form>
        );
      }
    `);

    expect(messages).toHaveLength(1);
    expect(messages[0]?.ruleId).toBe(PERSISTENCE_SAVE_PLACEMENT_RULE);
  });

  it('does not report Save submit actions in DialogFooter', () => {
    const messages = runRule(PERSISTENCE_SAVE_PLACEMENT_RULE, `
      function Demo() {
        return (
          <DialogFooter>
            <Button type="submit">Save</Button>
          </DialogFooter>
        );
      }
    `);

    expect(messages).toHaveLength(0);
  });

  it('does not report SaveActions internal submit button in SaveActions file', () => {
    const messages = runRule(
      PERSISTENCE_SAVE_PLACEMENT_RULE,
      `
      export function SaveActions() {
        return (
          <fieldset>
            <Button type="submit">Save</Button>
          </fieldset>
        );
      }
      `,
      'packages/core/src/components/SaveActions.tsx'
    );

    expect(messages).toHaveLength(0);
  });
});

describe('no-directory-card-list-grid', () => {
  it('reports ul with column grid classes', () => {
    const messages = runRule(DIRECTORY_CARD_LIST_GRID_RULE, `
      function Demo() {
        return (
          <ul className="grid list-none grid-cols-3 gap-4">
            <li><article>Card</article></li>
          </ul>
        );
      }
    `);

    expect(messages).toHaveLength(1);
    expect(messages[0]?.ruleId).toBe(DIRECTORY_CARD_LIST_GRID_RULE);
  });

  it('does not report section column grids', () => {
    const messages = runRule(DIRECTORY_CARD_LIST_GRID_RULE, `
      function Demo() {
        return (
          <section className="grid grid-cols-3 gap-4">
            <article>Card</article>
          </section>
        );
      }
    `);

    expect(messages).toHaveLength(0);
  });

  it('does not report inline chip rows with grid-flow-col', () => {
    const messages = runRule(DIRECTORY_CARD_LIST_GRID_RULE, `
      function Demo() {
        return (
          <ul className="inline-grid list-none grid-flow-col auto-cols-max gap-1.5">
            <li>Chip</li>
          </ul>
        );
      }
    `);

    expect(messages).toHaveLength(0);
  });

  it('does not report palette swatch grids with grid-cols-12', () => {
    const messages = runRule(DIRECTORY_CARD_LIST_GRID_RULE, `
      function Demo() {
        return (
          <ul className="grid grid-cols-12 list-none gap-1">
            <li>Swatch</li>
          </ul>
        );
      }
    `);

    expect(messages).toHaveLength(0);
  });
});
