import { describe, expect, it } from 'vitest';
import { Linter } from 'eslint';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const apiTechStackRules = require('./07-api-tech-stack.cjs');

const RULE_ID = 'pace-core-compliance/rpc-naming-pattern';

function runRpcNamingRule(code: string, filename = 'src/features/EventsPage.tsx') {
  const linter = new Linter({ configType: 'eslintrc' });
  linter.defineRules(
    Object.fromEntries(
      Object.entries(apiTechStackRules.rules).map(([name, rule]) => [
        `pace-core-compliance/${name}`,
        rule,
      ])
    )
  );

  return linter.verify(
    code,
    {
      parserOptions: {
        ecmaVersion: 2022,
        sourceType: 'module',
      },
      rules: {
        [RULE_ID]: 'warn',
      },
    },
    filename
  );
}

describe('rpc-naming-pattern', () => {
  it('does not report pump_* platform contract RPCs', () => {
    const messages = runRpcNamingRule(`
      async function load(service) {
        await service.rpc('pump_list_merge_fields', { organisation_id: 'org-1' });
        await service.rpc('pump_get_effective_sender_identity', { organisation_id: 'org-1' });
      }
    `);

    expect(messages.filter((m) => m.ruleId === RULE_ID)).toHaveLength(0);
  });

  it('does not report rbac_* platform RPCs', () => {
    const messages = runRpcNamingRule(`
      async function load(service) {
        await service.rpc('rbac_get_permission_map', { organisation_id: 'org-1' });
      }
    `);

    expect(messages.filter((m) => m.ruleId === RULE_ID)).toHaveLength(0);
  });

  it('does not report base_* platform contract RPCs', () => {
    const messages = runRpcNamingRule(`
      async function load(service) {
        await service.rpc('base_application_is_applicant', {
          p_application_id: 'app-1',
          p_user_id: 'user-1',
        });
      }
    `);

    expect(messages.filter((m) => m.ruleId === RULE_ID)).toHaveLength(0);
  });

  it('does not report set_organisation_context session RPC', () => {
    const messages = runRpcNamingRule(`
      async function setCtx(client) {
        await client.rpc('set_organisation_context', {
          p_organisation_id: 'org-1',
          p_event_id: null,
          p_app_id: null,
        });
      }
    `);

    expect(messages.filter((m) => m.ruleId === RULE_ID)).toHaveLength(0);
  });

  it('reports app-defined RPCs missing data_ or app_ prefix', () => {
    const messages = runRpcNamingRule(`
      async function load(service) {
        await service.rpc('events_list', {});
      }
    `);

    expect(messages.some((m) => m.ruleId === RULE_ID)).toBe(true);
  });

  it('does not false-positive on app_* resolve write RPCs', () => {
    const messages = runRpcNamingRule(`
      async function load(service) {
        await service.rpc('app_resolve_member_request', {
          p_request_id: 'id',
          p_status: 'approved',
        });
      }
    `);

    expect(messages.filter((m) => m.ruleId === RULE_ID)).toHaveLength(0);
  });

  it('does not false-positive on app_base_application_check_set_status write RPCs', () => {
    const messages = runRpcNamingRule(`
      async function load(service) {
        await service.rpc('app_base_application_check_set_status', { p_check_id: 'id', p_status: 'satisfied' });
        await service.rpc('app_base_application_check_reissue_token', { p_check_id: 'id' });
      }
    `);

    expect(messages.filter((m) => m.ruleId === RULE_ID)).toHaveLength(0);
  });
});
