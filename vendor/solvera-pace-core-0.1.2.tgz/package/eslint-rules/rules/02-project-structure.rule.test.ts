import { describe, expect, it } from 'vitest';
import { Linter } from 'eslint';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const projectStructureRules = require('./02-project-structure.cjs');

const RBAC_PAGE_NAME_RULE = 'pace-core-compliance/rbac-page-name-convention';
const ROUTE_PATH_RULE = 'pace-core-compliance/route-path-kebab-case';
const LEGACY_PAGE_NAME_RULE = 'pace-core-compliance/legacy-rbac-page-name';

function runRule(ruleId: string, code: string, filename = 'src/pages/DashboardPage.tsx') {
  const linter = new Linter({ configType: 'eslintrc' });
  const localRuleId = ruleId.replace('pace-core-compliance/', '');
  linter.defineRule(ruleId, projectStructureRules.rules[localRuleId]);

  return linter.verify(
    code,
    {
      parserOptions: {
        ecmaVersion: 2022,
        sourceType: 'module',
        ecmaFeatures: { jsx: true },
      },
      rules: {
        [ruleId]: 'error',
      },
    },
    filename
  );
}

describe('rbac-page-name-convention', () => {
  it('accepts PascalCase pageName matching file stem', () => {
    const messages = runRule(
      RBAC_PAGE_NAME_RULE,
      `
      function Page() {
        return <PagePermissionGuard pageName="DashboardPage" operation="read"><p>x</p></PagePermissionGuard>;
      }
    `
    );
    expect(messages).toHaveLength(0);
  });

  it('reports legacy kebab-case pageName', () => {
    const messages = runRule(
      RBAC_PAGE_NAME_RULE,
      `
      function Page() {
        return <PagePermissionGuard pageName="dashboard" operation="read"><p>x</p></PagePermissionGuard>;
      }
    `
    );
    expect(messages.length).toBeGreaterThan(0);
    expect(messages[0]?.ruleId).toBe(RBAC_PAGE_NAME_RULE);
  });

  it('reports legacy kebab-case pageName in JSX expression form', () => {
    const messages = runRule(
      RBAC_PAGE_NAME_RULE,
      `
      function Page() {
        return <PagePermissionGuard pageName={'dashboard'} operation="read"><p>x</p></PagePermissionGuard>;
      }
    `
    );
    expect(messages.length).toBeGreaterThan(0);
    expect(messages[0]?.ruleId).toBe(RBAC_PAGE_NAME_RULE);
  });

  it('accepts PascalCase pageName in JSX expression form matching file stem', () => {
    const messages = runRule(
      RBAC_PAGE_NAME_RULE,
      `
      function Page() {
        return <PagePermissionGuard pageName={'DashboardPage'} operation="read"><p>x</p></PagePermissionGuard>;
      }
    `
    );
    expect(messages).toHaveLength(0);
  });

  it('accepts shared BASE catalogue pageName on sibling route modules', () => {
    const sharedCases = [
      {
        filename: 'src/pages/activities/ActivityOfferingPage.tsx',
        pageName: 'ActivitiesPage',
      },
      {
        filename: 'src/pages/registrationTypes/RegistrationTypeBuilderPage.tsx',
        pageName: 'RegistrationTypesPage',
      },
      {
        filename: 'src/pages/forms/FormBuilderPage.tsx',
        pageName: 'RegistrationTypesPage',
      },
      {
        filename: 'src/pages/scanning/ScanningTrackingPage.tsx',
        pageName: 'ScanningPage',
      },
      {
        filename: 'src/pages/forms/FormsListPage.tsx',
        pageName: 'FormsPage',
      },
    ];

    for (const { filename, pageName } of sharedCases) {
      const messages = runRule(
        RBAC_PAGE_NAME_RULE,
        `
        function Page() {
          return <PagePermissionGuard pageName="${pageName}" operation="read"><p>x</p></PagePermissionGuard>;
        }
      `,
        filename
      );
      expect(messages).toHaveLength(0);
    }
  });
});

describe('route-path-kebab-case', () => {
  it('accepts kebab-case route paths', () => {
    const messages = runRule(
      ROUTE_PATH_RULE,
      `
      function App() {
        return <Route path="/member-roles" element={<section />} />;
      }
    `,
      'src/App.tsx'
    );
    expect(messages).toHaveLength(0);
  });

  it('reports PascalCase route segments', () => {
    const messages = runRule(
      ROUTE_PATH_RULE,
      `
      function App() {
        return <Route path="/MemberRoles" element={<section />} />;
      }
    `,
      'src/App.tsx'
    );
    expect(messages.length).toBeGreaterThan(0);
    expect(messages[0]?.ruleId).toBe(ROUTE_PATH_RULE);
  });

  it('reports PascalCase route segments in JSX expression form', () => {
    const messages = runRule(
      ROUTE_PATH_RULE,
      `
      function App() {
        return <Route path={'/MemberRoles'} element={<section />} />;
      }
    `,
      'src/App.tsx'
    );
    expect(messages.length).toBeGreaterThan(0);
    expect(messages[0]?.ruleId).toBe(ROUTE_PATH_RULE);
  });

  it('accepts catch-all Route paths', () => {
    const messages = runRule(
      ROUTE_PATH_RULE,
      `
      function App() {
        return <Route path="*" element={<section />} />;
      }
    `,
      'src/App.tsx'
    );
    expect(messages).toHaveLength(0);
  });

  it('ignores non-router path object properties', () => {
    const messages = runRule(
      ROUTE_PATH_RULE,
      `
      const field = { path: 'metadata.closesAt' };
      const upload = { path: 'p/file.pdf' };
    `,
      'src/forms/workflow/validateWorkflowAuthoringState.ts'
    );
    expect(messages).toHaveLength(0);
  });
});

describe('legacy-rbac-page-name', () => {
  it('warns on legacy catalogue strings', () => {
    const linter = new Linter({ configType: 'eslintrc' });
    linter.defineRule(LEGACY_PAGE_NAME_RULE, projectStructureRules.rules['legacy-rbac-page-name']);
    const messages = linter.verify(
      `
      function Page() {
        return <PagePermissionGuard pageName="dashboard" operation="read"><p>x</p></PagePermissionGuard>;
      }
    `,
      {
        parserOptions: {
          ecmaVersion: 2022,
          sourceType: 'module',
          ecmaFeatures: { jsx: true },
        },
        rules: {
          [LEGACY_PAGE_NAME_RULE]: 'warn',
        },
      },
      'src/pages/DashboardPage.tsx'
    );
    expect(messages.length).toBeGreaterThan(0);
    expect(messages[0]?.ruleId).toBe(LEGACY_PAGE_NAME_RULE);
  });
});
