/**
 * Main entry point for pace-core ESLint rules
 * @package @solvera/pace-core
 * @module ESLintRules
 * 
 * This module exports all pace-core ESLint rules organized by standards.
 * Rules are organized to match the 10-file standards structure.
 * 
 * Reference: packages/core/docs/standards/README.md
 */

const paceCoreComplianceRules = require('./rules/01-pace-core-compliance.cjs');
const projectStructureRules = require('./rules/02-project-structure.cjs');
const architectureRules = require('./rules/03-architecture.cjs');
const codeQualityRules = require('./rules/04-code-quality.cjs');
const stylingRules = require('./rules/05-styling.cjs');
const securityRbacRules = require('./rules/06-security-rbac.cjs');
const apiTechStackRules = require('./rules/07-api-tech-stack.cjs');
const testingRules = require('./rules/08-testing.cjs');
const operationsRules = require('./rules/09-operations.cjs');
const paceCoreAuthoringRules = require('./rules/10-pace-core-authoring.cjs');

module.exports = {
  rules: {
    // Standard 1: pace-core Compliance
    ...paceCoreComplianceRules.rules,
    // Standard 2: Project Structure
    ...projectStructureRules.rules,
    // Standard 3: Architecture
    ...architectureRules.rules,
    // Standard 4: Code Quality
    ...codeQualityRules.rules,
    // Standard 07: Visual (styling / markup — 7-visual-standards.md)
    ...stylingRules.rules,
    // Standard 6: Security & RBAC
    ...securityRbacRules.rules,
    // Standard 7: API & Tech Stack
    ...apiTechStackRules.rules,
    // Standard 8: Testing
    ...testingRules.rules,
    // Standard 9: Operations
    ...operationsRules.rules,
    // pace-core package component authoring
    ...paceCoreAuthoringRules.rules,
  }
};

