#!/usr/bin/env node
const assert = require('node:assert/strict');
const path = require('node:path');
const { test } = require('node:test');
const { RuleTester } = require('eslint');
const paceCoreAuthoring = require('../rules/10-pace-core-authoring.cjs');

const tester = new RuleTester({
  languageOptions: {
    ecmaVersion: 2022,
    sourceType: 'module',
    parserOptions: { ecmaFeatures: { jsx: true } },
  },
});

test('prefer-cn-class-merge flags manual join pattern', () => {
  tester.run('prefer-cn-class-merge', paceCoreAuthoring.rules['prefer-cn-class-merge'], {
    valid: [
      {
        filename: path.join(process.cwd(), 'packages/core/src/components/primitives/Badge.tsx'),
        code: "const classes = cn('a', className);",
      },
    ],
    invalid: [
      {
        filename: path.join(process.cwd(), 'packages/core/src/components/primitives/Badge.tsx'),
        code: "const classes = ['a', className].filter(Boolean).join(' ');",
        errors: [{ messageId: 'preferCn' }],
      },
    ],
  });
});

test('max-named-exports-package flags large export surface', () => {
  tester.run(
    'max-named-exports-package',
    paceCoreAuthoring.rules['max-named-exports-package'],
    {
      valid: [
        {
          filename: path.join(process.cwd(), 'packages/core/src/components/primitives/Button.tsx'),
          code: 'export function Button() {}\nexport type ButtonProps = {};',
        },
      ],
      invalid: [
        {
          filename: path.join(process.cwd(), 'packages/core/src/components/primitives/Button.tsx'),
          code: Array.from({ length: 11 }, (_, index) => `export const e${index} = ${index};`).join('\n'),
          errors: [{ messageId: 'tooMany' }],
        },
      ],
    },
  );
});
