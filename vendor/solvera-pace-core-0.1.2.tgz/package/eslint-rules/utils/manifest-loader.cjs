/**
 * Shared utility for pace-core compliance lists.
 * @package @solvera/pace-core
 * @module ESLintRules/utils/manifest-loader
 */

const DEFAULT_MANIFEST = {
  restrictedImports: [
    { module: '@radix-ui/react-avatar', reason: 'Use Avatar component from pace-core instead' },
    { module: '@radix-ui/react-checkbox', reason: 'Use Checkbox component from pace-core instead' },
    { module: '@radix-ui/react-dialog', reason: 'Use Dialog component from pace-core instead' },
    { module: '@radix-ui/react-label', reason: 'Use Label component from pace-core instead' },
    { module: '@radix-ui/react-slot', reason: 'Use Button component from pace-core which handles slot composition' },
    { module: '@radix-ui/react-switch', reason: 'Use Switch component from pace-core instead' },
    { module: '@radix-ui/react-tabs', reason: 'Use Tabs component from pace-core instead' },
    { module: '@radix-ui/react-toast', reason: 'Use Toast component and useToast hook from pace-core instead' },
    { module: '@radix-ui/react-tooltip', reason: 'Use Tooltip component from pace-core instead' },
    { module: 'react-day-picker', reason: 'Use Calendar component from pace-core instead' },
    { module: '@tanstack/react-table', reason: 'Use DataTable component and related hooks from pace-core instead. DataTable wraps and standardizes table functionality' },
    { module: 'react-hook-form', reason: 'Use Form component and useZodForm hook from pace-core instead' },
    { module: 'zod', reason: 'Use validation utilities and schemas from pace-core instead. pace-core provides standardized validation helpers' },
  ],
  components: [
    'Button', 'Card', 'Dialog', 'Input', 'Form', 'Select', 'Alert', 'Badge', 'Checkbox',
    'Switch', 'Textarea', 'Label', 'Table', 'DataTable', 'Toast', 'Tooltip', 'Tabs', 'Calendar',
    'Avatar', 'Progress',
  ],
  hooks: [
    'useToast', 'useDebounce', 'useUnifiedAuth', 'useEvents', 'useOrganisations',
    'useFileReference', 'useStorage', 'useZodForm', 'useRBAC', 'usePermissions',
  ],
  utils: [
    'formatDate', 'formatCurrency', 'formatNumber', 'formatTime', 'formatDateTime', 'cn',
    'validateUserInput', 'sanitizeUserInput', 'hasPermission', 'getAppConfig',
  ],
};

// Get restricted imports from manifest or use defaults
const getRestrictedImports = () => {
  return DEFAULT_MANIFEST.restrictedImports;
};

// Get pace-core components from manifest or use defaults
const getPaceCoreComponents = () => {
  return DEFAULT_MANIFEST.components;
};

// Get pace-core hooks from manifest or use defaults
const getPaceCoreHooks = () => {
  return DEFAULT_MANIFEST.hooks;
};

// Get pace-core utils from manifest or use defaults
const getPaceCoreUtils = () => {
  return DEFAULT_MANIFEST.utils;
};

module.exports = {
  getRestrictedImports,
  getPaceCoreComponents,
  getPaceCoreHooks,
  getPaceCoreUtils,
};

