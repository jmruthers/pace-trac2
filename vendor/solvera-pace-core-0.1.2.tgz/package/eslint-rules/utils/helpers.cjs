/**
 * Shared helper functions for ESLint rules
 * @package @solvera/pace-core
 * @module ESLintRules/utils/helpers
 */

// Helper function to get pace-core alternative for restricted imports
function getPaceCoreAlternative(importSource) {
  const alternatives = {
    '@radix-ui/react-avatar': '/components',
    '@radix-ui/react-checkbox': '/components',
    '@radix-ui/react-dialog': '/components',
    '@radix-ui/react-label': '/components',
    '@radix-ui/react-switch': '/components',
    '@radix-ui/react-tabs': '/components',
    '@radix-ui/react-toast': '/components',
    '@radix-ui/react-tooltip': '/components',
    'react-day-picker': '/components',
    '@tanstack/react-table': '/components',
    'react-hook-form': '/components',
    'zod': '/utils'
  };
  
  return alternatives[importSource] || '';
}

/**
 * Check if a file is in the pace-core source directory
 * @param {string} filename - The file path to check
 * @returns {boolean} - True if the file is in packages/core/src
 */
function isPaceCoreSourceFile(filename) {
  // Check for both Unix and Windows path separators
  return filename.includes('packages/core/src') || filename.includes('packages\\core\\src');
}

function normalizePath(filename) {
  return filename.replace(/\\/g, '/');
}

/** Grandfathered non-PascalCase module filenames (see Standard 1 legacy component module filenames). */
const LEGACY_COMPONENT_FILENAME_ALLOWLIST = [
  'columnFactory.tsx',
  'createFieldRegistry.tsx',
  'adapters.tsx',
];

const UTILITY_EXPORT_PREFIXES = [
  'handle',
  'on',
  'get',
  'set',
  'load',
  'read',
  'create',
  'update',
  'delete',
  'with',
  'use',
  'should',
  'render',
  'parse',
  'resolve',
  'listbox',
  'toast',
  'are',
  'build',
];

function isTestTsxFile(filename) {
  const normalized = normalizePath(filename);
  return /\.(test|integration\.test)\.tsx$/.test(normalized);
}

function isBootstrapTsxFile(filename) {
  const normalized = normalizePath(filename);
  return /\/(main|App)\.tsx$/.test(normalized);
}

function isLegacyComponentFilename(filename) {
  const normalized = normalizePath(filename);
  return LEGACY_COMPONENT_FILENAME_ALLOWLIST.some((entry) => normalized.endsWith(entry));
}

/**
 * Modules where exported React components are subject to PascalCase naming rules.
 */
function isComponentNamingScopeFile(filename) {
  const normalized = normalizePath(filename);
  if (!normalized.endsWith('.tsx')) return false;
  if (isTestTsxFile(normalized) || isBootstrapTsxFile(normalized)) return false;

  if (/(components|Components)\//.test(normalized)) return true;
  if (/\/packages\/core\/src\/(rbac|comms|forms)\//.test(normalized)) return true;
  if (/\/src\/(rbac|comms|forms)\//.test(normalized)) return true;

  return false;
}

function isUtilityExportName(name) {
  return UTILITY_EXPORT_PREFIXES.some((prefix) => name.startsWith(prefix));
}

function returnsJsx(functionText) {
  return functionText.includes('return') && (functionText.includes('<') || functionText.includes('createElement'));
}

function isPascalCaseIdentifier(name) {
  return /^[A-Z][a-zA-Z0-9]*$/.test(name);
}

function getTsxFileStem(filename) {
  const base = normalizePath(filename).split('/').pop() ?? '';
  return base.replace(/\.tsx$/, '');
}

function isExportedDeclaration(node) {
  return (
    node.parent?.type === 'ExportNamedDeclaration' ||
    node.parent?.type === 'ExportDefaultDeclaration' ||
    node.parent?.parent?.type === 'ExportNamedDeclaration' ||
    node.parent?.parent?.type === 'ExportDefaultDeclaration'
  );
}

module.exports = {
  getPaceCoreAlternative,
  isPaceCoreSourceFile,
  LEGACY_COMPONENT_FILENAME_ALLOWLIST,
  isTestTsxFile,
  isBootstrapTsxFile,
  isLegacyComponentFilename,
  isComponentNamingScopeFile,
  isUtilityExportName,
  returnsJsx,
  isPascalCaseIdentifier,
  getTsxFileStem,
  isExportedDeclaration,
};

