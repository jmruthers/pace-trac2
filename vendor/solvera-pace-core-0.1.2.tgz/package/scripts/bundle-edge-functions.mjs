#!/usr/bin/env node
/* eslint-env node */
/**
 * Bundle Supabase Edge Function entrypoints for Deno deploy.
 *
 * Source (committed): supabase/functions/<slug>/index.source.ts
 * Output (gitignored): supabase/functions/<slug>/index.ts
 *
 * Resolves pace-core src/comms `.js` import specifiers via esbuild; Supabase CLI
 * cannot bundle ../../../src/comms directly.
 */
import * as esbuild from 'esbuild';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const scriptDir = path.dirname(fileURLToPath(import.meta.url));
const packageRoot = path.resolve(scriptDir, '..');
const functionsDir = path.join(packageRoot, 'supabase', 'functions');

const denoExternalPlugin = {
  name: 'deno-npm-external',
  setup(build) {
    build.onResolve({ filter: /^@supabase\/supabase-js$/ }, () => ({
      path: 'npm:@supabase/supabase-js@2',
      external: true,
    }));
    build.onResolve({ filter: /^npm:/ }, (args) => ({
      path: args.path,
      external: true,
    }));
    build.onResolve({ filter: /^jsr:/ }, (args) => ({
      path: args.path,
      external: true,
    }));
  },
};

function listFunctionSlugs() {
  return fs
    .readdirSync(functionsDir, { withFileTypes: true })
    .filter((entry) => entry.isDirectory() && entry.name !== '_shared')
    .map((entry) => entry.name)
    .sort();
}

async function bundleSlug(slug) {
  const entry = path.join(functionsDir, slug, 'index.source.ts');
  const outfile = path.join(functionsDir, slug, 'index.ts');

  if (!fs.existsSync(entry)) {
    throw new Error(`Missing entry: ${path.relative(packageRoot, entry)}`);
  }

  const result = await esbuild.build({
    entryPoints: [entry],
    outfile,
    bundle: true,
    format: 'esm',
    platform: 'neutral',
    target: 'es2022',
    write: true,
    sourcemap: false,
    logLevel: 'warning',
    outExtension: { '.js': '.ts' },
    plugins: [denoExternalPlugin],
    // pace-core package root so resolution matches repo layout
    absWorkingDir: packageRoot,
  });

  if (result.errors.length > 0) {
    throw new Error(`Bundle failed for ${slug}`);
  }

  const stat = fs.statSync(outfile);
  console.log(`  ${slug} → index.ts (${Math.round(stat.size / 1024)} KiB)`);
}

async function main() {
  const slugs = listFunctionSlugs();
  if (slugs.length === 0) {
    console.error('No edge function slugs found under supabase/functions');
    process.exit(1);
  }

  console.log(`Bundling ${slugs.length} edge functions…`);
  for (const slug of slugs) {
    await bundleSlug(slug);
  }
  console.log('Done. Deploy with: npm run edge:deploy (from repo root) or packages/core.');
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
