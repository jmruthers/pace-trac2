#!/usr/bin/env node
/**
 * Fast drift check for Standard 8 tiered Vitest pattern (consuming apps).
 * Subset of audit Standard 8 checks — useful before full npm run validate.
 */
const path = require('path');
const {
  checkTestTierScripts,
  checkTestSetupFiles,
  checkVitestSharedModule,
  checkVitestEnvironmentSplit,
  checkHappyDomDependency,
} = require('../audit-tool/audits/08-testing-documentation.cjs');

const cwd = process.cwd();
const issues = [
  ...checkTestTierScripts(cwd),
  ...checkVitestEnvironmentSplit(cwd),
  ...checkTestSetupFiles(cwd),
  ...checkVitestSharedModule(cwd),
  ...checkHappyDomDependency(cwd),
].filter((issue) => issue.severity === 'error');

if (issues.length > 0) {
  console.error('Vitest tiered test pattern check failed:\n');
  for (const issue of issues) {
    console.error(`  [${issue.type}] ${issue.file}: ${issue.message}`);
    if (issue.fix) console.error(`    Fix: ${issue.fix}`);
  }
  process.exit(1);
}

console.log('check-vitest-test-pattern: ok');
