#!/usr/bin/env node

/**
 * Validation Script for pace-core (monorepo and consuming apps)
 * @package @solvera/pace-core
 * @module Scripts/validate
 *
 * Runs validation in order:
 * 1. Authority wiring (consuming apps only; ensures managed setup has not drifted)
 * 2. Type check (summary in terminal)
 * 3. Lint (summary in terminal; markdown report in audit/ when issues are found)
 * 4. Build (summary in terminal)
 * 5. Tests (summary in terminal; runs test:coverage when available)
 * 6. pace-core audit(s): markdown in audit/ when blocking issues exist (errors, warnings, infos).
 *    Set PACE_VALIDATE_WRITE_REPORTS=1 or pass --write-reports to persist clean-step reports too.
 *
 * Each step runs only if the corresponding script (or audit-tool) exists.
 *
 * Usage:
 *   node node_modules/@solvera/pace-core/scripts/validate.cjs
 *
 * Or add to package.json:
 *   "scripts": { "validate": "node node_modules/@solvera/pace-core/scripts/validate.cjs" }
 */

const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const colors = {
  reset: '\x1b[0m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m',
  bold: '\x1b[1m',
  red: '\x1b[31m'
};

function findPaceCoreRoot() {
  const cwd = process.cwd();
  const nodeModulesPath = path.join(cwd, 'node_modules', '@solvera', 'pace-core');
  if (fs.existsSync(nodeModulesPath)) return nodeModulesPath;
  const scriptDir = __dirname;
  const relativePath = path.join(scriptDir, '..');
  if (fs.existsSync(relativePath)) return relativePath;
  throw new Error('Could not find pace-core package');
}

function getAvailableScripts() {
  const packageJsonPath = path.join(process.cwd(), 'package.json');
  if (!fs.existsSync(packageJsonPath)) return {};
  try {
    const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'));
    return packageJson.scripts || {};
  } catch {
    return {};
  }
}

function generateTimestamp() {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  const h = String(now.getHours()).padStart(2, '0');
  const min = String(now.getMinutes()).padStart(2, '0');
  return `${y}${m}${d}${h}${min}`;
}

function slugifyStepName(stepName) {
  return String(stepName)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

function applyStepOrdinalToken(value, stepOrdinal) {
  if (typeof value !== 'string') return value;
  return value.split('{STEP_ORDINAL}').join(stepOrdinal);
}

function resolveStepForRun(step, stepOrdinal) {
  const resolvedArgs = Array.isArray(step.args)
    ? step.args.map((arg) => applyStepOrdinalToken(arg, stepOrdinal))
    : step.args;
  return { ...step, args: resolvedArgs };
}

function stripAnsiCodes(text) {
  if (typeof text !== 'string') return '';
  return text.replace(/\u001b\[[0-9;]*m/g, '');
}

function shouldWriteValidateReports() {
  return process.env.PACE_VALIDATE_WRITE_REPORTS === '1' || process.argv.includes('--write-reports');
}

function shouldPersistStepReport(result, forceAllReports) {
  if (forceAllReports) return true;
  return !result.passed || result.errorCount > 0;
}

function parseAuditErrors(out) {
  const blocking = out.match(/Failing due to (\d+) blocking issue/i);
  if (blocking) return parseInt(blocking[1], 10);
  const m = out.match(/\*\*Total Issues:\*\*\s+(\d+)/i);
  return m ? parseInt(m[1], 10) : 0;
}

const AUDIT_MAX_SEVERITY_ARGS = ['--max-severity', 'info'];

function ensureAuditDir() {
  const auditDir = path.join(process.cwd(), 'audit');
  if (!fs.existsSync(auditDir)) fs.mkdirSync(auditDir, { recursive: true });
  return auditDir;
}

function isPaceCoreRepo(cwd) {
  const packagesCorePath = path.resolve(cwd, 'packages', 'core');
  const packageJsonPath = path.join(cwd, 'package.json');
  if (!fs.existsSync(packagesCorePath) || !fs.existsSync(packageJsonPath)) return false;
  try {
    const name = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8')).name;
    return name === 'pace-core';
  } catch {
    return false;
  }
}

function isPaceCoreLibraryWorkspace(cwd) {
  const packageJsonPath = path.join(cwd, 'package.json');
  if (!fs.existsSync(packageJsonPath)) return false;
  try {
    const name = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8')).name;
    return name === '@solvera/pace-core' && fs.existsSync(path.join(cwd, 'audit-tool', 'index.cjs'));
  } catch {
    return false;
  }
}

function runPeerDependenciesMetaGuard(cwd) {
  const { validatePeerDependenciesMeta } = require('./peer-dependencies-meta-policy.cjs');
  let packageJsonPath = null;
  if (isPaceCoreRepo(cwd)) {
    packageJsonPath = path.join(cwd, 'packages', 'core', 'package.json');
  } else if (isPaceCoreLibraryWorkspace(cwd)) {
    packageJsonPath = path.join(cwd, 'package.json');
  } else {
    return [];
  }
  const pkg = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'));
  const result = validatePeerDependenciesMeta(
    pkg.peerDependencies || {},
    pkg.peerDependenciesMeta || {}
  );
  return result.ok ? [] : result.errors;
}

function walkFiles(rootDir, allowedExts) {
  const output = [];
  if (!fs.existsSync(rootDir)) return output;
  const stack = [rootDir];
  while (stack.length > 0) {
    const current = stack.pop();
    const entries = fs.readdirSync(current, { withFileTypes: true });
    for (const entry of entries) {
      if (entry.name === 'node_modules' || entry.name === '.git' || entry.name === 'dist' || entry.name === 'coverage' || entry.name === 'audit') continue;
      const abs = path.join(current, entry.name);
      if (entry.isDirectory()) {
        stack.push(abs);
        continue;
      }
      const ext = path.extname(entry.name);
      if (allowedExts.has(ext) || allowedExts.has(entry.name)) output.push(abs);
    }
  }
  return output;
}

function runCanonicalStructureGuards(cwd) {
  const failures = [];
  const rootStandardsDir = path.join(cwd, 'docs', 'standards');
  const rootTemplatesDir = path.join(cwd, 'docs', 'templates');
  const packageStandardsDir = path.join(cwd, 'packages', 'core', 'docs', 'standards');
  const packageTemplatesDir = path.join(cwd, 'packages', 'core', 'templates');

  if (fs.existsSync(rootStandardsDir)) {
    failures.push('Root duplication detected: docs/standards must not exist (use packages/core/docs/standards).');
  }
  if (fs.existsSync(rootTemplatesDir)) {
    failures.push('Root duplication detected: docs/templates must not exist (use packages/core/templates).');
  }

  const requiredStandards = [
    '0-standards-overview.md',
    '1-project-structure-standards.md',
    '2-architecture-standards.md',
    '3-security-rbac-standards.md',
    '4-api-tech-stack-standards.md',
    '5-pace-core-compliance-standards.md',
    '6-code-quality-standards.md',
    '7-visual-standards.md',
    '8-testing-documentation-standards.md',
    '9-operations-standards.md',
  ];
  for (const standardFile of requiredStandards) {
    if (!fs.existsSync(path.join(packageStandardsDir, standardFile))) {
      failures.push(`Missing canonical standard file: packages/core/docs/standards/${standardFile}.`);
    }
  }

  const requiredTemplates = ['app.css', 'main.tsx', 'vite.config.ts', 'supabase.ts', 'tsconfig.json', 'mcp.json'];
  for (const templateFile of requiredTemplates) {
    if (!fs.existsSync(path.join(packageTemplatesDir, templateFile))) {
      failures.push(`Missing canonical template file: packages/core/templates/${templateFile}.`);
    }
  }

  const rootRulesDir = path.join(cwd, '.cursor', 'rules');
  if (!fs.existsSync(rootRulesDir)) {
    failures.push('Missing root .cursor/rules directory.');
  } else {
    const rules = fs.readdirSync(rootRulesDir).filter((name) => name.endsWith('.mdc'));
    for (const ruleFile of rules) {
      const filePath = path.join(rootRulesDir, ruleFile);
      const text = fs.readFileSync(filePath, 'utf8');
      if (/^\d{2}-/.test(ruleFile) && !text.includes('../packages/core/docs/standards/')) {
        failures.push(`Root cursor rule does not reference canonical standards path: .cursor/rules/${ruleFile}.`);
      }
    }
  }

  const allowedExts = new Set(['.md', '.mdc', '.cjs', '.js', '.json', '.sql', 'package.json']);
  const scanRoots = [
    path.join(cwd, '.cursor', 'rules'),
    path.join(cwd, 'packages', 'core', 'cursor-rules'),
    path.join(cwd, 'packages', 'core', 'eslint-rules'),
    path.join(cwd, 'packages', 'core', 'audit-tool'),
    path.join(cwd, 'packages', 'core', 'scripts'),
    path.join(cwd, 'packages', 'core', 'supabase', 'migrations'),
    path.join(cwd, 'docs', 'NEW-PROJECT-SETUP.md'),
    path.join(cwd, 'README.md'),
  ];

  const files = [];
  for (const root of scanRoots) {
    if (!fs.existsSync(root)) continue;
    const stat = fs.statSync(root);
    if (stat.isDirectory()) {
      files.push(...walkFiles(root, allowedExts));
    } else {
      files.push(root);
    }
  }

  const disallowedPatterns = [
    { label: '../docs/standards/', regex: /\.\.\/docs\/standards\// },
    { label: '../../standards/', regex: /\.\.\/\.\.\/standards\// },
    { label: '../docs/templates/', regex: /\.\.\/docs\/templates\// },
    { label: 'node_modules/@solvera/pace-core/packages/core/docs/standards/', regex: /node_modules\/@solvera\/pace-core\/packages\/core\/docs\/standards\// },
    { label: 'root docs/standards/', regex: /(^|[^A-Za-z0-9_\/-])docs\/standards\//m },
    { label: 'root docs/templates/', regex: /(^|[^A-Za-z0-9_\/-])docs\/templates\//m },
  ];
  const allowedMentionFiles = new Set([
    'packages/core/scripts/validate.cjs',
    'packages/core/scripts/validate-authority.cjs',
    'packages/core/scripts/setup.cjs',
  ]);

  for (const filePath of files) {
    let text = '';
    try {
      text = fs.readFileSync(filePath, 'utf8');
    } catch {
      continue;
    }
    const rel = path.relative(cwd, filePath).replace(/\\/g, '/');
    if (allowedMentionFiles.has(rel)) continue;
    for (const pattern of disallowedPatterns) {
      if (
        rel.startsWith('packages/core/cursor-rules/') &&
        (pattern.label === '../docs/standards/' || pattern.label === '../docs/templates/')
      ) {
        continue;
      }
      if (pattern.regex.test(text)) {
        failures.push(`Deprecated path reference "${pattern.label}" found in ${rel}.`);
      }
    }
  }

  return failures;
}

function parsePackOutputJson(output) {
  const start = output.indexOf('[');
  const end = output.lastIndexOf(']');
  if (start === -1 || end === -1 || end < start) return null;
  const candidate = output.slice(start, end + 1);
  try {
    return JSON.parse(candidate);
  } catch {
    return null;
  }
}

// Convert ESLint output file paths to clickable markdown links (relative to report dir)
function convertFilePathsToLinks(output, cwd, reportDir) {
  const lines = output.split('\n');
  const out = [];
  let currentFileAbsolute = null;
  let currentFileDisplayPath = null;
  let inCommandOutput = false;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (line.trim().startsWith('>')) {
      inCommandOutput = true;
      out.push(line);
      continue;
    }
    if (line.trim() === '' || line.startsWith('eslint') || line.match(/^✖|^✔/)) inCommandOutput = false;

    const filePathMatch = !inCommandOutput && line.match(/^(\/|\.\/)?([^\s]+\.(ts|tsx|js|jsx|mjs|cjs|json|css|scss|sass|less|html|vue|svelte|md|mdx))$/);
    if (filePathMatch) {
      const filePath = line.trim();
      const absolutePath = path.isAbsolute(filePath) ? filePath : path.resolve(cwd, filePath);
      currentFileAbsolute = absolutePath;
      const displayPath = path.relative(cwd, absolutePath).replace(/\\/g, '/');
      const linkPath = path.relative(reportDir, absolutePath).replace(/\\/g, '/');
      currentFileDisplayPath = displayPath;
      out.push(`[${displayPath}](${linkPath})`);
    } else {
      const errorLineMatch = line.match(/^(\s+)(\d+):(\d+)\s+(error|warning)\s+(.+)$/);
      if (errorLineMatch && currentFileAbsolute) {
        const [, indent, lineNum, colNum, severity, message] = errorLineMatch;
        const linkPath = path.relative(reportDir, currentFileAbsolute).replace(/\\/g, '/');
        const linkUrl = `${linkPath}#L${lineNum}`;
        out.push(`${indent}[${currentFileDisplayPath}:${lineNum}:${colNum}](${linkUrl})  ${severity}  ${message}`);
      } else {
        out.push(line);
        if (line.trim() === '' && (i === 0 || lines[i - 1].trim() === '')) currentFileAbsolute = currentFileDisplayPath = null;
        else if (line.startsWith('npm') || line.startsWith('eslint') || line.match(/^✖|^✔/)) currentFileAbsolute = currentFileDisplayPath = null;
      }
    }
  }
  return out.join('\n');
}

function writeStepReport(step, result, runTimestamp, stepOrdinal, cwd, auditDir) {
  const statusLabel = result.passed ? 'PASSED' : 'FAILED';
  const slug = slugifyStepName(step.name);
  const reportName = `${runTimestamp}-${stepOrdinal}-${slug}-report.md`;
  const reportPath = path.join(auditDir, reportName);
  const cleanedOutput = stripAnsiCodes(result.fullOutput || '');
  const reportContent = [
    `# ${step.name} Report`,
    '',
    `**Generated:** ${new Date().toISOString()}`,
    `**Step:** ${step.name}`,
    `**Status:** ${statusLabel}`,
    `**Duration:** ${result.duration}s`,
    `**Exit Code:** ${result.exitCode}`,
    '',
    '## Output',
    '',
    '```text',
    cleanedOutput.length > 0 ? cleanedOutput : '(No output captured)',
    '```',
    '',
  ].join('\n');
  fs.writeFileSync(reportPath, reportContent, 'utf8');
  return reportPath;
}

function buildSteps() {
  const scripts = getAvailableScripts();
  const steps = [];
  const cwd = process.cwd();
  const paceCoreRoot = (() => {
    try { return findPaceCoreRoot(); } catch { return null; }
  })();
  const auditToolPath = paceCoreRoot && path.join(paceCoreRoot, 'audit-tool', 'index.cjs');
  const validateAuthorityPath = paceCoreRoot && path.join(paceCoreRoot, 'scripts', 'validate-authority.cjs');
  const packagesCorePath = path.resolve(cwd, 'packages', 'core');
  const packageJsonPath = path.join(cwd, 'package.json');
  let projectName = null;
  if (fs.existsSync(packageJsonPath)) {
    try {
      projectName = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8')).name || null;
    } catch {
      projectName = null;
    }
  }
  const isPaceCoreRepo = auditToolPath && fs.existsSync(auditToolPath) && fs.existsSync(packagesCorePath) && projectName === 'pace-core';
  const isPaceCoreLibraryWorkspace =
    projectName === '@solvera/pace-core' && fs.existsSync(path.join(cwd, 'audit-tool', 'index.cjs'));

  // In consuming apps, fail fast on managed wiring drift before running other validations.
  if (!isPaceCoreRepo && !isPaceCoreLibraryWorkspace && validateAuthorityPath && fs.existsSync(validateAuthorityPath)) {
    steps.push({
      name: 'Authority Wiring',
      command: 'node',
      args: [validateAuthorityPath],
      runInCwd: true,
      parseErrors: (out, step) => {
        const m = out.match(/drift detected\s+\((\d+)\s+issue/i);
        if (m) return parseInt(m[1], 10);
        if ((out.match(/^\s*-\s+/gm) || []).length > 0) return (out.match(/^\s*-\s+/gm) || []).length;
        return 0;
      },
      formatErrorCount: (n) => n > 0 ? `${n} drift issue${n !== 1 ? 's' : ''}` : ''
    });
  }

  if (scripts['type-check']) {
    steps.push({
      name: 'Type Check',
      command: 'npm',
      args: ['run', 'type-check'],
      parseErrors: (out) => (out.match(/error TS\d+:/g) || []).length,
      formatErrorCount: (n) => n > 0 ? `${n} error${n !== 1 ? 's' : ''}` : ''
    });
  }

  if (scripts.lint) {
    const lintStep = {
      name: 'Lint',
      command: 'npm',
      args: ['run', 'lint'],
      parseErrors: (out, step) => {
        const m = out.match(/✖\s+(\d+)\s+problems?\s+\((\d+)\s+errors?,\s+(\d+)\s+warnings?\)/i);
        if (m) {
          step.details = { total: parseInt(m[1], 10), errors: parseInt(m[2], 10), warnings: parseInt(m[3], 10) };
          return step.details.total;
        }
        const pm = out.match(/(\d+)\s+problems?/i);
        if (pm) return parseInt(pm[1], 10);
        return (out.match(/(?:error|Error:)/gi) || []).length;
      },
      formatErrorCount: (n, step) => {
        if (step.details) return `${step.details.total} problems (${step.details.errors} errors, ${step.details.warnings} warnings)`;
        return n > 0 ? `${n} problem${n !== 1 ? 's' : ''}` : '';
      }
    };
    lintStep.reportFile = (ts, stepOrdinal) => `audit/${ts}-${stepOrdinal}-eslint-report.md`;
    lintStep.writeReport = (fullOutput, reportPath, cwd, auditDir) => {
      const content = `# ESLint Report\n\n**Generated:** ${new Date().toISOString()}\n\n## Output\n\n${convertFilePathsToLinks(fullOutput, cwd, auditDir)}\n`;
      fs.writeFileSync(reportPath, content, 'utf8');
    };
    steps.push(lintStep);
  }

  if (scripts.build) {
    steps.push({
      name: 'Build',
      command: 'npm',
      args: ['run', 'build'],
      parseErrors: (out) => (out.match(/(?:error|Error:)/gi) || []).length,
      formatErrorCount: (n) => n > 0 ? `${n} error${n !== 1 ? 's' : ''}` : ''
    });
  }

  if (isPaceCoreRepo) {
    steps.push({
      name: 'Package Publish Surface',
      command: 'npm',
      args: ['pack', '--dry-run', '--json', '-w', '@solvera/pace-core'],
      runInCwd: true,
      parseErrors: (out, step) => {
        const parsed = parsePackOutputJson(out);
        if (!Array.isArray(parsed) || parsed.length === 0 || !Array.isArray(parsed[0]?.files)) {
          step.details = { parseError: true };
          return 1;
        }
        const files = parsed[0].files.map((item) => item.path).filter(Boolean);
        const mustInclude = ['docs/', 'templates/', 'scripts/', 'dist/styles/core.css'];
        const missing = mustInclude.filter((requiredPath) =>
          requiredPath.endsWith('/')
            ? !files.some((filePath) => String(filePath).startsWith(requiredPath))
            : !files.includes(requiredPath)
        );
        step.details = { missing };
        return missing.length;
      },
      formatErrorCount: (n, step) => {
        if (step.details?.parseError) return 'could not parse npm pack output';
        if (n > 0 && Array.isArray(step.details?.missing)) {
          return `missing publish artifacts: ${step.details.missing.join(', ')}`;
        }
        return '';
      }
    });
  }

  if (scripts.test) {
    const testScript = scripts['test:coverage'] ? 'test:coverage' : 'test';
    const testRunsCoverage = testScript === 'test:coverage';
    steps.push({
      name: 'Tests',
      command: 'npm',
      args: ['run', testScript],
      testRunsCoverage,
      parseErrors: (out, step) => {
        const lines = out.split('\n');
        let testsLine = null;
        let testFilesLine = null;
        for (let i = lines.length - 1; i >= 0; i--) {
          const line = lines[i].trim();
          if (/^Tests\s+/.test(line) && (/\d+\s+passed/i.test(line) || /\d+\s+failed/i.test(line))) {
            testsLine = line;
            break;
          }
          if (!testFilesLine && /^Test\s+Files?\s+/.test(line) && (/\d+\s+passed/i.test(line) || /\d+\s+failed/i.test(line))) {
            testFilesLine = line;
          }
        }
        const summaryLine = testsLine || testFilesLine;
        if (summaryLine) {
          const passedMatch = summaryLine.match(/(\d+)\s+passed/i);
          const failedMatch = summaryLine.match(/(\d+)\s+failed/i);
          const skippedMatch = summaryLine.match(/(\d+)\s+skipped/i);
          const passed = passedMatch ? parseInt(passedMatch[1], 10) : 0;
          const failed = failedMatch ? parseInt(failedMatch[1], 10) : 0;
          const skipped = skippedMatch ? parseInt(skippedMatch[1], 10) : 0;
          step.details = { passed, failed, skipped };
          return failed;
        }
        const sm = out.match(/Tests?\s+(\d+)\s+failed\s+\|\s+(\d+)\s+passed/i);
        if (sm) {
          step.details = { passed: parseInt(sm[2], 10), failed: parseInt(sm[1], 10), skipped: 0 };
          return parseInt(sm[1], 10);
        }
        const allPassedOut = out.match(/Tests?\s+(\d+)\s+passed/i);
        if (allPassedOut && !out.match(/Tests?\s+\d+\s+failed/i)) {
          step.details = { passed: parseInt(allPassedOut[1], 10), failed: 0, skipped: 0 };
          return 0;
        }
        const fm = out.match(/Tests?\s+(\d+)\s+failed/i);
        if (fm) {
          step.details = { passed: 0, failed: parseInt(fm[1], 10), skipped: 0 };
          return parseInt(fm[1], 10);
        }
        return 0;
      },
      formatErrorCount: (n, step) => {
        if (step.details) {
          const { passed, failed, skipped } = step.details;
          const parts = [`${passed} passed`, `${failed} failed`, `${skipped} skipped`];
          return parts.join(', ');
        }
        return n > 0 ? `${n} failed` : '';
      }
    });
  }

  if (auditToolPath && fs.existsSync(auditToolPath)) {
    if (isPaceCoreRepo) {
      steps.push({
        name: 'pace-core Demo App Audit',
        command: 'node',
        args: [
          auditToolPath,
          '.',
          '--output',
          path.join('audit', '{STEP_ORDINAL}-pace-demo-app-audit.md'),
          ...AUDIT_MAX_SEVERITY_ARGS,
        ],
        runInCwd: true,
        parseErrors: parseAuditErrors,
        formatErrorCount: (n) => n > 0 ? `${n} issue${n !== 1 ? 's' : ''}` : ''
      });
      steps.push({
        name: 'pace-core Package Audit',
        command: 'node',
        args: [
          auditToolPath,
          packagesCorePath,
          '--output',
          path.join('audit', '{STEP_ORDINAL}-pace-core-package-audit.md'),
          ...AUDIT_MAX_SEVERITY_ARGS,
        ],
        runInCwd: true,
        parseErrors: parseAuditErrors,
        formatErrorCount: (n) => n > 0 ? `${n} issue${n !== 1 ? 's' : ''}` : ''
      });
    } else {
      steps.push({
        name: 'pace-core Audit',
        command: 'node',
        args: [
          auditToolPath,
          '--output',
          path.join('audit', '{STEP_ORDINAL}-pace-core-audit.md'),
          ...AUDIT_MAX_SEVERITY_ARGS,
        ],
        runInCwd: true,
        parseErrors: parseAuditErrors,
        formatErrorCount: (n) => n > 0 ? `${n} issue${n !== 1 ? 's' : ''}` : ''
      });
    }
  }

  return steps;
}

function runStep(step, runTimestamp, auditDir) {
  return new Promise((resolve) => {
    const startTime = Date.now();
    let stdout = '';
    let stderr = '';
    let timeoutId = null;
    let testKillTimeout = null;
    let testSummarySeen = false;
    const timeout = step.name === 'Tests' ? 300000 : 120000;
    const cwd = process.cwd();
    const spawnOpts = {
      cwd: step.runInCwd ? cwd : cwd,
      shell: !step.runInCwd,
      stdio: ['ignore', 'pipe', 'pipe'],
      env: { ...process.env, CI: 'true', FORCE_COLOR: '0' }
    };
    const child = spawn(
      step.command,
      step.args,
      spawnOpts
    );

    const checkForTestSummary = () => {
      if (step.name === 'Tests' && !step.testRunsCoverage && !testSummarySeen) {
        const output = stdout + stderr;
        if ((/Tests?\s+\d+\s+failed\s+\|\s+\d+\s+passed/i.test(output) || /Test\s+Files?\s+\d+\s+failed\s+\|\s+\d+\s+passed/i.test(output)) &&
            (/Duration|Start at|Watching for file changes/i.test(output))) {
          if (testKillTimeout) clearTimeout(testKillTimeout);
          testKillTimeout = setTimeout(() => {
            testSummarySeen = true;
            child.kill('SIGTERM');
          }, 1000);
        }
      }
    };

    child.stdout.on('data', (d) => { stdout += d.toString(); checkForTestSummary(); });
    child.stderr.on('data', (d) => { stderr += d.toString(); checkForTestSummary(); });

    timeoutId = setTimeout(() => {
      if (testKillTimeout) clearTimeout(testKillTimeout);
      child.kill('SIGTERM');
      resolve({
        name: step.name,
        passed: false,
        exitCode: -1,
        errorCount: 1,
        duration: ((Date.now() - startTime) / 1000).toFixed(2),
        fullOutput: stdout + stderr,
        output: `Command timed out after ${timeout / 1000}s`,
        step
      });
    }, timeout);

    child.on('close', (code) => {
      if (timeoutId) clearTimeout(timeoutId);
      if (testKillTimeout) clearTimeout(testKillTimeout);
      const duration = ((Date.now() - startTime) / 1000).toFixed(2);
      const fullOutput = stdout + stderr;
      let errorCount = step.parseErrors ? step.parseErrors(fullOutput, step) : 0;
      const isAuditStep = step.name === 'pace-core Audit' || step.name === 'pace-core Demo App Audit' || step.name === 'pace-core Package Audit';
      if (step.name === 'Tests' && code !== 0 && errorCount === 0) {
        errorCount = 1;
        if (!step.details) step.details = { passed: 0, failed: 1, skipped: 0 };
      }
      const testsPassedAfterKill = step.name === 'Tests' && (code === 143 || code === 130) && step.details && step.details.failed === 0;
      const passed = step.name === 'Tests'
        ? (testsPassedAfterKill || (code === 0 && errorCount === 0))
        : isAuditStep
          ? code === 0 && errorCount === 0
          : code === 0 && errorCount === 0;
      resolve({
        name: step.name,
        passed,
        exitCode: code,
        errorCount,
        duration,
        fullOutput,
        output: fullOutput.slice(0, 500),
        step
      });
    });

    child.on('error', (err) => {
      if (timeoutId) clearTimeout(timeoutId);
      if (testKillTimeout) clearTimeout(testKillTimeout);
      resolve({
        name: step.name,
        passed: false,
        exitCode: -1,
        errorCount: 1,
        duration: ((Date.now() - startTime) / 1000).toFixed(2),
        fullOutput: '',
        output: err.message,
        step
      });
    });
  });
}

function runComponentGovernanceCheck(cwd) {
  const packageJsonPath = path.join(cwd, 'package.json');
  if (!fs.existsSync(packageJsonPath)) return [];
  try {
    const name = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8')).name;
    if (name !== '@solvera/pace-core') return [];
  } catch {
    return [];
  }
  const scriptPath = path.join(cwd, 'scripts', 'check-component-test-matrix.cjs');
  if (!fs.existsSync(scriptPath)) return [];
  const { runComponentGovernance } = require(scriptPath);
  const componentsDir = path.join(cwd, 'src', 'components');
  return runComponentGovernance(componentsDir);
}

async function main() {
  const cwd = process.cwd();
  const componentGovernanceFailures = runComponentGovernanceCheck(cwd);
  if (componentGovernanceFailures.length > 0) {
    console.error(`${colors.red}❌ Component governance validation failed:${colors.reset}`);
    for (const failure of componentGovernanceFailures) {
      console.error(`  - ${failure}`);
    }
    process.exit(1);
  }

  const peerMetaFailures = runPeerDependenciesMetaGuard(cwd);
  if (peerMetaFailures.length > 0) {
    console.error(`${colors.red}❌ peerDependenciesMeta validation failed:${colors.reset}`);
    for (const failure of peerMetaFailures) {
      console.error(`  - ${failure}`);
    }
    process.exit(1);
  }

  if (isPaceCoreRepo(cwd)) {
    const structureFailures = runCanonicalStructureGuards(cwd);
    if (structureFailures.length > 0) {
      console.error(`${colors.red}❌ Canonical structure validation failed:${colors.reset}`);
      for (const failure of structureFailures) {
        console.error(`  - ${failure}`);
      }
      process.exit(1);
    }
  }

  const steps = buildSteps();
  if (steps.length === 0) {
    console.log(`${colors.yellow}No validation steps available.${colors.reset}`);
    const scripts = getAvailableScripts();
    ['type-check', 'lint', 'build', 'test'].forEach(s => {
      if (scripts[s]) console.log(`  • ${s}`);
    });
    console.log(`${colors.cyan}Add scripts to package.json and ensure pace-core (with audit-tool) is available.${colors.reset}`);
    process.exit(0);
  }

  const runTimestamp = generateTimestamp();
  const writeAllReports = shouldWriteValidateReports();
  let auditDir = null;

  console.log(`${colors.bold}${colors.cyan}🔍 Running validation...${colors.reset}\n`);
  console.log('='.repeat(60));

  const results = [];
  for (let i = 0; i < steps.length; i++) {
    const step = steps[i];
    const stepNumber = i + 1;
    const stepOrdinal = String(stepNumber).padStart(2, '0');
    const resolvedStep = resolveStepForRun(step, stepOrdinal);
    console.log(`\n[${stepOrdinal}/${steps.length}] Running: ${resolvedStep.name}`);
    console.log('-'.repeat(60));

    const result = await runStep(resolvedStep, runTimestamp, auditDir);
    results.push(result);

    let stepReportPath = null;
    if (shouldPersistStepReport(result, writeAllReports) && result.fullOutput !== undefined) {
      try {
        if (!auditDir) auditDir = ensureAuditDir();
        if (resolvedStep.reportFile) {
          stepReportPath = path.join(cwd, resolvedStep.reportFile(runTimestamp, stepOrdinal));
          resolvedStep.writeReport(result.fullOutput, stepReportPath, cwd, auditDir);
        } else if (
          resolvedStep.name === 'pace-core Audit' ||
          resolvedStep.name === 'pace-core Demo App Audit' ||
          resolvedStep.name === 'pace-core Package Audit'
        ) {
          stepReportPath = null;
        } else {
          stepReportPath = writeStepReport(resolvedStep, result, runTimestamp, stepOrdinal, cwd, auditDir);
        }
        if (stepReportPath) {
          console.log(`Report [${stepOrdinal}]: ${stepReportPath}`);
        }
      } catch (e) {
        console.log(`${colors.yellow}Could not write report: ${e.message}${colors.reset}`);
      }
    }
    if ((resolvedStep.name === 'pace-core Audit' || resolvedStep.name === 'pace-core Demo App Audit' || resolvedStep.name === 'pace-core Package Audit') && result.fullOutput) {
      const reportSavedMatch = result.fullOutput.match(/Report saved to:[^\n]+/);
      if (reportSavedMatch) console.log(`[${stepOrdinal}] ${reportSavedMatch[0].trim()}`);
    }

    const status = result.passed ? `${colors.green}✅ PASSED${colors.reset}` : `${colors.red}❌ FAILED${colors.reset}`;
    const errorInfo = result.errorCount > 0 && result.step.formatErrorCount
      ? result.step.formatErrorCount(result.errorCount, result.step)
      : '';
    const testSummary = step.name === 'Tests' && result.step.details && result.step.formatErrorCount
      ? result.step.formatErrorCount(result.errorCount, result.step)
      : '';
    console.log(`Status: ${status}${errorInfo ? ' ' + errorInfo : ''}`);
    if (testSummary) console.log(`Tests: ${testSummary}`);
    if (resolvedStep.name === 'Tests' && !resolvedStep.testRunsCoverage) {
      console.log(`${colors.cyan}Tip: add a \`test:coverage\` script to package.json to generate a coverage report during validate.${colors.reset}`);
    }
    if (resolvedStep.name === 'Tests' && resolvedStep.testRunsCoverage) {
      const coverageIndex = path.join(cwd, 'coverage', 'index.html');
      if (fs.existsSync(coverageIndex)) {
        console.log(`Coverage report: file://${coverageIndex}`);
        console.log(`${colors.cyan}This report includes both package and app source; see Standard 8 for thresholds.${colors.reset}`);
      } else {
        console.log(`${colors.cyan}Coverage HTML report was not generated. Check test output above; ensure test.coverage.reporter includes "html" in vitest.shared.ts.${colors.reset}`);
      }
    }
    console.log(`Duration: ${result.duration}s`);
    console.log(`Exit Code: ${result.exitCode}`);
  }

  console.log('\n' + '='.repeat(60));
  console.log(`\n${colors.bold}📊 VALIDATION SUMMARY${colors.reset}\n`);
  console.log('='.repeat(60));

  const passed = results.filter(r => r.passed).length;
  const failed = results.filter(r => !r.passed).length;
  results.forEach((r, idx) => {
    const stepOrdinal = String(idx + 1).padStart(2, '0');
    const status = r.passed ? `${colors.green}✅${colors.reset}` : `${colors.red}❌${colors.reset}`;
    const err = r.errorCount > 0 && r.step.formatErrorCount ? ` - ${r.step.formatErrorCount(r.errorCount, r.step)}` : '';
    console.log(`[${stepOrdinal}] ${status} ${r.name}${err}`);
  });

  console.log('\n' + '-'.repeat(60));
  console.log(`Total: ${results.length} checks`);
  console.log(`${colors.green}Passed: ${passed}${colors.reset}`);
  console.log(`${failed > 0 ? colors.red : colors.green}Failed: ${failed}${colors.reset}`);
  console.log('='.repeat(60));

  process.exit(failed > 0 ? 1 : 0);
}

if (require.main === module) {
  main().catch((err) => {
    console.error(`${colors.red}❌ Validation error:${colors.reset}`, err);
    process.exit(1);
  });
}

module.exports = { main };
