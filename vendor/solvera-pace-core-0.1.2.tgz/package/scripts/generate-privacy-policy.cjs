#!/usr/bin/env node
/**
 * Embed privacy-policy.md as a TypeScript string for PrivacyPolicyDialog.
 * Run before tsc (see package.json build script).
 */
const fs = require('fs');
const path = require('path');

const pkgRoot = path.resolve(__dirname, '..');
const sourcePath = path.join(pkgRoot, 'content', 'privacy-policy.md');
const outPath = path.join(pkgRoot, 'src', 'support', 'privacy-policy.generated.ts');

if (!fs.existsSync(sourcePath)) {
  console.error(`Missing privacy policy source: ${sourcePath}`);
  process.exit(1);
}

const markdown = fs.readFileSync(sourcePath, 'utf8');
const escaped = JSON.stringify(markdown);

const output = `/**
 * Generated from content/privacy-policy.md — do not edit by hand.
 * Regenerate: node scripts/generate-privacy-policy.cjs
 */
export const PRIVACY_POLICY_MARKDOWN = ${escaped} as const;
`;

fs.mkdirSync(path.dirname(outPath), { recursive: true });
fs.writeFileSync(outPath, output, 'utf8');
console.log(`Generated ${path.relative(pkgRoot, outPath)}`);
