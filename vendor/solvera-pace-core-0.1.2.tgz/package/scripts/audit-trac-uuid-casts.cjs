#!/usr/bin/env node
/**
 * Audit TRAC trac_* function bodies for uuid/text mismatches.
 *
 * Usage:
 *   node scripts/audit-trac-uuid-casts.cjs [--report path.md]
 *
 * Exit code 1 when findings remain (for CI / validate).
 */

const path = require('node:path');
const {
  UUID_COLUMNS,
  TEXT_ID_COLUMNS,
  AUDIT_SKIP,
  BAD_PATTERNS,
} = require('./trac-rpc-uuid-config.cjs');
const { runRpcUuidAudit } = require('./rpc-uuid-audit-lib.cjs');

const coreRoot = path.join(__dirname, '..');
const migrationsDir = path.join(coreRoot, 'supabase', 'migrations');

const reportArgIdx = process.argv.indexOf('--report');
const reportPath = reportArgIdx !== -1 ? process.argv[reportArgIdx + 1] : null;

runRpcUuidAudit({
  title: 'TRAC RPC uuid audit',
  reportPath,
  migrationsDir,
  nameFilter: (name) => name.startsWith('trac_'),
  auditSkip: AUDIT_SKIP,
  badPatterns: BAD_PATTERNS,
  uuidColumns: UUID_COLUMNS,
  textIdColumns: TEXT_ID_COLUMNS,
});
