#!/usr/bin/env node

/**
 * Release @solvera/pace-core to npm via the tag-driven GitHub Actions workflow.
 *
 * Default flow:
 *   1. Bump packages/core/package.json version (patch by default)
 *   2. npm run validate
 *   3. npm pack --dry-run
 *   4. Commit, tag v{version}, push branch + tag
 *   5. GitHub Actions publishes to npm (requires NPM_TOKEN secret)
 *
 * Usage (from pace-core2 repo root):
 *   npm run publish              # patch bump + push
 *   npm run publish -- minor     # minor bump + push
 *   npm run publish -- major     # major bump + push
 *   npm run publish -- --version 0.2.0
 *   npm run publish:dry-run      # validate + pack only (no bump, no git)
 *   npm run publish -- --no-push # bump + commit + tag locally only
 *   npm run publish -- --local   # validate + npm publish from this machine
 *
 * @package @solvera/pace-core
 */

const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');

const PACKAGE_JSON = 'packages/core/package.json';
const VALID_BUMPS = new Set(['patch', 'minor', 'major']);

const colors = {
  reset: '\x1b[0m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m',
  bold: '\x1b[1m',
  red: '\x1b[31m',
};

function log(message, color = colors.reset) {
  console.log(`${color}${message}${colors.reset}`);
}

function fail(message) {
  log(`\n✗ ${message}`, colors.red);
  process.exit(1);
}

function parseArgs(argv) {
  const options = {
    bump: 'patch',
    explicitVersion: null,
    dryRun: false,
    push: true,
    local: false,
  };

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === '--dry-run') {
      options.dryRun = true;
      continue;
    }
    if (arg === '--no-push') {
      options.push = false;
      continue;
    }
    if (arg === '--push') {
      options.push = true;
      continue;
    }
    if (arg === '--local') {
      options.local = true;
      continue;
    }
    if (arg === '--version') {
      const next = argv[i + 1];
      if (!next || next.startsWith('-')) {
        fail('--version requires a semver value (for example 0.1.1).');
      }
      options.explicitVersion = next;
      i += 1;
      continue;
    }
    if (arg.startsWith('-')) {
      fail(`Unknown option: ${arg}`);
    }
    if (VALID_BUMPS.has(arg)) {
      options.bump = arg;
    } else {
      fail(`Unknown argument: ${arg}. Use patch, minor, major, --version, --dry-run, --no-push, or --local.`);
    }
  }

  if (options.dryRun) {
    options.push = false;
  }

  if (options.local) {
    options.push = false;
  }

  return options;
}

function findRepoRoot() {
  let dir = process.cwd();
  while (true) {
    const candidate = path.join(dir, PACKAGE_JSON);
    if (fs.existsSync(candidate)) {
      return dir;
    }
    const parent = path.dirname(dir);
    if (parent === dir) {
      fail(`Could not find ${PACKAGE_JSON}. Run this script from the pace-core2 repository.`);
    }
    dir = parent;
  }
}

function run(command, args, cwd, label) {
  if (label) {
    log(`\n→ ${label}`, colors.cyan);
  }
  const result = spawnSync(command, args, {
    cwd,
    stdio: 'inherit',
    env: process.env,
  });
  if (result.error) {
    fail(`${command} failed: ${result.error.message}`);
  }
  if (result.status !== 0) {
    throw new Error(`${label || command} failed with exit code ${result.status ?? 1}`);
  }
}

function gitOutput(args, cwd) {
  const result = spawnSync('git', args, {
    cwd,
    encoding: 'utf8',
  });
  if (result.status !== 0) {
    fail(`git ${args.join(' ')} failed.`);
  }
  return (result.stdout || '').trim();
}

function readPackageVersion(repoRoot) {
  const packageJsonPath = path.join(repoRoot, PACKAGE_JSON);
  const pkg = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'));
  if (!pkg.version) {
    fail(`Missing version in ${PACKAGE_JSON}.`);
  }
  return { packageJsonPath, pkg, version: pkg.version };
}

function bumpVersion(current, bump) {
  const match = /^(\d+)\.(\d+)\.(\d+)(.*)$/.exec(current);
  if (!match) {
    fail(`Current version "${current}" is not a supported semver (expected X.Y.Z).`);
  }
  let major = Number(match[1]);
  let minor = Number(match[2]);
  let patch = Number(match[3]);
  const suffix = match[4] || '';
  if (suffix) {
    fail(`Prerelease versions are not supported by this script yet (${current}). Pass --version explicitly.`);
  }
  if (bump === 'major') {
    major += 1;
    minor = 0;
    patch = 0;
  } else if (bump === 'minor') {
    minor += 1;
    patch = 0;
  } else if (bump === 'patch') {
    patch += 1;
  } else {
    fail(`Unsupported bump type: ${bump}`);
  }
  return `${major}.${minor}.${patch}`;
}

function assertCleanGit(repoRoot) {
  const status = gitOutput(['status', '--porcelain'], repoRoot);
  if (status) {
    fail('Working tree is not clean. Commit or stash changes before releasing.');
  }
}

function assertTagAvailable(repoRoot, tag) {
  const existing = spawnSync('git', ['rev-parse', '--verify', tag], {
    cwd: repoRoot,
    encoding: 'utf8',
  });
  if (existing.status === 0) {
    fail(`Git tag ${tag} already exists.`);
  }
}

function writeVersion(repoRoot, packageJsonPath, pkg, version) {
  pkg.version = version;
  fs.writeFileSync(packageJsonPath, `${JSON.stringify(pkg, null, 2)}\n`, 'utf8');
}

function main() {
  const options = parseArgs(process.argv.slice(2));
  const repoRoot = findRepoRoot();

  const { packageJsonPath, pkg, version: currentVersion } = readPackageVersion(repoRoot);
  const nextVersion = options.explicitVersion || bumpVersion(currentVersion, options.bump);
  const tag = `v${nextVersion}`;

  log('\n@solvera/pace-core release', colors.bold);
  log(`Repository: ${repoRoot}`, colors.blue);
  log(`Current version: ${currentVersion}`, colors.blue);

  if (options.dryRun) {
    log('Mode: dry run (validate + npm pack only)', colors.yellow);
    run('npm', ['run', 'validate'], repoRoot, 'Validate package');
    run('npm', ['pack', '--dry-run'], path.join(repoRoot, 'packages/core'), 'Preview tarball');
    log('\n✓ Dry run complete. No version bump, commit, tag, or publish performed.', colors.green);
    return;
  }

  log(`Next version: ${nextVersion}`, colors.blue);
  if (options.local) {
    log('Mode: local npm publish', colors.yellow);
  } else if (options.push) {
    log('Mode: CI publish (commit, tag, push → GitHub Actions)', colors.yellow);
  } else {
    log('Mode: local release prep only (--no-push)', colors.yellow);
  }

  assertCleanGit(repoRoot);
  assertTagAvailable(repoRoot, tag);

  let versionBumped = false;
  try {
    writeVersion(repoRoot, packageJsonPath, pkg, nextVersion);
    versionBumped = true;
    log(`Updated ${PACKAGE_JSON} → ${nextVersion}`, colors.green);

    run('npm', ['run', 'validate'], repoRoot, 'Validate package');
    run('npm', ['pack', '--dry-run'], path.join(repoRoot, 'packages/core'), 'Preview tarball');

    if (options.local) {
      run(
        'npm',
        ['publish', '--access', 'restricted', '--ignore-scripts'],
        path.join(repoRoot, 'packages/core'),
        'Publish to npm from this machine'
      );
      log(`\n✓ Published @solvera/pace-core@${nextVersion} locally.`, colors.green);
      log('Remember to commit the version bump and create the matching git tag.', colors.yellow);
      return;
    }

    run('git', ['add', PACKAGE_JSON], repoRoot, 'Stage version bump');
    run(
      'git',
      ['commit', '-m', `Release @solvera/pace-core ${nextVersion}`],
      repoRoot,
      'Commit release'
    );
    run('git', ['tag', tag], repoRoot, `Create tag ${tag}`);

    if (options.push) {
      const branch = gitOutput(['rev-parse', '--abbrev-ref', 'HEAD'], repoRoot);
      run('git', ['push', 'origin', branch], repoRoot, `Push ${branch}`);
      run('git', ['push', 'origin', tag], repoRoot, `Push ${tag}`);
      log('\n✓ Release pushed. GitHub Actions will publish to npm.', colors.green);
      log(`Watch: gh run list -R $(git remote get-url origin | sed 's/.*github.com[:/]\\(.*\\)\\.git/\\1/') --workflow=release.yml`, colors.cyan);
    } else {
      log('\n✓ Release prepared locally (not pushed).', colors.green);
      log(`Next: git push origin HEAD && git push origin ${tag}`, colors.cyan);
    }
  } catch (error) {
    if (versionBumped) {
      writeVersion(repoRoot, packageJsonPath, pkg, currentVersion);
      log(`Restored ${PACKAGE_JSON} version to ${currentVersion}.`, colors.yellow);
    }
    fail(error.message);
  }
}

main();
