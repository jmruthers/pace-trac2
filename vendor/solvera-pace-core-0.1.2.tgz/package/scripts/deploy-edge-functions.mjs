#!/usr/bin/env node
/* eslint-env node */
/**
 * Deploy bundled Supabase Edge Functions (runs edge:bundle first).
 *
 * Usage:
 *   node scripts/deploy-edge-functions.mjs              # all slugs
 *   node scripts/deploy-edge-functions.mjs pump-send    # one slug
 */
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const scriptDir = path.dirname(fileURLToPath(import.meta.url));
const packageRoot = path.resolve(scriptDir, '..');
const repoRoot = path.resolve(packageRoot, '../..');
const functionsDir = path.join(packageRoot, 'supabase', 'functions');

function listFunctionSlugs() {
  return fs
    .readdirSync(functionsDir, { withFileTypes: true })
    .filter((entry) => entry.isDirectory() && entry.name !== '_shared')
    .map((entry) => entry.name)
    .sort();
}

function run(command, args) {
  const result = spawnSync(command, args, {
    cwd: repoRoot,
    stdio: 'inherit',
    shell: process.platform === 'win32',
  });
  if (result.status !== 0) {
    process.exit(result.status ?? 1);
  }
}

function ensureBundled(slugs) {
  for (const slug of slugs) {
    const bundled = path.join(functionsDir, slug, 'index.ts');
    if (!fs.existsSync(bundled)) {
      console.error(`Missing bundled ${path.relative(packageRoot, bundled)} — run npm run edge:bundle first.`);
      process.exit(1);
    }
  }
}

function main() {
  const requested = process.argv.slice(2).filter((arg) => !arg.startsWith('-'));
  const slugs = requested.length > 0 ? requested : listFunctionSlugs();

  console.log('Bundling edge functions…');
  run('npm', ['run', 'edge:bundle', '-w', '@solvera/pace-core']);

  ensureBundled(slugs);

  const deployArgs = ['run', 'supabase', '--', 'functions', 'deploy', ...slugs, '--workdir', 'packages/core'];
  console.log(`Deploying: ${slugs.join(', ')}`);
  run('npm', deployArgs);
}

main();
