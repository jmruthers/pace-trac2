/**
 * Canonical Supabase CLI invocation for npm scripts and helpers.
 *
 * Uses `npx supabase@latest` so db push / migration list / db query on preview
 * branches authenticate via the logged-in access token (login role) instead of
 * stale SUPABASE_DB_PASSWORD values in .env.
 */
module.exports = {
  command: 'npx',
  argsPrefix: ['supabase@latest'],
  /** Full command prefix for execSync-style strings (no extra quoting). */
  execPrefix: 'npx supabase@latest',
};
