#!/usr/bin/env node
/**
 * Fail when eslint-disable comments appear in source (prefer fixing the underlying issue).
 */
const fs = require('fs');
const path = require('path');

const pkgRoot = path.resolve(__dirname, '..');
const scanRoots = [
  path.join(pkgRoot, 'src'),
  path.join(pkgRoot, 'supabase', 'functions'),
];

const EXT = new Set(['.ts', '.tsx', '.js', '.jsx', '.cjs', '.mjs']);
const PATTERN = /eslint-disable/;

function walk(dir, hits) {
  if (!fs.existsSync(dir)) return;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (entry.name === 'node_modules' || entry.name === 'dist') continue;
      walk(full, hits);
      continue;
    }
    const ext = path.extname(entry.name);
    if (!EXT.has(ext)) continue;
    const text = fs.readFileSync(full, 'utf8');
    const lines = text.split(/\r?\n/);
    for (let i = 0; i < lines.length; i++) {
      if (PATTERN.test(lines[i])) {
        hits.push({ file: path.relative(pkgRoot, full), line: i + 1, text: lines[i].trim() });
      }
    }
  }
}

const hits = [];
for (const root of scanRoots) {
  walk(root, hits);
}

if (hits.length > 0) {
  console.error('eslint-disable comments are not allowed; fix the underlying lint issue instead:\n');
  for (const hit of hits) {
    console.error(`  ${hit.file}:${hit.line}  ${hit.text}`);
  }
  process.exit(1);
}

console.log('check-no-eslint-disable: ok');
