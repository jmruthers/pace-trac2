#!/usr/bin/env node
/**
 * Export Supabase advisor findings and bucket by remediation action.
 * Usage: node packages/core/scripts/advisor-inventory.cjs [--linked]
 */
const { spawnSync } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');

const repoRoot = path.resolve(__dirname, '../../..');
const auditDir = path.join(repoRoot, 'audit');
const date = new Date().toISOString().slice(0, 10);

const BUCKETS = {
  fix_grant: ['anon_security_definer_function_executable'],
  fix_rls: ['rls_disabled_in_public'],
  fix_policy_perf: ['multiple_permissive_policies', 'auth_rls_initplan'],
  fix_fk_index: ['unindexed_foreign_keys'],
  fix_storage: ['public_bucket_allows_listing'],
  fix_auth_dashboard: ['auth_leaked_password_protection'],
  accept_definer: ['authenticated_security_definer_function_executable'],
  backlog_index: ['unused_index'],
  backlog_ops: ['auth_db_connections_absolute'],
};

function runAdvisors(type, level) {
  const args = [
    path.join(__dirname, 'run-supabase-cli.cjs'),
    'db',
    'advisors',
    '--linked',
    '--type',
    type,
    '--level',
    level || 'info',
    '--output-format',
    'json',
    '--workdir',
    'packages/core',
  ];
  const result = spawnSync('node', args, {
    cwd: repoRoot,
    encoding: 'utf8',
    maxBuffer: 50 * 1024 * 1024,
  });
  const raw = result.stdout || '';
  const start = raw.indexOf('[');
  const end = raw.lastIndexOf(']');
  if (start === -1 || end === -1 || end <= start) {
    console.error('Failed to parse advisor JSON');
    console.error(raw.slice(0, 500));
    process.exit(1);
  }
  return JSON.parse(raw.slice(start, end + 1));
}

function bucketFinding(item) {
  for (const [bucket, names] of Object.entries(BUCKETS)) {
    if (names.includes(item.name)) return bucket;
  }
  return 'other';
}

function main() {
  const all = runAdvisors('all', 'info');

  const byBucket = {};
  const byName = {};
  const byLevel = {};

  for (const item of all) {
    const bucket = bucketFinding(item);
    byBucket[bucket] = byBucket[bucket] || [];
    byBucket[bucket].push(item);
    byName[item.name] = (byName[item.name] || 0) + 1;
    byLevel[item.level] = (byLevel[item.level] || 0) + 1;
  }

  if (!fs.existsSync(auditDir)) fs.mkdirSync(auditDir, { recursive: true });

  const snapshotPath = path.join(auditDir, `advisor-snapshot-${date}.json`);
  fs.writeFileSync(
    snapshotPath,
    JSON.stringify({ generatedAt: new Date().toISOString(), total: all.length, byLevel, byName, byBucket, items: all }, null, 2),
  );

  const mdLines = [
    `# Advisor snapshot ${date}`,
    '',
    `Total: **${all.length}**`,
    '',
    '## By level',
    ...Object.entries(byLevel).map(([k, v]) => `- ${k}: ${v}`),
    '',
    '## By lint name',
    ...Object.entries(byName)
      .sort((a, b) => b[1] - a[1])
      .map(([k, v]) => `- ${k}: ${v}`),
    '',
    '## By remediation bucket',
    ...Object.entries(byBucket)
      .sort((a, b) => b[1].length - a[1].length)
      .map(([k, v]) => `- **${k}**: ${v.length}`),
    '',
    `Full JSON: \`audit/advisor-snapshot-${date}.json\``,
  ];

  const mdPath = path.join(auditDir, `advisor-snapshot-${date}.md`);
  fs.writeFileSync(mdPath, mdLines.join('\n'));

  console.log(`Wrote ${snapshotPath}`);
  console.log(`Wrote ${mdPath}`);
  console.log('Buckets:', Object.fromEntries(Object.entries(byBucket).map(([k, v]) => [k, v.length])));
}

main();
