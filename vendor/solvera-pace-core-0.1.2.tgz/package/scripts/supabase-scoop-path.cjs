const fs = require('node:fs');
const path = require('node:path');

/**
 * npm / GUI-launched terminals on Windows often omit user-level PATH entries (e.g. Scoop shims).
 * Prepend default Scoop shim dirs so child_process can resolve `supabase`.
 */
function envWithScoopShimsOnPath(baseEnv) {
  const env = { ...baseEnv };
  const sep = process.platform === 'win32' ? ';' : ':';
  const shims = [];

  if (process.env.USERPROFILE) {
    const win = path.join(process.env.USERPROFILE, 'scoop', 'shims');
    if (fs.existsSync(win)) shims.push(win);
  }
  if (process.platform !== 'win32' && process.env.HOME) {
    const unix = path.join(process.env.HOME, 'scoop', 'shims');
    if (fs.existsSync(unix)) shims.push(unix);
  }

  if (shims.length === 0) return env;

  const pathVal = env.PATH ?? env.Path ?? '';
  const next = `${shims.join(sep)}${sep}${pathVal}`;
  env.PATH = next;
  if (process.platform === 'win32') env.Path = next;
  return env;
}

module.exports = { envWithScoopShimsOnPath };
