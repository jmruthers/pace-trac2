#!/usr/bin/env node
/**
 * Runs `supabase link` using project refs from the consuming app `.env`.
 *
 * Usage:
 *   node packages/core/scripts/supabase-link-from-env.cjs           # SUPABASE_PROJECT_REF (active env)
 *   node packages/core/scripts/supabase-link-from-env.cjs dev       # SUPABASE_PROJECT_REF_DEV
 *   node packages/core/scripts/supabase-link-from-env.cjs prod      # SUPABASE_PROJECT_REF_PROD
 */
const fs = require('node:fs');
const path = require('node:path');
const { execSync } = require('node:child_process');
const { envWithScoopShimsOnPath } = require('./supabase-scoop-path.cjs');
const { execPrefix: supabaseExecPrefix } = require('./supabase-cli-invocation.cjs');

const DEFAULTS = {
  dev: 'ykobfbfgushlrjcnwwkf',
  prod: 'srqhjwivpohjcjqikjry',
};

const target = (process.argv[2] || 'active').toLowerCase();

const rootDir = process.cwd();
const envPath = path.join(rootDir, '.env');

function detectSupabaseWorkdir(baseDir) {
  const directConfig = path.join(baseDir, 'supabase', 'config.toml');
  if (fs.existsSync(directConfig)) return '.';
  const packageConfig = path.join(baseDir, 'packages', 'core', 'supabase', 'config.toml');
  if (fs.existsSync(packageConfig)) return 'packages/core';
  return null;
}

function parseDotEnv(content) {
  const entries = {};
  for (const line of content.split('\n')) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const idx = line.indexOf('=');
    if (idx === -1) continue;
    const key = line.slice(0, idx).trim();
    entries[key] = line.slice(idx + 1).trim();
  }
  return entries;
}

let projectRef;

if (!fs.existsSync(envPath)) {
  console.error('Missing .env in current project root. Copy .env.example and run npm run env:dev or env:prod.');
  process.exit(1);
}

const parsed = parseDotEnv(fs.readFileSync(envPath, 'utf8'));

if (target === 'active' || target === 'current') {
  projectRef = parsed.SUPABASE_PROJECT_REF?.trim();
} else if (target === 'dev') {
  projectRef = parsed.SUPABASE_PROJECT_REF_DEV?.trim() || DEFAULTS.dev;
} else if (target === 'prod') {
  projectRef = parsed.SUPABASE_PROJECT_REF_PROD?.trim() || DEFAULTS.prod;
} else {
  console.error('Usage: node supabase-link-from-env.cjs [dev|prod]');
  console.error('  (no args) — uses SUPABASE_PROJECT_REF from .env');
  process.exit(1);
}

if (!projectRef) {
  console.error(
    'No project ref found. Set SUPABASE_PROJECT_REF (or SUPABASE_PROJECT_REF_DEV / _PROD) in .env, or run npm run env:dev | env:prod.',
  );
  process.exit(1);
}

const supabaseWorkdir = detectSupabaseWorkdir(rootDir);
if (!supabaseWorkdir) {
  console.error('No Supabase project configuration found. Expected supabase/config.toml in current project (or packages/core/supabase/config.toml).');
  process.exit(1);
}

const workdirArg = supabaseWorkdir === '.' ? '' : ` --workdir ${supabaseWorkdir}`;
execSync(`${supabaseExecPrefix} link --project-ref ${projectRef}${workdirArg}`, {
  cwd: rootDir,
  stdio: 'inherit',
  env: envWithScoopShimsOnPath(process.env),
});
