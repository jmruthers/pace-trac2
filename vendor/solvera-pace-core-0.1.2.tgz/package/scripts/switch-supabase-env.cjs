#!/usr/bin/env node
const fs = require('node:fs');
const path = require('node:path');
const { execSync } = require('node:child_process');
const { envWithScoopShimsOnPath } = require('./supabase-scoop-path.cjs');
const { execPrefix: supabaseExecPrefix } = require('./supabase-cli-invocation.cjs');

const target = process.argv[2];

const DEFAULTS = {
  dev: {
    projectRef: 'ykobfbfgushlrjcnwwkf',
    url: 'https://ykobfbfgushlrjcnwwkf.supabase.co',
  },
  prod: {
    projectRef: 'srqhjwivpohjcjqikjry',
    url: 'https://srqhjwivpohjcjqikjry.supabase.co',
  },
};

if (!target || !DEFAULTS[target]) {
  console.error('Usage: node packages/core/scripts/switch-supabase-env.cjs <dev|prod>');
  process.exit(1);
}

const rootDir = process.cwd();
const envPath = path.join(rootDir, '.env');
const mcpPath = path.join(rootDir, '.cursor', 'mcp.json');

function detectSupabaseWorkdir(baseDir) {
  const directConfig = path.join(baseDir, 'supabase', 'config.toml');
  if (fs.existsSync(directConfig)) return '.';
  const packageConfig = path.join(baseDir, 'packages', 'core', 'supabase', 'config.toml');
  if (fs.existsSync(packageConfig)) return 'packages/core';
  return null;
}

function parseDotEnv(content) {
  const entries = {};
  const lines = content.split('\n');
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const idx = line.indexOf('=');
    if (idx === -1) continue;
    const key = line.slice(0, idx).trim();
    const value = line.slice(idx + 1);
    entries[key] = value;
  }
  return entries;
}

function upsertLine(lines, key, value) {
  const prefix = `${key}=`;
  const idx = lines.findIndex((line) => line.startsWith(prefix));
  if (idx >= 0) {
    lines[idx] = `${prefix}${value}`;
    return;
  }
  lines.push(`${prefix}${value}`);
}

function resolveTargetConfig(parsed, name) {
  const fallback = DEFAULTS[name];
  const refKey = name === 'dev' ? 'SUPABASE_PROJECT_REF_DEV' : 'SUPABASE_PROJECT_REF_PROD';
  const urlKey = name === 'dev' ? 'VITE_SUPABASE_URL_DEV' : 'VITE_SUPABASE_URL_PROD';
  const ref = parsed[refKey]?.trim() || fallback.projectRef;
  const url =
    parsed[urlKey]?.trim() ||
    (ref ? `https://${ref}.supabase.co` : fallback.url);
  return { projectRef: ref, url };
}

const envFileExists = fs.existsSync(envPath);
const existingEnv = envFileExists ? fs.readFileSync(envPath, 'utf8') : '';
const parsedEnv = parseDotEnv(existingEnv);
const envLines = existingEnv ? existingEnv.replace(/\r\n/g, '\n').split('\n') : [];

const envConfig = resolveTargetConfig(parsedEnv, target);

if (target === 'dev') {
  upsertLine(envLines, 'SUPABASE_PROJECT_REF_DEV', envConfig.projectRef);
  upsertLine(envLines, 'VITE_SUPABASE_URL_DEV', envConfig.url);
}
if (target === 'prod') {
  const prodCfg = resolveTargetConfig(parsedEnv, 'prod');
  upsertLine(envLines, 'SUPABASE_PROJECT_REF_PROD', prodCfg.projectRef);
  upsertLine(envLines, 'VITE_SUPABASE_URL_PROD', prodCfg.url);
}

const activeKey = parsedEnv.VITE_SUPABASE_PUBLISHABLE_KEY || '';
const devKey = parsedEnv.VITE_SUPABASE_PUBLISHABLE_KEY_DEV || '';
const prodKey = parsedEnv.VITE_SUPABASE_PUBLISHABLE_KEY_PROD || '';
const selectedKey = target === 'dev' ? devKey : prodKey;

if (!devKey && target === 'dev') {
  console.warn('Warning: VITE_SUPABASE_PUBLISHABLE_KEY_DEV is empty in .env');
}

if (!prodKey && target === 'prod') {
  console.warn('Warning: VITE_SUPABASE_PUBLISHABLE_KEY_PROD is empty in .env');
}

if (!devKey && activeKey && target === 'dev') {
  upsertLine(envLines, 'VITE_SUPABASE_PUBLISHABLE_KEY_DEV', activeKey);
}

if (!prodKey && activeKey && target === 'prod') {
  upsertLine(envLines, 'VITE_SUPABASE_PUBLISHABLE_KEY_PROD', activeKey);
}

upsertLine(envLines, 'SUPABASE_ENV', target);
upsertLine(envLines, 'SUPABASE_PROJECT_REF', envConfig.projectRef);
upsertLine(envLines, 'VITE_SUPABASE_URL', envConfig.url);
upsertLine(envLines, 'VITE_SUPABASE_PUBLISHABLE_KEY', selectedKey || activeKey || '');

if (envLines.length > 0 && envLines[envLines.length - 1] !== '') {
  envLines.push('');
}

fs.writeFileSync(envPath, envLines.join('\n'), 'utf8');

const mcpConfig = {
  mcpServers: {
    supabase: {
      url: `https://mcp.supabase.com/mcp?project_ref=${envConfig.projectRef}`,
    },
  },
};
fs.mkdirSync(path.dirname(mcpPath), { recursive: true });
fs.writeFileSync(mcpPath, `${JSON.stringify(mcpConfig, null, 2)}\n`, 'utf8');

const supabaseWorkdir = detectSupabaseWorkdir(rootDir);
if (supabaseWorkdir) {
  const workdirArg = supabaseWorkdir === '.' ? '' : ` --workdir ${supabaseWorkdir}`;
  execSync(`${supabaseExecPrefix} link --project-ref ${envConfig.projectRef}${workdirArg}`, {
    cwd: rootDir,
    stdio: 'inherit',
    env: envWithScoopShimsOnPath(process.env),
  });
}

console.log(`Switched Supabase context to ${target} (${envConfig.projectRef}).`);
