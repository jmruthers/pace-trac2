/**
 * TRAC function uuid cast audit config.
 */

/** Uuid columns compared against text params in TRAC helpers. */
const UUID_COLUMNS = ['event_id'];

const TEXT_ID_COLUMNS = new Set();

/** Trigger helpers use uuid-native comparisons only. */
const AUDIT_SKIP = new Set([
  'trac_itinerary_assignment_cleanup_after_resource_delete',
  'trac_itinerary_assignment_validate_resource',
]);

const BAD_PATTERNS = [];

module.exports = {
  UUID_COLUMNS,
  TEXT_ID_COLUMNS,
  AUDIT_SKIP,
  BAD_PATTERNS,
};
