#!/usr/bin/env node
/**
 * Generate a consumer-facing export index for @solvera/pace-core.
 *
 * Reads package exports + declaration files and writes:
 * packages/core/docs/reference/consumer-exports-index.md
 */
const fs = require('fs');
const path = require('path');
const ts = require('typescript');

const pkgRoot = path.resolve(__dirname, '..');
const distRoot = path.join(pkgRoot, 'dist');
const packageJsonPath = path.join(pkgRoot, 'package.json');
const outputPath = path.join(pkgRoot, 'docs', 'reference', 'consumer-exports-index.md');
const governanceConfigPath = path.join(pkgRoot, 'scripts', 'export-governance.config.json');

function readJson(filePath) {
  return JSON.parse(fs.readFileSync(filePath, 'utf8'));
}

function listDtsFilesRecursive(dir) {
  if (!fs.existsSync(dir)) return [];
  const out = [];
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      out.push(...listDtsFilesRecursive(fullPath));
    } else if (entry.isFile() && entry.name.endsWith('.d.ts')) {
      out.push(fullPath);
    }
  }
  return out;
}

function resolveTypesPath(rawTypesPath) {
  const directPath = path.join(pkgRoot, rawTypesPath);
  if (fs.existsSync(directPath)) return directPath;

  // Fallback: "./dist/icons.d.ts" -> "./dist/icons/index.d.ts"
  if (rawTypesPath.endsWith('.d.ts')) {
    const withoutExt = rawTypesPath.slice(0, -'.d.ts'.length);
    const indexPath = path.join(pkgRoot, withoutExt, 'index.d.ts');
    if (fs.existsSync(indexPath)) return indexPath;
  }

  return null;
}

function toModuleName(pkgName, subpath) {
  if (subpath === '.') return pkgName;
  return `${pkgName}/${subpath.replace(/^\.\//, '')}`;
}

function humanizeName(input) {
  return input
    .replace(/[_-]+/g, ' ')
    .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();
}

function shorten(value, max = 140) {
  if (value.length <= max) return value;
  return `${value.slice(0, max - 1)}...`;
}

function escapeTableCell(value) {
  return value.replace(/\|/g, '\\|').replace(/\n/g, ' ');
}

function classifyStability(moduleName, symbolName, packageName, governanceConfig) {
  const internalSymbols = new Set(governanceConfig.internalSymbols || []);
  if (internalSymbols.has(symbolName)) return 'internal';
  if (moduleName === packageName) return 'stable';
  return 'advanced';
}

function preferredImportPath(stability, moduleName, packageName) {
  if (stability === 'stable') return packageName;
  if (stability === 'internal') return `${moduleName} (internal)`;
  return moduleName;
}

function getKind(symbol, isTypeOnly) {
  const name = symbol.getName();
  const flags = symbol.flags;
  if (isTypeOnly) return 'type';
  if (/^use[A-Z0-9]/.test(name)) return 'hook';
  if (name.endsWith('Provider')) return 'provider';
  if (flags & ts.SymbolFlags.Class) return 'class';
  if (flags & ts.SymbolFlags.Enum) return 'enum';
  if (/^[A-Z]/.test(name) && !/^[A-Z0-9_]+$/.test(name)) return 'component';
  if (flags & ts.SymbolFlags.Function) return 'function';
  if (/^[A-Z0-9_]+$/.test(name)) return 'constant';
  if (flags & ts.SymbolFlags.Variable) return 'constant';
  return 'function';
}

function getDescription(name, kind) {
  if (kind === 'hook') {
    return `React hook for ${humanizeName(name.replace(/^use/, ''))}.`;
  }
  if (kind === 'provider') {
    return `React context provider for ${humanizeName(name.replace(/Provider$/, ''))}.`;
  }
  if (kind === 'component') {
    return `UI component for ${humanizeName(name)}.`;
  }
  if (kind === 'constant') {
    return `Constant value for ${humanizeName(name)}.`;
  }
  if (kind === 'class') {
    return `Class export for ${humanizeName(name)}.`;
  }
  if (kind === 'enum') {
    return `Enum export for ${humanizeName(name)}.`;
  }
  if (kind === 'type') {
    if (name.endsWith('Props')) return `Props type for ${humanizeName(name.replace(/Props$/, ''))}.`;
    if (name.endsWith('Options')) return `Options type for ${humanizeName(name.replace(/Options$/, ''))}.`;
    if (name.endsWith('Result')) return `Result type for ${humanizeName(name.replace(/Result$/, ''))}.`;
    return `Type export for ${humanizeName(name)}.`;
  }
  return `Function for ${humanizeName(name)}.`;
}

function symbolToSignature(symbol, checker, name, isTypeOnly, kind) {
  const declarations = symbol.getDeclarations() || [];
  const declaration = declarations[0];

  if (isTypeOnly) {
    if (symbol.flags & ts.SymbolFlags.Interface) {
      return `interface ${name}`;
    }
    if (symbol.flags & ts.SymbolFlags.TypeAlias) {
      return `type ${name}`;
    }
    return `type ${name}`;
  }

  if (symbol.flags & ts.SymbolFlags.Class) return `class ${name}`;
  if (symbol.flags & ts.SymbolFlags.Enum) return `enum ${name}`;

  if (!declaration) return name;

  const type = checker.getTypeOfSymbolAtLocation(symbol, declaration);
  const signatures = type.getCallSignatures();
  if (
    signatures.length > 0 &&
    (kind === 'hook' || kind === 'function' || kind === 'component' || kind === 'provider')
  ) {
    const rendered = checker.signatureToString(
      signatures[0],
      declaration,
      ts.TypeFormatFlags.NoTruncation
    );
    return normalizeSignature(`${name}${rendered}`);
  }

  const renderedType = checker.typeToString(type, declaration, ts.TypeFormatFlags.NoTruncation);
  if (symbol.flags & ts.SymbolFlags.Function) return `function ${name}`;
  if (symbol.flags & ts.SymbolFlags.Variable) return normalizeSignature(`const ${name}: ${shorten(renderedType)}`);
  return normalizeSignature(`${name}: ${shorten(renderedType)}`);
}

function normalizeSignature(signature) {
  return signature
    .replace(/import\("react\/jsx-runtime"\)\.JSX\.Element/g, 'JSX.Element')
    .replace(/import\("react"\)\.ReactPortal/g, 'ReactPortal')
    .replace(/import\("react"\)\.ReactNode/g, 'ReactNode')
    .replace(/import\("react"\)\.RefAttributes/g, 'RefAttributes')
    .replace(/import\("react"\)\.ComponentType/g, 'ComponentType')
    .replace(/import\(".*node_modules\/@types\/react\/index"\)\.ReactNode/g, 'ReactNode')
    .replace(/import\(".*node_modules\/@types\/react\/index"\)\.RefAttributes/g, 'RefAttributes')
    .replace(/typeof import\(".*node_modules\/zod\/v4\/classic\/external"\)/g, 'typeof zod');
}

function buildExportRows(entrypointFile, checker, program, context) {
  const sourceFile = program.getSourceFile(entrypointFile);
  if (!sourceFile) return { runtime: [], typeOnly: [] };

  const moduleSymbol = checker.getSymbolAtLocation(sourceFile);
  if (!moduleSymbol) return { runtime: [], typeOnly: [] };

  const exports = checker.getExportsOfModule(moduleSymbol);
  const runtime = [];
  const typeOnly = [];

  for (const exported of exports) {
    const exportName = exported.getName();
    if (exportName === 'default') continue;

    const resolvedSymbol =
      exported.flags & ts.SymbolFlags.Alias ? checker.getAliasedSymbol(exported) : exported;

    const isValue =
      Boolean(resolvedSymbol.flags & ts.SymbolFlags.Function) ||
      Boolean(resolvedSymbol.flags & ts.SymbolFlags.Class) ||
      Boolean(resolvedSymbol.flags & ts.SymbolFlags.Enum) ||
      Boolean(resolvedSymbol.flags & ts.SymbolFlags.ValueModule) ||
      Boolean(resolvedSymbol.flags & ts.SymbolFlags.Variable) ||
      Boolean(resolvedSymbol.flags & ts.SymbolFlags.Method) ||
      Boolean(resolvedSymbol.flags & ts.SymbolFlags.Property) ||
      Boolean(resolvedSymbol.flags & ts.SymbolFlags.GetAccessor) ||
      Boolean(resolvedSymbol.flags & ts.SymbolFlags.SetAccessor);

    const isTypeOnly = !isValue;
    let kind = getKind(resolvedSymbol, isTypeOnly);
    const signature = symbolToSignature(resolvedSymbol, checker, exportName, isTypeOnly, kind);
    const looksLikeReactComponent = /JSX\.Element|ReactNode|ReactPortal/.test(signature);
    if (!isTypeOnly) {
      if (kind === 'component' && !looksLikeReactComponent) kind = 'function';
      if (
        kind === 'constant' &&
        /^[A-Z]/.test(exportName) &&
        looksLikeReactComponent &&
        !/^[A-Z0-9_]+$/.test(exportName)
      ) {
        kind = 'component';
      }
    }
    const stability = classifyStability(
      context.moduleName,
      exportName,
      context.packageName,
      context.governanceConfig
    );
    const description = getDescription(exportName, kind);
    const preferredImport = preferredImportPath(stability, context.moduleName, context.packageName);

    const row = {
      name: exportName,
      kind,
      description,
      signature,
      stability,
      preferredImport,
    };

    if (isTypeOnly) {
      typeOnly.push(row);
    } else {
      runtime.push(row);
    }
  }

  runtime.sort((a, b) => a.name.localeCompare(b.name));
  typeOnly.sort((a, b) => a.name.localeCompare(b.name));
  return { runtime, typeOnly };
}

function renderSectionTable(rows) {
  if (rows.length === 0) return '_None._\n';
  const lines = [
    '| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |',
    '|---|---|---|---|---|---|',
  ];
  for (const row of rows) {
    lines.push(
      `| \`${escapeTableCell(row.name)}\` | ${escapeTableCell(row.kind)} | ${escapeTableCell(row.stability)} | \`${escapeTableCell(row.preferredImport)}\` | ${escapeTableCell(row.description)} | \`${escapeTableCell(row.signature)}\` |`
    );
  }
  return `${lines.join('\n')}\n`;
}

function generateIndexMarkdown() {
  if (!fs.existsSync(packageJsonPath)) {
    throw new Error(`Missing package.json at ${packageJsonPath}`);
  }
  if (!fs.existsSync(distRoot)) {
    throw new Error('dist directory is missing. Run `npm run build` in packages/core first.');
  }

  const pkgJson = readJson(packageJsonPath);
  const packageName = String(pkgJson.name || '@solvera/pace-core');
  const exportsMap = pkgJson.exports || {};
  const governanceConfig = fs.existsSync(governanceConfigPath)
    ? readJson(governanceConfigPath)
    : { internalSymbols: [], strictRootPrimitiveNoClassName: [], knownNameCollisions: {} };

  const entrypoints = [];
  for (const [subpath, exportConfig] of Object.entries(exportsMap)) {
    if (!exportConfig || typeof exportConfig === 'string') continue;
    if (typeof exportConfig.types !== 'string') continue;

    const resolvedTypesPath = resolveTypesPath(exportConfig.types);
    if (!resolvedTypesPath) continue;
    entrypoints.push({
      subpath,
      moduleName: toModuleName(packageName, subpath),
      typesPath: resolvedTypesPath,
    });
  }

  entrypoints.sort((a, b) => a.moduleName.localeCompare(b.moduleName));

  const allDtsFiles = listDtsFilesRecursive(distRoot);
  const program = ts.createProgram(allDtsFiles, {
    allowJs: false,
    declaration: true,
    emitDeclarationOnly: true,
    module: ts.ModuleKind.ESNext,
    moduleResolution: ts.ModuleResolutionKind.Bundler,
    skipLibCheck: true,
    target: ts.ScriptTarget.ES2022,
  });
  const checker = program.getTypeChecker();

  const now = new Date().toISOString();
  const lines = [];
  lines.push('# pace-core consumer export index');
  lines.push('');
  lines.push('Comprehensive index of all public `@solvera/pace-core` exports for consumers.');
  lines.push('');
  lines.push('- Scope: all package API entrypoints in `package.json` `exports` with TypeScript declarations.');
  lines.push('- Detail level: signature-level only (function signatures + props/option type surfaces).');
  lines.push('- Stability tiers: `stable` (root consumer contract), `advanced` (scoped entrypoints), `internal` (not for consumer use).');
  lines.push('- Preferred import path: root for stable APIs, scoped entrypoints for advanced APIs.');
  lines.push(`- Generated: \`${now}\` via \`npm run docs:exports-index\`.`);
  lines.push('');
  lines.push('## Import policy');
  lines.push('');
  lines.push('- Use `@solvera/pace-core` by default for stable APIs.');
  lines.push('- Use scoped entrypoints only for advanced APIs.');
  lines.push('- Do not depend on exports marked `internal`.');
  lines.push('');
  lines.push('## Known collisions');
  lines.push('');
  const collisionEntries = Object.entries(governanceConfig.knownNameCollisions || {});
  if (collisionEntries.length === 0) {
    lines.push('- None.');
  } else {
    for (const [symbol, modules] of collisionEntries) {
      lines.push(`- \`${symbol}\`: ${modules.map((mod) => `\`${mod}\``).join(', ')}`);
    }
    lines.push('');
    lines.push('Collision-safe import examples:');
    for (const [symbol, modules] of collisionEntries) {
      const first = modules[0];
      const second = modules[1];
      if (first && second) {
        lines.push(`- \`${symbol}\` component from \`${first}\`: \`import { ${symbol} } from '${first}';\``);
        lines.push(`- \`${symbol}\` alternative from \`${second}\`: \`import { ${symbol} as ${symbol}Alt } from '${second}';\``);
      }
    }
  }
  lines.push('');
  lines.push('## Entry points');
  lines.push('');
  for (const entrypoint of entrypoints) {
    const anchorId = entrypoint.moduleName
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+/, '')
      .replace(/-+$/, '');
    lines.push(`- [\`${entrypoint.moduleName}\`](#${anchorId})`);
  }
  lines.push('');

  for (const entrypoint of entrypoints) {
    const context = { moduleName: entrypoint.moduleName, packageName, governanceConfig };
    const { runtime, typeOnly } = buildExportRows(entrypoint.typesPath, checker, program, context);
    lines.push(`## \`${entrypoint.moduleName}\``);
    lines.push('');
    lines.push(`Declaration source: \`${path.relative(pkgRoot, entrypoint.typesPath)}\``);
    lines.push('');
    lines.push('### Runtime exports');
    lines.push('');
    lines.push(renderSectionTable(runtime).trimEnd());
    lines.push('');
    lines.push('### Type exports');
    lines.push('');
    lines.push(renderSectionTable(typeOnly).trimEnd());
    lines.push('');
  }

  return {
    markdown: `${lines.join('\n').trimEnd()}\n`,
    entrypointCount: entrypoints.length,
  };
}

function main() {
  const { markdown, entrypointCount } = generateIndexMarkdown();
  fs.mkdirSync(path.dirname(outputPath), { recursive: true });
  fs.writeFileSync(outputPath, markdown, 'utf8');
  console.log(`Generated ${path.relative(pkgRoot, outputPath)} with ${entrypointCount} entrypoints.`);
}

if (require.main === module) {
  main();
}

module.exports = {
  generateIndexMarkdown,
};
