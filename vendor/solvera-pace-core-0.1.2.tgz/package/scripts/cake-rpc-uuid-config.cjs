/**
 * DEC-075 uuid columns and CAKE RPC audit config.
 * Shared by audit-cake-rpc-uuid-casts.cjs.
 */

/** Columns migrated to uuid in DEC-075 (table.column). */
const UUID_COLUMNS = [
  'event_id',
  'supplier_id',
  'diettype_id',
  'meal_id',
  'dish_id',
  'item_id',
  'package_id',
  'package_itemid',
  'delivery_id',
  'delivery_supplier_id',
  'supply_id',
  'supply_packageid',
  'supply_supplier_id',
  'recipe_id',
  'recipe_dish_id',
  'recipe_item_id',
  'recipe_diettype_id',
  'diner_id',
  'diner_diettype_id',
  'mealplan_id',
  'mealplan_meal_id',
  'mealplan_dish_id',
  'diner_meal_id',
  'diner_meal_meal_id',
  'diner_meal_diettype_id',
];

/** Text columns intentionally NOT uuid after DEC-075. */
const TEXT_ID_COLUMNS = new Set([
  'unit_id',
  'diner_meal_unit_id',
  'diner_meal_external_person_id',
  'meal_mealtype_id',
  'mealtype_id',
  'dish_mealtype_id',
]);

/** Functions excluded from audit (text PK by design or already uuid-native params). */
const AUDIT_SKIP = new Set([
  'app_cake_unit_create',
  'app_cake_units_bulk_import',
  'app_cake_order_receiving_create',
  'app_cake_order_receiving_update',
  'app_cake_order_receiving_delete',
  'app_cake_order_receiving_upsert',
  'data_cake_order_receiving_get',
  'data_cake_order_receiving_list',
]);

const BAD_PATTERNS = [
  {
    id: 'hyphen_stripped_uuid',
    severity: 'error',
    regex: /REPLACE\s*\(\s*gen_random_uuid\s*\(\s*\)\s*::\s*text\s*,\s*'-'\s*,\s*''\s*\)/gi,
    message: 'Uses hyphen-stripped text UUID instead of gen_random_uuid()',
  },
  {
    id: 'uuid_cast_to_text',
    severity: 'error',
    regex: /gen_random_uuid\s*\(\s*\)\s*::\s*text/gi,
    message: 'Casts gen_random_uuid() to text for uuid PK insert',
  },
];

module.exports = {
  UUID_COLUMNS,
  TEXT_ID_COLUMNS,
  AUDIT_SKIP,
  BAD_PATTERNS,
};
