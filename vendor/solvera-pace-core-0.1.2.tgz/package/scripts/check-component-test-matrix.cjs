#!/usr/bin/env node
/**
 * Validates pace-core package component test colocation and folder layout.
 * Run from packages/core (or via validate.cjs).
 */
const fs = require('fs');
const path = require('path');

const ALLOWED_TOP_LEVEL = new Set([
  'primitives',
  'overlays',
  'shell',
  'forms-feedback',
  'auth',
  'advanced-ui',
  'data-table',
  'public-layout',
]);

const LEGACY_FOLDERS = ['DataTable', 'PublicLayout', 'select-internal'];
const UTIL_EXCLUDE = new Set(['index.ts', 'types.ts', 'dataTableControllerTypes.ts']);
const COMPONENT_TEST_EXCLUDE = [
  /[/\\]internal[/\\]/,
  /[/\\]data-table[/\\]DataTable(Modals|Layout|CaptionToolbar|FilterRow|Body|PaginationFooter)\.tsx$/,
  /[/\\]data-table[/\\]columnFactory\.tsx$/,
];
const ORCHESTRATION_HOOK_EXCLUDE = [
  /[/\\]data-table[/\\]useDataTable(Controller|ToolbarState|SelectionState|ServerParams)\.ts$/,
];

function walk(dir, cb) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const abs = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(abs, cb);
    else cb(abs);
  }
}

function runComponentGovernance(componentsDir) {
  const failures = [];

  if (!fs.existsSync(componentsDir)) {
    failures.push(`Missing components directory: ${componentsDir}`);
    return failures;
  }

  for (const legacy of LEGACY_FOLDERS) {
    if (fs.existsSync(path.join(componentsDir, legacy))) {
      failures.push(`Legacy component folder must be removed: components/${legacy}/`);
    }
  }

  for (const entry of fs.readdirSync(componentsDir, { withFileTypes: true })) {
    if (!entry.isDirectory()) {
      if (entry.name.endsWith('.tsx')) {
        failures.push(`Component .tsx at components root is not allowed: ${entry.name}`);
      }
      continue;
    }
    if (!ALLOWED_TOP_LEVEL.has(entry.name)) {
      failures.push(`Disallowed top-level components folder: ${entry.name}/`);
    }
  }

  walk(componentsDir, (file) => {
    if (!file.endsWith('.tsx') || file.includes('.integration.test.') || file.includes('.test.')) {
      return;
    }
    if (COMPONENT_TEST_EXCLUDE.some((pattern) => pattern.test(file))) {
      return;
    }
    const base = path.basename(file, '.tsx');
    const dir = path.dirname(file);
    const integrationTest = path.join(dir, `${base}.integration.test.tsx`);
    if (!fs.existsSync(integrationTest)) {
      failures.push(`Missing integration test for exported component: ${path.relative(componentsDir, file)}`);
    }
    const plainTest = path.join(dir, `${base}.test.tsx`);
    if (fs.existsSync(plainTest)) {
      failures.push(`Duplicate DOM component test naming (use *.integration.test.tsx): ${path.relative(componentsDir, plainTest)}`);
    }
  });

  walk(componentsDir, (file) => {
    if (!file.endsWith('.ts') || file.includes('.test.') || file.endsWith('.typetest.ts')) return;
    const base = path.basename(file);
    if (UTIL_EXCLUDE.has(base)) return;
    if (base.endsWith('.tsx')) return;
    if (COMPONENT_TEST_EXCLUDE.some((pattern) => pattern.test(file))) return;
    if (ORCHESTRATION_HOOK_EXCLUDE.some((pattern) => pattern.test(file))) return;
    const testFile = file.replace(/\.ts$/, '.test.ts');
    if (!fs.existsSync(testFile)) {
      failures.push(`Missing unit test for component utility: ${path.relative(componentsDir, file)}`);
    }
  });

  return failures;
}

function main() {
  const cwd = process.cwd();
  const componentsDir = path.join(cwd, 'src', 'components');
  const failures = runComponentGovernance(componentsDir);
  if (failures.length > 0) {
    console.error('Component governance check failed:');
    for (const failure of failures) {
      console.error(`  - ${failure}`);
    }
    process.exit(1);
  }
  console.log('Component governance check passed.');
}

if (require.main === module) {
  main();
}

module.exports = { runComponentGovernance };
