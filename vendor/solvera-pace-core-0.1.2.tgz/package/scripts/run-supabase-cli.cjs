#!/usr/bin/env node
const { spawnSync } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');
const { envWithScoopShimsOnPath } = require('./supabase-scoop-path.cjs');
const { command: supabaseCommand, argsPrefix: supabaseArgsPrefix } = require('./supabase-cli-invocation.cjs');

function parseDotEnv(content) {
  const entries = {};
  for (const line of content.split('\n')) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const idx = line.indexOf('=');
    if (idx === -1) continue;
    const key = line.slice(0, idx).trim();
    entries[key] = line.slice(idx + 1).trim();
  }
  return entries;
}

function detectSupabaseWorkdir(baseDir) {
  const directConfig = path.join(baseDir, 'supabase', 'config.toml');
  if (fs.existsSync(directConfig)) return '.';
  const packageConfig = path.join(baseDir, 'packages', 'core', 'supabase', 'config.toml');
  if (fs.existsSync(packageConfig)) return 'packages/core';
  return null;
}

function loadProjectEnv(baseEnv) {
  const envPath = path.join(process.cwd(), '.env');
  if (!fs.existsSync(envPath)) return { ...baseEnv };
  const fromFile = parseDotEnv(fs.readFileSync(envPath, 'utf8'));
  return { ...baseEnv, ...fromFile };
}

function hasWorkdirArg(args) {
  return args.some((arg, index) => {
    if (arg === '--workdir') return true;
    if (arg.startsWith('--workdir=')) return true;
    if (index > 0 && args[index - 1] === '--workdir') return true;
    return false;
  });
}

function ensureWorkdirArgs(args) {
  if (hasWorkdirArg(args)) return args;
  const workdir = detectSupabaseWorkdir(process.cwd());
  if (!workdir) return args;
  return ['--workdir', workdir, ...args];
}

function readWorkdirFromArgs(args) {
  for (let i = 0; i < args.length; i += 1) {
    if (args[i] === '--workdir' && args[i + 1]) return args[i + 1];
    if (args[i].startsWith('--workdir=')) return args[i].slice('--workdir='.length);
  }
  return null;
}

/**
 * Supabase CLI v2.79+ uses access-token "login role" when cwd is the linked workdir
 * and --workdir is `.`. Spawning from repo root with --workdir packages/core falls
 * back to SUPABASE_DB_PASSWORD (often stale on preview branches).
 */
function resolveSpawnContext(repoRoot, args) {
  const workdirRel = readWorkdirFromArgs(args) ?? detectSupabaseWorkdir(repoRoot);
  const spawnCwd =
    !workdirRel || workdirRel === '.' ? repoRoot : path.resolve(repoRoot, workdirRel);

  const normalizedArgs = [...args];
  if (workdirRel) {
    let replaced = false;
    for (let i = 0; i < normalizedArgs.length; i += 1) {
      if (normalizedArgs[i] === '--workdir' && normalizedArgs[i + 1]) {
        normalizedArgs[i + 1] = '.';
        replaced = true;
        break;
      }
      if (normalizedArgs[i].startsWith('--workdir=')) {
        normalizedArgs[i] = '--workdir=.';
        replaced = true;
        break;
      }
    }
    if (!replaced) {
      normalizedArgs.unshift('--workdir', '.');
    }
  }

  return { args: normalizedArgs, spawnCwd, workdirRel };
}

function readLinkedProjectRef(spawnCwd) {
  const refPath = path.join(spawnCwd, 'supabase', '.temp', 'project-ref');
  if (!fs.existsSync(refPath)) return null;
  return fs.readFileSync(refPath, 'utf8').trim() || null;
}

function warnIfLinkedRefDrifts(env, spawnCwd) {
  const expectedRef = env.SUPABASE_PROJECT_REF?.trim();
  if (!expectedRef || !spawnCwd) return;
  const linkedRef = readLinkedProjectRef(spawnCwd);
  if (linkedRef && linkedRef !== expectedRef) {
    console.warn(
      `Warning: linked Supabase project (${linkedRef}) does not match SUPABASE_PROJECT_REF (${expectedRef}). Run npm run migrate:link or npm run env:dev | env:prod.`,
    );
  }
}

const rawArgs = process.argv.slice(2);
if (rawArgs.length === 0) {
  console.error('Usage: pass Supabase CLI args, e.g. npm run supabase -- login');
  process.exit(1);
}

const repoRoot = process.cwd();
const argsWithWorkdir = ensureWorkdirArgs(rawArgs);
const env = envWithScoopShimsOnPath(loadProjectEnv(process.env));
// Stale branch passwords in .env force direct postgres auth and block login-role flow.
delete env.SUPABASE_DB_PASSWORD;
const { args, spawnCwd } = resolveSpawnContext(repoRoot, argsWithWorkdir);
warnIfLinkedRefDrifts(env, spawnCwd);

const result = spawnSync(supabaseCommand, [...supabaseArgsPrefix, ...args], {
  cwd: spawnCwd,
  stdio: 'inherit',
  env,
  shell: process.platform === 'win32',
});

process.exit(result.status === null ? 1 : result.status);
