#!/usr/bin/env node
/**
 * Export governance checks:
 * - root exports must be stable-only
 * - strict primitives in root must not expose className
 * - root className usage must follow explicit allowlist
 * - consumer-published entrypoints must not expose internal exports
 * - generated export index must be up to date
 */
const fs = require('fs');
const path = require('path');
const { generateIndexMarkdown } = require('./generate-consumer-exports-index.cjs');

const pkgRoot = path.resolve(__dirname, '..');
const outputPath = path.join(pkgRoot, 'docs', 'reference', 'consumer-exports-index.md');
const governanceConfigPath = path.join(pkgRoot, 'scripts', 'export-governance.config.json');

function parseRows(markdown) {
  const rows = [];
  const lines = markdown.split(/\r?\n/);
  let currentSection = '';
  let currentTable = '';
  for (const line of lines) {
    const sectionMatch = line.match(/^## `([^`]+)`$/);
    if (sectionMatch) {
      currentSection = sectionMatch[1];
      currentTable = '';
      continue;
    }
    if (line === '### Runtime exports') {
      currentTable = 'runtime';
      continue;
    }
    if (line === '### Type exports') {
      currentTable = 'types';
      continue;
    }
    if (!line.startsWith('| `')) continue;
    const cols = line.split('|').map((part) => part.trim());
    if (cols.length < 8) continue;
    rows.push({
      section: currentSection,
      table: currentTable,
      name: cols[1].replace(/`/g, ''),
      kind: cols[2],
      stability: cols[3],
      preferredImport: cols[4].replace(/`/g, ''),
      description: cols[5],
      signature: cols[6].replace(/`/g, ''),
    });
  }
  return rows;
}

function main() {
  const governanceConfig = fs.existsSync(governanceConfigPath)
    ? JSON.parse(fs.readFileSync(governanceConfigPath, 'utf8'))
    : { strictRootPrimitiveNoClassName: [] };

  const generated = generateIndexMarkdown().markdown;

  if (!fs.existsSync(outputPath)) {
    throw new Error(`Missing generated index: ${path.relative(pkgRoot, outputPath)}. Run npm run docs:exports-index.`);
  }

  const existing = fs.readFileSync(outputPath, 'utf8');
  const normalize = (value) =>
    value.replace(/- Generated: `[^`]+` via `npm run docs:exports-index`\./, '- Generated: `<timestamp>` via `npm run docs:exports-index`.');
  if (normalize(existing) !== normalize(generated)) {
    throw new Error(
      'Export index is out of date. Run npm run docs:exports-index and commit the generated output.'
    );
  }

  const rows = parseRows(existing);
  const rootRows = rows.filter((row) => row.section === '@solvera/pace-core');
  const rootNonStable = rootRows.filter((row) => row.stability !== 'stable');
  if (rootNonStable.length > 0) {
    const list = rootNonStable.map((row) => row.name).join(', ');
    throw new Error(`Root entrypoint includes non-stable exports: ${list}`);
  }

  const rootRuntimeAllowlist = new Set(governanceConfig.rootRuntimeAllowlist || []);
  const rootTypeAllowlist = new Set(governanceConfig.rootTypeAllowlist || []);
  const rootRuntimeRows = rootRows.filter((row) => row.table === 'runtime');
  const rootTypeRows = rootRows.filter((row) => row.table === 'types');

  const rootRuntimeOffenders = rootRuntimeRows.filter((row) => !rootRuntimeAllowlist.has(row.name));
  if (rootRuntimeOffenders.length > 0) {
    const list = rootRuntimeOffenders.map((row) => row.name).join(', ');
    throw new Error(`Root runtime facade exposes non-allowlisted symbols: ${list}`);
  }

  const rootTypeOffenders = rootTypeRows.filter((row) => !rootTypeAllowlist.has(row.name));
  if (rootTypeOffenders.length > 0) {
    const list = rootTypeOffenders.map((row) => row.name).join(', ');
    throw new Error(`Root type facade exposes non-allowlisted symbols: ${list}`);
  }

  const strictNames = new Set(governanceConfig.strictRootPrimitiveNoClassName || []);
  const offenders = rootRows.filter(
    (row) =>
      row.table === 'runtime' &&
      strictNames.has(row.name) &&
      /\bclassName\b/.test(row.signature)
  );
  if (offenders.length > 0) {
    const list = offenders.map((row) => `${row.name}`).join(', ');
    throw new Error(`Strict root primitives still expose className: ${list}`);
  }

  const rootClassNameAllowlist = new Set(governanceConfig.rootRuntimeClassNameAllowlist || []);
  const classNameViolations = rootRows.filter(
    (row) =>
      row.table === 'runtime' &&
      row.kind === 'component' &&
      /\bclassName\b/.test(row.signature) &&
      !rootClassNameAllowlist.has(row.name)
  );
  if (classNameViolations.length > 0) {
    const list = classNameViolations.map((row) => row.name).join(', ');
    throw new Error(`Root components exposing className outside allowlist: ${list}`);
  }

  const denylistedPublicSymbols = new Set(governanceConfig.denylistedPublicSymbols || []);
  const denylistedLeaks = rows.filter((row) => denylistedPublicSymbols.has(row.name));
  if (denylistedLeaks.length > 0) {
    const list = denylistedLeaks.map((row) => `${row.section}:${row.name}`).join(', ');
    throw new Error(`Denylisted symbols leaked through consumer entrypoints: ${list}`);
  }

  const canonicalEntrypoints = governanceConfig.canonicalEntrypoints || {};
  const canonicalViolations = rows.filter((row) => {
    const owner = canonicalEntrypoints[row.name];
    return typeof owner === 'string' && owner.length > 0 && row.section !== owner;
  });
  if (canonicalViolations.length > 0) {
    const list = canonicalViolations
      .map((row) => `${row.section}:${row.name} (owner: ${canonicalEntrypoints[row.name]})`)
      .join(', ');
    throw new Error(`Canonical ownership violations: ${list}`);
  }

  const duplicateModulesBySymbol = new Map();
  for (const row of rows) {
    const modules = duplicateModulesBySymbol.get(row.name) || new Set();
    modules.add(row.section);
    duplicateModulesBySymbol.set(row.name, modules);
  }

  const allowlistedDuplicateSymbols = governanceConfig.allowlistedDuplicateSymbols || {};
  const knownNameCollisions = governanceConfig.knownNameCollisions || {};
  const duplicateOffenders = [];
  for (const [symbol, moduleSet] of duplicateModulesBySymbol.entries()) {
    if (moduleSet.size <= 1) continue;
    const sortedModules = Array.from(moduleSet).sort();
    const allowlistModules = allowlistedDuplicateSymbols[symbol] || knownNameCollisions[symbol] || [];
    const allowlistSorted = Array.from(new Set(allowlistModules)).sort();
    const isAllowlisted =
      allowlistSorted.length === sortedModules.length &&
      allowlistSorted.every((moduleName, idx) => moduleName === sortedModules[idx]);
    if (!isAllowlisted) {
      duplicateOffenders.push(`${symbol} => ${sortedModules.join(', ')}`);
    }
  }
  if (duplicateOffenders.length > 0) {
    throw new Error(`Duplicate symbol exports are not allowlisted: ${duplicateOffenders.join(' | ')}`);
  }

  const allowlistedInternalExports = new Set(governanceConfig.allowlistedInternalExports || []);
  const internalLeaks = rows.filter(
    (row) =>
      row.stability === 'internal' &&
      !allowlistedInternalExports.has(`${row.section}:${row.name}`)
  );
  if (internalLeaks.length > 0) {
    const list = internalLeaks.map((row) => `${row.section}:${row.name}`).join(', ');
    throw new Error(`Internal exports leaked through consumer entrypoints: ${list}`);
  }

  console.log('Export governance checks passed.');
}

if (require.main === module) {
  try {
    main();
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}
