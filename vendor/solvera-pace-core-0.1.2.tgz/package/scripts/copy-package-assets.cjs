#!/usr/bin/env node
/**
 * Copy package assets so the package is self-contained for publish or symlink:
 * (1) package src/styles → package dist/styles
 * (2) package src/assets/app-icons → package dist/assets/app-icons
 * No-ops when a source is missing.
 */
const fs = require('fs');
const path = require('path');

const pkgRoot = path.resolve(__dirname, '..');

function listFilesRecursive(dir, prefix = '') {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    const rel = prefix ? path.join(prefix, entry.name) : entry.name;
    const full = path.join(dir, rel);
    if (entry.isDirectory()) {
      files.push(...listFilesRecursive(full, rel));
    } else {
      files.push(rel);
    }
  }
  return files;
}

function copyRecursive(sourceDir, targetDir) {
  if (!fs.existsSync(sourceDir)) return;
  const relFiles = listFilesRecursive(sourceDir);
  for (const rel of relFiles) {
    const src = path.join(sourceDir, rel);
    const dest = path.join(targetDir, rel);
    const destDir = path.dirname(dest);
    if (!fs.existsSync(destDir)) {
      fs.mkdirSync(destDir, { recursive: true });
    }
    fs.copyFileSync(src, dest);
  }
}

// (1) package src/styles → package dist/styles (no-op if dist missing)
const srcStyles = path.join(pkgRoot, 'src', 'styles');
const distStyles = path.join(pkgRoot, 'dist', 'styles');
if (fs.existsSync(srcStyles) && fs.existsSync(path.join(pkgRoot, 'dist'))) {
  fs.mkdirSync(distStyles, { recursive: true });
  const files = fs.readdirSync(srcStyles);
  for (const file of files) {
    const src = path.join(srcStyles, file);
    if (fs.statSync(src).isFile()) {
      fs.copyFileSync(src, path.join(distStyles, file));
    }
  }
}

// (2) package src/assets/app-icons → package dist/assets/app-icons
const srcAppIcons = path.join(pkgRoot, 'src', 'assets', 'app-icons');
const distAppIcons = path.join(pkgRoot, 'dist', 'assets', 'app-icons');
if (fs.existsSync(srcAppIcons) && fs.existsSync(path.join(pkgRoot, 'dist'))) {
  copyRecursive(srcAppIcons, distAppIcons);
}
