/**
 * Shared helpers for CAKE/TRAC RPC uuid cast audits.
 */

const fs = require('node:fs');
const path = require('node:path');

function listMigrationFiles(migrationsDir) {
  return fs
    .readdirSync(migrationsDir)
    .filter((name) => name.endsWith('.sql') && !name.startsWith('README'))
    .sort();
}

function extractFunctions(sql, nameFilter) {
  const functions = new Map();
  const re = /CREATE\s+(?:OR\s+REPLACE\s+)?FUNCTION\s+(?:public\.)?(\w+)\s*\(/gi;
  let match;
  while ((match = re.exec(sql)) !== null) {
    const name = match[1];
    if (!nameFilter(name)) continue;
    const start = match.index;
    const end = sql.indexOf('$function$;', start);
    if (end === -1) continue;
    const block = sql.slice(start, end + '$function$;'.length);
    const sigMatch = block.match(
      /CREATE\s+(?:OR\s+REPLACE\s+)?FUNCTION\s+(?:public\.)?\w+\s*(\([\s\S]*?\))\s*RETURNS/is
    );
    functions.set(name, {
      name,
      signature: sigMatch ? sigMatch[1].replace(/\s+/g, ' ').trim() : '(?)',
      body: block,
      sourceOffset: start,
    });
  }
  return functions;
}

function buildLatestFunctionMap(migrationsDir, nameFilter) {
  const latest = new Map();
  const files = listMigrationFiles(migrationsDir);
  for (const file of files) {
    if (file.includes('archive')) continue;
    const fullPath = path.join(migrationsDir, file);
    const sql = fs.readFileSync(fullPath, 'utf8');
    const fns = extractFunctions(sql, nameFilter);
    for (const [name, fn] of fns) {
      latest.set(name, { ...fn, file });
    }
  }
  return latest;
}

function parseTextParams(signature) {
  const textParams = new Set();
  const paramsRaw = signature.replace(/^\(|\)$/g, '');
  for (const part of paramsRaw.split(',')) {
    const trimmed = part.replace(/\s+DEFAULT\s+[\s\S]+$/i, '').trim();
    const m = trimmed.match(/^(p_[a-z0-9_]+)\s+(\w+)/i);
    if (m && m[2].toLowerCase() !== 'uuid') {
      textParams.add(m[1]);
    }
  }
  return textParams;
}

function findUuidTextComparisons(body, textParams, uuidColumns, textIdColumns) {
  const findings = [];
  for (const col of uuidColumns) {
    if (textIdColumns.has(col)) continue;
    const colRe = new RegExp(`\\b${col}\\b\\s*=\\s*(p_[a-z0-9_]+|v_[a-z0-9_]+)`, 'gi');
    let m;
    while ((m = colRe.exec(body)) !== null) {
      const rhs = m[1];
      if (rhs.startsWith('p_') && !textParams.has(rhs)) {
        continue;
      }
      if (/::\s*uuid/i.test(body.slice(Math.max(0, m.index - 80), m.index + m[0].length + 80))) {
        continue;
      }
      if (/trim\s*\(\s*[^)]+\s*\)\s*::\s*uuid/i.test(body.slice(Math.max(0, m.index - 120), m.index))) {
        continue;
      }
      if (rhs.startsWith('v_') && new RegExp(`\\b${rhs}\\s+uuid\\b`, 'i').test(body)) {
        continue;
      }
      const line = body.slice(0, m.index).split('\n').length;
      findings.push({
        id: 'uuid_text_compare',
        severity: 'error',
        column: col,
        snippet: m[0],
        line,
        message: `Compares uuid column ${col} to text expression ${rhs} without ::uuid cast`,
      });
    }
  }
  return findings;
}

function auditFunctionBody(fn, { auditSkip, badPatterns, uuidColumns, textIdColumns }) {
  if (auditSkip.has(fn.name)) return [];
  const textParams = parseTextParams(fn.signature);
  const hits = [];
  for (const pattern of badPatterns) {
    if (pattern.regex.test(fn.body)) {
      hits.push({
        id: pattern.id,
        severity: pattern.severity,
        message: pattern.message,
        snippet: fn.body.match(pattern.regex)?.[0] ?? pattern.id,
      });
      pattern.regex.lastIndex = 0;
    }
  }
  hits.push(...findUuidTextComparisons(fn.body, textParams, uuidColumns, textIdColumns));
  return hits;
}

function renderAuditReport({ title, scopeDescription, allFindings }) {
  const lines = [
    `# ${title}`,
    '',
    `Generated: ${new Date().toISOString()}`,
    '',
    `Scope: ${scopeDescription}`,
    '',
  ];
  if (allFindings.length === 0) {
    lines.push('No uuid/text mismatches found in latest RPC definitions.', '');
    return lines.join('\n');
  }
  lines.push(`**${allFindings.length} function(s) with findings:**`, '');
  for (const entry of allFindings) {
    lines.push(`## ${entry.name}`, '');
    lines.push(`- File: \`${entry.file}\``, '');
    for (const hit of entry.hits) {
      lines.push(`- **${hit.severity}** [${hit.id}]: ${hit.message}`);
      if (hit.snippet) lines.push(`  - \`${hit.snippet.trim()}\``);
      if (hit.line) lines.push(`  - line ~${hit.line}`);
    }
    lines.push('');
  }
  return lines.join('\n');
}

function runRpcUuidAudit({
  title,
  reportPath,
  migrationsDir,
  nameFilter,
  auditSkip,
  badPatterns,
  uuidColumns,
  textIdColumns,
  scopeDescription = 'Scans all active supabase/migrations/*.sql (latest definition per function)',
}) {
  const latest = buildLatestFunctionMap(migrationsDir, nameFilter);
  const allFindings = [];

  for (const [name, fn] of latest) {
    const hits = auditFunctionBody(fn, { auditSkip, badPatterns, uuidColumns, textIdColumns });
    if (hits.length > 0) {
      allFindings.push({ name, file: fn.file, hits });
    }
  }

  allFindings.sort((a, b) => a.name.localeCompare(b.name));

  const report = renderAuditReport({ title, scopeDescription, allFindings });

  console.log(`${title}: ${allFindings.length} function(s) with findings`);
  if (reportPath) {
    fs.mkdirSync(path.dirname(reportPath), { recursive: true });
    fs.writeFileSync(reportPath, report);
    console.log(`Report: ${reportPath}`);
  }

  if (allFindings.length > 0) {
    for (const entry of allFindings) {
      console.log(`  - ${entry.name} (${entry.hits.length} hit(s))`);
    }
    process.exit(1);
  }
  process.exit(0);
}

module.exports = {
  runRpcUuidAudit,
};
