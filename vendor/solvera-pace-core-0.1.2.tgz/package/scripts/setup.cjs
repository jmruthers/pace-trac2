#!/usr/bin/env node

/**
 * Combined Setup Script for pace-core
 * @package @solvera/pace-core
 * @module Scripts/setup
 * 
 * Sets up pace-core in consuming apps:
 * - Adds setup and validation scripts to package.json when missing (consuming apps only)
 * - Sets up ESLint configuration
 * - Sets up cursor rules as symlinks to package rules (authoritative mode)
 * - Copies .env.example from package templates
 * - Writes canonical .cursor/mcp.json for Cursor MCP
 * 
 * Usage:
 *   node node_modules/@solvera/pace-core/scripts/setup.cjs        # Run all setup tasks
 *   node node_modules/@solvera/pace-core/scripts/setup.cjs --force # Force update even if already configured
 * 
 * Or add to package.json:
 *   "scripts": {
 *     "setup": "node node_modules/@solvera/pace-core/scripts/setup.cjs"
 *   }
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// ANSI color codes for terminal output
const colors = {
  reset: '\x1b[0m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m',
  bold: '\x1b[1m',
  red: '\x1b[31m'
};

// Find pace-core package root
function findPaceCoreRoot() {
  const cwd = process.cwd();
  
  // Try node_modules first (for consuming apps)
  const nodeModulesPath = path.join(cwd, 'node_modules', '@solvera', 'pace-core');
  if (fs.existsSync(nodeModulesPath)) {
    return nodeModulesPath;
  }
  
  // Try relative to script location (for pace-core repo)
  const scriptDir = __dirname;
  const relativePath = path.join(scriptDir, '..');
  if (fs.existsSync(relativePath)) {
    return relativePath;
  }
  
  throw new Error('Could not find pace-core package');
}

/** True when running in a consuming app (pace-core in node_modules, and not the pace-core repo itself). */
function isConsumingApp() {
  const cwd = process.cwd();
  const nodeModulesPath = path.join(cwd, 'node_modules', '@solvera', 'pace-core');
  const packagesCorePath = path.join(cwd, 'packages', 'core');
  return fs.existsSync(nodeModulesPath) && !fs.existsSync(packagesCorePath);
}

const CONSUMING_APP_SETUP_SCRIPT = 'node node_modules/@solvera/pace-core/scripts/setup.cjs';
const CONSUMING_APP_VALIDATE_SCRIPT = 'node node_modules/@solvera/pace-core/scripts/validate.cjs';
const CONSUMING_APP_VALIDATE_AUTHORITY_SCRIPT = 'node node_modules/@solvera/pace-core/scripts/validate-authority.cjs';
const CONSUMING_APP_ENV_DEV_SCRIPT = 'node node_modules/@solvera/pace-core/scripts/switch-supabase-env.cjs dev';
const CONSUMING_APP_ENV_PROD_SCRIPT = 'node node_modules/@solvera/pace-core/scripts/switch-supabase-env.cjs prod';
const CONSUMING_APP_ENV_STATUS_SCRIPT = 'node -e "const fs=require(\'node:fs\');const p=\'.env\';if(!fs.existsSync(p)){console.log(\'.env not found\');process.exit(0);}const t=fs.readFileSync(p,\'utf8\');const g=(k)=>{const m=t.match(new RegExp(\'^\'+k+\'=(.*)$\',\'m\'));return m?m[1]:\'\'};console.log(\'SUPABASE_ENV=\'+g(\'SUPABASE_ENV\'));console.log(\'SUPABASE_PROJECT_REF=\'+g(\'SUPABASE_PROJECT_REF\'));console.log(\'VITE_SUPABASE_URL=\'+g(\'VITE_SUPABASE_URL\'));"';
const CONSUMING_APP_MIGRATE_LINK_SCRIPT = 'node node_modules/@solvera/pace-core/scripts/supabase-link-from-env.cjs';
const CONSUMING_APP_MIGRATE_LINK_DEV_SCRIPT = 'node node_modules/@solvera/pace-core/scripts/supabase-link-from-env.cjs dev';
const CONSUMING_APP_MIGRATE_LINK_PROD_SCRIPT = 'node node_modules/@solvera/pace-core/scripts/supabase-link-from-env.cjs prod';
const CANONICAL_MCP_CONFIG = {
  mcpServers: {
    supabase: {
      url: 'https://mcp.supabase.com/mcp?project_ref=srqhjwivpohjcjqikjry',
    },
  },
};

/**
 * Add setup and validation scripts to package.json when missing. Only in consuming apps.
 * Does not overwrite existing script values.
 */
function addPackageJsonScripts() {
  if (!isConsumingApp()) return { added: 0, updated: 0 };
  const cwd = process.cwd();
  const pkgPath = path.join(cwd, 'package.json');
  if (!fs.existsSync(pkgPath)) return { added: 0, updated: 0 };
  let pkg;
  try {
    pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
  } catch {
    return { added: 0, updated: 0 };
  }
  const scripts = pkg.scripts || {};
  let added = 0;
  let updated = 0;
  const managedScripts = {
    setup: CONSUMING_APP_SETUP_SCRIPT,
    validate: CONSUMING_APP_VALIDATE_SCRIPT,
    'validate-authority': CONSUMING_APP_VALIDATE_AUTHORITY_SCRIPT,
    'env:dev': CONSUMING_APP_ENV_DEV_SCRIPT,
    'env:prod': CONSUMING_APP_ENV_PROD_SCRIPT,
    'env:status': CONSUMING_APP_ENV_STATUS_SCRIPT,
    'migrate:link': CONSUMING_APP_MIGRATE_LINK_SCRIPT,
    'migrate:link:dev': CONSUMING_APP_MIGRATE_LINK_DEV_SCRIPT,
    'migrate:link:prod': CONSUMING_APP_MIGRATE_LINK_PROD_SCRIPT,
  };
  for (const [scriptName, canonicalValue] of Object.entries(managedScripts)) {
    const existingValue = scripts[scriptName];
    if (existingValue === canonicalValue) continue;
    if (existingValue == null) added++;
    else updated++;
    scripts[scriptName] = canonicalValue;
  }
  if (added === 0 && updated === 0) return { added: 0, updated: 0 };
  pkg.scripts = scripts;
  fs.writeFileSync(pkgPath, JSON.stringify(pkg, null, 2) + '\n', 'utf8');
  return { added, updated };
}

/**
 * Copy templates/.env.example to project root .env.example.
 * Overwrites only if force or target missing or content differs.
 */
function copyEnvExample(force = false) {
  const cwd = process.cwd();
  const paceCoreRoot = findPaceCoreRoot();
  const sourcePath = path.join(paceCoreRoot, 'templates', '.env.example');
  const targetPath = path.join(cwd, '.env.example');
  if (!fs.existsSync(sourcePath)) return { action: 'skipped', reason: 'source not found' };
  const targetExists = fs.existsSync(targetPath);
  if (!force && targetExists) {
    const sourceContent = fs.readFileSync(sourcePath, 'utf8');
    const targetContent = fs.readFileSync(targetPath, 'utf8');
    if (sourceContent === targetContent) return { action: 'skipped', reason: 'up to date' };
  }
  fs.copyFileSync(sourcePath, targetPath);
  return { action: targetExists ? 'updated' : 'created' };
}

/**
 * Write canonical MCP config to .cursor/mcp.json.
 * Creates .cursor/ if needed. Overwrites only if force or target missing or content differs.
 */
function copyMcpConfig(force = false) {
  const cwd = process.cwd();
  const targetDir = path.join(cwd, '.cursor');
  const targetPath = path.join(targetDir, 'mcp.json');
  const canonicalContent = `${JSON.stringify(CANONICAL_MCP_CONFIG, null, 2)}\n`;
  if (!fs.existsSync(targetDir)) fs.mkdirSync(targetDir, { recursive: true });
  const targetExists = fs.existsSync(targetPath);
  if (!force && targetExists) {
    const targetContent = fs.readFileSync(targetPath, 'utf8');
    if (canonicalContent === targetContent) return { action: 'skipped', reason: 'up to date' };
  }
  fs.writeFileSync(targetPath, canonicalContent, 'utf8');
  return { action: targetExists ? 'updated' : 'created' };
}

// ============================================================================
// App shell: public dirs, app.css, tsconfig, deps, vite, main.tsx, supabase
// ============================================================================

function ensurePublicDirs() {
  const cwd = process.cwd();
  const dirs = [path.join(cwd, 'public', 'fonts'), path.join(cwd, 'public', 'logos')];
  let created = 0;
  for (const dir of dirs) {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
      created++;
    }
  }
  return { created };
}

function ensureAppCss(force) {
  const cwd = process.cwd();
  const paceCoreRoot = findPaceCoreRoot();
  const appCssPath = path.join(cwd, 'src', 'app.css');
  const templatePath = path.join(paceCoreRoot, 'templates', 'app.css');
  if (!fs.existsSync(templatePath)) return { action: 'skipped', reason: 'template not found' };
  const template = fs.readFileSync(templatePath, 'utf8');
  const exists = fs.existsSync(appCssPath);
  if (!exists || force) {
    const srcDir = path.dirname(appCssPath);
    if (!fs.existsSync(srcDir)) fs.mkdirSync(srcDir, { recursive: true });
    fs.writeFileSync(appCssPath, template, 'utf8');
    return { action: exists ? 'updated' : 'created' };
  }
  return { action: 'skipped', reason: 'up to date' };
}

function ensureTsconfigFromTemplate(force) {
  const cwd = process.cwd();
  const paceCoreRoot = findPaceCoreRoot();
  const tsconfigPath = path.join(cwd, 'tsconfig.json');
  const templatePath = path.join(paceCoreRoot, 'templates', 'tsconfig.json');
  if (!fs.existsSync(templatePath)) return { updated: false };
  const exists = fs.existsSync(tsconfigPath);
  if (!exists || force) {
    const template = fs.readFileSync(templatePath, 'utf8');
    fs.writeFileSync(tsconfigPath, template, 'utf8');
    return { updated: true };
  }
  return { updated: false };
}

const REQUIRED_DEPS = { 'react-router-dom': '^6.0.0 || ^7.0.0', '@tanstack/react-query': '^5.0.0', '@supabase/supabase-js': '^2.0.0' };
const REQUIRED_DEV_DEPS = {
  'tailwindcss': '^4.0.0',
  '@tailwindcss/vite': '^4.0.0',
  'eslint': '^9.15.0',
  '@eslint/js': '^9.15.0',
  'typescript-eslint': '^8.15.0',
  '@typescript-eslint/parser': '^8.15.0',
  'eslint-plugin-react': '^7.37.0',
  'eslint-plugin-react-hooks': '^5.0.0',
  'vitest': '^2.0.0',
  '@testing-library/react': '^16.0.0',
  '@testing-library/user-event': '^14.0.0',
  '@testing-library/jest-dom': '^6.0.0',
  '@vitest/coverage-v8': '^2.0.0',
  '@vitest/coverage-istanbul': '^2.0.0',
  'happy-dom': '^15.0.0',
};

/** Vitest tiered test pattern — root config files (safe to overwrite with --force). */
const VITEST_ROOT_TEMPLATE_FILES = [
  'vitest.shared.ts',
  'vitest.config.ts',
  'vitest.unit.config.ts',
  'vitest.integration.config.ts',
];

/** Vitest tiered test pattern — src setup files (safe to overwrite with --force). */
const VITEST_SRC_TEMPLATE_FILES = [
  { template: 'test-setup.ts', target: path.join('src', 'test-setup.ts') },
  { template: 'test-setup-unit.ts', target: path.join('src', 'test-setup-unit.ts') },
  { template: 'test-polyfills.ts', target: path.join('src', 'test-polyfills.ts') },
  { template: 'test-utils.ts', target: path.join('src', 'test-utils.ts') },
];

const VITEST_MANAGED_SCRIPTS = {
  test: 'vitest run -c vitest.config.ts',
  'test:watch': 'vitest -c vitest.config.ts',
  'test:unit': 'vitest run -c vitest.unit.config.ts',
  'test:integration': 'vitest run -c vitest.integration.config.ts',
  'test:changed': 'vitest run -c vitest.config.ts --changed HEAD~1',
  'test:coverage': 'vitest run -c vitest.config.ts --coverage --coverage.provider=v8',
  'test:coverage:fast': 'vitest run -c vitest.unit.config.ts --coverage --coverage.provider=v8',
};

function ensureVitestTestingPattern(force = false) {
  const cwd = process.cwd();
  const paceCoreRoot = findPaceCoreRoot();
  const templateDir = path.join(paceCoreRoot, 'templates', 'testing');
  if (!fs.existsSync(templateDir)) {
    return { created: 0, updated: 0, skipped: 0, scriptsAdded: 0, reason: 'template dir not found' };
  }

  let created = 0;
  let updated = 0;
  let skipped = 0;

  for (const name of VITEST_ROOT_TEMPLATE_FILES) {
    const sourcePath = path.join(templateDir, name);
    const targetPath = path.join(cwd, name);
    if (!fs.existsSync(sourcePath)) continue;
    const template = fs.readFileSync(sourcePath, 'utf8');
    const exists = fs.existsSync(targetPath);
    if (!exists || force) {
      fs.writeFileSync(targetPath, template, 'utf8');
      if (exists) updated++;
      else created++;
    } else {
      skipped++;
    }
  }

  for (const { template, target } of VITEST_SRC_TEMPLATE_FILES) {
    const sourcePath = path.join(templateDir, template);
    const targetPath = path.join(cwd, target);
    if (!fs.existsSync(sourcePath)) continue;
    const templateContent = fs.readFileSync(sourcePath, 'utf8');
    const targetDir = path.dirname(targetPath);
    if (!fs.existsSync(targetDir)) fs.mkdirSync(targetDir, { recursive: true });
    const exists = fs.existsSync(targetPath);
    if (!exists || force) {
      fs.writeFileSync(targetPath, templateContent, 'utf8');
      if (exists) updated++;
      else created++;
    } else {
      skipped++;
    }
  }

  const pkgPath = path.join(cwd, 'package.json');
  let scriptsAdded = 0;
  if (fs.existsSync(pkgPath)) {
    try {
      const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
      const scripts = pkg.scripts || {};
      for (const [scriptName, canonicalValue] of Object.entries(VITEST_MANAGED_SCRIPTS)) {
        if (scripts[scriptName] == null) {
          scripts[scriptName] = canonicalValue;
          scriptsAdded++;
        }
      }
      if (scriptsAdded > 0) {
        pkg.scripts = scripts;
        fs.writeFileSync(pkgPath, JSON.stringify(pkg, null, 2) + '\n', 'utf8');
      }
    } catch {
      // skip script merge on parse failure
    }
  }

  return { created, updated, skipped, scriptsAdded };
}

function ensureDependencies() {
  const cwd = process.cwd();
  const pkgPath = path.join(cwd, 'package.json');
  if (!fs.existsSync(pkgPath)) return { added: 0 };
  let pkg;
  try {
    pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
  } catch {
    return { added: 0 };
  }
  let added = 0;
  const deps = pkg.dependencies || {};
  for (const [name, range] of Object.entries(REQUIRED_DEPS)) {
    if (!deps[name]) {
      deps[name] = range;
      added++;
    }
  }
  pkg.dependencies = deps;
  const devDeps = pkg.devDependencies || {};
  for (const [name, range] of Object.entries(REQUIRED_DEV_DEPS)) {
    if (!devDeps[name]) {
      devDeps[name] = range;
      added++;
    }
  }
  pkg.devDependencies = devDeps;
  if (added === 0) return { added: 0 };
  fs.writeFileSync(pkgPath, JSON.stringify(pkg, null, 2) + '\n', 'utf8');
  return { added };
}

function ensureViteConfigFromTemplate(force) {
  const cwd = process.cwd();
  const paceCoreRoot = findPaceCoreRoot();
  const vitePath = path.join(cwd, 'vite.config.ts');
  const vitePathJs = path.join(cwd, 'vite.config.js');
  const templatePath = path.join(paceCoreRoot, 'templates', 'vite.config.ts');
  if (!fs.existsSync(templatePath)) return { updated: false };
  const exists = fs.existsSync(vitePath) || fs.existsSync(vitePathJs);
  if (!exists || force) {
    if (fs.existsSync(vitePathJs)) fs.unlinkSync(vitePathJs);
    const template = fs.readFileSync(templatePath, 'utf8');
    fs.writeFileSync(vitePath, template, 'utf8');
    return { updated: true };
  }
  return { updated: false };
}

function ensureMainAndSupabase(force) {
  const cwd = process.cwd();
  const paceCoreRoot = findPaceCoreRoot();
  const mainPath = path.join(cwd, 'src', 'main.tsx');
  const supabasePath = path.join(cwd, 'src', 'lib', 'supabase.ts');
  const libDir = path.join(cwd, 'src', 'lib');
  const mainTemplatePath = path.join(paceCoreRoot, 'templates', 'main.tsx');
  const supabaseTemplatePath = path.join(paceCoreRoot, 'templates', 'supabase.ts');
  let updated = 0;
  if (fs.existsSync(supabaseTemplatePath)) {
    const supabaseExists = fs.existsSync(supabasePath) || fs.existsSync(path.join(cwd, 'src', 'lib', 'supabase.js'));
    if (!supabaseExists || force) {
      if (!fs.existsSync(libDir)) fs.mkdirSync(libDir, { recursive: true });
      fs.copyFileSync(supabaseTemplatePath, supabasePath);
      updated++;
    }
  }
  if (fs.existsSync(mainTemplatePath)) {
    const mainExists = fs.existsSync(mainPath) || fs.existsSync(path.join(cwd, 'src', 'main.jsx')) || fs.existsSync(path.join(cwd, 'src', 'main.js'));
    if (!mainExists || force) {
      let template = fs.readFileSync(mainTemplatePath, 'utf8');
      const hasAppTsx = fs.existsSync(path.join(cwd, 'src', 'App.tsx'));
      const hasAppJsx = fs.existsSync(path.join(cwd, 'src', 'App.jsx'));
      if (!hasAppTsx && !hasAppJsx) {
        template = template.replace(/import App from '\.\/App';/, "import App from './App';\n// Ensure you have src/App.tsx or src/App.jsx");
      }
      const outDir = path.dirname(mainPath);
      if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });
      fs.writeFileSync(mainPath, template, 'utf8');
      updated++;
    }
  }
  return { updated };
}

// ============================================================================
// ESLint Configuration Setup
// ============================================================================

const ESLINT_CONFIG_FILES = [
  'eslint.config.js',
  'eslint.config.cjs',
  'eslint.config.mjs',
  '.eslintrc.js',
  '.eslintrc.cjs',
  '.eslintrc.json',
  '.eslintrc.yaml',
  '.eslintrc.yml',
];

const CANONICAL_ESLINT_CONFIG = `const paceCoreConfig = require('@solvera/pace-core/eslint-config');
const js = require('@eslint/js');

let tseslint = null;
let react = null;
let reactHooks = null;

try { tseslint = require('typescript-eslint'); } catch {}
try { react = require('eslint-plugin-react'); } catch {}
try { reactHooks = require('eslint-plugin-react-hooks'); } catch {}

const config = [
  ...paceCoreConfig,
  js.configs.recommended,
];

if (tseslint?.configs?.recommended) {
  config.push(...tseslint.configs.recommended);
}

if (react?.configs?.recommended?.rules && reactHooks?.configs?.recommended?.rules) {
  config.push({
    files: ['**/*.{ts,tsx}'],
    plugins: {
      react,
      'react-hooks': reactHooks,
    },
    languageOptions: {
      parserOptions: {
        ecmaFeatures: { jsx: true },
      },
      globals: {
        React: 'readonly',
        JSX: 'readonly',
      },
    },
    settings: {
      react: { version: 'detect' },
    },
    rules: {
      ...react.configs.recommended.rules,
      ...reactHooks.configs.recommended.rules,
    },
  });
}

config.push({
  ignores: ['dist/**', 'coverage/**', 'node_modules/**', 'audit/**', '**/*.cjs'],
});

module.exports = config;
`;

function setupESLint(force = false) {
  const cwd = process.cwd();
  if (isConsumingApp()) {
    let removed = 0;
    for (const configFile of ESLINT_CONFIG_FILES) {
      const configPath = path.join(cwd, configFile);
      if (fs.existsSync(configPath)) {
        fs.unlinkSync(configPath);
        removed++;
      }
    }
    const configPath = path.join(cwd, 'eslint.config.cjs');
    fs.writeFileSync(configPath, CANONICAL_ESLINT_CONFIG, 'utf8');
    return { action: removed ? 'updated' : 'created', file: 'eslint.config.cjs', format: 'CommonJS' };
  }
  return { action: 'skipped', file: null, format: null };
}

// ============================================================================
// Cursor Rules Setup (authoritative symlink mode)
// ============================================================================

function normalizeForCompare(inputPath) {
  return path.normalize(inputPath).replace(/\\/g, '/');
}

function ensureCursorRuleSymlink(sourcePath, targetPath, force) {
  const relativeTarget = path.relative(path.dirname(targetPath), sourcePath);
  const expectedResolvedTarget = normalizeForCompare(path.resolve(path.dirname(targetPath), relativeTarget));
  const targetExists = fs.existsSync(targetPath);
  if (targetExists) {
    const stats = fs.lstatSync(targetPath);
    if (!stats.isSymbolicLink()) {
      if (!force) {
        throw new Error(
          `Authoritative setup requires symlinks for Cursor rules. Found regular file: ${targetPath}. ` +
          'Remove local rule files or rerun with --force to replace them.'
        );
      }
      fs.rmSync(targetPath, { force: true });
    } else {
      const currentLinkTarget = fs.readlinkSync(targetPath);
      const currentResolvedTarget = normalizeForCompare(path.resolve(path.dirname(targetPath), currentLinkTarget));
      if (currentResolvedTarget === expectedResolvedTarget) {
        return 'skipped';
      }
      if (!force) {
        throw new Error(
          `Cursor rule symlink drift detected at ${targetPath}. ` +
          'Rerun setup with --force to repair authoritative links.'
        );
      }
      fs.rmSync(targetPath, { force: true });
    }
  }

  try {
    fs.symlinkSync(relativeTarget, targetPath, 'file');
    return 'linked';
  } catch (error) {
    throw new Error(
      `Failed to create required Cursor rule symlink:\n` +
      `  link: ${targetPath}\n` +
      `  ->   ${sourcePath}\n` +
      `Reason: ${error.message}\n\n` +
      'Symlink support is mandatory in authoritative setup mode.'
    );
  }
}

function setupCursorRules(force = false) {
  const paceCoreRoot = findPaceCoreRoot();
  const sourceDir = path.join(paceCoreRoot, 'cursor-rules');
  const targetDir = path.join(process.cwd(), '.cursor', 'rules');
  
  if (!fs.existsSync(sourceDir)) {
    throw new Error('cursor-rules directory not found in pace-core');
  }
  
  if (!fs.existsSync(targetDir)) {
    fs.mkdirSync(targetDir, { recursive: true });
  }
  
  const files = fs.readdirSync(sourceDir)
    .filter(file => file.endsWith('.mdc'))
    .sort();
  
  if (files.length === 0) {
    return { linked: 0, skipped: 0 };
  }

  let linked = 0;
  let skipped = 0;

  files.forEach((file) => {
    const sourcePath = path.join(sourceDir, file);
    const targetPath = path.join(targetDir, file);
    const action = ensureCursorRuleSymlink(sourcePath, targetPath, force);
    if (action === 'linked') linked++;
    else skipped++;
  });

  return { linked, skipped };
}

// ============================================================================
// Main Execution
// ============================================================================

function main() {
  const force = process.argv.includes('--force');
  const cwd = process.cwd();
  const pkgPath = path.join(cwd, 'package.json');

  if (isConsumingApp() && !fs.existsSync(pkgPath)) {
    console.error(`${colors.red}Error:${colors.reset} package.json not found in current directory.`);
    console.error(`  Current directory: ${cwd}`);
    console.error(`  Run this script from your project root (where package.json lives), e.g.:`);
    console.error(`  ${colors.cyan}cd /path/to/your-app && node node_modules/@solvera/pace-core/scripts/setup.cjs${colors.reset}`);
    process.exit(1);
  }

  if (force) {
    console.log(`${colors.yellow}Warning: --force flag is set. This will overwrite existing configurations.${colors.reset}\n`);
  }

  try {
    console.log(`${colors.bold}${colors.cyan}Setting up pace-core...${colors.reset}\n`);

    // 1. Add setup/validate scripts to package.json when missing (consuming apps only)
    const scriptsResult = addPackageJsonScripts();
    if (isConsumingApp()) {
      if (scriptsResult.added > 0 || scriptsResult.updated > 0) {
        console.log(
          `${colors.green}✓${colors.reset} package.json: Added ${scriptsResult.added} script(s), updated ${scriptsResult.updated} managed script(s)`
        );
      } else {
        console.log(`${colors.blue}○${colors.reset} package.json: Managed scripts already canonical`);
      }
    }
    
    // 2. Setup ESLint
    const eslintResult = setupESLint(force);
    if (eslintResult.action === 'created') {
      console.log(`${colors.green}✓${colors.reset} ESLint: Created ${eslintResult.file}`);
    } else if (eslintResult.action === 'updated') {
      console.log(`${colors.green}✓${colors.reset} ESLint: Updated ${eslintResult.file}`);
    } else {
      console.log(`${colors.blue}○${colors.reset} ESLint: Already configured`);
    }
    
    // 3. Setup cursor rules (authoritative symlinks)
    const cursorRulesResult = setupCursorRules(force);
    if (cursorRulesResult.linked > 0) {
      console.log(`${colors.green}✓${colors.reset} Cursor Rules: Linked ${cursorRulesResult.linked}, ${cursorRulesResult.skipped} already linked`);
    } else {
      console.log(`${colors.blue}○${colors.reset} Cursor Rules: All authoritative symlinks already in place`);
    }
    console.log(`${colors.blue}○${colors.reset} Standards: Authoritative mode uses node_modules/@solvera/pace-core/docs/standards (no local copy)`);

    // 4. Copy .env.example
    const envResult = copyEnvExample(force);
    if (envResult.action === 'created' || envResult.action === 'updated') {
      console.log(`${colors.green}✓${colors.reset} .env.example: ${envResult.action}`);
    } else if (envResult.action === 'skipped' && envResult.reason === 'source not found') {
      console.log(`${colors.blue}○${colors.reset} .env.example: Source not found (run \`npm run build\` in the pace-core repo if using a symlink).`);
    } else {
      console.log(`${colors.blue}○${colors.reset} .env.example: Already up to date`);
    }

    // 5. Copy MCP config to .cursor/mcp.json
    const mcpResult = copyMcpConfig(force);
    if (mcpResult.action === 'created' || mcpResult.action === 'updated') {
      console.log(`${colors.green}✓${colors.reset} .cursor/mcp.json: ${mcpResult.action}`);
    } else {
      console.log(`${colors.blue}○${colors.reset} .cursor/mcp.json: Already up to date`);
    }

    // 6. App shell (consuming app only): public dirs, deps, app.css, tsconfig, vite, main.tsx, supabase
    let depsAdded = 0;
    if (isConsumingApp()) {
      const pub = ensurePublicDirs();
      if (pub.created > 0) console.log(`${colors.green}✓${colors.reset} public/fonts, public/logos: ${pub.created} dir(s) created`);
      const deps = ensureDependencies();
      depsAdded = deps.added;
      if (deps.added > 0) {
        console.log(`${colors.green}✓${colors.reset} package.json: ${deps.added} dependency(ies) added; running npm install...`);
        try {
          execSync('npm install', { cwd: process.cwd(), stdio: 'inherit' });
          console.log(`${colors.green}✓${colors.reset} Dependencies installed.`);
        } catch (err) {
          console.log(`${colors.yellow}!${colors.reset} npm install failed or was cancelled. Run ${colors.bold}npm install${colors.reset} manually, then ${colors.bold}npm run dev${colors.reset}.`);
        }
      }
      const appCss = ensureAppCss(force);
      if (appCss.action === 'created' || appCss.action === 'updated') console.log(`${colors.green}✓${colors.reset} src/app.css: ${appCss.action}`);
      else if (appCss.action === 'skipped' && appCss.reason === 'template not found') console.log(`${colors.blue}○${colors.reset} src/app.css: Template not found (run \`npm run build\` in pace-core).`);
      const ts = ensureTsconfigFromTemplate(force);
      if (ts.updated) console.log(`${colors.green}✓${colors.reset} tsconfig: written from template`);
      const vite = ensureViteConfigFromTemplate(force);
      if (vite.updated) console.log(`${colors.green}✓${colors.reset} vite.config: written from template`);
      const mainSup = ensureMainAndSupabase(force);
      if (mainSup.updated > 0) console.log(`${colors.green}✓${colors.reset} main entry / supabase client: ${mainSup.updated} file(s) created or updated`);
      const vitestPattern = ensureVitestTestingPattern(force);
      if (vitestPattern.reason === 'template dir not found') {
        console.log(`${colors.blue}○${colors.reset} Vitest test pattern: templates not found`);
      } else if (vitestPattern.created > 0 || vitestPattern.updated > 0 || vitestPattern.scriptsAdded > 0) {
        const parts = [];
        if (vitestPattern.created > 0) parts.push(`${vitestPattern.created} created`);
        if (vitestPattern.updated > 0) parts.push(`${vitestPattern.updated} updated`);
        if (vitestPattern.scriptsAdded > 0) parts.push(`${vitestPattern.scriptsAdded} script(s) added`);
        console.log(`${colors.green}✓${colors.reset} Vitest tiered test pattern: ${parts.join(', ')}`);
      } else {
        console.log(`${colors.blue}○${colors.reset} Vitest tiered test pattern: Already up to date`);
      }
    }

    // Summary
    console.log(`\n${colors.bold}${colors.green}✓ Setup complete!${colors.reset}`);
    console.log(`\n${colors.cyan}Required next steps:${colors.reset}`);
    if (isConsumingApp() && depsAdded > 0) {
      console.log(`  • If ${colors.bold}npm install${colors.reset} did not run or failed, run it now so ${colors.bold}npm run dev${colors.reset} works.`);
    }
    console.log(`  • Copy ${colors.bold}.env.example${colors.reset} to ${colors.bold}.env${colors.reset} and set VITE_SUPABASE_URL and VITE_SUPABASE_PUBLISHABLE_KEY`);
    console.log(`  • If needed, update ${colors.bold}.cursor/mcp.json${colors.reset} to your app's Supabase project ref`);
    console.log(`  • Use ${colors.bold}npm run env:dev${colors.reset} / ${colors.bold}npm run env:prod${colors.reset} to switch Supabase environment context`);
    console.log(`  • Restart Cursor to load rules and MCP`);
    console.log(`  • Run ${colors.bold}npm run validate${colors.reset} (includes authority check) to verify setup and quality checks`);
    
  } catch (error) {
    console.error(`\n${colors.red}Error during setup:${colors.reset}`);
    console.error(error.message);
    if (error.stack) {
      console.error(error.stack);
    }
    process.exit(1);
  }
}

if (require.main === module) {
  main();
}

module.exports = {
  main,
  setupESLint,
  setupCursorRules,
  addPackageJsonScripts,
  copyEnvExample,
  copyMcpConfig,
  ensurePublicDirs,
  ensureAppCss,
  ensureTsconfigFromTemplate,
  ensureDependencies,
  ensureViteConfigFromTemplate,
  ensureMainAndSupabase,
  ensureVitestTestingPattern,
};
