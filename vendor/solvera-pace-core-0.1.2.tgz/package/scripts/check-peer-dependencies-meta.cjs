#!/usr/bin/env node
/**
 * CLI guard: @solvera/pace-core peerDependenciesMeta completeness.
 */
const fs = require('fs');
const path = require('path');
const { validatePeerDependenciesMeta } = require('./peer-dependencies-meta-policy.cjs');

const pkgRoot = path.resolve(__dirname, '..');
const packageJsonPath = path.join(pkgRoot, 'package.json');

function main() {
  const pkg = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'));
  const result = validatePeerDependenciesMeta(
    pkg.peerDependencies || {},
    pkg.peerDependenciesMeta || {}
  );

  if (!result.ok) {
    for (const error of result.errors) {
      console.error(error);
    }
    process.exit(1);
  }

  console.log('check-peer-dependencies-meta: ok');
}

main();
