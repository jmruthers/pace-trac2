#!/usr/bin/env node
/**
 * Run CAKE and TRAC RPC uuid cast audits.
 */

const { spawnSync } = require('node:child_process');
const path = require('node:path');

const scriptsDir = __dirname;
const audits = [
  'audit-cake-rpc-uuid-casts.cjs',
  'audit-trac-uuid-casts.cjs',
];

for (const script of audits) {
  const result = spawnSync(process.execPath, [path.join(scriptsDir, script)], {
    stdio: 'inherit',
  });
  if (result.status !== 0) {
    process.exit(result.status ?? 1);
  }
}
