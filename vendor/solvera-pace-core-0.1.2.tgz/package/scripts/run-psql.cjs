#!/usr/bin/env node
/**
 * Run SQL against the linked Supabase database via Supabase CLI (login role).
 * Does not require SUPABASE_DB_PASSWORD — uses `supabase login` like migrate:push.
 *
 * Usage (from pace-core2 repo root):
 *   npm run migrate:link:prod
 *   npm run db:psql -- -v dry_run=true -f packages/core/supabase/seeds/<file>.sql
 *   npm run db:psql -- -c "SELECT count(*) FROM core_organisations;"
 */
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { envWithScoopShimsOnPath } = require('./supabase-scoop-path.cjs');
const { command: supabaseCommand, argsPrefix: supabaseArgsPrefix } = require('./supabase-cli-invocation.cjs');

const DEFAULT_VARS = {
  keep_org_name: 'scouts-victoria',
  dry_run: 'false',
  seed_purge_confirm: '',
  seed_event_id: 'd2df5d75-cf06-4856-a9cf-c3e8fba7f6b1',
  seed_event_code: 'BASEBA18',
};

function parseDotEnv(content) {
  const entries = {};
  for (const line of content.split('\n')) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const idx = line.indexOf('=');
    if (idx === -1) continue;
    const envKey = line.slice(0, idx).trim();
    entries[envKey] = line.slice(idx + 1).trim();
  }
  return entries;
}

function detectCoreDir(repoRoot) {
  const packageCore = path.join(repoRoot, 'packages', 'core');
  if (fs.existsSync(path.join(packageCore, 'supabase', 'config.toml'))) {
    return packageCore;
  }
  if (fs.existsSync(path.join(repoRoot, 'supabase', 'config.toml'))) {
    return repoRoot;
  }
  return null;
}

function readTrimmed(filePath) {
  if (!fs.existsSync(filePath)) return null;
  return fs.readFileSync(filePath, 'utf8').trim();
}

function parseVarsFromArgv(argv) {
  const vars = { ...DEFAULT_VARS };
  const remaining = [];

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === '-v' && argv[i + 1]) {
      const eq = argv[i + 1].indexOf('=');
      if (eq !== -1) {
        vars[argv[i + 1].slice(0, eq)] = argv[i + 1].slice(eq + 1);
      }
      i += 1;
      continue;
    }
    remaining.push(arg);
  }

  return { vars, remaining };
}

/** Strip psql meta-commands (\set, \if, …) — not valid in plain SQL. */
function stripPsqlMeta(sql) {
  return sql
    .split('\n')
    .filter((line) => !/^\s*\\/.test(line))
    .join('\n');
}

function substitutePsqlVars(sql, vars) {
  const merged = { ...DEFAULT_VARS, ...vars };
  let out = sql;
  const dryRun = merged.dry_run === 'true';
  out = out.replace(
    /v_dry_run constant boolean := \(\s*:'dry_run'\s*=\s*'true'\s*\);/g,
    `v_dry_run constant boolean := ${dryRun};`,
  );
  for (const [key, value] of Object.entries(merged)) {
    if (key === 'dry_run') continue;
    const escaped = String(value).replace(/'/g, "''");
    out = out.replace(new RegExp(`:'${key}'`, 'g'), `'${escaped}'`);
  }
  return out;
}

function preprocessSqlFile(filePath, vars) {
  const raw = fs.readFileSync(filePath, 'utf8');
  return substitutePsqlVars(stripPsqlMeta(raw), vars);
}

function warnIfLinkedRefDrifts(env, coreDir) {
  const expectedRef = env.SUPABASE_PROJECT_REF?.trim();
  const linkedRef = readTrimmed(path.join(coreDir, 'supabase', '.temp', 'project-ref'));
  if (linkedRef && expectedRef && linkedRef !== expectedRef) {
    console.warn(
      `Warning: linked Supabase project (${linkedRef}) differs from .env SUPABASE_PROJECT_REF (${expectedRef}).\n` +
        'Using the linked project. Run: npm run migrate:link:dev   or   npm run migrate:link:prod',
    );
  }
  return linkedRef;
}

function runSupabaseQuery(coreDir, env, queryArgs) {
  delete env.SUPABASE_DB_PASSWORD;
  return spawnSync(supabaseCommand, [...supabaseArgsPrefix, 'db', 'query', '--linked', ...queryArgs], {
    cwd: coreDir,
    stdio: 'inherit',
    env,
    shell: process.platform === 'win32',
  });
}

const repoRoot = process.cwd();
const coreDir = detectCoreDir(repoRoot);
if (!coreDir) {
  console.error('No Supabase config found under packages/core/supabase or ./supabase.');
  process.exit(1);
}

const linkedRef = readTrimmed(path.join(coreDir, 'supabase', '.temp', 'project-ref'));
if (!linkedRef) {
  console.error(
    'No linked Supabase project. Run first:\n' +
      '  npm run migrate:link:dev   or   npm run migrate:link:prod\n' +
      'Also ensure you are logged in: npx supabase login',
  );
  process.exit(1);
}

const envPath = path.join(repoRoot, '.env');
const envFile = fs.existsSync(envPath) ? parseDotEnv(fs.readFileSync(envPath, 'utf8')) : {};
const env = envWithScoopShimsOnPath({ ...process.env, ...envFile });
warnIfLinkedRefDrifts(envFile, coreDir);

const rawArgv = process.argv.slice(2);
if (rawArgv.length === 0) {
  console.error('Usage: npm run db:psql -- [psql-style args]');
  console.error('Example: npm run db:psql -- -v dry_run=true -f packages/core/supabase/seeds/delete_orgs_except_scouts_victoria_once.sql');
  process.exit(1);
}

const { vars, remaining } = parseVarsFromArgv(rawArgv);

let result;
let tempFile = null;

try {
  const fileFlagIndex = remaining.findIndex((arg) => arg === '-f' || arg === '--file');
  if (fileFlagIndex !== -1) {
    const fileArg = remaining[fileFlagIndex + 1];
    if (!fileArg) {
      console.error('Missing path after -f');
      process.exit(1);
    }
    const sqlPath = path.isAbsolute(fileArg) ? fileArg : path.resolve(repoRoot, fileArg);
    if (!fs.existsSync(sqlPath)) {
      console.error(`SQL file not found: ${sqlPath}`);
      process.exit(1);
    }
    const sql = preprocessSqlFile(sqlPath, vars);
    tempFile = path.join(os.tmpdir(), `pace-psql-${process.pid}-${Date.now()}.sql`);
    fs.writeFileSync(tempFile, sql, 'utf8');
    result = runSupabaseQuery(coreDir, env, ['-f', tempFile]);
  } else {
    const commandFlagIndex = remaining.findIndex((arg) => arg === '-c' || arg === '--command');
    if (commandFlagIndex === -1) {
      console.error('Supported flags: -f <file> or -c <sql>. Other psql flags are not passed through.');
      process.exit(1);
    }
    const sql = remaining[commandFlagIndex + 1];
    if (!sql) {
      console.error('Missing SQL after -c');
      process.exit(1);
    }
    result = runSupabaseQuery(coreDir, env, [sql]);
  }
} finally {
  if (tempFile && fs.existsSync(tempFile)) {
    fs.unlinkSync(tempFile);
  }
}

if (result.status !== 0) {
  console.error(
    '\nIf auth failed, run: npx supabase login\n' +
      'Then link the target project: npm run migrate:link:dev | migrate:link:prod',
  );
}

process.exit(result.status ?? 1);
