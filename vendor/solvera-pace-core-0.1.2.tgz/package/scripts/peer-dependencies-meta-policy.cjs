/**
 * Canonical peerDependenciesMeta contract for @solvera/pace-core.
 * Required peers use {}; only listed optional peers may set optional: true.
 */
const OPTIONAL_PEERS = new Set(['@typescript-eslint/parser']);

/**
 * @param {Record<string, string>} peerDependencies
 * @param {Record<string, { optional?: boolean }>} peerDependenciesMeta
 * @returns {{ ok: boolean, errors: string[] }}
 */
function validatePeerDependenciesMeta(peerDependencies, peerDependenciesMeta) {
  const peers = Object.keys(peerDependencies || {});
  const meta = peerDependenciesMeta || {};
  const errors = [];

  const missingMeta = peers.filter((dep) => !meta[dep]);
  if (missingMeta.length > 0) {
    errors.push(
      `peerDependenciesMeta is missing entries for: ${missingMeta.join(', ')}`
    );
  }

  const unexpectedOptional = Object.entries(meta).filter(
    ([dep, value]) => value?.optional && !OPTIONAL_PEERS.has(dep)
  );
  if (unexpectedOptional.length > 0) {
    errors.push(
      `Only ${[...OPTIONAL_PEERS].join(', ')} may be optional peers. Unexpected optional entries: ${unexpectedOptional.map(([dep]) => dep).join(', ')}`
    );
  }

  const extraMeta = Object.keys(meta).filter((dep) => !peers.includes(dep));
  if (extraMeta.length > 0) {
    errors.push(
      `peerDependenciesMeta contains keys not in peerDependencies: ${extraMeta.join(', ')}`
    );
  }

  return { ok: errors.length === 0, errors };
}

module.exports = {
  OPTIONAL_PEERS,
  validatePeerDependenciesMeta,
};
