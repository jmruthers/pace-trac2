/**
 * ESLint Config Preset for pace-core Compliance
 * @package @solvera/pace-core
 * @module ESLintConfig
 * 
 * Shareable ESLint configuration that consuming apps can extend
 * to enforce pace-core usage patterns.
 * 
 * @example
 * // In your consuming app's eslint.config.js:
 * import paceCoreConfig from '@solvera/pace-core/eslint-config';
 * 
 * export default [
 *   ...paceCoreConfig,
 *   // your other config
 * ];
 */

const path = require('path');
const fs = require('fs');

// Load pace-core ESLint rules
let paceCoreRules = {};
const sourceRulesPath = path.resolve(__dirname, 'eslint-rules/index.cjs');
const distRulesPath = path.resolve(__dirname, 'dist/eslint-rules/index.cjs');
const cwdRulesPath = path.resolve(process.cwd(), 'node_modules/@solvera/pace-core/dist/eslint-rules/index.cjs');

try {
  // Try source path first (for development) - new location at package root
  if (fs.existsSync(sourceRulesPath)) {
    paceCoreRules = require(sourceRulesPath).rules;
  } else {
    // Try dist path (for published package)
    if (fs.existsSync(distRulesPath)) {
      paceCoreRules = require(distRulesPath).rules;
    } else {
      // Try relative to current working directory (for consuming apps)
      if (fs.existsSync(cwdRulesPath)) {
        paceCoreRules = require(cwdRulesPath).rules;
      }
    }
  }
} catch (error) {
  // Log warning in development but don't fail - rules will be empty, but config will still work
  // This allows the config to be used even if rules aren't available
  if (process.env.NODE_ENV !== 'production') {
    console.warn(`Warning: Could not load pace-core ESLint rules: ${error.message}`);
    console.warn(`  Tried paths: ${sourceRulesPath}, ${distRulesPath}, ${cwdRulesPath}`);
  }
}

// Optional TypeScript parser: apply to .ts/.tsx when @typescript-eslint/parser is installed
let tsParserConfig = null;
try {
  const tsParser = require('@typescript-eslint/parser');
  tsParserConfig = {
    files: ['**/*.ts', '**/*.tsx'],
    languageOptions: { parser: tsParser }
  };
} catch {
  // Parser not installed; config still works, but .ts/.tsx may need parser from app's config
}

// Shared config ignores build/generated output by default so only source is linted.
// TypeScript parsing for .ts/.tsx is applied when @typescript-eslint/parser is installed.
const config = [
  // Global ignores: dist, coverage, node_modules (works from any cwd)
  {
    ignores: [
      'dist/**', '**/dist/**',
      'coverage/**', '**/coverage/**',
      'node_modules/**', '**/node_modules/**',
      // Vitest/Vite ephemeral config bundles (configLoader=runner avoids creating these)
      '**/*config*.timestamp-*.mjs',
      // esbuild deploy bundles (sources are index.source.ts)
      '**/supabase/functions/**/index.ts',
    ]
  },
  ...(tsParserConfig ? [tsParserConfig] : []),
  {
    plugins: {
      'pace-core-compliance': {
        rules: paceCoreRules
      }
    },
    rules: {
      // Standard 1: pace-core Compliance
      'pace-core-compliance/prefer-pace-core-components': 'warn',
      'pace-core-compliance/prefer-pace-core-hooks': 'warn',
      'pace-core-compliance/prefer-pace-core-utils': 'warn',
      'pace-core-compliance/no-local-component-duplication': 'error',
      'pace-core-compliance/no-restricted-imports': 'error',
      'pace-core-compliance/prefer-pace-core-form': 'error',
      'pace-core-compliance/require-pace-app-layout-user-menu-props': 'error',
      'pace-core-compliance/prefer-src-alias-imports': 'warn',
      'pace-core-compliance/no-base-supabase-import-outside-bootstrap': 'warn',
      'pace-core-compliance/rbac-page-name-convention': 'error',
      'pace-core-compliance/legacy-rbac-page-name': 'error',
      'pace-core-compliance/route-path-kebab-case': 'error',
      
      // Standard 4: Code Quality
      'pace-core-compliance/naming-convention': 'warn',
      'pace-core-compliance/component-naming': 'warn',
      'pace-core-compliance/component-filename': 'warn',
      'pace-core-compliance/type-naming': 'warn',
      
      // Standard 07: Visual (7-visual-standards.md — ESLint rules in eslint-rules/rules/05-styling.cjs)
      'pace-core-compliance/no-inline-styles': 'error',
      'pace-core-compliance/no-typography-styling': 'error',
      'pace-core-compliance/no-pace-core-style-override': 'warn',
      'pace-core-compliance/prefer-semantic-html': 'warn',
      'pace-core-compliance/no-nested-same-type-tags': 'error',
      'pace-core-compliance/no-redundant-card-subcomponent-wrapper': 'error',
      'pace-core-compliance/no-flex-layout-classes': 'error',
      'pace-core-compliance/no-directory-card-list-grid': 'error',
      'pace-core-compliance/no-legacy-tailwind-color-classes': 'error',
      'pace-core-compliance/persistence-save-label': 'error',
      'pace-core-compliance/persistence-save-placement': 'error',
      
      // Standard 6: Security & RBAC
      'pace-core-compliance/no-direct-supabase-client': 'error',
      'pace-core-compliance/rbac-permission-loading': 'error',
      'pace-core-compliance/no-direct-rbac-rpc': 'error',
      'pace-core-compliance/no-direct-rbac-table': 'error',
      'pace-core-compliance/no-hardcoded-role-checks': 'error',
      'pace-core-compliance/rbac-use-resource-names-constants': 'error',
      'pace-core-compliance/no-rbac-wrapper-components': 'error',
      'pace-core-compliance/no-rbac-wrapper-functions': 'error',
      'pace-core-compliance/require-derived-organisation-id': 'warn',
      'pace-core-compliance/require-setup-rbac-get-app-id': 'error',
      'pace-core-compliance/canonical-app-name-uppercase': 'error',
      
      // Standard 7: API & Tech Stack
      'pace-core-compliance/rpc-naming-pattern': 'warn',
      'pace-core-compliance/no-class-components': 'error',
      'pace-core-compliance/prefer-import-meta-env': 'error',
      
      // Standard 8: Testing
      'pace-core-compliance/test-file-naming': 'warn',
      'pace-core-compliance/prefer-setup-user': 'error',

      // Standard 9: Operations
      'pace-core-compliance/no-silent-catch': 'error',
      'pace-core-compliance/no-sensitive-log-fields': 'error',
      
      // Enforced via plugin rule so behavior is consistent with manifest-loader defaults.
      'no-restricted-imports': 'off'
    }
  },
  // Standard 3: Architecture - SRP proxies (source only; consuming app src/; exclude tests)
  {
    files: ['src/**/*.{ts,tsx}'],
    ignores: [
      '**/__tests__/**',
      '**/*.{spec,test}.{ts,tsx}',
      '**/fixtures/**',
      '**/mocks/**',
      '**/*.mock.{ts,tsx}',
      '**/*.template.{ts,tsx}',
    ],
    rules: {
      // Standard 3: SRP proxies (line limits + named exports) — single source
      'max-lines': ['warn', { max: 1000 }],
      'max-lines-per-function': ['warn', { max: 400 }],
      'pace-core-compliance/max-named-exports': ['warn', { max: 10 }],
      'complexity': ['warn', { max: 30 }],
    }
  },
  // pace-core package component authoring (packages/core/src/components)
  {
    files: ['packages/core/src/**/*.{ts,tsx}'],
    rules: {
      'pace-core-compliance/component-filename': 'error',
    },
  },
  {
    files: ['packages/core/src/components/**/*.{ts,tsx}'],
    ignores: [
      '**/*.{test,integration.test}.{ts,tsx}',
      '**/index.ts',
      '**/*.types.ts',
      '**/types.ts',
      '**/columnFactory.tsx',
      '**/overlays/dialog/Dialog.tsx',
      '**/overlays/select/Select.tsx',
      '**/primitives/Table.tsx',
      '**/primitives/Card.tsx',
      '**/forms-feedback/Toast.tsx',
    ],
    rules: {
      'max-lines': ['error', { max: 1000, skipBlankLines: true, skipComments: true }],
      'max-lines-per-function': ['error', { max: 400, skipBlankLines: true, skipComments: true }],
      complexity: ['warn', { max: 30 }],
      'pace-core-compliance/prefer-cn-class-merge': 'error',
      'pace-core-compliance/no-duplicate-button-classes': 'error',
      'pace-core-compliance/component-test-naming': 'error',
      'pace-core-compliance/require-component-integration-test': 'error',
      'pace-core-compliance/max-named-exports-package': ['error', { max: 10 }],
    },
  },
  {
    files: ['src/components/**/*.{ts,tsx}'],
    ignores: [
      '**/*.{test,integration.test}.{ts,tsx}',
      '**/index.ts',
      '**/*.types.ts',
      '**/types.ts',
      '**/columnFactory.tsx',
    ],
    rules: {
      'max-lines': ['error', { max: 1000, skipBlankLines: true, skipComments: true }],
      'max-lines-per-function': ['error', { max: 400, skipBlankLines: true, skipComments: true }],
      complexity: ['warn', { max: 30 }],
      'pace-core-compliance/prefer-cn-class-merge': 'error',
      'pace-core-compliance/no-duplicate-button-classes': 'error',
      'pace-core-compliance/component-test-naming': 'error',
      'pace-core-compliance/require-component-integration-test': 'error',
      'pace-core-compliance/max-named-exports-package': ['error', { max: 10 }],
    },
  },
  // Override for Edge Functions (Deno runtime)
  // Edge Functions run in Deno, not React, so they cannot use React hooks
  // They need direct Supabase client access and console.log for debugging
  {
    files: ['**/supabase/functions/**/*.{ts,js}'],
    rules: {
      // Allow console.log in Edge Functions for debugging and monitoring
      'no-console': 'off',
      // Edge Functions cannot use React hooks, so they must use createClient directly
      // The rule already excludes Edge Functions, but we explicitly allow it here for clarity
      'pace-core-compliance/no-direct-supabase-client': 'off',
    }
  }
];

module.exports = config;

