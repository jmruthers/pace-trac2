/**
 * Dependencies Audit (Pre-Standard)
 * @package @solvera/pace-core
 * @module Audit/Dependencies
 * 
 * Audits consuming apps for dependency compliance with pace-core.
 * This runs before standard audits as it validates the foundation.
 * 
 * Checks for:
 * - Included dependencies that should NOT be installed
 * - Missing required peer dependencies
 * - Incorrect version ranges
 * - Dependencies in the wrong location
 * 
 * Reference: packages/core/docs/standards/5-pace-core-compliance-standards.md
 */

const fs = require('fs');
const path = require('path');
const { validatePeerDependenciesMeta } = require('../scripts/peer-dependencies-meta-policy.cjs');

// Colors for terminal output
const colors = {
  reset: '\x1b[0m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m',
  bold: '\x1b[1m',
};

// Get pace-core package.json
// When run from consuming app: __dirname is node_modules/@solvera/pace-core/audit-tool
// When run from pace-core repo: __dirname is packages/core/audit-tool
function findPaceCorePackageJson(consumingAppPath) {
  // Try relative to script location first (when in pace-core repo or installed package)
  // Now we're in audit-tool/ directory, so need to go up one level
  let paceCorePath = path.resolve(__dirname, '../package.json');
  if (fs.existsSync(paceCorePath)) {
    return paceCorePath;
  }
  
  // Try alternative location (if script is in different structure)
  paceCorePath = path.resolve(__dirname, '../../../package.json');
  if (fs.existsSync(paceCorePath)) {
    return paceCorePath;
  }
  
  // Try finding from consuming app's node_modules (when run from consuming app)
  if (consumingAppPath) {
    const nodeModulesPath = path.join(consumingAppPath, 'node_modules', '@solvera', 'pace-core', 'package.json');
    if (fs.existsSync(nodeModulesPath)) {
      return nodeModulesPath;
    }
  }
  
  // Fallback: try from process.argv (for standalone CLI usage)
  const fallbackPath = process.argv[2] || process.cwd();
  const fallbackNodeModules = path.join(fallbackPath, 'node_modules', '@solvera', 'pace-core', 'package.json');
  if (fs.existsSync(fallbackNodeModules)) {
    return fallbackNodeModules;
  }
  
  return null;
}

// Version range matcher
function matchesVersionRange(version, range) {
  if (!range) return true;
  
  // Simple check for caret ranges (^)
  if (range.startsWith('^')) {
    const major = parseInt(range.slice(1).split('.')[0]);
    const versionMajor = parseInt(version.split('.')[0]);
    return versionMajor >= major;
  }
  
  // For exact matches or other ranges, use semver if available
  // For now, just check if version starts with the range
  return version.startsWith(range.replace(/[\^~]/, ''));
}

// Compare two version strings (e.g., "4.1.8" vs "4.1.16")
// Returns: -1 if v1 < v2, 0 if v1 === v2, 1 if v1 > v2
function compareVersions(v1, v2) {
  const parts1 = v1.split('.').map(Number);
  const parts2 = v2.split('.').map(Number);
  const maxLength = Math.max(parts1.length, parts2.length);
  
  for (let i = 0; i < maxLength; i++) {
    const part1 = parts1[i] || 0;
    const part2 = parts2[i] || 0;
    
    if (part1 < part2) return -1;
    if (part1 > part2) return 1;
  }
  
  return 0;
}

// Check version compatibility
function checkVersion(installed, required) {
  if (!required) return { valid: true };
  
  // Extract version number from installed (remove ^, ~, etc.)
  const installedVersion = installed.replace(/[\^~]/, '');
  const requiredVersion = required.replace(/[\^~]/, '');
  
  // Parse version parts
  const installedParts = installedVersion.split('.').map(Number);
  const requiredParts = requiredVersion.split('.').map(Number);
  
  const installedMajor = installedParts[0] || 0;
  const requiredMajor = requiredParts[0] || 0;
  
  if (required.startsWith('^')) {
    // Caret range: ^4.1.16 means >= 4.1.16 and < 5.0.0
    // Check if installed version is >= required version
    const versionComparison = compareVersions(installedVersion, requiredVersion);
    
    // Must be same major version and >= required version
    const valid = installedMajor === requiredMajor && versionComparison >= 0;
    
    return {
      valid,
      installed,
      required,
    };
  }
  
  if (required.startsWith('~')) {
    // Tilde range: ~4.1.16 means >= 4.1.16 and < 4.2.0
    const versionComparison = compareVersions(installedVersion, requiredVersion);
    const installedMinor = installedParts[1] || 0;
    const requiredMinor = requiredParts[1] || 0;
    
    const valid = installedMajor === requiredMajor && 
                  installedMinor === requiredMinor && 
                  versionComparison >= 0;
    
    return {
      valid,
      installed,
      required,
    };
  }
  
  // Exact match or no prefix - check major version
  return {
    valid: installedMajor === requiredMajor,
    installed,
    required,
  };
}

// Main audit function - returns data structure for programmatic use
// auditContext: { isPaceCorePackage?: boolean } - when true, skip audit (package does not install itself)
function runDependencyAudit(consumingAppPath = process.cwd(), auditContext = {}) {
  const packageJsonPath = path.join(consumingAppPath, 'package.json');
  const emptyIssues = { includedDeps: [], missingRequired: [], missingOptional: [], versionIssues: [], wrongLocation: [], missingDevDeps: [], devVersionIssues: [] };

  if (!fs.existsSync(packageJsonPath)) {
    return {
      error: `package.json not found at ${packageJsonPath}`,
      issues: emptyIssues
    };
  }

  if (auditContext.isPaceCorePackage === true) {
    try {
      const pkg = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'));
      return {
        projectName: pkg.name || '@solvera/pace-core',
        paceCoreVersion: 'self',
        issues: emptyIssues
      };
    } catch (e) {
      return { projectName: 'unknown', paceCoreVersion: 'self', issues: emptyIssues };
    }
  }
  
  // Load pace-core package.json
  const paceCorePath = findPaceCorePackageJson(consumingAppPath);
  if (!paceCorePath) {
    return {
      error: 'Could not find pace-core package.json. Make sure @solvera/pace-core is installed in your project.',
      issues: emptyIssues
    };
  }
  
  const paceCorePkg = JSON.parse(fs.readFileSync(paceCorePath, 'utf8'));
  const INCLUDED_DEPS = Object.keys(paceCorePkg.dependencies || {});
  const PEER_DEPS = paceCorePkg.peerDependencies || {};
  const PEER_META = paceCorePkg.peerDependenciesMeta || {};
  
  // Required peers are those NOT marked as optional in peerDependenciesMeta
  const REQUIRED_PEERS = Object.keys(PEER_DEPS).filter(
    dep => !PEER_META[dep]?.optional
  );
  
  // Optional peers are those marked as optional in peerDependenciesMeta
  const OPTIONAL_PEERS = Object.keys(PEER_DEPS).filter(
    dep => PEER_META[dep]?.optional
  );
  
  const metaValidation = validatePeerDependenciesMeta(PEER_DEPS, PEER_META);
  if (!metaValidation.ok) {
    for (const error of metaValidation.errors) {
      console.warn(`${colors.yellow}Warning: ${error}${colors.reset}`);
    }
    console.warn(
      `${colors.yellow}Required peers use {} in peerDependenciesMeta; only @typescript-eslint/parser may be optional.${colors.reset}`
    );
  }
  
  // Verify pace-core is installed
  const paceCoreInNodeModules = path.join(consumingAppPath, 'node_modules', '@solvera', 'pace-core', 'package.json');
  if (!fs.existsSync(paceCoreInNodeModules)) {
    return {
      error: '@solvera/pace-core not found in node_modules. Please run: npm install @solvera/pace-core',
      issues: { includedDeps: [], missingRequired: [], missingOptional: [], versionIssues: [], wrongLocation: [], missingDevDeps: [], devVersionIssues: [] }
    };
  }
  
  const consumingPkg = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'));
  const allDeps = {
    ...(consumingPkg.dependencies || {}),
    ...(consumingPkg.devDependencies || {}),
  };
  
  const issues = {
    includedDeps: [],
    missingRequired: [],
    missingOptional: [],
    versionIssues: [],
    wrongLocation: [],
    missingDevDeps: [],
    devVersionIssues: [],
  };
  
  // When auditing the pace-core repo root (monorepo), skip "included deps" check:
  // the root package.json is the workspace root and shares the dependency tree with packages/core.
  const packagesCorePath = path.join(consumingAppPath, 'packages', 'core', 'package.json');
  const isPaceCoreRepoRoot = fs.existsSync(packagesCorePath);
  let skipIncludedDepsCheck = false;
  if (isPaceCoreRepoRoot) {
    try {
      const corePkg = JSON.parse(fs.readFileSync(packagesCorePath, 'utf8'));
      if (corePkg.name === '@solvera/pace-core') {
        skipIncludedDepsCheck = true;
      }
    } catch (e) {
      // ignore
    }
  }
  
  // Check for included dependencies (skip when auditing pace-core repo root)
  const paceCoreSpec = consumingPkg.dependencies?.['@solvera/pace-core'];
  const usesFileLinkedPaceCore =
    typeof paceCoreSpec === 'string' && paceCoreSpec.trim().startsWith('file:');
  /** With `file:` links, nested node_modules for pace-core are not installed; RHF must resolve from the app for Vite/tsc. */
  const INCLUDED_DEP_EXCEPTIONS_WHEN_FILE_LINKED = new Set(['react-hook-form']);

  if (!skipIncludedDepsCheck) {
    INCLUDED_DEPS.forEach(dep => {
      if (allDeps[dep]) {
        if (usesFileLinkedPaceCore && INCLUDED_DEP_EXCEPTIONS_WHEN_FILE_LINKED.has(dep)) {
          return;
        }
        issues.includedDeps.push({
          package: dep,
          installed: allDeps[dep],
          location: consumingPkg.dependencies?.[dep] ? 'dependencies' : 'devDependencies',
        });
      }
    });
  }
  
  // Check for required peer dependencies
  REQUIRED_PEERS.forEach(dep => {
    if (!allDeps[dep]) {
      issues.missingRequired.push({
        package: dep,
        required: PEER_DEPS[dep],
      });
    } else {
      // Check version
      const versionCheck = checkVersion(allDeps[dep], PEER_DEPS[dep]);
      if (!versionCheck.valid) {
        issues.versionIssues.push({
          package: dep,
          installed: versionCheck.installed,
          required: versionCheck.required,
        });
      }
    }
  });
  
  // Check for optional peer dependencies (warn if missing, but don't fail)
  OPTIONAL_PEERS.forEach(dep => {
    if (!allDeps[dep]) {
      issues.missingOptional.push({
        package: dep,
        required: PEER_DEPS[dep],
      });
    } else {
      // Check version
      const versionCheck = checkVersion(allDeps[dep], PEER_DEPS[dep]);
      if (!versionCheck.valid) {
        issues.versionIssues.push({
          package: dep,
          installed: versionCheck.installed,
          required: versionCheck.required,
        });
      }
    }
  });
  
  // Check for @tailwindcss/vite in wrong location
  if (consumingPkg.dependencies?.['@tailwindcss/vite']) {
    issues.wrongLocation.push({
      package: '@tailwindcss/vite',
      current: 'dependencies',
      shouldBe: 'devDependencies',
    });
  }
  
  // Check required dev dependencies
  // Get pace-core's dev dependencies to use as reference versions
  const paceCoreDevDeps = paceCorePkg.devDependencies || {};
  const devDeps = consumingPkg.devDependencies || {};
  
  // Build list of required dev dependencies dynamically from pace-core's devDependencies
  // Exclude packages that consuming apps don't need:
  // 1. pace-core-specific build tools (tsup, typedoc, etc.)
  // 2. Testing libraries (consuming apps may use different testing setups)
  // 3. Type definitions (@types/* - consuming apps manage their own)
  // 4. Packages already checked as peer dependencies (except tailwindcss which we check in both)
  // 5. Packages already included in pace-core's dependencies
  
  const requiredDevDeps = {};
  
  Object.entries(paceCoreDevDeps).forEach(([dep, version]) => {
    // Skip pace-core-specific build tools
    if (dep === 'tsup' || 
        dep === 'typedoc' || 
        dep.startsWith('typedoc-plugin-') ||
        dep === 'esbuild' ||
        dep === '@vitest/coverage-v8') {
      return;
    }
    
    // Skip testing libraries (consuming apps may use different testing)
    if (dep.includes('testing-library') || 
        dep === 'jsdom' ||
        dep === 'vitest') {
      return;
    }
    
    // Skip type definitions (consuming apps manage their own @types/*)
    if (dep.startsWith('@types/')) {
      return;
    }
    
    // Skip if it's already a peer dependency (checked separately)
    // Exception: tailwindcss - we check both peer and dev dependency versions
    if (PEER_DEPS[dep] && dep !== 'tailwindcss') {
      return;
    }
    
    // Skip if it's already in pace-core's dependencies (included, not needed by consuming apps)
    if (INCLUDED_DEPS.includes(dep)) {
      return;
    }
    
    // Skip if it's in pace-core's dependencies (shouldn't be in devDependencies)
    if (paceCorePkg.dependencies?.[dep]) {
      return;
    }
    
    // Add to required dev dependencies - versions come directly from pace-core's package.json
    requiredDevDeps[dep] = version;
  });
  
  // Override tailwindcss version with peer dependency version if available
  // This ensures we use the peer dependency requirement, not the dev dependency version
  if (PEER_DEPS.tailwindcss) {
    requiredDevDeps.tailwindcss = PEER_DEPS.tailwindcss;
  }
  
  // Check for missing required dev dependencies
  Object.entries(requiredDevDeps).forEach(([dep, requiredVersion]) => {
    if (!requiredVersion) return; // Skip if pace-core doesn't specify a version
    
    if (!devDeps[dep] && !consumingPkg.dependencies?.[dep]) {
      issues.missingDevDeps.push({
        package: dep,
        required: requiredVersion,
      });
    } else {
      // Check version if installed
      const installedVersion = devDeps[dep] || consumingPkg.dependencies?.[dep];
      if (installedVersion) {
        const versionCheck = checkVersion(installedVersion, requiredVersion);
        if (!versionCheck.valid) {
          issues.devVersionIssues.push({
            package: dep,
            installed: versionCheck.installed,
            required: versionCheck.required,
            location: devDeps[dep] ? 'devDependencies' : 'dependencies',
          });
        }
      }
    }
  });
  
  // Check for dev dependencies in wrong location (should be in devDependencies, not dependencies)
  // This is dynamic - check all required dev dependencies
  Object.keys(requiredDevDeps).forEach(dep => {
    if (consumingPkg.dependencies?.[dep] && !devDeps[dep]) {
      issues.wrongLocation.push({
        package: dep,
        current: 'dependencies',
        shouldBe: 'devDependencies',
      });
    }
  });
  
  // Find pace-core version - check dependencies, devDependencies, or installed package
  let paceCoreVersion = consumingPkg.dependencies?.['@solvera/pace-core'] || 
                        consumingPkg.devDependencies?.['@solvera/pace-core'];
  
  // If not in package.json, try to read from installed package
  if (!paceCoreVersion) {
    const installedPkgPath = path.join(consumingAppPath, 'node_modules', '@solvera', 'pace-core', 'package.json');
    if (fs.existsSync(installedPkgPath)) {
      try {
        const installedPkg = JSON.parse(fs.readFileSync(installedPkgPath, 'utf8'));
        paceCoreVersion = `installed: ${installedPkg.version}`;
      } catch (e) {
        paceCoreVersion = 'installed (version unknown)';
      }
    } else {
      paceCoreVersion = 'NOT FOUND';
    }
  }
  
  return {
    projectName: consumingPkg.name || 'unknown',
    paceCoreVersion,
    issues,
  };
}

// CLI function - displays results and returns exit code
function auditDependencies(consumingAppPath = process.cwd()) {
  const result = runDependencyAudit(consumingAppPath);
  
  if (result.error) {
    console.error(`${colors.red}Error: ${result.error}${colors.reset}`);
    process.exit(1);
  }
  
  const { projectName, paceCoreVersion, issues } = result;
  
  // Report results
  console.log(`\n${colors.bold}${colors.cyan}Dependency Audit Report${colors.reset}`);
  console.log(`${colors.cyan}${'='.repeat(50)}${colors.reset}\n`);
  console.log(`Project: ${colors.bold}${projectName}${colors.reset}`);
  console.log(`pace-core: ${colors.bold}${paceCoreVersion}${colors.reset}\n`);
  
  let hasErrors = false;
  
  // Included dependencies (errors)
  if (issues.includedDeps.length > 0) {
    hasErrors = true;
    console.log(`${colors.red}❌ INCLUDED DEPENDENCIES (MUST REMOVE):${colors.reset}`);
    issues.includedDeps.forEach(issue => {
      console.log(`  - ${colors.red}${issue.package}${colors.reset}@${issue.installed} (in ${issue.location})`);
      console.log(`    → Should NOT be installed (already included in pace-core)`);
    });
    console.log();
  }
  
  // Missing required dependencies (errors)
  if (issues.missingRequired.length > 0) {
    hasErrors = true;
    console.log(`${colors.red}❌ MISSING REQUIRED DEPENDENCIES:${colors.reset}`);
    issues.missingRequired.forEach(issue => {
      console.log(`  - ${colors.red}${issue.package}${colors.reset} (required: ${issue.required})`);
    });
    console.log();
  }
  
  // Version issues (errors)
  if (issues.versionIssues.length > 0) {
    hasErrors = true;
    console.log(`${colors.yellow}⚠️  VERSION ISSUES:${colors.reset}`);
    issues.versionIssues.forEach(issue => {
      console.log(`  - ${colors.yellow}${issue.package}${colors.reset}`);
      console.log(`    Installed: ${issue.installed}`);
      console.log(`    Required: ${issue.required}`);
    });
    console.log();
  }
  
  // Wrong location (warnings)
  if (issues.wrongLocation.length > 0) {
    console.log(`${colors.yellow}⚠️  WRONG LOCATION:${colors.reset}`);
    issues.wrongLocation.forEach(issue => {
      console.log(`  - ${colors.yellow}${issue.package}${colors.reset}`);
      console.log(`    Currently in: ${issue.current}`);
      console.log(`    Should be in: ${issue.shouldBe}`);
    });
    console.log();
  }
  
  // Missing optional dependencies (warnings)
  if (issues.missingOptional.length > 0) {
    console.log(`${colors.blue}ℹ️  MISSING OPTIONAL DEPENDENCIES:${colors.reset}`);
    console.log(`  (Only install if you use these features)`);
    issues.missingOptional.forEach(issue => {
      console.log(`  - ${colors.blue}${issue.package}${colors.reset} (required: ${issue.required})`);
    });
    console.log();
  }
  
  // Missing dev dependencies (errors)
  if (issues.missingDevDeps.length > 0) {
    hasErrors = true;
    console.log(`${colors.red}❌ MISSING REQUIRED DEV DEPENDENCIES:${colors.reset}`);
    issues.missingDevDeps.forEach(issue => {
      console.log(`  - ${colors.red}${issue.package}${colors.reset} (required: ${issue.required})`);
    });
    console.log();
  }
  
  // Dev version issues (errors)
  if (issues.devVersionIssues.length > 0) {
    hasErrors = true;
    console.log(`${colors.yellow}⚠️  DEV DEPENDENCY VERSION ISSUES:${colors.reset}`);
    issues.devVersionIssues.forEach(issue => {
      console.log(`  - ${colors.yellow}${issue.package}${colors.reset} (in ${issue.location})`);
      console.log(`    Installed: ${issue.installed}`);
      console.log(`    Required: ${issue.required}`);
    });
    console.log();
  }
  
  // Success message
  if (!hasErrors && issues.missingOptional.length === 0 && issues.wrongLocation.length === 0) {
    console.log(`${colors.green}✅ All dependencies are correctly configured!${colors.reset}\n`);
    return 0;
  }
  
  // Generate fix commands
  if (hasErrors || issues.wrongLocation.length > 0) {
    console.log(`${colors.bold}Fix Commands:${colors.reset}\n`);
    
    if (issues.includedDeps.length > 0) {
      const depsToRemove = issues.includedDeps.map(i => i.package).join(' ');
      console.log(`${colors.cyan}# Remove included dependencies${colors.reset}`);
      console.log(`npm uninstall ${depsToRemove}\n`);
    }
    
    if (issues.missingRequired.length > 0) {
      const depsToInstall = issues.missingRequired
        .map(i => `${i.package}@${i.required}`)
        .join(' ');
      console.log(`${colors.cyan}# Install missing required dependencies${colors.reset}`);
      console.log(`npm install ${depsToInstall}\n`);
    }
    
    if (issues.missingDevDeps.length > 0) {
      const devDepsToInstall = issues.missingDevDeps
        .map(i => `${i.package}@${i.required}`)
        .join(' ');
      console.log(`${colors.cyan}# Install missing required dev dependencies${colors.reset}`);
      console.log(`npm install -D ${devDepsToInstall}\n`);
    }
    
    if (issues.versionIssues.length > 0) {
      const depsToFix = issues.versionIssues
        .map(i => `${i.package}@${i.required}`)
        .join(' ');
      console.log(`${colors.cyan}# Fix version ranges${colors.reset}`);
      console.log(`npm install ${depsToFix}\n`);
    }
    
    if (issues.devVersionIssues.length > 0) {
      const devDepsToFix = issues.devVersionIssues
        .map(i => `${i.package}@${i.required}`)
        .join(' ');
      console.log(`${colors.cyan}# Fix dev dependency version ranges${colors.reset}`);
      console.log(`npm install -D ${devDepsToFix}\n`);
    }
    
    if (issues.wrongLocation.length > 0) {
      issues.wrongLocation.forEach(issue => {
        console.log(`${colors.cyan}# Move ${issue.package} to devDependencies${colors.reset}`);
        console.log(`npm uninstall ${issue.package}`);
        console.log(`npm install -D ${issue.package}\n`);
      });
    }
  }
  
  return hasErrors ? 1 : 0;
}

// Export for use by other scripts
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { runDependencyAudit, checkVersion, findPaceCorePackageJson };
}

// Run audit only if this file is executed directly (not required)
if (require.main === module) {
  // If run from pace-core repo without path, try to detect consuming app in parent directory
  let consumingAppPath = process.argv[2];
  if (!consumingAppPath) {
    const cwd = process.cwd();
    // If we're in pace-core repo, try to find consuming app in parent directory
    if (cwd.includes('pace-core')) {
      // Look for sibling directories that might be consuming apps
      const parentDir = path.resolve(cwd, '../..');
      const possibleApps = ['pace-admin', 'pace-base', 'pace-cake', 'pace-gear', 'pace-mint', 'pace-portal', 'pace-pump', 'pace-trac'];
      for (const app of possibleApps) {
        const appPath = path.join(parentDir, app);
        if (fs.existsSync(path.join(appPath, 'package.json'))) {
          consumingAppPath = appPath;
          break;
        }
      }
    }
    // Fall back to current directory
    if (!consumingAppPath) {
      consumingAppPath = process.cwd();
    }
  }
  const exitCode = auditDependencies(consumingAppPath);
  process.exit(exitCode);
}

