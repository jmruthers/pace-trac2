#!/usr/bin/env node

/**
 * Comprehensive Audit Script for Consuming Apps
 * @package @solvera/pace-core
 * @module Audit
 * 
 * Audits consuming apps against pace-core standards and generates a markdown report.
 * Organized by the 10-file standards structure (Standards 1-9).
 * 
 * This is Layer 4 of the quality enforcement strategy:
 * - Layer 1: Standards Documents (Source of Truth)
 * - Layer 2: Cursor Rules (Real-time Guidance)
 * - Layer 3: ESLint (Fast, Local Static Analysis)
 * - Layer 4: Audit Tool (Deep, System-Level Analysis) ← You are here
 * 
 * Usage:
 *   node packages/core/audit-tool/index.cjs [path-to-consuming-app] [--output report.md] [--max-severity info]
 *   npm run validate (runs this tool as the pace-core Audit step; default fail threshold is info)
 *
 * If no path provided, assumes current directory is consuming app.
 *
 * Note: This tool scans migration SQL for RLS policy and RPC naming compliance
 * using file-based checks in addition to source/config audits.
 */

const fs = require('fs');
const path = require('path');
const { STANDARD_KEYS, STANDARD_META } = require('./standard-keys.cjs');

// Import dependency audit (runs before standards)
const { runDependencyAudit } = require('./00-dependencies.cjs');

// Import new standard-aligned audit modules
const { runStandard1Audit } = require('./audits/01-pace-core-compliance.cjs');
const { runStandard2Audit } = require('./audits/02-project-structure.cjs');
const { runStandard3Audit } = require('./audits/03-architecture.cjs');
const { runStandard4Audit } = require('./audits/04-code-quality.cjs');
const { runStandard5Audit } = require('./audits/05-styling.cjs');
const { runStandard6Audit } = require('./audits/06-security-rbac.cjs');
const { runStandard7Audit } = require('./audits/07-api-tech-stack.cjs');
const { runStandard8Audit } = require('./audits/08-testing-documentation.cjs');
const { runStandard9Audit } = require('./audits/09-operations.cjs');

// Import report utilities
const { generateMarkdownReport, generateSummary } = require('./utils/report-utils.cjs');

// Colors for terminal output
const colors = {
  reset: '\x1b[0m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m',
  bold: '\x1b[1m',
};

const SEVERITY_RANK = {
  none: 4,
  error: 3,
  warning: 2,
  info: 1,
};

function parseMaxSeverity(args) {
  const maxSeverityArg = args.find(arg => arg.startsWith('--max-severity'));
  if (!maxSeverityArg) return 'info';
  const raw = maxSeverityArg.includes('=') ? maxSeverityArg.split('=')[1] : args[args.indexOf(maxSeverityArg) + 1];
  if (!raw) return 'info';
  const normalized = String(raw).toLowerCase();
  if (normalized === 'error' || normalized === 'warning' || normalized === 'info' || normalized === 'none') {
    return normalized;
  }
  return 'info';
}

function issueBlocks(issue, threshold) {
  if (threshold === 'none') return false;
  const severity = String(issue?.severity || 'error').toLowerCase();
  const issueRank = SEVERITY_RANK[severity] || SEVERITY_RANK.error;
  const thresholdRank = SEVERITY_RANK[threshold];
  return issueRank >= thresholdRank;
}

/**
 * Resolve a centralized report directory for this repository.
 * For pace-core package audits, always write reports to repo-root audit/.
 * For consuming app audits, keep audit output local to the audited app path.
 */
function resolveAuditBasePath(consumingAppPath, isPaceCorePackage) {
  if (isPaceCorePackage) {
    return path.resolve(consumingAppPath, '..', '..');
  }
  return consumingAppPath;
}

/**
 * Run all standard audits
 * @param {string} consumingAppPath - Path to the app/package being audited
 * @param {boolean} showProgress - Whether to log progress
 * @param {{ consumingAppPath: string, isPaceCorePackage: boolean }} [auditContext] - Optional context (isPaceCorePackage skips app-only checks)
 */
function runAllAudits(consumingAppPath, showProgress = false, auditContext = {}) {
  const results = {};

  const auditFunctions = [
    { key: STANDARD_KEYS.projectStructure, name: STANDARD_META[STANDARD_KEYS.projectStructure].name, fn: runStandard2Audit },
    { key: STANDARD_KEYS.architecture, name: STANDARD_META[STANDARD_KEYS.architecture].name, fn: runStandard3Audit },
    { key: STANDARD_KEYS.securityRbac, name: STANDARD_META[STANDARD_KEYS.securityRbac].name, fn: runStandard6Audit },
    { key: STANDARD_KEYS.apiTechStack, name: STANDARD_META[STANDARD_KEYS.apiTechStack].name, fn: runStandard7Audit },
    { key: STANDARD_KEYS.paceCoreCompliance, name: STANDARD_META[STANDARD_KEYS.paceCoreCompliance].name, fn: runStandard1Audit },
    { key: STANDARD_KEYS.codeQuality, name: STANDARD_META[STANDARD_KEYS.codeQuality].name, fn: runStandard4Audit },
    { key: STANDARD_KEYS.visual, name: STANDARD_META[STANDARD_KEYS.visual].name, fn: runStandard5Audit },
    { key: STANDARD_KEYS.testingDocumentation, name: STANDARD_META[STANDARD_KEYS.testingDocumentation].name, fn: runStandard8Audit },
    { key: STANDARD_KEYS.operations, name: STANDARD_META[STANDARD_KEYS.operations].name, fn: runStandard9Audit },
  ];
  
  auditFunctions.forEach(({ key, name, fn }) => {
    if (showProgress) {
      console.log(`${colors.blue}Running ${name} audit...${colors.reset}`);
    }
    
    try {
      const result = fn(consumingAppPath, auditContext);
      results[key] = result;
      
      if (result.error && showProgress) {
        console.warn(`${colors.yellow}Warning: ${name} audit failed: ${result.error}${colors.reset}`);
      }
    } catch (error) {
      if (showProgress) {
        console.warn(`${colors.yellow}Warning: ${name} audit encountered an error: ${error.message}${colors.reset}`);
      }
      results[key] = {
        standard: key,
        issues: [],
        error: error.message,
      };
    }
  });
  
  return results;
}

/**
 * Main function
 */
function main() {
  const args = process.argv.slice(2);
  const maxSeverity = parseMaxSeverity(args);
  const outputArg = args.find(arg => arg.startsWith('--output'));
  const outputPath = outputArg ? (outputArg.includes('=') ? outputArg.split('=')[1] : args[args.indexOf(outputArg) + 1] || 'audit-report.md') : null;
  const maxSeverityArg = args.find(arg => arg.startsWith('--max-severity'));
  const maxSeverityValue = maxSeverityArg && !maxSeverityArg.includes('=') ? args[args.indexOf(maxSeverityArg) + 1] : null;
  const consumingAppPath = path.resolve(
    args.find(arg =>
      !arg.startsWith('--') &&
      arg !== outputPath &&
      arg !== maxSeverityValue
    ) || process.cwd()
  );
  
  console.log(`${colors.bold}${colors.cyan}pace-core Comprehensive Audit${colors.reset}\n`);
  console.log(`${colors.cyan}${'='.repeat(50)}${colors.reset}\n`);
  
  // Get project info and detect if we're auditing the pace-core package itself
  const packageJsonPath = path.join(consumingAppPath, 'package.json');
  let projectName = 'unknown';
  let paceCoreVersion = 'unknown';
  let isPaceCorePackage = false;
  
  if (fs.existsSync(packageJsonPath)) {
    try {
      const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'));
      projectName = packageJson.name || 'unknown';
      isPaceCorePackage = projectName === '@solvera/pace-core';
      
      // Find pace-core version
      const allDeps = {
        ...(packageJson.dependencies || {}),
        ...(packageJson.devDependencies || {}),
      };
      paceCoreVersion = allDeps['@solvera/pace-core'] || 'not found in package.json';
    } catch (error) {
      // Skip if package.json can't be parsed
    }
  }
  
  const auditContext = { consumingAppPath, isPaceCorePackage };
  
  console.log(`Project: ${colors.bold}${projectName}${colors.reset}`);
  console.log(`pace-core: ${colors.bold}${paceCoreVersion}${colors.reset}\n`);
  console.log(`Fail threshold: ${colors.bold}${maxSeverity}${colors.reset} (set with --max-severity)\n`);
  
  // Run dependency audit
  console.log(`${colors.blue}Running dependency audit...${colors.reset}`);
  const dependencyResult = runDependencyAudit(consumingAppPath, auditContext);
  
  // Run all standard audits
  const standardResults = runAllAudits(consumingAppPath, true, auditContext);
  
  // Combine results
  const allResults = {
    ...standardResults,
    dependencies: dependencyResult,
  };
  
  // Generate summary
  const summary = generateSummary(standardResults);
  
  // Display audit results summary
  console.log(`\n${colors.bold}Audit Results:${colors.reset}\n`);
  
  // Display dependency audit first
  if (dependencyResult.error) {
    console.log(`  ${colors.red}❌ Dependency Audit: Error - ${dependencyResult.error}${colors.reset}`);
  } else {
    const depIssues = dependencyResult.issues || {};
    const depCount = (depIssues.includedDeps?.length || 0) +
                     (depIssues.missingRequired?.length || 0) +
                     (depIssues.versionIssues?.length || 0) +
                     (depIssues.wrongLocation?.length || 0) +
                     (depIssues.missingDevDeps?.length || 0) +
                     (depIssues.devVersionIssues?.length || 0);
    
    if (depCount === 0) {
      console.log(`  ${colors.green}✅ Dependency Audit: 0 issues${colors.reset}`);
    } else {
      console.log(`  ${colors.red}❌ Dependency Audit: ${depCount} issue(s)${colors.reset}`);
    }
  }
  
  // Display each standard
  Object.entries(standardResults).forEach(([key, result]) => {
    const name = STANDARD_META[key]?.name || key;
    const issues = Array.isArray(result.issues) ? result.issues : Object.values(result.issues || {}).flat();
    const count = issues.length;
    
    if (count === 0) {
      console.log(`  ${colors.green}✅ ${name}: 0 issues${colors.reset}`);
    } else {
      console.log(`  ${colors.red}❌ ${name}: ${count} issue(s)${colors.reset}`);
    }
  });
  
  // Total summary
  const totalIssues = summary.total + (dependencyResult.error ? 0 : 
    ((dependencyResult.issues?.includedDeps?.length || 0) +
     (dependencyResult.issues?.missingRequired?.length || 0) +
     (dependencyResult.issues?.versionIssues?.length || 0) +
     (dependencyResult.issues?.wrongLocation?.length || 0) +
     (dependencyResult.issues?.missingDevDeps?.length || 0) +
     (dependencyResult.issues?.devVersionIssues?.length || 0)));
  
  console.log(
    `${colors.bold}Severity Totals:${colors.reset} ` +
    `${colors.red}error=${summary.bySeverity.error}${colors.reset}, ` +
    `${colors.yellow}warning=${summary.bySeverity.warning}${colors.reset}, ` +
    `${colors.blue}info=${summary.bySeverity.info}${colors.reset}`
  );
  console.log(`\n${colors.bold}Total Issues: ${totalIssues === 0 ? colors.green + '0 (All checks passed!)' : colors.red + totalIssues}${colors.reset}\n`);
  
  // Exit behavior is severity-aware; dependency audit issues are treated as blocking errors.
  let blockingIssues = 0;
  Object.values(standardResults).forEach((result) => {
    const issues = Array.isArray(result.issues) ? result.issues : Object.values(result.issues || {}).flat();
    issues.forEach((issue) => {
      if (issueBlocks(issue, maxSeverity)) blockingIssues++;
    });
  });

  const dependencyIssueCount = dependencyResult.error ? 0 :
    ((dependencyResult.issues?.includedDeps?.length || 0) +
      (dependencyResult.issues?.missingRequired?.length || 0) +
      (dependencyResult.issues?.versionIssues?.length || 0) +
      (dependencyResult.issues?.wrongLocation?.length || 0) +
      (dependencyResult.issues?.missingDevDeps?.length || 0) +
      (dependencyResult.issues?.devVersionIssues?.length || 0));
  blockingIssues += dependencyIssueCount;

  const forceWriteReport = process.env.PACE_VALIDATE_WRITE_REPORTS === '1';
  const shouldWriteReport = outputPath && (blockingIssues > 0 || forceWriteReport);

  // Generate and save markdown report when issues exist (or when PACE_VALIDATE_WRITE_REPORTS=1).
  if (shouldWriteReport) {
    const markdownReport = generateMarkdownReport(standardResults, consumingAppPath, dependencyResult);

    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const timestamp = `${year}${month}${day}${hours}${minutes}`;

    function addTimestampToFilename(filePath) {
      const dir = path.dirname(filePath);
      const ext = path.extname(filePath);
      const name = path.basename(filePath, ext);
      return path.join(dir, `${timestamp}-${name}${ext}`);
    }

    const auditBasePath = resolveAuditBasePath(consumingAppPath, isPaceCorePackage);
    const outputAbsolutePath = path.isAbsolute(outputPath)
      ? outputPath
      : path.join(auditBasePath, outputPath);
    const outputDir = path.dirname(outputAbsolutePath);
    if (!fs.existsSync(outputDir)) {
      fs.mkdirSync(outputDir, { recursive: true });
    }
    const reportPath = addTimestampToFilename(outputAbsolutePath);
    fs.writeFileSync(reportPath, markdownReport, 'utf8');
    const relativeReportPath = path.relative(process.cwd(), reportPath);
    console.log(`${colors.bold}Report saved to:${colors.reset} ${colors.cyan}${relativeReportPath}${colors.reset}\n`);
  }

  if (blockingIssues > 0) {
    console.log(`${colors.red}Failing due to ${blockingIssues} blocking issue(s) at threshold "${maxSeverity}".${colors.reset}`);
  } else {
    console.log(`${colors.green}No blocking issues at threshold "${maxSeverity}".${colors.reset}`);
  }
  process.exit(blockingIssues > 0 ? 1 : 0);
}

// Export for programmatic usage
module.exports = {
  runAudit: main,
  runAllAudits,
  runStandardAudit: (standardNumber, consumingAppPath) => {
    const auditFunctions = {
      '1': runStandard1Audit,
      '2': runStandard2Audit,
      '3': runStandard3Audit,
      '4': runStandard4Audit,
      '5': runStandard5Audit,
      '6': runStandard6Audit,
      '7': runStandard7Audit,
      '8': runStandard8Audit,
      '9': runStandard9Audit,
    };
    
    const fn = auditFunctions[standardNumber];
    if (!fn) {
      throw new Error(`Invalid standard number: ${standardNumber}. Must be 1-9.`);
    }
    
    return fn(consumingAppPath);
  },
};

// Run if called directly
if (require.main === module) {
  main();
}
