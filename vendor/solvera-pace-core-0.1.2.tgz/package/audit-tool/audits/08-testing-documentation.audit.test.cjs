#!/usr/bin/env node
/**
 * Unit tests for Standard 8 tiered Vitest audit checks.
 */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { test } = require('node:test');
const {
  parseDomUnitTestTsFiles,
  checkTestTierScripts,
  checkTestSetupFiles,
  checkPreferSetupUser,
  checkDomInWrongTier,
} = require('./08-testing-documentation.cjs');

function makeTempDir() {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'pace-s8-audit-'));
}

function write(filePath, content) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, content, 'utf8');
}

test('parseDomUnitTestTsFiles extracts quoted paths', () => {
  const content = `export const domUnitTestTsFiles = [
    'src/hooks/useFoo.test.ts',
    // Example: 'src/hooks/useBar.test.ts',
  ];`;
  assert.deepEqual(parseDomUnitTestTsFiles(content), ['src/hooks/useFoo.test.ts']);
});

test('checkTestTierScripts reports missing scripts', () => {
  const dir = makeTempDir();
  write(path.join(dir, 'package.json'), JSON.stringify({ scripts: {} }, null, 2));
  const issues = checkTestTierScripts(dir);
  assert.ok(issues.some((i) => i.type === 'testTierScripts'));
  fs.rmSync(dir, { recursive: true, force: true });
});

test('checkTestSetupFiles reports missing setup files', () => {
  const dir = makeTempDir();
  const issues = checkTestSetupFiles(dir);
  assert.ok(issues.some((i) => i.type === 'testSetupFiles'));
  fs.rmSync(dir, { recursive: true, force: true });
});

test('checkPreferSetupUser flags bare userEvent.setup()', () => {
  const dir = makeTempDir();
  write(
    path.join(dir, 'src', 'Button.test.tsx'),
    `import userEvent from '@testing-library/user-event';
     it('x', () => { userEvent.setup(); });`
  );
  const issues = checkPreferSetupUser(dir);
  assert.ok(issues.some((i) => i.type === 'preferSetupUser'));
  fs.rmSync(dir, { recursive: true, force: true });
});

test('checkDomInWrongTier flags DOM usage in unlisted .test.ts', () => {
  const dir = makeTempDir();
  write(path.join(dir, 'vitest.shared.ts'), 'export const domUnitTestTsFiles = [];');
  write(
    path.join(dir, 'src', 'useHook.test.ts'),
    `import { renderHook } from '@testing-library/react';`
  );
  const issues = checkDomInWrongTier(dir);
  assert.ok(issues.some((i) => i.type === 'domInWrongTier'));
  fs.rmSync(dir, { recursive: true, force: true });
});
