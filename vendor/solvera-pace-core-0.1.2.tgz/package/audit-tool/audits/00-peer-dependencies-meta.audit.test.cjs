#!/usr/bin/env node
/**
 * Regression test: @solvera/pace-core peerDependenciesMeta completeness.
 */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { test } = require('node:test');
const { validatePeerDependenciesMeta } = require('../../scripts/peer-dependencies-meta-policy.cjs');

const packageJsonPath = path.resolve(__dirname, '../../package.json');

test('pace-core package.json lists peerDependenciesMeta for every peerDependency', () => {
  const pkg = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'));
  const result = validatePeerDependenciesMeta(
    pkg.peerDependencies || {},
    pkg.peerDependenciesMeta || {}
  );

  assert.equal(result.ok, true, result.errors.join('; '));
});
