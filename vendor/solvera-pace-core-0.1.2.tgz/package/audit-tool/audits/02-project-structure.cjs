/**
 * Standard 2: Project Structure Audit
 * @package @solvera/pace-core
 * @module Audit/Standard2
 * 
 * Audits consuming apps for compliance with Standard 2: Project Structure.
 * Validates directory structure, file organization, and naming conventions.
 * 
 * Reference: packages/core/docs/standards/1-project-structure-standards.md
 */

const fs = require('fs');
const path = require('path');
const { directoryExists, fileExists, findConfigFiles, readFileSafe, getRelativePath, findSourceFiles } = require('../utils/file-utils.cjs');
const {
  isPageFileName,
  isKebabPublicAssetFilename,
  validateRoutePath,
  collectPageNameIssuesFromSource,
  collectAppNameFromSource,
  collectAppPublicLogoIssues,
} = require('../../naming/naming-by-layer.cjs');

/**
 * Check standard directory structure
 * @param {string} consumingAppPath
 * @param {boolean} isPaceCorePackage - When true, skip consuming-app-only requirements (public/fonts, public/logos, .cursor)
 */
function checkDirectoryStructure(consumingAppPath, isPaceCorePackage = false) {
  const issues = [];
  
  // Required directories (aligned with 1-project-structure-standards.md); consuming-app-only items skipped when isPaceCorePackage
  const requiredDirs = [
    { path: 'src', required: true, description: 'Source code directory' },
    { path: 'src/components', required: false, description: 'App-specific components' },
    { path: 'src/hooks', required: false, description: 'App-specific hooks' },
    { path: 'src/pages', required: false, description: 'Page components' },
    { path: 'src/utils', required: false, description: 'App-specific utility functions' },
    { path: 'src/lib', required: false, description: 'Base Supabase client only' },
    { path: 'public', required: !isPaceCorePackage, description: 'Static assets' },
    { path: 'public/fonts', required: !isPaceCorePackage, description: 'App fonts (.woff2)' },
    { path: 'public/logos', required: !isPaceCorePackage, description: 'App logos' },
    { path: '.cursor', required: !isPaceCorePackage, description: 'Cursor rules and MCP config' },
  ];
  
  requiredDirs.forEach(({ path: dirPath, required, description }) => {
    const fullPath = path.join(consumingAppPath, dirPath);
    const exists = directoryExists(fullPath);
    
    if (required && !exists) {
      issues.push({
        type: 'directoryStructure',
        file: dirPath,
        line: 0,
        message: `Required directory missing: ${dirPath} (${description})`,
        severity: 'error',
        fix: `Create ${dirPath}/ directory`,
        standardSection: 'Standard Directory Structure',
      });
    }
  });
  
  return issues;
}

/**
 * Check for required configuration files
 * @param {string} consumingAppPath
 * @param {boolean} isPaceCorePackage - When true, skip .env / .env.example (consuming-app-only)
 */
function checkConfigFiles(consumingAppPath, isPaceCorePackage = false) {
  const issues = [];
  
  const requiredConfigs = [
    { name: 'package.json', required: true, description: 'Package configuration' },
    { name: 'tsconfig.json', required: false, description: 'TypeScript configuration' },
    { name: 'vite.config.ts', required: false, description: 'Vite configuration' },
    { name: '.env', required: !isPaceCorePackage, description: 'Local environment variables' },
    { name: '.env.example', required: !isPaceCorePackage, description: 'Template for required env vars' },
  ];
  
  requiredConfigs.forEach(({ name, required, description }) => {
    const configFiles = findConfigFiles(consumingAppPath, [name]);
    const configPath = configFiles[name];
    
    if (required && !configPath) {
      issues.push({
        type: 'configFiles',
        file: name,
        line: 0,
        message: `Required configuration file missing: ${name} (${description})`,
        severity: 'error',
        fix: `Create ${name} file`,
        standardSection: 'Configuration Files',
      });
    }
  });
  
  return issues;
}

/**
 * Check import path configuration in tsconfig.json
 */
function checkImportPaths(consumingAppPath) {
  const issues = [];
  
  const tsconfigFiles = findConfigFiles(consumingAppPath, ['tsconfig.json']);
  const tsconfigPath = tsconfigFiles['tsconfig.json'];
  
  if (!tsconfigPath) {
    return issues; // No tsconfig, skip check
  }
  
  const content = readFileSafe(tsconfigPath);
  if (!content) {
    return issues;
  }
  
  // Try to parse as JSON (might be JSON with comments)
  let config;
  try {
    // Remove comments for JSON parsing
    const jsonContent = content.replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*/g, '');
    config = JSON.parse(jsonContent);
  } catch (error) {
    // Not valid JSON, might be JSONC - skip detailed checks
    return issues;
  }
  
  const relativePath = getRelativePath(tsconfigPath, consumingAppPath);
  
  // Check for paths configuration (recommended but not required)
  if (!config.compilerOptions?.paths) {
    issues.push({
      type: 'importPaths',
      file: relativePath,
      line: 1,
      message: 'tsconfig.json missing paths configuration. Consider adding path aliases for cleaner imports.',
      severity: 'info',
      fix: 'Add paths configuration: { "compilerOptions": { "paths": { "@/*": ["./src/*"] } } }',
      standardSection: 'Import Path Configuration',
    });
  }
  
  return issues;
}

/**
 * Check test file colocation
 * Only flags tests that are in the wrong location (e.g., in __tests__/ when they should be colocated).
 * Does not flag missing test files - use test coverage tools for that.
 */
function checkTestColocation(consumingAppPath) {
  const issues = [];
  
  const srcDir = path.join(consumingAppPath, 'src');
  if (!directoryExists(srcDir)) {
    return issues;
  }
  
  // Find all test files
  const testFiles = [];
  function findTestFiles(dir) {
    if (!fs.existsSync(dir)) return;
    
    const files = fs.readdirSync(dir);
    files.forEach(file => {
      const filePath = path.join(dir, file);
      const stat = fs.statSync(filePath);
      
      if (stat.isDirectory()) {
        if (!['node_modules', 'dist', 'build', '.git'].includes(file)) {
          findTestFiles(filePath);
        }
      } else if (/\.(ts|tsx|js|jsx)$/.test(file) && (file.includes('.test.') || file.includes('.spec.'))) {
        testFiles.push(filePath);
      }
    });
  }
  
  findTestFiles(srcDir);
  
  // Check if test files are in the wrong location
  testFiles.forEach(testFile => {
    const testDir = path.dirname(testFile);
    const testBasename = path.basename(testFile);
    
    // Extract the source file name from the test file name
    // e.g., "Component.test.tsx" -> "Component.tsx"
    const sourceBasename = testBasename.replace(/\.(test|spec)\./, '.');
    const sourceFile = path.join(testDir, sourceBasename);
    
    // Check if test is in a __tests__ or tests directory
    const isInTestDirectory = testDir.includes('/__tests__/') || testDir.includes('/tests/') || 
                               testDir.endsWith('/__tests__') || testDir.endsWith('/tests');
    
    // If test is in a test directory, check if the source file exists in the parent directory
    if (isInTestDirectory) {
      // Get the parent directory (should be where the source file is)
      const parentDir = path.dirname(testDir);
      const expectedSourceFile = path.join(parentDir, sourceBasename);
      
      // If source file exists in parent, flag that test should be colocated
      if (fileExists(expectedSourceFile)) {
        const relativePath = getRelativePath(testFile, consumingAppPath);
        issues.push({
          type: 'testColocation',
          file: relativePath,
          line: 1,
          message: `Test file is in a test directory but should be colocated with source file. Move to ${parentDir}`,
          severity: 'warning',
          fix: `Move test file to ${parentDir} to colocate with source file`,
          standardSection: 'Testing Structure (Test Colocation)',
        });
      }
    }
  });
  
  return issues;
}

/**
 * Check for domain-based organization (Pattern 2 - not allowed)
 * Feature-based organization is the only standard
 */
function checkFeatureBasedOrganization(consumingAppPath) {
  const issues = [];
  
  const srcDir = path.join(consumingAppPath, 'src');
  if (!directoryExists(srcDir)) {
    return issues;
  }
  
  // Check for src/domains/ directory (Pattern 2 structure - not allowed)
  const domainsDir = path.join(srcDir, 'domains');
  if (directoryExists(domainsDir)) {
    issues.push({
      type: 'organizationPattern',
      file: 'src/domains',
      line: 0,
      message: 'Domain-based organization (src/domains/) is not allowed. Use feature-based organization instead (src/components/[feature]/, src/hooks/[feature]/, etc.)',
      severity: 'error',
      fix: 'Reorganize to feature-based structure: move components from src/domains/[domain]/components/ to src/components/[domain]/, hooks to src/hooks/[domain]/, etc.',
      standardSection: 'Component Organization / File Organization Standard',
    });
  }
  
  // Check components directory for type-based organization (anti-pattern)
  const componentsDir = path.join(srcDir, 'components');
  if (directoryExists(componentsDir)) {
    const componentDirs = [];
    function scanComponentsDir(dir) {
      if (!fs.existsSync(dir)) return;
      const entries = fs.readdirSync(dir);
      entries.forEach(entry => {
        const entryPath = path.join(dir, entry);
        const stat = fs.statSync(entryPath);
        if (stat.isDirectory()) {
          componentDirs.push(entry);
        }
      });
    }
    scanComponentsDir(componentsDir);
    
    // Common type-based directory names that should not exist
    const typeBasedPatterns = ['buttons', 'button', 'inputs', 'input', 'cards', 'card', 'forms', 'form', 'modals', 'modal', 'dialogs', 'dialog'];
    const foundTypeBased = componentDirs.filter(dir => typeBasedPatterns.includes(dir.toLowerCase()));
    
    if (foundTypeBased.length > 0) {
      issues.push({
        type: 'organizationPattern',
        file: `src/components/${foundTypeBased[0]}`,
        line: 0,
        message: `Components organized by type (${foundTypeBased.join(', ')}) instead of feature. Use pace-core components for UI primitives and organize app components by feature.`,
        severity: 'error',
        fix: `Reorganize components by feature. Use pace-core for ${foundTypeBased.join(', ')} components. Move feature-specific components to src/components/[feature]/`,
        standardSection: 'Component Organization / File Organization Standard',
      });
    }
  }
  
  return issues;
}

/**
 * Check .cursor/mcp.json exists (required by 1-project-structure-standards.md; consuming apps only)
 */
function checkCursorMcp(consumingAppPath, isPaceCorePackage = false) {
  const issues = [];
  if (isPaceCorePackage) return issues;
  const mcpPath = path.join(consumingAppPath, '.cursor', 'mcp.json');
  if (!fileExists(mcpPath)) {
    issues.push({
      type: 'configFiles',
      file: '.cursor/mcp.json',
      line: 0,
      message: 'Required file missing: .cursor/mcp.json (MCP server configuration)',
      severity: 'error',
      fix: 'Create .cursor/mcp.json',
      standardSection: 'Standard Directory Structure',
    });
  }
  return issues;
}

/**
 * Check Supabase structure: consuming apps MUST NOT have supabase/migrations (migrations only in pace-core)
 */
function checkSupabaseStructure(consumingAppPath, isPaceCorePackage) {
  const issues = [];
  if (isPaceCorePackage) {
    return issues;
  }
  const migrationsDir = path.join(consumingAppPath, 'supabase', 'migrations');
  if (directoryExists(migrationsDir)) {
    issues.push({
      type: 'directoryStructure',
      file: 'supabase/migrations',
      line: 0,
      message: 'Consuming apps MUST NOT have supabase/migrations/. All database migrations are managed only in pace-core.',
      severity: 'error',
      fix: 'Remove supabase/migrations/; use existing Supabase schema. Migrations are managed in pace-core.',
      standardSection: 'Database & Supabase Structure (Migrations)',
    });
  }
  return issues;
}

/**
 * Run audit for Standard 2: Project Structure
 * @param {string} consumingAppPath - Path to consuming app
 * @param {{ isPaceCorePackage?: boolean }} [auditContext] - When isPaceCorePackage, skip organizationPattern (library organizes by type by design)
 * @returns {object} - Audit results with issues array
 */
const PACE_CORE_COMPONENT_FOLDERS = new Set([
  'primitives',
  'overlays',
  'shell',
  'forms-feedback',
  'auth',
  'advanced-ui',
  'data-table',
  'public-layout',
]);

function checkPaceCoreComponentLayout(consumingAppPath) {
  const issues = [];
  const componentsDir = path.join(consumingAppPath, 'src', 'components');
  if (!directoryExists(componentsDir)) return issues;

  for (const entry of fs.readdirSync(componentsDir, { withFileTypes: true })) {
    if (entry.isFile() && entry.name.endsWith('.tsx')) {
      issues.push({
        type: 'componentFolderLayout',
        file: `src/components/${entry.name}`,
        line: 0,
        message: 'pace-core components must live in feature folders, not the components root.',
        severity: 'error',
        fix: 'Move the component into the appropriate feature folder under src/components/.',
        standardSection: 'pace-core package component layout',
      });
    }
    if (entry.isDirectory() && !PACE_CORE_COMPONENT_FOLDERS.has(entry.name)) {
      issues.push({
        type: 'componentFolderLayout',
        file: `src/components/${entry.name}/`,
        line: 0,
        message: `Disallowed top-level components folder: ${entry.name}/`,
        severity: 'error',
        fix: 'Use an allowed feature folder (primitives, overlays, shell, forms-feedback, auth, advanced-ui, data-table, public-layout).',
        standardSection: 'pace-core package component layout',
      });
    }
  }

  for (const legacy of ['DataTable', 'PublicLayout', 'select-internal']) {
    if (directoryExists(path.join(componentsDir, legacy))) {
      issues.push({
        type: 'componentFolderLayout',
        file: `src/components/${legacy}/`,
        line: 0,
        message: `Legacy components folder must be removed: ${legacy}/`,
        severity: 'error',
        fix: 'Rename or migrate to the kebab-case feature folder and delete the legacy path.',
        standardSection: 'pace-core package component layout',
      });
    }
  }

  return issues;
}

const ROUTER_FILE_PATTERN = /(?:App|routes?|Router)\.(tsx?|jsx?)$/i;

function isRouterSourceFile(relativePath) {
  return ROUTER_FILE_PATTERN.test(relativePath) || relativePath.includes('/routes/');
}

function isExemptPagesDirectoryModule(filename) {
  return /(?:Routes|Placeholders)\.tsx$/i.test(filename) || /^index\.tsx$/i.test(filename);
}

function checkNamingByLayer(consumingAppPath, isPaceCorePackage = false) {
  const issues = [];
  const srcDir = path.join(consumingAppPath, 'src');
  if (!directoryExists(srcDir)) {
    return issues;
  }

  const pagesDir = path.join(srcDir, 'pages');
  if (directoryExists(pagesDir)) {
    function walkPages(dir) {
      for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
        const full = path.join(dir, entry.name);
        if (entry.isDirectory()) {
          walkPages(full);
        } else if (/\.tsx$/.test(entry.name) && !/\.(test|spec)\./.test(entry.name)) {
          if (!isPageFileName(entry.name) && !isExemptPagesDirectoryModule(entry.name)) {
            const rel = getRelativePath(full, consumingAppPath);
            issues.push({
              type: 'namingByLayer',
              file: rel,
              line: 0,
              message: `Page module "${entry.name}" must be PascalCase with Page suffix (e.g. EventsPage.tsx)`,
              severity: isPaceCorePackage ? 'warning' : 'error',
              fix: 'Rename to PascalCasePage.tsx — do not kebab-case React filenames for URL alignment',
              standardSection: 'Naming by layer (Page modules)',
            });
          }
        }
      }
    }
    walkPages(pagesDir);
  }

  const publicDir = path.join(consumingAppPath, 'public');
  if (!isPaceCorePackage && directoryExists(publicDir)) {
    function walkPublic(dir) {
      for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
        const full = path.join(dir, entry.name);
        if (entry.isDirectory()) {
          walkPublic(full);
        } else if (!isKebabPublicAssetFilename(entry.name)) {
          const rel = getRelativePath(full, consumingAppPath);
          issues.push({
            type: 'namingByLayer',
            file: rel,
            line: 0,
            message: `Public asset "${entry.name}" should use kebab-case filename`,
            severity: 'error',
            fix: 'Rename asset to kebab-case (e.g. org-logo.svg)',
            standardSection: 'Naming by layer (Static assets)',
          });
        }
      }
    }
    walkPublic(publicDir);
  }

  if (!isPaceCorePackage) {
    const appName = collectAppNameFromSource(srcDir, fs);
    const logosDir = path.join(consumingAppPath, 'public', 'logos');
    if (appName) {
      const logoIssues = collectAppPublicLogoIssues(logosDir, appName, { fsModule: fs });
      for (const issue of logoIssues) {
        issues.push({
          type: 'namingByLayer',
          file: issue.file || 'public/logos',
          line: 0,
          message: issue.message,
          severity: issue.severity,
          fix: issue.fix,
          standardSection: 'Naming by layer (App public logos)',
        });
      }
    }
  }

  const sourceFiles = findSourceFiles(srcDir);
  const jsxRoutePathPattern = /<Route[^>]*\spath\s*=\s*["']([^"']+)["']/g;
  const staticHrefPattern = /href\s*:\s*['"]([^'"]+)['"]/g;

  for (const filePath of sourceFiles) {
    const relativePath = getRelativePath(filePath, consumingAppPath);
    const content = readFileSafe(filePath);
    if (!content) continue;

    if (isRouterSourceFile(relativePath)) {
      for (const pattern of [jsxRoutePathPattern, staticHrefPattern]) {
        pattern.lastIndex = 0;
        let routeMatch;
        while ((routeMatch = pattern.exec(content)) !== null) {
          const routePath = routeMatch[1].trim();
          if (!routePath || routePath.includes('${') || routePath.includes('.')) continue;
          const validation = validateRoutePath(routePath);
          if (!validation.ok) {
            issues.push({
              type: 'namingByLayer',
              file: relativePath,
              line: 1,
              message: validation.message,
              severity: 'error',
              fix: 'Use lowercase kebab-case static route segments; no underscores in app paths',
              standardSection: 'Naming by layer (Routes and browser URLs)',
            });
          }
        }
      }
    }

    const fileStem = /\/pages\//.test(relativePath)
      ? path.basename(relativePath).replace(/\.(tsx?|jsx?)$/, '')
      : undefined;
    const pageNameIssues = collectPageNameIssuesFromSource(content, {
      fileStem: fileStem && /Page$/.test(fileStem) ? fileStem : undefined,
      legacyMode: 'allow-warn',
      relativePath,
      skipTestFiles: /\.(?:test|spec)\./.test(relativePath),
    });
    for (const issue of pageNameIssues) {
      issues.push({
        type: issue.type === 'legacyPageName' ? 'legacyPageName' : 'namingByLayer',
        file: relativePath,
        line: 1,
        message: issue.message,
        severity: issue.severity,
        fix: issue.migrationTarget
          ? `Migrate to pageName="${issue.migrationTarget}"`
          : 'Use PascalCase pageName matching page file stem',
        standardSection: issue.type === 'legacyPageName'
          ? 'Legacy RBAC page names'
          : 'Naming by layer (RBAC page catalogue vs routes)',
      });
    }
  }

  return issues;
}

function checkInternalExportLeak(consumingAppPath) {
  const issues = [];
  const indexPath = path.join(consumingAppPath, 'src', 'components', 'index.ts');
  if (!fs.existsSync(indexPath)) return issues;

  const content = fs.readFileSync(indexPath, 'utf8');
  const internalExportPattern = /from\s+['"][^'"]*\/internal\//;
  if (internalExportPattern.test(content)) {
    issues.push({
      type: 'internalExportLeak',
      file: 'src/components/index.ts',
      line: 0,
      message: 'Internal component modules must not be re-exported from the public components barrel.',
      severity: 'error',
      fix: 'Remove exports that reference /internal/ paths; keep internal modules private to their feature folder.',
      standardSection: 'pace-core package component layout',
    });
  }

  return issues;
}

function runStandard2Audit(consumingAppPath, auditContext = {}) {
  const issues = [];
  const isPaceCorePackage = auditContext.isPaceCorePackage === true;

  try {
    if (isPaceCorePackage) {
      issues.push(...checkPaceCoreComponentLayout(consumingAppPath));
      issues.push(...checkInternalExportLeak(consumingAppPath));
    }
    issues.push(...checkDirectoryStructure(consumingAppPath, isPaceCorePackage));
    issues.push(...checkConfigFiles(consumingAppPath, isPaceCorePackage));
    issues.push(...checkCursorMcp(consumingAppPath, isPaceCorePackage));
    issues.push(...checkImportPaths(consumingAppPath));
    issues.push(...checkTestColocation(consumingAppPath));
    if (!isPaceCorePackage) {
      issues.push(...checkFeatureBasedOrganization(consumingAppPath));
      issues.push(...checkNamingByLayer(consumingAppPath, false));
    } else {
      issues.push(...checkNamingByLayer(consumingAppPath, true));
    }
    issues.push(...checkSupabaseStructure(consumingAppPath, isPaceCorePackage));
  } catch (error) {
    return {
      standard: '01-project-structure',
      issues: [],
      error: error.message,
    };
  }
  
  return {
    standard: '01-project-structure',
    issues,
    error: null,
  };
}

module.exports = {
  runStandard2Audit,
  checkPaceCoreComponentLayout,
  checkInternalExportLeak,
};
