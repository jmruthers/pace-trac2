/**
 * Standard 4: Code Quality Audit
 * @package @solvera/pace-core
 * @module Audit/Standard4
 * 
 * Audits consuming apps for compliance with Standard 4: Code Quality.
 * Focuses on system-level checks (TypeScript config, test coverage config).
 * File-level checks (any types, naming) are handled by ESLint.
 * 
 * Reference: packages/core/docs/standards/6-code-quality-standards.md
 */

const path = require('path');
const { findConfigFiles, readFileSafe, getRelativePath, findSourceFiles } = require('../utils/file-utils.cjs');
const { getLineNumber, isInCommentOrString } = require('../utils/code-utils.cjs');

/**
 * Check TypeScript configuration
 */
function checkTypeScriptConfig(consumingAppPath) {
  const issues = [];
  
  const tsconfigFiles = findConfigFiles(consumingAppPath, ['tsconfig.json']);
  const tsconfigPath = tsconfigFiles['tsconfig.json'];
  
  if (!tsconfigPath) {
    issues.push({
      type: 'typescriptConfig',
      file: 'tsconfig.json (not found)',
      line: 0,
      message: 'tsconfig.json not found. TypeScript strict mode must be enabled.',
      severity: 'error',
      fix: 'Create tsconfig.json with "strict": true in compilerOptions.',
      standardSection: 'TypeScript Rules (Avoid Implicit any / tsconfig)',
    });
    return issues;
  }
  
  const content = readFileSafe(tsconfigPath);
  if (!content) {
    return issues;
  }
  
  // Try to parse as JSON (might be JSON with comments)
  let config;
  try {
    // Remove comments for JSON parsing
    const jsonContent = content.replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*/g, '');
    config = JSON.parse(jsonContent);
  } catch (error) {
    // Not valid JSON, might be JSONC - skip detailed checks
    return issues;
  }
  
  const relativePath = getRelativePath(tsconfigPath, consumingAppPath);
  const compilerOptions = config.compilerOptions || {};
  
  // Check for strict mode
  if (compilerOptions.strict !== true) {
    issues.push({
      type: 'typescriptConfig',
      file: relativePath,
      line: 1,
      message: 'TypeScript strict mode not enabled. Must set "strict": true in compilerOptions.',
      severity: 'error',
      fix: 'Set "strict": true in tsconfig.json compilerOptions.',
      standardSection: 'TypeScript Rules (tsconfig strict mode)',
    });
  }

  // Check for noImplicitAny
  if (compilerOptions.noImplicitAny !== true && compilerOptions.strict !== true) {
    issues.push({
      type: 'typescriptConfig',
      file: relativePath,
      line: 1,
      message: 'noImplicitAny not enabled. Should set "noImplicitAny": true in compilerOptions (or enable strict mode).',
      severity: 'error',
      fix: 'Set "noImplicitAny": true in tsconfig.json compilerOptions (or enable strict mode).',
      standardSection: 'TypeScript Rules (Avoid Implicit any)',
    });
  }
  
  return issues;
}

/**
 * Check test coverage configuration
 */
function checkTestCoverageConfig(consumingAppPath) {
  const issues = [];
  
  const vitestConfigFiles = findConfigFiles(consumingAppPath, ['vitest.config.ts', 'vitest.config.js']);
  const vitestConfigPath = vitestConfigFiles['vitest.config.ts'] || vitestConfigFiles['vitest.config.js'];
  
  // Also check package.json for test scripts
  const packageJsonPath = path.join(consumingAppPath, 'package.json');
  const packageJsonContent = readFileSafe(packageJsonPath);
  
  if (!vitestConfigPath && !packageJsonContent) {
    return issues; // No test config found, skip
  }
  
  // Check vitest.config.ts for coverage settings
  if (vitestConfigPath) {
    const content = readFileSafe(vitestConfigPath);
    if (content) {
      const hasCoverageConfig = /coverage\s*[:=]/.test(content);
      const coverageUnderTest = /test\s*:\s*\{[\s\S]*?coverage\s*:/.test(content);
      const relativePath = getRelativePath(vitestConfigPath, consumingAppPath);
      if (!hasCoverageConfig) {
        issues.push({
          type: 'testCoverage',
          file: relativePath,
          line: 1,
          message: 'vitest.config.ts missing coverage configuration. Consider adding coverage under test.coverage.',
          severity: 'info',
          fix: 'Add test.coverage with provider "istanbul", include/exclude, and thresholds. See Standard 8 (Coverage setup).',
          standardSection: 'Test coverage config (see Testing standard)',
        });
      } else if (!coverageUnderTest) {
        issues.push({
          type: 'testCoverage',
          file: relativePath,
          line: 1,
          message: 'Coverage must be under test.coverage in vitest.config.ts (Vitest reads it there). Move coverage block inside test: { }.',
          severity: 'warn',
          fix: 'Move coverage configuration inside test: { coverage: { provider: "istanbul", ... } }. See Standard 8.',
          standardSection: 'Test coverage config (see Testing standard)',
        });
      }
    }
  }
  
  return issues;
}

/**
 * Check for excessive console logging in production code
 */
function checkConsoleLogging(consumingAppPath) {
  const issues = [];
  
  const srcDir = path.join(consumingAppPath, 'src');
  if (!require('fs').existsSync(srcDir)) {
    return issues;
  }
  
  const sourceFiles = findSourceFiles(srcDir).filter(file => {
    // Skip test files
    const isTestFile = file.includes('.test.') || 
                       file.includes('.spec.') || 
                       file.includes('/test/') || 
                       file.includes('/tests/') ||
                       file.includes('__tests__') ||
                       file.includes('__test__') ||
                       path.basename(file, path.extname(file)).toLowerCase().startsWith('test');
    
    return !isTestFile;
  });
  
  sourceFiles.forEach(filePath => {
    const content = readFileSafe(filePath);
    if (!content) {
      return;
    }
    
    const relativePath = getRelativePath(filePath, consumingAppPath);
    
    // Count console.log, console.debug, console.warn, console.error statements
    const consolePatterns = [
      { pattern: /console\.(log|debug)\s*\(/gi, name: 'console.log/debug', threshold: 3 },
      { pattern: /console\.warn\s*\(/gi, name: 'console.warn', threshold: 5 },
      { pattern: /console\.error\s*\(/gi, name: 'console.error', threshold: 10 }, // Errors are usually OK
    ];
    
    consolePatterns.forEach(({ pattern, name, threshold }) => {
      const matches = [...content.matchAll(pattern)];
      const validMatches = matches.filter(match => {
        const index = match.index;
        return !isInCommentOrString(content, index);
      });
      
      if (validMatches.length > threshold) {
        const firstMatch = validMatches[0];
        issues.push({
          type: 'excessiveConsoleLogging',
          file: relativePath,
          line: getLineNumber(content, firstMatch.index),
          message: `Excessive ${name} usage detected (${validMatches.length} instances). Consider removing debug logs or using a proper logging library.`,
          severity: 'warning',
          fix: `Remove or replace ${name} statements. Use a logging library or remove debug logs before production.`,
          standardSection: 'Forbidden Patterns / code hygiene',
        });
      }
    });
    
    // Special check for DEBUG logging (common pattern)
    const debugLogPattern = /console\.(log|debug)\s*\(\s*['"`]\[DEBUG\]/gi;
    const debugMatches = [...content.matchAll(debugLogPattern)];
    const validDebugMatches = debugMatches.filter(match => {
      const index = match.index;
      return !isInCommentOrString(content, index);
    });
    
    if (validDebugMatches.length > 0) {
      const firstMatch = validDebugMatches[0];
      issues.push({
        type: 'debugConsoleLogging',
        file: relativePath,
        line: getLineNumber(content, firstMatch.index),
        message: `Debug console logging detected (${validDebugMatches.length} instances). Debug logs should be removed or disabled in production.`,
        severity: 'warning',
        fix: 'Remove debug console.log statements or use environment-based logging that can be disabled in production.',
        standardSection: 'Forbidden Patterns / code hygiene',
      });
    }
  });
  
  return issues;
}

/**
 * Run audit for Standard 4: Code Quality
 * @param {string} consumingAppPath - Path to consuming app
 * @param {{ isPaceCorePackage?: boolean }} [auditContext] - Optional context (unused)
 * @returns {object} - Audit results with issues array
 */
function runStandard4Audit(consumingAppPath, auditContext = {}) {
  const issues = [];
  
  try {
    issues.push(...checkTypeScriptConfig(consumingAppPath));
    issues.push(...checkTestCoverageConfig(consumingAppPath));
    issues.push(...checkConsoleLogging(consumingAppPath));
  } catch (error) {
    return {
      standard: '06-code-quality',
      issues: [],
      error: error.message,
    };
  }
  
  return {
    standard: '06-code-quality',
    issues,
    error: null,
  };
}

module.exports = { runStandard4Audit };
