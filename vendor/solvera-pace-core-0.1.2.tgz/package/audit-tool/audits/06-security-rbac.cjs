/**
 * Standard 6: Security & RBAC Audit
 * @package @solvera/pace-core
 * @module Audit/Standard6
 *
 * Audits consuming apps for compliance with Standard 6: Security & RBAC.
 * Validates RLS policy patterns in migration SQL plus PagePermissionGuard coverage
 * and Edge Functions RBAC wiring.
 *
 * Reference: packages/core/docs/standards/3-security-rbac-standards.md
 */

const path = require('path');
const fs = require('fs');
const { findSQLFiles, findSourceFiles, readFileSafe, getRelativePath, directoryExists } = require('../utils/file-utils.cjs');
const { getLineNumber, getCodeSnippet, isInCommentOrStringSQL, isInCommentOrString, importsFromPaceCore } = require('../utils/code-utils.cjs');
const {
  validatePageName,
  isKebabCaseCatalogueSlug,
  isPascalCasePageName,
} = require('../../naming/naming-by-layer.cjs');

/** MINT tables scoped to organisation only (no event_id column). See docs/database/domains/mint.md */
const ORG_SCOPED_MINT_TABLES = new Set([
  'mint_action_log',
  'mint_actual_transaction',
  'mint_context_currency',
  'mint_context_variable',
  'mint_credit_balance',
  'mint_dd_mandate_log',
  'mint_financial_context',
  'mint_idempotency',
  'mint_invoice',
  'mint_line_item',
  'mint_mit_consent_log',
  'mint_payment_method',
  'mint_plan',
  'mint_plan_line',
  'mint_plan_line_attachment',
  'mint_webhook_log',
]);

/** Legacy MINT tables that carry event_id and require event-scoped INSERT checks */
const EVENT_SCOPED_MINT_TABLES = new Set([
  'mint_budgets',
  'mint_budget_variables',
]);

const EVENT_SCOPED_TABLE_PREFIXES = ['trac_', 'cake_', 'medi_'];

/**
 * Whether an INSERT policy should require event_id IS NOT NULL in WITH CHECK.
 * Org-only MINT billing tables and org-level RBAC (NULL event context) are excluded.
 */
function tableRequiresEventIdOnInsert(tableName, policyBody) {
  const normalized = tableName.toLowerCase();

  if (ORG_SCOPED_MINT_TABLES.has(normalized)) {
    return false;
  }

  if (EVENT_SCOPED_MINT_TABLES.has(normalized)) {
    return true;
  }

  if (EVENT_SCOPED_TABLE_PREFIXES.some((prefix) => normalized.startsWith(prefix))) {
    return true;
  }

  if (normalized.startsWith('mint_')) {
    if (/,\s*NULL\s*,/i.test(policyBody)) {
      return false;
    }
    return /\bevent_id\b/i.test(policyBody);
  }

  return /\bevent_id\b/i.test(policyBody);
}

/**
 * Check RLS policy compliance in SQL migrations.
 */
function checkRLSPolicies(consumingAppPath) {
  const issues = [];
  const migrationsPath = path.join(consumingAppPath, 'supabase', 'migrations');
  const altMigrationsPath = path.join(consumingAppPath, 'migrations');
  const migrationsDir = fs.existsSync(migrationsPath) ? migrationsPath :
                        (fs.existsSync(altMigrationsPath) ? altMigrationsPath : null);
  if (!migrationsDir) {
    return issues;
  }
  const sqlFiles = findSQLFiles(migrationsDir);
  
  sqlFiles.forEach(filePath => {
    try {
      const content = readFileSafe(filePath);
      if (!content) {
        return;
      }
      
      const relativePath = getRelativePath(filePath, consumingAppPath);
      
      // Find CREATE POLICY statements
      const policyPattern = /CREATE\s+POLICY\s+["']?([^"'\s]+)["']?\s+ON\s+(\w+)\s+FOR\s+(\w+)/gi;
      let match;
      
      while ((match = policyPattern.exec(content)) !== null) {
        const policyName = match[1];
        const tableName = match[2];
        const operation = match[3].toLowerCase();
        const policyStart = match.index;
        
        // Check policy naming: rbac_{operation}_{table_name}_{scope}
        const expectedPattern = new RegExp(`^rbac_${operation}_${tableName}(?:_\\w+)?$`, 'i');
        if (!expectedPattern.test(policyName)) {
          issues.push({
            type: 'rlsPolicy',
            file: relativePath,
            line: getLineNumber(content, policyStart),
            message: `RLS policy '${policyName}' does not follow naming convention. Should be 'rbac_${operation}_${tableName}' or 'rbac_${operation}_${tableName}_scope'.`,
            code: getCodeSnippet(content, policyStart, 0, 100),
            severity: 'error',
            fix: `Rename policy to follow pattern: rbac_${operation}_${tableName}`,
            standardSection: 'Policy Naming Convention (RLS Policy Patterns)',
          });
        }
        
        // Find the USING/WITH CHECK clause
        const policyEnd = content.indexOf(';', policyStart);
        if (policyEnd === -1) continue;
        
        const policyBody = content.substring(policyStart, policyEnd);
        
        // Check for inline auth.uid() calls (performance issue)
        const authUidPattern = /\bauth\.uid\s*\(/gi;
        if (authUidPattern.test(policyBody) && !isInCommentOrStringSQL(content, content.indexOf('auth.uid', policyStart))) {
          issues.push({
            type: 'rlsPolicy',
            file: relativePath,
            line: getLineNumber(content, policyStart),
            message: `RLS policy '${policyName}' contains inline auth.uid() call. Must use helper function instead for performance.`,
            code: getCodeSnippet(content, policyStart, 0, 200),
            severity: 'error',
            fix: 'Replace auth.uid() with helper function like safe_get_user_id_for_rls(). Helper functions must be STABLE SECURITY DEFINER.',
            standardSection: 'Forbidden Patterns / Helper Function Requirements',
          });
        }
        
        // Check for subqueries in USING/WITH CHECK (performance issue)
        const subqueryPattern = /(?:USING|WITH\s+CHECK)\s*\([^)]*(?:SELECT\s+[^)]+FROM[^)]+WHERE[^)]*)\)/gi;
        if (subqueryPattern.test(policyBody)) {
          issues.push({
            type: 'rlsPolicy',
            file: relativePath,
            line: getLineNumber(content, policyStart),
            message: `RLS policy '${policyName}' contains subquery. Must use helper functions instead for performance.`,
            code: getCodeSnippet(content, policyStart, 0, 200),
            severity: 'error',
            fix: 'Replace subquery with helper function. Helper functions must be STABLE SECURITY DEFINER SET search_path TO public.',
            standardSection: 'Forbidden Patterns / Helper Function Requirements',
          });
        }
        
        // Check for inline current_setting calls (performance issue)
        const currentSettingPattern = /\bcurrent_setting\s*\(/gi;
        if (currentSettingPattern.test(policyBody) && !isInCommentOrStringSQL(content, content.indexOf('current_setting', policyStart))) {
          issues.push({
            type: 'rlsPolicy',
            file: relativePath,
            line: getLineNumber(content, policyStart),
            message: `RLS policy '${policyName}' contains inline current_setting() call. Must use helper function instead for performance.`,
            code: getCodeSnippet(content, policyStart, 0, 200),
            severity: 'error',
            fix: 'Replace current_setting() with helper function. Helper functions must be STABLE SECURITY DEFINER.',
            standardSection: 'Forbidden Patterns / Helper Function Requirements',
          });
        }
        
        // Check for is_super_admin() without parameter (security risk)
        const isSuperAdminWithoutParamPattern = /\bis_super_admin\s*\(\s*\)/gi;
        if (isSuperAdminWithoutParamPattern.test(policyBody) && !isInCommentOrStringSQL(content, content.indexOf('is_super_admin', policyStart))) {
          issues.push({
            type: 'rlsPolicy',
            file: relativePath,
            line: getLineNumber(content, policyStart),
            message: `RLS policy '${policyName}' uses is_super_admin() without parameter. Must use is_super_admin(safe_get_user_id_for_rls()) to avoid fallback strategy vulnerabilities.`,
            code: getCodeSnippet(content, policyStart, 0, 200),
            severity: 'error',
            fix: 'Replace is_super_admin() with is_super_admin(safe_get_user_id_for_rls()) to require explicit parameter passing.',
            standardSection: 'Standard Helper Functions (is_super_admin)',
          });
        }
        
        // Check for missing super-admin checks in authenticated policies
        const isAuthenticatedPolicy = /TO\s+authenticated/i.test(policyBody);
        const hasSuperAdminCheck = /\bis_super_admin\s*\(/i.test(policyBody);
        const isPublicPolicy = /TO\s+(?:public|anon)/i.test(policyBody) || policyName.toLowerCase().includes('public') || policyName.toLowerCase().includes('anon');
        
        // Exception: User-scoped policies that only check user_id don't need super-admin
        const isUserScopedOnly = /organisation_id\s+IS\s+NULL/i.test(policyBody) && 
                                 /safe_get_user_id_for_rls\s*\(\s*\)\s*=\s*user_id/i.test(policyBody) &&
                                 !/\bOR\b/i.test(policyBody);
        
        // Skip check for public/anonymous policies or service role policies
        if (isAuthenticatedPolicy && !hasSuperAdminCheck && !isPublicPolicy && !policyName.toLowerCase().includes('service')) {
          if (!isUserScopedOnly) {
            issues.push({
              type: 'rlsPolicy',
              file: relativePath,
              line: getLineNumber(content, policyStart),
              message: `RLS policy '${policyName}' for authenticated users is missing super-admin check. All authenticated policies must include is_super_admin(safe_get_user_id_for_rls()) as a bypass.`,
              code: getCodeSnippet(content, policyStart, 0, 200),
              severity: 'error',
              fix: 'Add is_super_admin(safe_get_user_id_for_rls()) check. Pattern: (is_super_admin(safe_get_user_id_for_rls()) OR ...other checks...)',
              standardSection: 'Standard Organisation-Scoped Policy / Policy Best Practices',
            });
          }
        }
        
        // Check for use of deprecated event access functions when RBAC permissions should be used
        const usesEventAccess = /\bcheck_user_event_access\s*\(/i.test(policyBody);
        const usesEventCreator = /\bcheck_user_is_event_creator\s*\(/i.test(policyBody);
        const usesRBACPermission = /\b(?:data_check_rbac_permission_with_context|check_rbac_permission_with_context)\s*\(/i.test(policyBody);
        
        // Tables that have page permissions and should use RBAC permission checks
        const tablesWithPagePermissions = [
          'trac_contacts', 'trac_risks', 'trac_journal_posts', 'trac_currency_rates',
          'trac_accommodation', 'trac_activity', 'trac_transport',
          'mint_budgets', 'mint_budget_variables',
          'cake_dish', 'cake_meal', 'cake_item', 'cake_recipe',
          'medi_profile', 'medi_action_plan'
        ];
        
        const hasPagePermissions = tablesWithPagePermissions.some(t => 
          tableName.toLowerCase().includes(t.toLowerCase())
        );
        
        if (hasPagePermissions && (usesEventAccess || usesEventCreator) && !usesRBACPermission) {
          issues.push({
            type: 'rlsPolicy',
            file: relativePath,
            line: getLineNumber(content, policyStart),
            message: `RLS policy '${policyName}' uses ${usesEventAccess ? 'check_user_event_access()' : 'check_user_is_event_creator()'} but table '${tableName}' has page permissions. Should use data_check_rbac_permission_with_context() with page-level permissions instead.`,
            code: getCodeSnippet(content, policyStart, 0, 200),
            severity: 'error',
            fix: `Replace ${usesEventAccess ? 'check_user_event_access(event_id)' : 'check_user_is_event_creator(event_id)'} with data_check_rbac_permission_with_context('${operation}:page.{page_name}', '{page_name}', organisation_id, event_id::text, data_get_app_id('{app_name}')). See RBAC compliance standard for page name mapping.`,
            standardSection: 'RBAC Permission-Based Policy / Helper Selection Quick Guide',
          });
        }
        
        // Check for missing required field checks in event-scoped tables
        const hasEventIdColumn = tableRequiresEventIdOnInsert(tableName, policyBody);
        const hasOrganisationIdColumn = /organisation_id/i.test(policyBody) || 
                                        !tableName.toLowerCase().includes('rbac_') &&
                                        !tableName.toLowerCase().includes('core_organisations');
        
        const checksEventIdNotNull = /event_id\s+IS\s+NOT\s+NULL/i.test(policyBody);
        const checksOrganisationIdNotNull = /organisation_id\s+IS\s+NOT\s+NULL/i.test(policyBody);
        
        // For INSERT policies on event-scoped tables, event_id should be required
        if (operation === 'insert' && hasEventIdColumn && !checksEventIdNotNull) {
          issues.push({
            type: 'rlsPolicy',
            file: relativePath,
            line: getLineNumber(content, policyStart),
            message: `RLS INSERT policy '${policyName}' for event-scoped table '${tableName}' should require event_id IS NOT NULL. Permission checks need event_id to verify event-level roles.`,
            code: getCodeSnippet(content, policyStart, 0, 200),
            severity: 'error',
            fix: 'Add event_id IS NOT NULL check to WITH CHECK clause. Pattern: event_id IS NOT NULL AND ...',
            standardSection: 'Policy Best Practices / Standard Organisation-Scoped Policy',
          });
        }
        
        // For authenticated policies, organisation_id should typically be checked
        if (isAuthenticatedPolicy && hasOrganisationIdColumn && !checksOrganisationIdNotNull && 
            !isUserScopedOnly && !tableName.toLowerCase().includes('rbac_')) {
          // Exception: Some tables legitimately allow NULL organisation_id (e.g., user profiles)
          const allowsNullOrg = /organisation_id\s+IS\s+NULL/i.test(policyBody) && 
                                /safe_get_user_id_for_rls\s*\(\s*\)\s*=\s*user_id/i.test(policyBody);
          
          if (!allowsNullOrg) {
            issues.push({
              type: 'rlsPolicy',
              file: relativePath,
              line: getLineNumber(content, policyStart),
              message: `RLS policy '${policyName}' for table '${tableName}' should check organisation_id IS NOT NULL. Permission checks need organisation_id for proper RBAC context.`,
              code: getCodeSnippet(content, policyStart, 0, 200),
              severity: 'warning',
              fix: 'Add organisation_id IS NOT NULL check. Pattern: organisation_id IS NOT NULL AND ...',
              standardSection: 'Policy Best Practices / Standard Organisation-Scoped Policy',
            });
          }
        }
      }
      
      // Check helper function definitions for required attributes
      const functionPattern = /CREATE\s+(?:OR\s+REPLACE\s+)?FUNCTION\s+["']?(\w+)["']?\s*\([^)]*\)\s*RETURNS[^;]+LANGUAGE\s+plpgsql[^;]*AS/gi;
      let funcMatch;
      while ((funcMatch = functionPattern.exec(content)) !== null) {
        const funcName = funcMatch[1];
        const funcStart = funcMatch.index;
        const funcEnd = content.indexOf('AS $$', funcStart);
        if (funcEnd === -1) continue;
        
        const funcDef = content.substring(funcStart, funcEnd);
        
        // Only flag if function looks like it might be used in RLS (has common helper function patterns)
        const isLikelyRLSHelper = /check_|get_|is_/.test(funcName.toLowerCase());
        
        // Check for security-critical functions with fallback strategies
        if (funcName.toLowerCase() === 'is_super_admin' || funcName.toLowerCase().includes('super_admin')) {
          const funcBodyStart = content.indexOf('AS $$', funcStart);
          if (funcBodyStart !== -1) {
            const funcBodyEnd = content.indexOf('$$;', funcBodyStart);
            if (funcBodyEnd !== -1) {
              const funcBody = content.substring(funcBodyStart, funcBodyEnd);
              
              // Check for DEFAULT NULL parameter (allows fallback strategies)
              const hasDefaultNull = /p_\w+\s+UUID\s+DEFAULT\s+NULL/i.test(funcDef);
              
              // Check for multiple fallback patterns in function body
              const hasFallbackPatterns = (
                /IF\s+\w+\s+IS\s+NULL\s+THEN/i.test(funcBody) &&
                /ELSE/i.test(funcBody) &&
                (/\bauth\.uid\s*\(/i.test(funcBody) || /\bcurrent_setting\s*\(/i.test(funcBody))
              );
              
              if (hasDefaultNull || hasFallbackPatterns) {
                issues.push({
                  type: 'rlsPolicy',
                  file: relativePath,
                  line: getLineNumber(content, funcStart),
                  message: `Security-critical function '${funcName}' uses fallback strategies (DEFAULT NULL parameter or multiple fallback patterns). This is a security risk - functions should require explicit parameters and fail secure.`,
                  code: getCodeSnippet(content, funcStart, 0, 300),
                  severity: 'error',
                  fix: 'Remove DEFAULT NULL parameter and all fallback logic. Function should require explicit parameter and return false if parameter is NULL (fail secure).',
                  standardSection: 'Security Anti-Patterns / Forbidden Patterns',
                });
              }
            }
          }
        }
        
        if (isLikelyRLSHelper) {
          const hasStable = /\bSTABLE\b/i.test(funcDef);
          const hasSecurityDefiner = /\bSECURITY\s+DEFINER\b/i.test(funcDef);
          const hasSearchPath = /SET\s+search_path\s+TO\s+['"]?public['"]?/i.test(funcDef);
          
          if (!hasStable) {
            issues.push({
              type: 'rlsPolicy',
              file: relativePath,
              line: getLineNumber(content, funcStart),
              message: `Helper function '${funcName}' missing STABLE attribute. RLS helper functions must be STABLE for performance.`,
              code: getCodeSnippet(content, funcStart, 0, 150),
              severity: 'error',
              fix: 'Add STABLE attribute to function definition.',
              standardSection: 'RLS Policy Performance Requirements / Helper Function Requirements',
            });
          }
          
          // Check if function queries RLS-protected tables to determine if SECURITY DEFINER is needed
          const funcBodyStart = content.indexOf('AS $$', funcStart);
          let needsSecurityDefiner = false;
          if (funcBodyStart !== -1) {
            const funcBodyEnd = content.indexOf('$$;', funcBodyStart);
            if (funcBodyEnd !== -1) {
              const funcBody = content.substring(funcBodyStart, funcBodyEnd);
              const rlsProtectedTables = ['rbac_organisation_roles', 'rbac_global_roles', 'rbac_event_app_roles', 'rbac_user_profiles', 'rbac_apps', 'rbac_app_pages', 'rbac_page_permissions'];
              needsSecurityDefiner = rlsProtectedTables.some(table => {
                const tablePattern = new RegExp(`\\b${table}\\b`, 'i');
                return tablePattern.test(funcBody);
              });
            }
          }
          
          if (!hasSecurityDefiner) {
            if (needsSecurityDefiner) {
              issues.push({
                type: 'rlsPolicy',
                file: relativePath,
                line: getLineNumber(content, funcStart),
                message: `Helper function '${funcName}' queries RLS-protected tables but missing SECURITY DEFINER attribute. REQUIRED: SECURITY DEFINER is needed to bypass RLS and avoid circular dependencies when querying RLS-protected tables from within RLS policies.`,
                code: getCodeSnippet(content, funcStart, 0, 150),
                severity: 'error',
                fix: 'Add SECURITY DEFINER attribute to function definition. Also ensure SET search_path TO public is present.',
                standardSection: 'SECURITY DEFINER Requirements & Security',
              });
            } else {
              // Function doesn't query RLS-protected tables, SECURITY DEFINER might not be needed
              // This is just informational, not an error
            }
          }
          
          if (!hasSearchPath) {
            issues.push({
              type: 'rlsPolicy',
              file: relativePath,
              line: getLineNumber(content, funcStart),
              message: `Helper function '${funcName}' missing SET search_path TO public. MANDATORY for SECURITY DEFINER functions to prevent search path hijacking attacks.`,
              code: getCodeSnippet(content, funcStart, 0, 150),
              severity: 'error',
              fix: 'Add SET search_path TO public to function definition. This is MANDATORY for SECURITY DEFINER functions to prevent search path hijacking.',
              standardSection: 'Helper Function Template / Security Risks & Mitigations',
            });
          }
          
          // Additional security checks for SECURITY DEFINER functions
          if (hasSecurityDefiner) {
            // Get function body to check for unqualified references
            const funcBodyStart = content.indexOf('AS $$', funcStart);
            if (funcBodyStart !== -1) {
              const funcBodyEnd = content.indexOf('$$;', funcBodyStart);
              if (funcBodyEnd !== -1) {
                const funcBody = content.substring(funcBodyStart, funcBodyEnd);
                
                // Check for unqualified table references (security risk)
                // Look for FROM/JOIN without schema qualification
                const unqualifiedTablePattern = /(?:FROM|JOIN)\s+([a-z_][a-z0-9_]*)\s+(?!WHERE|ON|,|$)/gi;
                let tableMatch;
                const rlsProtectedTables = ['rbac_organisation_roles', 'rbac_global_roles', 'rbac_event_app_roles', 'rbac_user_profiles', 'rbac_apps', 'rbac_app_pages', 'rbac_page_permissions'];
                
                while ((tableMatch = unqualifiedTablePattern.exec(funcBody)) !== null) {
                  const tableName = tableMatch[1].toLowerCase();
                  // Check if it's a known RLS-protected table without schema qualification
                  if (rlsProtectedTables.some(t => t.toLowerCase() === tableName)) {
                    // Check if it's already schema-qualified (public.table_name)
                    const beforeMatch = funcBody.substring(Math.max(0, tableMatch.index - 20), tableMatch.index);
                    if (!/public\./i.test(beforeMatch)) {
                      issues.push({
                        type: 'rlsPolicy',
                        file: relativePath,
                        line: getLineNumber(content, funcStart + tableMatch.index),
                        message: `SECURITY DEFINER function '${funcName}' uses unqualified table reference '${tableName}'. MANDATORY: All table references in SECURITY DEFINER functions must be schema-qualified (e.g., public.${tableName}) to prevent search path hijacking.`,
                        code: getCodeSnippet(content, funcStart + tableMatch.index, 0, 100),
                        severity: 'error',
                        fix: `Schema-qualify the table reference: public.${tableName}`,
                        standardSection: 'Security Anti-Patterns / Schema-qualify references',
                      });
                    }
                  }
                }
                
                // Check if function queries RLS-protected tables (justification for SECURITY DEFINER)
                const queriesRLSProtected = rlsProtectedTables.some(table => {
                  const tablePattern = new RegExp(`\\b${table}\\b`, 'i');
                  return tablePattern.test(funcBody);
                });
                
                // Check if function has any table queries at all
                const hasTableQueries = /(?:FROM|JOIN|INTO|UPDATE)\s+\w+/i.test(funcBody);
                
                if (!queriesRLSProtected && hasTableQueries) {
                  // Function has SECURITY DEFINER but doesn't query RLS-protected tables
                  // This might be okay if it needs elevated privileges, but should be documented
                  const hasComment = /COMMENT\s+ON\s+FUNCTION.*SECURITY\s+DEFINER/i.test(content.substring(funcStart, funcStart + 2000));
                  if (!hasComment) {
                    issues.push({
                      type: 'rlsPolicy',
                      file: relativePath,
                      line: getLineNumber(content, funcStart),
                      message: `SECURITY DEFINER function '${funcName}' does not query RLS-protected tables. If SECURITY DEFINER is needed for elevated privileges, document why in a COMMENT. Otherwise, consider removing SECURITY DEFINER if not needed.`,
                      code: getCodeSnippet(content, funcStart, 0, 200),
                      severity: 'warning',
                      fix: 'Add COMMENT ON FUNCTION explaining why SECURITY DEFINER is needed, or remove SECURITY DEFINER if not required.',
                      standardSection: 'Required Mitigations (Document rationale)',
                    });
                  }
                } else if (queriesRLSProtected && !hasComment) {
                  // Function queries RLS-protected tables but doesn't document why SECURITY DEFINER is needed
                  const hasComment = /COMMENT\s+ON\s+FUNCTION/i.test(content.substring(funcStart, funcStart + 2000));
                  if (!hasComment) {
                    issues.push({
                      type: 'rlsPolicy',
                      file: relativePath,
                      line: getLineNumber(content, funcStart),
                      message: `SECURITY DEFINER function '${funcName}' queries RLS-protected tables but lacks documentation. REQUIRED: Add COMMENT ON FUNCTION explaining why SECURITY DEFINER is needed (to avoid circular RLS dependencies).`,
                      code: getCodeSnippet(content, funcStart, 0, 200),
                      severity: 'warning',
                      fix: 'Add COMMENT ON FUNCTION documenting that SECURITY DEFINER is required to avoid circular RLS dependencies when querying RLS-protected tables.',
                      standardSection: 'Required Mitigations (Document rationale)',
                    });
                  }
                }
              }
            }
          }
        }
      }
    } catch (error) {
      // Skip files that can't be read
    }
  });
  return issues;
}

/**
 * Check PagePermissionGuard coverage (all protected pages have guard)
 */
function checkPagePermissionGuardCoverage(consumingAppPath) {
  const issues = [];
  
  const srcDir = path.join(consumingAppPath, 'src');
  if (!directoryExists(srcDir)) {
    return issues;
  }
  
  const sourceFiles = findSourceFiles(srcDir);
  
  // Helper to check if file is likely a page component
  const PAGE_SUPPORT_SEGMENTS = new Set([
    'components',
    'hooks',
    'utils',
    'lib',
    'types',
    'helpers',
  ]);

  function isPageComponent(filePath, content) {
    const fileName = path.basename(filePath);
    const dirName = path.dirname(filePath);
    const dirParts = dirName.split(path.sep);
    
    // EXCLUDE: Provider components, routing components, shared components
    if (dirParts.some(part => part.toLowerCase() === 'providers' || part.toLowerCase() === 'provider')) {
      return false;
    }
    if (/Route(s)?\.(tsx?|jsx?)$/i.test(fileName)) {
      return false;
    }

    const pagesIndex = dirParts.findIndex(part => part.toLowerCase() === 'pages');
    if (pagesIndex >= 0) {
      const afterPages = dirParts.slice(pagesIndex + 1);
      if (afterPages.some(segment => PAGE_SUPPORT_SEGMENTS.has(segment.toLowerCase()))) {
        return false;
      }
      // Route entry only: *Page.tsx under pages/<feature>/ (not nested support folders).
      return /Page\.(tsx|jsx)$/i.test(fileName);
    }
    
    // INCLUDE: Files matching *Page.tsx pattern outside pages/ (legacy layouts)
    if (/Page\.(tsx?|jsx?)$/i.test(fileName)) {
      return true;
    }
    
    return false;
  }
  
  sourceFiles.forEach(filePath => {
    const content = readFileSafe(filePath);
    if (!content) {
      return;
    }
    
    // Exclude test files - they don't need PagePermissionGuard
    if (filePath.includes('.test.') || filePath.includes('.spec.')) {
      return;
    }
    
    if (!isPageComponent(filePath, content)) {
      return;
    }
    
    const relativePath = getRelativePath(filePath, consumingAppPath);
    const fileName = path.basename(filePath, path.extname(filePath));
    
    // Exclude public/error pages that don't need RBAC protection
    // NotFound, 404, Error, Unauthorized, Forbidden, AccessDenied pages are public
    // Showcase/demo pages (UI, DataTable, Styles, Public, Organisation, Storage, etc.) are intentionally public
    const isPublicPage = /NotFound|not.*found|404|Error|Unauthorized|Forbidden|AccessDenied/i.test(fileName) ||
                        /public|error|unauthorized|forbidden|access.*denied/i.test(relativePath) ||
                        /Showcase|showcase|StylesShowcase|DataTableShowcase|UIShowcase|OrganisationShowcase|StorageShowcase|PublicPage|CalendarTest|SuperAdmin|HomePage/i.test(fileName) ||
                        /showcase|public.*page/i.test(relativePath) ||
                        /PaceLoginPage|Login|login/i.test(fileName) ||
                        /login/i.test(relativePath) ||
                        /** Onboarding profile wizard: ProtectedRoute + shell; PagePermissionGuard would block when rbac_page_permissions rows are absent. */
                        /ProfileCompletionWizard/i.test(fileName) ||
                        /profile-complete/i.test(relativePath) ||
                        /** PR14 participant event hub: ProtectedRoute + org gate; rbac_app_pages may omit a dedicated participant hub row. */
                        /EventHubPage/i.test(fileName) ||
                        /** BASE shell landing: ProtectedRoute + org gate; event picker is not a permission-scoped feature page (BA00). */
                        /ShellLandingPage/i.test(fileName);
    
    if (isPublicPage) {
      return; // Skip public/error pages - they don't need PagePermissionGuard
    }
    
    // Check if PagePermissionGuard is used
    const hasPagePermissionGuard = /<PagePermissionGuard/.test(content) || 
                                   /PagePermissionGuard\s*</.test(content);
    
    // Check if RBAC hooks are imported (indicates this should be protected)
    const hasRBACHooks = importsFromPaceCore(content, 'useCan') ||
                         importsFromPaceCore(content, 'useResourcePermissions') ||
                         importsFromPaceCore(content, 'usePermissions') ||
                         importsFromPaceCore(content, 'useRBAC');
    
    // Check if component returns JSX (likely a page)
    const returnsJSX = /return\s*\(/.test(content) || /return\s+</.test(content);
    
    if (returnsJSX && !hasPagePermissionGuard) {
      if (hasRBACHooks) {
        // Definitely should be protected
        issues.push({
          type: 'rbacPageGuard',
          file: relativePath,
          line: 1,
          message: 'Page component missing PagePermissionGuard wrapper. Pages using RBAC hooks must be protected.',
          severity: 'error',
          fix: 'Wrap page content with <PagePermissionGuard pageName="page-name" operation="read">',
          standardSection: 'Security Baseline (page protection)',
        });
      } else {
        // Might be a public page, but flag for review
        issues.push({
          type: 'rbacPageGuard',
          file: relativePath,
          line: 1,
          message: 'Page component does not use PagePermissionGuard. Verify if this page should be protected.',
          severity: 'warning',
          fix: 'If page should be protected, wrap with <PagePermissionGuard pageName="page-name" operation="read">',
          standardSection: 'Security Baseline (page protection)',
        });
      }
    }
    
    // Check if PagePermissionGuard is used incorrectly (missing required props)
    if (hasPagePermissionGuard) {
      const pageGuardPattern = /<PagePermissionGuard[^>]*>/g;
      let match;
      while ((match = pageGuardPattern.exec(content)) !== null) {
        if (isInCommentOrString(content, match.index)) {
          continue;
        }
        
        const guardProps = match[0];
        const hasPageName = /pageName\s*=/.test(guardProps);
        const hasOperation = /operation\s*=/.test(guardProps);
        
        if (!hasPageName || !hasOperation) {
          issues.push({
            type: 'rbacPageGuard',
            file: relativePath,
            line: getLineNumber(content, match.index),
            message: 'PagePermissionGuard missing required props (pageName or operation)',
            code: guardProps,
            severity: 'error',
            fix: 'Add required props: <PagePermissionGuard pageName="page-name" operation="read">',
            standardSection: 'Security Baseline (page protection)',
          });
        }

        const pageNameMatch = guardProps.match(/pageName\s*=\s*["']([^"']+)["']/);
        if (pageNameMatch) {
          const pageSlug = pageNameMatch[1];
          const fileStem = path.basename(relativePath).replace(/\.(tsx?|jsx?)$/, '');
          const pageFileStem = /\/pages\//.test(relativePath) && /Page$/.test(fileStem) ? fileStem : undefined;
          const validation = validatePageName(pageSlug, {
            fileStem: pageFileStem,
            legacyMode: 'allow-warn',
          });

          if (!validation.ok) {
            issues.push({
              type: 'rbacPageGuard',
              file: relativePath,
              line: getLineNumber(content, match.index),
              message: validation.message,
              code: guardProps,
              severity: 'error',
              fix: validation.kind === 'stem-mismatch'
                ? `Use pageName="${pageFileStem}" matching the page file stem`
                : 'Use PascalCase pageName matching rbac_app_pages (e.g. DashboardPage)',
              standardSection: 'Naming by layer (RBAC page catalogue vs routes)',
            });
          } else if (validation.warn) {
            issues.push({
              type: 'legacyPageName',
              file: relativePath,
              line: getLineNumber(content, match.index),
              message: validation.migrationTarget
                ? `Legacy pageName "${pageSlug}" — migrate to "${validation.migrationTarget}"`
                : `Legacy pageName "${pageSlug}" — migrate to PascalCase matching page file stem`,
              code: guardProps,
              severity: 'warning',
              fix: validation.migrationTarget
                ? `Rename catalogue row and update to pageName="${validation.migrationTarget}"`
                : 'Register PascalCase page_name in rbac_app_pages and update guards',
              standardSection: 'Legacy RBAC page names',
            });
          } else if (
            isKebabCaseCatalogueSlug(pageSlug) &&
            pageFileStem &&
            isPascalCasePageName(pageFileStem) &&
            pageSlug !== pageFileStem
          ) {
            issues.push({
              type: 'rbacPageGuard',
              file: relativePath,
              line: getLineNumber(content, match.index),
              message: `pageName "${pageSlug}" looks like a route slug; use catalogue key "${pageFileStem}" instead`,
              code: guardProps,
              severity: 'error',
              fix: `Use pageName="${pageFileStem}" — do not derive pageName from URL path segments`,
              standardSection: 'Route paths vs RBAC page catalogue',
            });
          }
        }
      }
    }
  });
  
  return issues;
}

/**
 * Check organisation ID resolution in consuming app source.
 * When both selectedOrganisation and selectedEvent are in scope, RPC/params that pass
 * organisation context (p_organisation_id, organisation_id, selectedOrganisationId) must use
 * a derived organisationId (selectedOrganisation?.id ?? selectedEvent?.organisation_id) so that
 * org is resolved correctly when an event is selected without an explicit org in the context selector.
 * Reference: Standard 6 data isolation; pace-core Event has organisation_id.
 */
function checkOrganisationIdResolution(consumingAppPath) {
  const issues = [];
  const srcDir = path.join(consumingAppPath, 'src');
  if (!directoryExists(srcDir)) {
    return issues;
  }
  const sourceFiles = findSourceFiles(srcDir);
  const orgParamKeys = ['p_organisation_id', 'organisation_id', 'selectedOrganisationId'];
  const orgParamKeyPattern = new RegExp(
    '\\b(' + orgParamKeys.join('|') + ')\\s*:\\s*([^,}\\n]+)',
    'g'
  );
  const usesSelectedOrgIdInValue = /selectedOrganisation\s*(\?\.id|\.id)/;

  sourceFiles.forEach((filePath) => {
    if (filePath.includes('.test.') || filePath.includes('.spec.')) {
      return;
    }
    const content = readFileSafe(filePath);
    if (!content) return;
    const hasOrg = /selectedOrganisation|useOrganisations\s*\(/.test(content);
    const hasEvent = /selectedEvent|useEvents\s*\(/.test(content);
    if (!hasOrg || !hasEvent) return;

    let match;
    orgParamKeyPattern.lastIndex = 0;
    while ((match = orgParamKeyPattern.exec(content)) !== null) {
      const key = match[1];
      const valuePart = match[2].trim();
      if (!usesSelectedOrgIdInValue.test(valuePart)) continue;
      if (/organisationId\b/.test(valuePart)) continue;
      if (isInCommentOrString(content, match.index)) continue;
      const lineNum = getLineNumber(content, match.index);
      issues.push({
        type: 'organisationIdResolution',
        file: getRelativePath(filePath, consumingAppPath),
        line: lineNum,
        message: `Organisation context (${key}) is set from selectedOrganisation?.id while selectedEvent is also in scope. Use a derived organisationId (e.g. selectedOrganisation?.id ?? selectedEvent?.organisation_id) so org is resolved correctly when an event is selected without an explicit org.`,
        code: getCodeSnippet(content, match.index, 0, 120),
        severity: 'error',
        fix: 'Derive organisationId = selectedOrganisation?.id ?? selectedEvent?.organisation_id ?? undefined (in a useMemo with [selectedOrganisation?.id, selectedEvent]) and use organisationId for all p_organisation_id, organisation_id, and selectedOrganisationId values.',
        standardSection: 'Data isolation (organisation context resolution)',
      });
    }
  });
  return issues;
}

/**
 * Check Edge Functions RBAC setup
 */
function checkEdgeFunctionsRBAC(consumingAppPath) {
  const issues = [];
  
  const edgeFunctionsDir = path.join(consumingAppPath, 'supabase', 'functions');
  if (!directoryExists(edgeFunctionsDir)) {
    return issues; // No edge functions, skip
  }
  
  // Find all edge function files
  function findEdgeFunctionFiles(dir) {
    const files = [];
    if (!fs.existsSync(dir)) return files;
    
    const entries = fs.readdirSync(dir);
    entries.forEach(entry => {
      const entryPath = path.join(dir, entry);
      const stat = fs.statSync(entryPath);
      
      if (stat.isDirectory()) {
        // Look for index.ts or index.js in function directory
        const indexFiles = ['index.ts', 'index.js', 'index.tsx', 'index.jsx'];
        indexFiles.forEach(indexFile => {
          const indexPath = path.join(entryPath, indexFile);
          if (fs.existsSync(indexPath)) {
            files.push(indexPath);
          }
        });
      }
    });
    
    return files;
  }
  
  const edgeFunctionFiles = findEdgeFunctionFiles(edgeFunctionsDir);
  
  edgeFunctionFiles.forEach(filePath => {
    const content = readFileSafe(filePath);
    if (!content) {
      return;
    }
    
    const relativePath = getRelativePath(filePath, consumingAppPath);
    
    // Check for setupRBAC import
    const hasSetupRBAC = /setupRBAC|from\s+['"]@solvera\/pace-core\/rbac['"]/.test(content);
    
    // Check for isPermitted usage
    const hasIsPermitted = /\bisPermitted\s*\(/.test(content);
    
    // If function uses RBAC but doesn't call setupRBAC
    if (hasIsPermitted && !hasSetupRBAC) {
      issues.push({
        type: 'edgeFunctionRBAC',
        file: relativePath,
        line: 1,
        message: 'Edge function uses isPermitted() but does not call setupRBAC(). Must call setupRBAC() before using RBAC functions.',
        severity: 'error',
        fix: 'Add: import { setupRBAC, isPermitted } from \'@solvera/pace-core/rbac\'; and call setupRBAC() at the start of the handler.',
        standardSection: 'Edge Functions and Serverless Functions',
      });
    }
  });
  
  return issues;
}

/**
 * Run audit for Standard 6: Security & RBAC
 * @param {string} consumingAppPath - Path to consuming app
 * @param {{ isPaceCorePackage?: boolean }} [auditContext] - Optional context (PaceLoginPage/Login are in public-page list)
 * @returns {object} - Audit results with issues array
 */
function runStandard6Audit(consumingAppPath, auditContext = {}) {
  const issues = [];
  
  try {
    issues.push(...checkRLSPolicies(consumingAppPath));
    issues.push(...checkPagePermissionGuardCoverage(consumingAppPath));
    issues.push(...checkOrganisationIdResolution(consumingAppPath));
    issues.push(...checkEdgeFunctionsRBAC(consumingAppPath));
  } catch (error) {
    return {
      standard: '03-security-rbac',
      issues: [],
      error: error.message,
    };
  }
  
  return {
    standard: '03-security-rbac',
    issues,
    error: null,
  };
}

module.exports = {
  runStandard6Audit,
  checkRLSPolicies,
  tableRequiresEventIdOnInsert,
  ORG_SCOPED_MINT_TABLES,
};
