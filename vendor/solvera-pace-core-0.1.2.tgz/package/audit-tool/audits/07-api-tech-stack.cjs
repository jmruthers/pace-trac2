/**
 * Standard 7: API & Tech Stack Audit
 * @package @solvera/pace-core
 * @module Audit/Standard7
 *
 * Audits consuming apps for compliance with Standard 7: API & Tech Stack.
 * Validates migration SQL RPC naming, tech stack versions, and Vite configuration.
 *
 * Reference: packages/core/docs/standards/4-api-tech-stack-standards.md
 */

const path = require('path');
const fs = require('fs');
const { findSQLFiles, findConfigFiles, readFileSafe, getRelativePath, findPaceCorePackageJson } = require('../utils/file-utils.cjs');
const { getLineNumber, getCodeSnippet, isInCommentOrStringSQL } = require('../utils/code-utils.cjs');

/**
 * Check RPC naming in SQL migrations (data_* for reads, app_* for writes).
 */
function checkRPCNaming(consumingAppPath) {
  const issues = [];
  const migrationsPath = path.join(consumingAppPath, 'supabase', 'migrations');
  const altMigrationsPath = path.join(consumingAppPath, 'migrations');
  const migrationsDir = fs.existsSync(migrationsPath) ? migrationsPath :
                        (fs.existsSync(altMigrationsPath) ? altMigrationsPath : null);
  if (!migrationsDir) {
    return issues;
  }
  const sqlFiles = findSQLFiles(migrationsDir);
  sqlFiles.forEach(filePath => {
    try {
      const content = readFileSafe(filePath);
      if (!content) {
        return;
      }
      
      const relativePath = getRelativePath(filePath, consumingAppPath);
      
      // Find CREATE FUNCTION statements
      const functionPattern = /CREATE\s+(?:OR\s+REPLACE\s+)?FUNCTION\s+(?:public\.)?["']?([^"'\s()]+)["']?\s*\(/gi;
      let match;
      const validVerbs = [
        'list', 'get', 'read',
        'create', 'update', 'delete',
        'check', 'upsert', 'ensure', 'grant', 'insert', 'remove', 'revoke', 'resolve',
        'submit',
        'bulk_create', 'bulk_update', 'bulk_import',
      ];
      const readVerbs = ['list', 'get', 'read', 'check', 'resolve'];
      const writeVerbs = [
        'create', 'update', 'delete', 'upsert',
        'bulk_create', 'bulk_update', 'bulk_import',
        'ensure', 'grant', 'insert', 'remove', 'revoke',
        'submit',
      ];
      /** Intentional app_* names where the last verb alone would misclassify (DB-303 token RPCs). */
      const rpcNamingVerbAllowlist = new Set([
        'app_base_application_check_resolve_token',
        'app_base_application_check_submit',
        // Historical identifier in already-applied migrations; renamed forward in 20260502122000.
        'app_base_application_progress_get',
        // Historical identifier in already-applied migrations; renamed forward in 20260503222000.
        'app_base_form_registration_bindings_get',
      ]);
      const qualifierPatterns = ['by_code', 'by_id', 'by_slug', 'by_name', 'by_email', 'by_uuid'];
      const hasOnlyQualifierTail = (tailParts) => {
        if (tailParts.length === 0) {
          return true;
        }
        const tail = tailParts.join('_');
        return qualifierPatterns.some((qp) => tail === qp || tail.startsWith(`${qp}_`));
      };

      /**
       * Extracts an operation verb from an RPC-style function name.
       * Supports qualifier suffixes such as _by_code.
       */
      function extractVerb(functionName) {
        const parts = functionName.split('_');
        if (parts[0] === 'data' || parts[0] === 'app') {
          parts.shift();
        }

        for (let i = parts.length - 1; i >= 0; i--) {
          if (i > 0) {
            const bulkCandidate = `${parts[i - 1]}_${parts[i]}`;
            if (writeVerbs.includes(bulkCandidate) && hasOnlyQualifierTail(parts.slice(i + 1))) {
              return bulkCandidate;
            }
          }

          const candidate = parts[i];
          if (validVerbs.includes(candidate) && hasOnlyQualifierTail(parts.slice(i + 1))) {
            return candidate;
          }
        }

        return null;
      }
      
      while ((match = functionPattern.exec(content)) !== null) {
        const functionName = match[1];
        const functionStart = match.index;
        
        if (isInCommentOrStringSQL(content, functionStart)) {
          continue;
        }
        
        // Skip if it's a helper function (starts with check_, get_, is_)
        if (/^(check_|get_|is_)/i.test(functionName)) {
          continue;
        }
        
        // Check if it's a system function (starts with pg_ or other system prefixes)
        if (/^(pg_|information_schema|current_|session_|set_|reset_|show_)/i.test(functionName)) {
          continue;
        }
        
        // Only enforce RPC naming contract on explicitly RPC-scoped functions.
        // Internal DB helpers/triggers/maintenance functions may use domain names outside data_/app_.
        if (!/^(data_|app_)/.test(functionName)) {
          continue;
        }

        if (rpcNamingVerbAllowlist.has(functionName)) {
          continue;
        }
        
        // Check naming pattern: data_* for reads, app_* for writes
        const verb = extractVerb(functionName);
        if (!verb) {
          continue;
        }
        
        if (!validVerbs.includes(verb)) {
          issues.push({
            type: 'rpcNaming',
            file: relativePath,
            line: getLineNumber(content, functionStart),
            message: `RPC '${functionName}' uses invalid verb '${verb}'. Use only: ${validVerbs.join(', ')}`,
            code: getCodeSnippet(content, functionStart, 0, 100),
            severity: 'error',
            fix: `Rename RPC to use valid verb: ${functionName.replace(verb, validVerbs[0])}`,
            standardSection: 'API & RPC Naming Conventions (RPC Naming Pattern / Naming Rules)',
          });
          continue;
        }
        
        // Check prefix-verb alignment
        const hasDataPrefix = functionName.startsWith('data_');
        const hasAppPrefix = functionName.startsWith('app_');
        const isReadOperation = readVerbs.includes(verb);
        const isWriteOperation = writeVerbs.includes(verb);
        
        if (hasDataPrefix && isWriteOperation) {
          issues.push({
            type: 'rpcNaming',
            file: relativePath,
            line: getLineNumber(content, functionStart),
            message: `RPC '${functionName}' has 'data_' prefix but uses write verb '${verb}'. Use 'app_' prefix for write operations.`,
            code: getCodeSnippet(content, functionStart, 0, 100),
            severity: 'error',
            fix: `Rename to app_${functionName.replace('data_', '')}`,
            standardSection: 'API & RPC Naming Conventions (RPC Naming Pattern / Naming Rules)',
          });
        }

        if (hasAppPrefix && isReadOperation) {
          issues.push({
            type: 'rpcNaming',
            file: relativePath,
            line: getLineNumber(content, functionStart),
            message: `RPC '${functionName}' has 'app_' prefix but uses read verb '${verb}'. Use 'data_' prefix for read operations.`,
            code: getCodeSnippet(content, functionStart, 0, 100),
            severity: 'error',
            fix: `Rename to data_${functionName.replace('app_', '')}`,
            standardSection: 'API & RPC Naming Conventions (RPC Naming Pattern / Naming Rules)',
          });
        }
      }
    } catch (error) {
      // Skip files that can't be read
    }
  });
  return issues;
}

/**
 * Check tech stack versions
 */
function checkTechStackVersions(consumingAppPath) {
  const issues = [];
  
  const packageJsonPath = path.join(consumingAppPath, 'package.json');
  const packageJsonContent = readFileSafe(packageJsonPath);
  
  if (!packageJsonContent) {
    return issues;
  }
  
  let packageJson;
  try {
    packageJson = JSON.parse(packageJsonContent);
  } catch (error) {
    return issues;
  }
  
  const allDeps = {
    ...(packageJson.dependencies || {}),
    ...(packageJson.devDependencies || {}),
  };

  // When auditing the pace-core package, its peerDependencies satisfy required dependency check
  if (packageJson.name === '@solvera/pace-core' && packageJson.peerDependencies) {
    Object.assign(allDeps, packageJson.peerDependencies);
  }
  
  // Get pace-core package.json for peer dependencies
  const paceCorePath = findPaceCorePackageJson(consumingAppPath);
  if (!paceCorePath) {
    return issues;
  }
  
  const paceCorePkg = JSON.parse(fs.readFileSync(paceCorePath, 'utf8'));
  const peerDeps = paceCorePkg.peerDependencies || {};
  
  // Check required peer dependencies
  const requiredPeers = ['react', 'react-dom', 'react-router-dom'];
  
  requiredPeers.forEach(dep => {
    if (!allDeps[dep]) {
      issues.push({
        type: 'techStack',
        file: 'package.json',
        line: 1,
        message: `Missing required dependency: ${dep}. Required version: ${peerDeps[dep] || 'latest'}`,
        severity: 'error',
        fix: `Install ${dep}: npm install ${dep}@${peerDeps[dep] || 'latest'}`,
        standardSection: 'Required Tech Stack / Version Requirements',
      });
    }
  });
  
  // Check React 19+ requirement
  if (allDeps.react) {
    const reactVersion = allDeps.react.replace(/[\^~]/, '');
    const reactMajor = parseInt(reactVersion.split('.')[0]);
    
    if (reactMajor < 19) {
      issues.push({
        type: 'techStack',
        file: 'package.json',
        line: 1,
        message: `React version ${reactVersion} is below required version 19+. pace-core requires React 19+.`,
        severity: 'error',
        fix: 'Upgrade React: npm install react@^19.0.0 react-dom@^19.0.0',
        standardSection: 'Required Tech Stack (React 19+)',
      });
    }
  }
  
  return issues;
}

/**
 * Check Vite configuration (optimizeDeps, resolve.dedupe)
 */
function checkViteConfig(consumingAppPath) {
  const issues = [];
  
  const viteConfigFiles = findConfigFiles(consumingAppPath, ['vite.config.ts', 'vite.config.js']);
  const viteConfigPath = viteConfigFiles['vite.config.ts'] || viteConfigFiles['vite.config.js'];
  
  if (!viteConfigPath) {
    return issues; // No vite config, skip
  }
  
  const content = readFileSafe(viteConfigPath);
  if (!content) {
    return issues;
  }
  
  const relativePath = getRelativePath(viteConfigPath, consumingAppPath);
  
  // Check for optimizeDeps.exclude (should exclude pace-core and react-router-dom)
  const hasOptimizeDepsExclude = /optimizeDeps\s*:\s*\{[^}]*exclude/.test(content);
  if (!hasOptimizeDepsExclude) {
    issues.push({
      type: 'viteConfig',
      file: relativePath,
      line: 1,
      message: 'vite.config.ts missing optimizeDeps.exclude. Should exclude @solvera/pace-core and react-router-dom to prevent React context mismatches.',
      severity: 'warning',
      fix: 'Add: optimizeDeps: { exclude: [\'@solvera/pace-core\', \'react-router-dom\'] }',
      standardSection: 'Tech Stack Configuration (Vite Configuration)',
    });
  } else {
    // Check if pace-core is excluded
    const excludesPaceCore = /exclude\s*:\s*\[[^\]]*['"]@solvera\/pace-core['"]/.test(content);
    if (!excludesPaceCore) {
      issues.push({
        type: 'viteConfig',
        file: relativePath,
        line: 1,
        message: 'vite.config.ts optimizeDeps.exclude should include @solvera/pace-core to prevent React context mismatches.',
        severity: 'warning',
        fix: 'Add \'@solvera/pace-core\' to optimizeDeps.exclude array',
        standardSection: 'Tech Stack Configuration (Vite Configuration)',
      });
    }
  }
  
  // Check for resolve.dedupe (should dedupe React dependencies)
  // Need to handle nested objects, so look for dedupe anywhere after resolve: {
  // Match resolve: { ... and then look for dedupe before the matching closing brace
  // Use a more flexible pattern that handles nested braces
  const resolvePattern = /resolve\s*:\s*\{/;
  const resolveMatch = content.match(resolvePattern);
  
  let hasResolveDedupe = false;
  if (resolveMatch) {
    const resolveStart = resolveMatch.index + resolveMatch[0].length;
    // Find the matching closing brace for the resolve object
    let braceCount = 1;
    let i = resolveStart;
    let resolveEnd = -1;
    
    while (i < content.length && braceCount > 0) {
      if (content[i] === '{') braceCount++;
      if (content[i] === '}') braceCount--;
      if (braceCount === 0) {
        resolveEnd = i;
        break;
      }
      i++;
    }
    
    if (resolveEnd > 0) {
      const resolveBody = content.substring(resolveStart, resolveEnd);
      // Check if dedupe exists in the resolve object body
      hasResolveDedupe = /dedupe\s*:/.test(resolveBody);
      
      // Also verify it includes the required dependencies
      if (hasResolveDedupe) {
        const dedupePattern = /dedupe\s*:\s*\[([^\]]+)\]/;
        const dedupeMatch = resolveBody.match(dedupePattern);
        if (dedupeMatch) {
          const dedupeArray = dedupeMatch[1];
          const hasReact = /['"]react['"]/.test(dedupeArray);
          const hasReactDom = /['"]react-dom['"]/.test(dedupeArray);
          const hasReactRouter = /['"]react-router-dom['"]/.test(dedupeArray);
          
          // If any required dependency is missing, flag it
          if (!hasReact || !hasReactDom || !hasReactRouter) {
            issues.push({
              type: 'viteConfig',
              file: relativePath,
              line: 1,
              message: 'vite.config.ts resolve.dedupe is missing required dependencies. Should include: react, react-dom, react-router-dom',
              severity: 'warning',
              fix: 'Update resolve.dedupe to include: [\'react\', \'react-dom\', \'react-router-dom\']',
              standardSection: 'Tech Stack Configuration (Vite Configuration)',
            });
          }
        }
      }
    }
  }
  
  if (!hasResolveDedupe) {
    issues.push({
      type: 'viteConfig',
      file: relativePath,
      line: 1,
      message: 'vite.config.ts missing resolve.dedupe. Should dedupe React dependencies to prevent context mismatches.',
      severity: 'warning',
      fix: 'Add: resolve: { dedupe: [\'react\', \'react-dom\', \'react-router-dom\'] }',
      standardSection: 'Tech Stack Configuration (Vite Configuration)',
    });
  }
  
  return issues;
}

/**
 * Run audit for Standard 7: API & Tech Stack
 * @param {string} consumingAppPath - Path to consuming app
 * @param {{ isPaceCorePackage?: boolean }} [auditContext] - Optional context (peerDeps satisfy required deps when package is pace-core)
 * @returns {object} - Audit results with issues array
 */
function runStandard7Audit(consumingAppPath, auditContext = {}) {
  const issues = [];
  
  try {
    issues.push(...checkRPCNaming(consumingAppPath));
    issues.push(...checkTechStackVersions(consumingAppPath));
    issues.push(...checkViteConfig(consumingAppPath));
  } catch (error) {
    return {
      standard: '04-api-tech-stack',
      issues: [],
      error: error.message,
    };
  }
  
  return {
    standard: '04-api-tech-stack',
    issues,
    error: null,
  };
}

module.exports = { runStandard7Audit };
