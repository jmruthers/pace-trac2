const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { checkCoreCssNaming } = require('./05-styling.cjs');

function makeTempCorePackage(coreCssContent) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'pace-s5-css-naming-audit-'));
  const coreCssDir = path.join(root, 'src', 'styles');
  fs.mkdirSync(coreCssDir, { recursive: true });
  fs.writeFileSync(path.join(coreCssDir, 'core.css'), coreCssContent);
  return root;
}

describe('05-styling checkCoreCssNaming', () => {
  it('flags custom properties with underscores', () => {
    const root = makeTempCorePackage(':root { --print_event_name: "x"; }');
    const issues = checkCoreCssNaming(root);
    assert.ok(
      issues.some(
        (issue) =>
          issue.type === 'cssNaming' &&
          issue.message.includes('--print_event_name')
      )
    );
  });

  it('accepts kebab-case custom properties', () => {
    const root = makeTempCorePackage(':root { --color-main-500: oklch(0.5 0.1 252); }');
    const issues = checkCoreCssNaming(root);
    assert.equal(issues.filter((issue) => issue.type === 'cssNaming').length, 0);
  });
});
