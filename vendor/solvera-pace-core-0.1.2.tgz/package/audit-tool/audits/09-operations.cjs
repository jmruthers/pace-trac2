/**
 * Standard 9: Operations Audit
 * @package @solvera/pace-core
 * @module Audit/Standard9
 * 
 * Audits consuming apps for compliance with Standard 9: Operations.
 * Validates error handling patterns, CI/CD configuration, and performance patterns.
 * 
 * Reference: packages/core/docs/standards/9-operations-standards.md
 */

const path = require('path');
const fs = require('fs');
const { findSourceFiles, readFileSafe, getRelativePath, directoryExists } = require('../utils/file-utils.cjs');
const { getLineNumber, getCodeSnippet, isInCommentOrString } = require('../utils/code-utils.cjs');

/**
 * Check error handling patterns (ApiResult usage)
 */
function checkErrorHandlingPatterns(consumingAppPath) {
  const issues = [];
  
  const srcDir = path.join(consumingAppPath, 'src');
  if (!directoryExists(srcDir)) {
    return issues;
  }
  
  const sourceFiles = findSourceFiles(srcDir);
  
  // Check for API functions that don't use ApiResult pattern
  sourceFiles.forEach(filePath => {
    const content = readFileSafe(filePath);
    if (!content) {
      return;
    }
    
    // Skip test files and test-utils
    if (filePath.includes('.test.') || filePath.includes('.spec.') || filePath.includes('test-utils')) {
      return;
    }
    
    const relativePath = getRelativePath(filePath, consumingAppPath);
    
    // Look for async functions that might be API functions
    const asyncFunctionPattern = /(?:export\s+)?(?:async\s+)?function\s+(\w+)\s*\([^)]*\)\s*:\s*Promise/gi;
    const matches = [...content.matchAll(asyncFunctionPattern)];
    
    matches.forEach(match => {
      const functionName = match[1];
      const functionIndex = match.index;
      
      // Skip if it's a hook
      if (functionName.startsWith('use')) {
        return;
      }
      
      // Check if function uses ApiResult
      const functionBody = content.substring(functionIndex, Math.min(functionIndex + 500, content.length));
      const usesApiResult = /ApiResult|ok:\s*(true|false)/.test(functionBody);
      
      if (!usesApiResult) {
        // Check if it's likely an API function (returns Promise, might throw errors)
        const returnsPromise = /:\s*Promise/.test(match[0]);
        const hasErrorHandling = /catch|throw|error/i.test(functionBody);
        
        if (returnsPromise && hasErrorHandling) {
          issues.push({
            type: 'errorHandling',
            file: relativePath,
            line: getLineNumber(content, functionIndex),
            message: `API function '${functionName}' does not use ApiResult pattern. Consider using ApiResult<T> for consistent error handling.`,
            code: getCodeSnippet(content, functionIndex),
            severity: 'info',
            fix: 'Use ApiResult<T> type: type ApiResult<T> = { ok: true; data: T } | { ok: false; error: ApiError }',
            standardSection: 'Error Handling Patterns / Result Types (API Errors)',
          });
        }
      }
    });
  });
  
  return issues;
}

/**
 * Check CI/CD configuration
 */
function checkCICDConfig(consumingAppPath) {
  const issues = [];
  
  // Check for .github/workflows directory
  const workflowsDir = path.join(consumingAppPath, '.github', 'workflows');
  
  if (!directoryExists(workflowsDir)) {
    issues.push({
      type: 'cicd',
      file: '.github/workflows/ (not found)',
      line: 0,
      message: 'CI/CD workflows directory not found. Consider setting up GitHub Actions for automated testing and deployment.',
      severity: 'info',
      fix: 'Create .github/workflows/ directory and add CI/CD workflow files',
      standardSection: 'CI/CD Integration (Required CI Checks)',
    });
    return issues;
  }
  
  // Check for common workflow files
  const workflowFiles = fs.existsSync(workflowsDir) 
    ? fs.readdirSync(workflowsDir).filter(file => file.endsWith('.yml') || file.endsWith('.yaml'))
    : [];
  
  if (workflowFiles.length === 0) {
    issues.push({
      type: 'cicd',
      file: '.github/workflows/',
      line: 0,
      message: 'No CI/CD workflow files found. Consider setting up automated testing and deployment.',
      severity: 'info',
      fix: 'Create workflow files in .github/workflows/ (e.g., ci.yml, deploy.yml)',
      standardSection: 'CI/CD Integration (Required CI Checks)',
    });
  } else {
    const combinedWorkflowContent = workflowFiles
      .map((name) => readFileSafe(path.join(workflowsDir, name)) || '')
      .join('\n');
    const hasValidatePipeline = /npm\s+run\s+validate|pnpm\s+validate|yarn\s+validate/i.test(combinedWorkflowContent);

    const requiredChecks = [
      { key: 'lint', pattern: /npm\s+run\s+lint|pnpm\s+lint|yarn\s+lint/i, fix: 'Add a CI step that runs `npm run lint`.' },
      { key: 'type-check', pattern: /npm\s+run\s+type-check|tsc\s+--noEmit|pnpm\s+type-check|yarn\s+type-check/i, fix: 'Add a CI step that runs `npm run type-check` (or `tsc --noEmit`).' },
      { key: 'test', pattern: /npm\s+run\s+test|pnpm\s+test|yarn\s+test/i, fix: 'Add a CI step that runs `npm run test`.' },
      { key: 'build', pattern: /npm\s+run\s+build|pnpm\s+build|yarn\s+build/i, fix: 'Add a CI step that runs `npm run build`.' },
    ];

    if (!hasValidatePipeline) {
      requiredChecks.forEach(({ key, pattern, fix }) => {
        if (!pattern.test(combinedWorkflowContent)) {
          issues.push({
            type: 'cicd',
            file: '.github/workflows/',
            line: 1,
            message: `CI workflow is missing required check: ${key}.`,
            severity: 'warning',
            fix,
            standardSection: 'CI/CD Integration (Required CI Checks)',
          });
        }
      });
    }

    if (!/npm\s+audit|pnpm\s+audit|yarn\s+audit|snyk|trivy|codeql/i.test(combinedWorkflowContent)) {
      issues.push({
        type: 'cicd',
        file: '.github/workflows/',
        line: 1,
        message: 'No security scanning step detected in CI workflow.',
        severity: 'info',
        fix: 'Add a security scan step (for example `npm audit --audit-level=moderate`).',
        standardSection: 'CI/CD Integration (Standard Pipeline Stages)',
      });
    }
  }
  
  return issues;
}

/**
 * Check package.json required scripts for CI and operations.
 */
function checkRequiredScripts(consumingAppPath) {
  const issues = [];
  const packageJsonPath = path.join(consumingAppPath, 'package.json');
  const packageJsonContent = readFileSafe(packageJsonPath);
  if (!packageJsonContent) return issues;

  let packageJson;
  try {
    packageJson = JSON.parse(packageJsonContent);
  } catch {
    return issues;
  }

  const scripts = packageJson.scripts || {};
  const requiredScripts = ['lint', 'type-check', 'test', 'test:coverage', 'build'];
  requiredScripts.forEach((name) => {
    if (!scripts[name]) {
      issues.push({
        type: 'requiredScripts',
        file: 'package.json',
        line: 1,
        message: `Missing required script: ${name}.`,
        severity: 'warning',
        fix: `Add \`${name}\` to package.json scripts.`,
        standardSection: 'Package.json Scripts',
      });
    }
  });

  return issues;
}

/**
 * Check for risky logging and silent error handling.
 */
function checkLoggingAndCatchQuality(consumingAppPath) {
  const issues = [];
  const srcDir = path.join(consumingAppPath, 'src');
  if (!directoryExists(srcDir)) return issues;
  const sourceFiles = findSourceFiles(srcDir);

  sourceFiles.forEach((filePath) => {
    if (filePath.includes('.test.') || filePath.includes('.spec.')) return;
    const content = readFileSafe(filePath);
    if (!content) return;
    const relativePath = getRelativePath(filePath, consumingAppPath);

    const sensitiveLogPattern = /(?:console\.(?:log|error|warn)|logger\.(?:error|warn|info|debug))\s*\([\s\S]{0,200}(password|token|secret|ssn|apiKey|apikey)/gi;
    let sensitiveMatch;
    while ((sensitiveMatch = sensitiveLogPattern.exec(content)) !== null) {
      if (isInCommentOrString(content, sensitiveMatch.index)) continue;
      issues.push({
        type: 'errorHandling',
        file: relativePath,
        line: getLineNumber(content, sensitiveMatch.index),
        message: 'Potential sensitive data logging detected (password/token/secret-like fields).',
        code: getCodeSnippet(content, sensitiveMatch.index),
        severity: 'error',
        fix: 'Remove sensitive fields from logs or redact them before logging.',
        standardSection: 'Error Messages (Logging Messages)',
      });
    }

    const silentCatchPattern = /catch\s*\(\s*[^)]*\)\s*\{\s*(?:\/\/[^\n]*\n|\s)*\}/gi;
    let catchMatch;
    while ((catchMatch = silentCatchPattern.exec(content)) !== null) {
      if (isInCommentOrString(content, catchMatch.index)) continue;
      issues.push({
        type: 'errorHandling',
        file: relativePath,
        line: getLineNumber(content, catchMatch.index),
        message: 'Silent catch block detected. Standard 9 requires explicit handling or safe propagation.',
        code: getCodeSnippet(content, catchMatch.index),
        severity: 'warning',
        fix: 'Handle the error explicitly (log safely, return ApiResult error, or rethrow).',
        standardSection: 'Error Handling Patterns',
      });
    }
  });

  return issues;
}

/**
 * Check for error boundary usage
 */
function checkErrorBoundaries(consumingAppPath) {
  const issues = [];
  
  const srcDir = path.join(consumingAppPath, 'src');
  if (!directoryExists(srcDir)) {
    return issues;
  }
  
  const sourceFiles = findSourceFiles(srcDir);
  
  // Check if ErrorBoundary is used
  let hasErrorBoundary = false;
  sourceFiles.forEach(filePath => {
    const content = readFileSafe(filePath);
    if (!content) {
      return;
    }
    
    if (/ErrorBoundary|errorBoundary/i.test(content)) {
      hasErrorBoundary = true;
    }
  });
  
  // Check main.tsx or App.tsx for ErrorBoundary
  const mainFiles = [
    path.join(consumingAppPath, 'src', 'main.tsx'),
    path.join(consumingAppPath, 'src', 'App.tsx'),
    path.join(consumingAppPath, 'App.tsx'),
  ];
  
  let hasErrorBoundaryInApp = false;
  mainFiles.forEach(filePath => {
    if (fs.existsSync(filePath)) {
      const content = readFileSafe(filePath);
      if (content && /ErrorBoundary|errorBoundary/i.test(content)) {
        hasErrorBoundaryInApp = true;
      }
    }
  });
  
  if (!hasErrorBoundaryInApp && hasErrorBoundary) {
    issues.push({
      type: 'errorBoundary',
      file: 'src/main.tsx or src/App.tsx',
      line: 1,
      message: 'ErrorBoundary component exists but is not used in main.tsx or App.tsx. Should wrap the app root to catch React errors.',
      severity: 'warning',
      fix: 'Wrap app root with ErrorBoundary in main.tsx or App.tsx',
      standardSection: 'Error Handling Patterns (Pattern 3: Error Boundaries)',
    });
  }
  
  return issues;
}

/**
 * Run audit for Standard 9: Operations
 * @param {string} consumingAppPath - Path to consuming app
 * @param {{ isPaceCorePackage?: boolean }} [auditContext] - When isPaceCorePackage, skip CICD/errorBoundary and ApiResult noise (package has no main/App)
 * @returns {object} - Audit results with issues array
 */
function runStandard9Audit(consumingAppPath, auditContext = {}) {
  const issues = [];
  const isPaceCorePackage = auditContext.isPaceCorePackage === true;

  try {
    if (!isPaceCorePackage) {
      issues.push(...checkErrorHandlingPatterns(consumingAppPath));
    }
    issues.push(...checkRequiredScripts(consumingAppPath));
    if (!isPaceCorePackage) {
      issues.push(...checkCICDConfig(consumingAppPath));
    }
    if (!isPaceCorePackage) {
      issues.push(...checkErrorBoundaries(consumingAppPath));
    }
    if (!isPaceCorePackage) {
      issues.push(...checkLoggingAndCatchQuality(consumingAppPath));
    }
  } catch (error) {
    return {
      standard: '09-operations',
      issues: [],
      error: error.message,
    };
  }
  
  return {
    standard: '09-operations',
    issues,
    error: null,
  };
}

module.exports = { runStandard9Audit };
