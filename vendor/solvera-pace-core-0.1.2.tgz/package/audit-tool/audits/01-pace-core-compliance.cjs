/**
 * Standard 1: pace-core Compliance Audit
 * @package @solvera/pace-core
 * @module Audit/Standard1
 * 
 * Audits consuming apps for compliance with Standard 1: pace-core Compliance.
 * Focuses on system-level checks that require cross-file analysis.
 * 
 * Reference: packages/core/docs/standards/5-pace-core-compliance-standards.md
 */

const fs = require('fs');
const path = require('path');
const { findSourceFiles, findConfigFiles, readFileSafe, getRelativePath, findPaceCorePackageJson } = require('../utils/file-utils.cjs');
const { getLineNumber, getCodeSnippet, isInCommentOrString } = require('../utils/code-utils.cjs');

function getRenderTreeSlice(content) {
  const renderCallMatch = content.match(/createRoot\s*\(|ReactDOM\.createRoot\s*\(|root\.render\s*\(/);
  if (!renderCallMatch || renderCallMatch.index === undefined) {
    return { slice: content, offset: 0 };
  }

  const start = renderCallMatch.index;
  const maxLength = 3000;
  return { slice: content.slice(start, start + maxLength), offset: start };
}

/**
 * Check provider nesting order in main.tsx
 */
function checkProviderNesting(consumingAppPath) {
  const issues = [];
  
  // Find main.tsx
  const mainFiles = [
    path.join(consumingAppPath, 'src', 'main.tsx'),
    path.join(consumingAppPath, 'src', 'main.ts'),
    path.join(consumingAppPath, 'src', 'main.jsx'),
    path.join(consumingAppPath, 'src', 'main.js'),
    path.join(consumingAppPath, 'main.tsx'),
    path.join(consumingAppPath, 'main.ts'),
    path.join(consumingAppPath, 'main.jsx'),
    path.join(consumingAppPath, 'main.js'),
  ];
  
  let mainFile = null;
  for (const file of mainFiles) {
    if (fs.existsSync(file)) {
      mainFile = file;
      break;
    }
  }
  
  if (!mainFile) {
    issues.push({
      type: 'providerNesting',
      file: 'src/main.tsx (not found)',
      line: 0,
      message: 'main.tsx file not found. Cannot validate provider nesting order.',
      severity: 'error',
      fix: 'Create src/main.tsx with proper provider nesting: QueryClientProvider → BrowserRouter → UnifiedAuthProvider',
      standardSection: 'MUST: Provider Nesting Order',
    });
    return issues;
  }
  
  const content = readFileSafe(mainFile);
  if (!content) {
    return issues;
  }
  
  const relativePath = getRelativePath(mainFile, consumingAppPath);
  
  // Required provider order: QueryClientProvider → BrowserRouter → UnifiedAuthProvider
  // OrganisationServiceProvider is inside UnifiedAuthProvider; consuming apps must not wrap with it.
  const requiredProviders = [
    { name: 'QueryClientProvider', import: '@tanstack/react-query' },
    { name: 'BrowserRouter', import: 'react-router-dom' },
    { name: 'UnifiedAuthProvider', import: '@solvera/pace-core' },
  ];
  
  // Check if all required providers are imported
  const missingProviders = requiredProviders.filter(provider => {
    const names = [provider.name].concat(provider.altName || []);
    const hasImport = names.some(name => {
      const importPattern = new RegExp(`import.*${name}.*from\\s+['"]${provider.import.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}['"]`);
      return importPattern.test(content);
    });
    return !hasImport;
  });
  
  if (missingProviders.length > 0) {
    issues.push({
      type: 'providerNesting',
      file: relativePath,
      line: 1,
      message: `Missing required providers: ${missingProviders.map(p => p.name).join(', ')}`,
      severity: 'error',
      fix: `Import and use all required providers in the correct order: ${requiredProviders.map(p => p.name).join(' → ')}`,
      standardSection: 'MUST: Provider Nesting Order',
    });
    return issues;
  }
  
  // Check provider nesting order by finding JSX structure near render tree.
  const renderTree = getRenderTreeSlice(content);
  const providerPattern = /<(\w+Provider|BrowserRouter)\s*[^>]*>/g;
  const providers = [];
  let match;
  
  while ((match = providerPattern.exec(renderTree.slice)) !== null) {
    const absoluteIndex = renderTree.offset + match.index;
    if (isInCommentOrString(content, absoluteIndex)) {
      continue;
    }
    
    const providerName = match[1];
    const isRequired = requiredProviders.some(p => p.name === providerName || (p.altName && p.altName === providerName));
    if (isRequired) {
      providers.push({
        name: providerName,
        index: absoluteIndex,
        line: getLineNumber(content, absoluteIndex),
      });
    }
  }
  
  // Check order (normalize altName to canonical name for comparison)
  if (providers.length > 0) {
    const expectedOrder = requiredProviders.map(p => p.name);
    const actualOrder = providers.map(p => {
      const def = requiredProviders.find(r => r.name === p.name || r.altName === p.name);
      return def ? def.name : p.name;
    });
    
    // Check if order matches
    let orderCorrect = true;
    for (let i = 0; i < Math.min(expectedOrder.length, actualOrder.length); i++) {
      if (expectedOrder[i] !== actualOrder[i]) {
        orderCorrect = false;
        break;
      }
    }
    
    if (!orderCorrect) {
      issues.push({
        type: 'providerNesting',
        file: relativePath,
        line: providers[0].line,
        message: `Provider nesting order is incorrect. Expected: ${expectedOrder.join(' → ')}, Found: ${actualOrder.join(' → ')}`,
        code: getCodeSnippet(content, providers[0].index, 0, 200),
        severity: 'error',
        fix: `Reorder providers to: ${expectedOrder.join(' → ')}`,
        standardSection: 'MUST: Provider Nesting Order',
      });
    }
  }
  
  return issues;
}

/**
 * Check that UnifiedAuthProvider is configured with inactivity logout per R03.
 * Apps using UnifiedAuthProvider MUST pass idleTimeoutMs, warnBeforeMs, onIdleLogout, renderInactivityWarning
 * or set dangerouslyDisableInactivity (e.g. for tests).
 */
function checkUnifiedAuthInactivityConfig(consumingAppPath) {
  const issues = [];
  const srcPath = path.join(consumingAppPath, 'src');
  const rootPath = consumingAppPath;
  const searchDirs = [srcPath, rootPath].filter(d => fs.existsSync(d));
  const requiredInactivityProps = ['idleTimeoutMs', 'warnBeforeMs', 'onIdleLogout', 'renderInactivityWarning'];
  const hasAllInactivityProps = (content) =>
    requiredInactivityProps.every(prop => new RegExp(prop).test(content));
  const hasDisableInactivity = (content) =>
    /dangerouslyDisableInactivity\s*=\s*\{\s*true\s*\}/.test(content) ||
    /dangerouslyDisableInactivity\s*=\s*\{?\s*true\s*\}?/.test(content);

  for (const dir of searchDirs) {
    const files = findSourceFiles(dir, ['.tsx', '.ts', '.jsx', '.js']);
    for (const filePath of files) {
      const content = readFileSafe(filePath);
      if (!content || !content.includes('<UnifiedAuthProvider')) continue;
      if (isInCommentOrString(content, content.indexOf('<UnifiedAuthProvider'))) continue;
      const hasInactivity = hasAllInactivityProps(content);
      const hasDisabled = hasDisableInactivity(content);
      if (!hasInactivity && !hasDisabled) {
        const relativePath = getRelativePath(filePath, consumingAppPath);
        issues.push({
          type: 'unifiedAuthInactivity',
          file: relativePath,
          line: getLineNumber(content, content.indexOf('<UnifiedAuthProvider')),
          message: 'UnifiedAuthProvider must configure inactivity logout (idleTimeoutMs, warnBeforeMs, onIdleLogout, renderInactivityWarning) or set dangerouslyDisableInactivity. See R03.',
          severity: 'error',
          fix: 'Add idleTimeoutMs, warnBeforeMs, onIdleLogout, and renderInactivityWarning (e.g. InactivityWarningModal) to UnifiedAuthProvider, or set dangerouslyDisableInactivity={true} for tests.',
          standardSection: 'R03: Auth and context (inactivity logout)',
        });
      }
    }
  }

  return issues;
}

/**
 * Check RBAC setup in main.tsx
 */
function checkRBACSetup(consumingAppPath) {
  const issues = [];
  
  // Find main.tsx
  const mainFiles = [
    path.join(consumingAppPath, 'src', 'main.tsx'),
    path.join(consumingAppPath, 'src', 'main.ts'),
    path.join(consumingAppPath, 'src', 'main.jsx'),
    path.join(consumingAppPath, 'src', 'main.js'),
    path.join(consumingAppPath, 'main.tsx'),
    path.join(consumingAppPath, 'main.ts'),
    path.join(consumingAppPath, 'main.jsx'),
    path.join(consumingAppPath, 'main.js'),
  ];
  
  let mainFile = null;
  for (const file of mainFiles) {
    if (fs.existsSync(file)) {
      mainFile = file;
      break;
    }
  }
  
  if (!mainFile) {
    issues.push({
      type: 'rbacSetup',
      file: 'src/main.tsx (not found)',
      line: 0,
      message: 'main.tsx file not found. setupRBAC() must be called in main.tsx before app rendering.',
      severity: 'error',
      fix: 'Create src/main.tsx and call setupRBAC(supabase) before rendering the app.',
      standardSection: 'MUST: Setup RBAC Before Use',
    });
    return issues;
  }
  
  const content = readFileSafe(mainFile);
  if (!content) {
    return issues;
  }
  
  const relativePath = getRelativePath(mainFile, consumingAppPath);
  
  // Check for setupRBAC call
  const setupRBACPattern = /setupRBAC\s*\(/;
  if (!setupRBACPattern.test(content)) {
    issues.push({
      type: 'rbacSetup',
      file: relativePath,
      line: 1,
      message: 'setupRBAC() call not found. Must be called in main.tsx before app rendering.',
      severity: 'error',
      fix: 'Add: import { setupRBAC } from \'@solvera/pace-core/rbac\'; setupRBAC(supabase);',
      standardSection: 'MUST: Setup RBAC Before Use',
    });
  } else {
    // Check if it's called before React rendering
    const setupRBACIndex = content.indexOf('setupRBAC');
    const renderIndex = content.search(/(createRoot|render)\s*\(/);
    
    if (renderIndex !== -1 && setupRBACIndex > renderIndex) {
      issues.push({
        type: 'rbacSetup',
        file: relativePath,
        line: getLineNumber(content, setupRBACIndex),
        message: 'setupRBAC() called after React rendering. Must be called before rendering.',
        code: getCodeSnippet(content, setupRBACIndex),
        severity: 'error',
        fix: 'Move setupRBAC() call before createRoot() or render() call.',
        standardSection: 'MUST: Setup RBAC Before Use',
      });
    }
  }
  
  return issues;
}

/**
 * Check Vite aliases that bypass pace-core exports
 */
function checkViteAliases(consumingAppPath) {
  const issues = [];
  
  const viteConfigFiles = findConfigFiles(consumingAppPath, ['vite.config.ts', 'vite.config.js', 'vite.config.mjs', 'vite.config.cjs']);
  const viteConfigPath = viteConfigFiles['vite.config.ts'] || 
                         viteConfigFiles['vite.config.js'] || 
                         viteConfigFiles['vite.config.mjs'] || 
                         viteConfigFiles['vite.config.cjs'];
  
  if (!viteConfigPath) {
    return issues; // No vite config found, skip check
  }
  
  const content = readFileSafe(viteConfigPath);
  if (!content) {
    return issues;
  }
  
  // Get pace-core package.json to check included dependencies
  const paceCorePath = findPaceCorePackageJson(consumingAppPath);
  if (!paceCorePath) {
    return issues;
  }
  
  const paceCorePkg = JSON.parse(fs.readFileSync(paceCorePath, 'utf8'));
  const includedDeps = Object.keys(paceCorePkg.dependencies || {});
  
  const relativePath = getRelativePath(viteConfigPath, consumingAppPath);
  
  // Check for problematic aliases that bypass pace-core exports
  const paceCoreAliasPattern = /['"]@solvera\/pace-core\/(icons|utils|components|hooks|rbac)['"]\s*:\s*['"]([^'"]+)['"]/g;
  let match;
  
  while ((match = paceCoreAliasPattern.exec(content)) !== null) {
    const paceCoreExport = match[1];
    const aliasTarget = match[2];
    
    // Check if alias targets an included dependency
    if (includedDeps.includes(aliasTarget)) {
      issues.push({
        type: 'viteAlias',
        file: relativePath,
        line: getLineNumber(content, match.index),
        message: `Vite alias bypasses pace-core export: @solvera/pace-core/${paceCoreExport} → ${aliasTarget}`,
        code: getCodeSnippet(content, match.index),
        severity: 'error',
        fix: `Remove this alias and use @solvera/pace-core/${paceCoreExport} directly`,
        standardSection: 'MUST: Vite Configuration',
      });
    }
  }
  
  return issues;
}

/**
 * Check secure Supabase client file location
 */
function checkSecureSupabaseClient(consumingAppPath) {
  const issues = [];
  
  // Check main.tsx for createClient usage (allowed location)
  const mainFiles = [
    path.join(consumingAppPath, 'src', 'main.tsx'),
    path.join(consumingAppPath, 'src', 'main.ts'),
    path.join(consumingAppPath, 'main.tsx'),
    path.join(consumingAppPath, 'main.ts'),
  ];
  
  let mainFile = null;
  for (const file of mainFiles) {
    if (fs.existsSync(file)) {
      mainFile = file;
      break;
    }
  }
  
  // Check other source files for createClient usage
  const srcDir = path.join(consumingAppPath, 'src');
  if (!fs.existsSync(srcDir)) {
    return issues;
  }
  
  const sourceFiles = findSourceFiles(srcDir);
  
  sourceFiles.forEach(filePath => {
    // Skip main.tsx (allowed location)
    if (mainFile && path.resolve(filePath) === path.resolve(mainFile)) {
      return;
    }
    
    // Skip lib/supabase.ts (allowed location)
    const isLibSupabase = filePath.includes('lib/supabase.') || filePath.includes('lib\\supabase.');
    if (isLibSupabase) {
      return;
    }
    
    const content = readFileSafe(filePath);
    if (!content) {
      return;
    }
    
    const createClientPattern = /createClient\s*\(/g;
    let match;
    
    while ((match = createClientPattern.exec(content)) !== null) {
      if (isInCommentOrString(content, match.index)) {
        continue;
      }
      
      // Check if this is from @supabase/supabase-js
      const beforeMatch = content.substring(Math.max(0, match.index - 200), match.index);
      const hasSupabaseImport = /from\s+['"]@supabase\/supabase-js['"]/.test(beforeMatch);
      
      if (hasSupabaseImport) {
        const relativePath = getRelativePath(filePath, consumingAppPath);
        issues.push({
          type: 'supabaseClient',
          file: relativePath,
          line: getLineNumber(content, match.index),
          message: 'createClient() call detected in unauthorized location. Should only be in main.tsx or lib/supabase.ts',
          code: getCodeSnippet(content, match.index),
          severity: 'error',
          fix: 'Move createClient() call to main.tsx or lib/supabase.ts. Use useSecureSupabase() hook for queries.',
          standardSection: 'MUST: Use Secure Supabase Client',
        });
      }
    }
  });
  
  return issues;
}

/**
 * Check Cursor rules installation
 */
function checkCursorRules(consumingAppPath) {
  const issues = [];
  
  const cursorRulesDir = path.join(consumingAppPath, '.cursor', 'rules');
  
  if (!fs.existsSync(cursorRulesDir)) {
    issues.push({
      type: 'cursorRules',
      file: '.cursor/rules/ (not found)',
      line: 0,
      message: 'Cursor rules directory not found. Cursor rules provide AI-assisted enforcement.',
      severity: 'warning',
      fix: 'Run: npm run setup',
      standardSection: 'Step 3: Setup Cursor Rules',
    });
    return issues;
  }
  
  // Check for pace-core rules (Standard 5 = pace-core Compliance = 05-*.mdc)
  const paceCoreRuleFiles = [
    '00-standards-overview.mdc',
    '05-pace-core-compliance.mdc',
  ];
  
  const missingRules = paceCoreRuleFiles.filter(ruleFile => {
    const rulePath = path.join(cursorRulesDir, ruleFile);
    return !fs.existsSync(rulePath);
  });
  
  if (missingRules.length > 0) {
    issues.push({
      type: 'cursorRules',
      file: '.cursor/rules/',
      line: 0,
      message: `Missing pace-core cursor rules: ${missingRules.join(', ')}`,
      severity: 'warning',
      fix: 'Run: npm run setup',
      standardSection: 'Step 3: Setup Cursor Rules',
    });
  }
  
  return issues;
}

/**
 * Check for global auth gate anti-pattern (redirect to /login when !isAuthenticated in a wrapper).
 * MUST use public /login route and ProtectedRoute per route; MUST NOT wrap Routes in a component
 * that redirects unauthenticated users to /login (races with post-login context updates).
 */
function checkAuthRoutingPattern(consumingAppPath) {
  const issues = [];
  const srcDir = path.join(consumingAppPath, 'src');
  if (!fs.existsSync(srcDir)) {
    return issues;
  }

  const sourceFiles = findSourceFiles(srcDir, ['.tsx', '.jsx']);
  const hasNavigateToLogin = /<Navigate\s+[^>]*to\s*=\s*\{?['"`]\/login['"`]?\}?/;
  const hasAuthCheck = /(isAuthenticated|useUnifiedAuth\s*\(|useAuth\s*\()/;
  const hasRedirectWhenUnauthenticated = /(!\s*isAuthenticated|isAuthenticated\s*===\s*false|!\s*user\b)/;

  sourceFiles.forEach(filePath => {
    const content = readFileSafe(filePath);
    if (!content) return;

    if (!hasNavigateToLogin.test(content)) return;
    if (!hasAuthCheck.test(content)) return;
    if (!hasRedirectWhenUnauthenticated.test(content)) return;

    const normalizedPath = path.normalize(filePath);
    if (normalizedPath.includes('ProtectedRoute') || normalizedPath.includes('packages' + path.sep + 'core')) return;

    const relativePath = getRelativePath(filePath, consumingAppPath);
    const navigateMatch = content.match(hasNavigateToLogin);
    const line = navigateMatch ? getLineNumber(content, content.indexOf(navigateMatch[0])) : 1;

    issues.push({
      type: 'authRouting',
      file: relativePath,
      line,
      message: 'Possible global auth gate: redirect to /login when not authenticated. This pattern can cause "login succeeds but redirect doesn\'t happen" or form reset.',
      code: navigateMatch ? getCodeSnippet(content, content.indexOf(navigateMatch[0]), 0, 80) : undefined,
      severity: 'error',
      fix: 'Use a public /login route and wrap other routes in <Route element={<ProtectedRoute />}> imported from its canonical entrypoint (typically @solvera/pace-core/rbac). Do not wrap <Routes> in a component that redirects when !isAuthenticated.',
      standardSection: 'MUST: Auth routing',
      details: 'See Authentication implementation guide: Critical: Auth routing pattern and troubleshooting "Login succeeds but redirect doesn\'t happen".',
    });
  });

  return issues;
}

/**
 * Check that PaceAppLayout usage includes required authenticated user-menu props.
 */
function checkPaceAppLayoutUserMenuContract(consumingAppPath) {
  const issues = [];
  const srcDir = path.join(consumingAppPath, 'src');
  if (!fs.existsSync(srcDir)) {
    return issues;
  }

  const requiredProps = ['userFullName', 'userEmail', 'onUserMenuSignOut', 'onUserMenuChangePassword'];
  const sourceFiles = findSourceFiles(srcDir, ['.tsx', '.jsx']);

  sourceFiles.forEach((filePath) => {
    const content = readFileSafe(filePath);
    if (!content || !content.includes('<PaceAppLayout')) {
      return;
    }

    const relativePath = getRelativePath(filePath, consumingAppPath);
    const usagePattern = /<PaceAppLayout\b([\s\S]*?)>/g;
    let match;

    while ((match = usagePattern.exec(content)) !== null) {
      const fullTag = match[0];
      const tagStart = match.index;
      if (isInCommentOrString(content, tagStart)) {
        continue;
      }

      const hasSpreadProps = /\{\s*\.\.\./.test(fullTag);
      if (hasSpreadProps) {
        continue;
      }

      const missingProps = requiredProps.filter(
        (prop) => !new RegExp(`\\b${prop}\\s*=`, 'm').test(fullTag)
      );

      if (missingProps.length === 0) {
        continue;
      }

      issues.push({
        type: 'paceAppLayoutUserMenuContract',
        file: relativePath,
        line: getLineNumber(content, tagStart),
        message: `PaceAppLayout is missing required authenticated user-menu props: ${missingProps.join(', ')}`,
        code: getCodeSnippet(content, tagStart, 0, 220),
        severity: 'error',
        fix: 'Provide userFullName, userEmail, onUserMenuSignOut, and onUserMenuChangePassword on each authenticated PaceAppLayout usage.',
        standardSection: 'MUST: PaceAppLayout Authenticated User Menu Contract',
      });
    }
  });

  return issues;
}

/**
 * Check ESLint config setup
 */
function checkESLintConfig(consumingAppPath) {
  const issues = [];
  
  const eslintConfigFiles = findConfigFiles(consumingAppPath, [
    'eslint.config.js',
    'eslint.config.cjs',
    'eslint.config.mjs',
    '.eslintrc.js',
    '.eslintrc.cjs',
    '.eslintrc.json',
  ]);
  
  const eslintConfigPath = Object.values(eslintConfigFiles).find(path => path !== null);
  
  if (!eslintConfigPath) {
    issues.push({
      type: 'eslintConfig',
      file: 'eslint.config.js (not found)',
      line: 0,
      message: 'ESLint config file not found. ESLint provides real-time compliance checking.',
      severity: 'warning',
      fix: 'Run: npm run setup',
      standardSection: 'Step 2: Setup ESLint',
    });
    return issues;
  }
  
  const content = readFileSafe(eslintConfigPath);
  if (!content) {
    return issues;
  }
  
  const relativePath = getRelativePath(eslintConfigPath, consumingAppPath);
  
  // Check if pace-core config is included
  const hasPaceCoreConfig = /@solvera\/pace-core\/eslint-config/.test(content) ||
                            /paceCoreConfig/.test(content) ||
                            /pace-core-compliance/.test(content);
  
  if (!hasPaceCoreConfig) {
    issues.push({
      type: 'eslintConfig',
      file: relativePath,
      line: 1,
      message: 'ESLint config does not include pace-core config. pace-core ESLint rules provide real-time compliance checking.',
      severity: 'warning',
      fix: 'Run: npm run setup or manually add: import paceCoreConfig from \'@solvera/pace-core/eslint-config\';',
      standardSection: 'Step 2: Setup ESLint',
    });
  }
  
  return issues;
}

/**
 * Check drift between standards/cursor guidance and exported API symbols.
 * This guard primarily targets the pace-core package repository.
 */
function checkAuthorityDrift(consumingAppPath) {
  const issues = [];
  const filesToCheck = [
    {
      file: path.join(consumingAppPath, 'packages', 'core', 'docs', 'standards', '5-pace-core-compliance-standards.md'),
      relative: 'packages/core/docs/standards/5-pace-core-compliance-standards.md'
    },
    {
      file: path.join(consumingAppPath, 'packages', 'core', 'cursor-rules', '05-pace-core-compliance.mdc'),
      relative: 'packages/core/cursor-rules/05-pace-core-compliance.mdc'
    },
    {
      file: path.join(consumingAppPath, 'packages', 'core', 'cursor-rules', '00-standards-overview.mdc'),
      relative: 'packages/core/cursor-rules/00-standards-overview.mdc'
    },
    {
      file: path.join(consumingAppPath, '.cursor', 'rules', '05-pace-core-compliance.mdc'),
      relative: '.cursor/rules/05-pace-core-compliance.mdc'
    },
    {
      file: path.join(consumingAppPath, '.cursor', 'rules', '00-standards-overview.mdc'),
      relative: '.cursor/rules/00-standards-overview.mdc'
    }
  ];

  filesToCheck.forEach(({ file, relative }) => {
    if (!fs.existsSync(file)) return;
    const content = readFileSafe(file);
    if (!content) return;

    if (/\bOrganisationProvider\b/.test(content)) {
      issues.push({
        type: 'authorityDrift',
        file: relative,
        line: getLineNumber(content, content.indexOf('OrganisationProvider')),
        message: 'Guidance drift detected: found deprecated `OrganisationProvider` reference.',
        severity: 'error',
        fix: 'Replace with `OrganisationServiceProvider` imported from `@solvera/pace-core/providers`.',
        standardSection: 'Consumer export governance / MUST: Provider Nesting Order',
      });
    }
  });

  const facadePath = path.join(consumingAppPath, 'packages', 'core', 'src', 'index.ts');
  if (fs.existsSync(facadePath)) {
    const content = readFileSafe(facadePath) || '';
    const requiredExports = ['UnifiedAuthProvider', 'setupRBAC'];
    requiredExports.forEach((symbol) => {
      if (!new RegExp(`\\b${symbol}\\b`).test(content)) {
        issues.push({
          type: 'authorityDrift',
          file: 'packages/core/src/index.ts',
          line: 1,
          message: `Root facade drift detected: required symbol \`${symbol}\` not found in package root exports.`,
          severity: 'error',
          fix: `Restore \`${symbol}\` export or update standards/rules to match the current root API contract.`,
          standardSection: 'Consumer export governance',
        });
      }
    });
  }

  return issues;
}

/**
 * Run audit for Standard 1: pace-core Compliance
 * @param {string} consumingAppPath - Path to consuming app
 * @param {{ isPaceCorePackage?: boolean }} [auditContext] - When isPaceCorePackage, skip app-only checks (main.tsx, app.css, rbacSetup, cursorRules, eslintConfig)
 * @returns {object} - Audit results with issues array
 */
function runStandard1Audit(consumingAppPath, auditContext = {}) {
  const issues = [];
  const isPaceCorePackage = auditContext.isPaceCorePackage === true;

  try {
    if (!isPaceCorePackage) {
      issues.push(...checkProviderNesting(consumingAppPath));
      issues.push(...checkUnifiedAuthInactivityConfig(consumingAppPath));
      issues.push(...checkRBACSetup(consumingAppPath));
      issues.push(...checkCursorRules(consumingAppPath));
      issues.push(...checkESLintConfig(consumingAppPath));
      issues.push(...checkPaceAppLayoutUserMenuContract(consumingAppPath));
    }
    issues.push(...checkAuthorityDrift(consumingAppPath));
    issues.push(...checkViteAliases(consumingAppPath));
    issues.push(...checkSecureSupabaseClient(consumingAppPath));
    issues.push(...checkAuthRoutingPattern(consumingAppPath));
  } catch (error) {
    return {
      standard: '05-pace-core-compliance',
      issues: [],
      error: error.message,
    };
  }
  
  return {
    standard: '05-pace-core-compliance',
    issues,
    error: null,
  };
}

module.exports = { runStandard1Audit };
