#!/usr/bin/env node
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { test } = require('node:test');

function makeTempDir() {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'pace-component-gov-'));
}

function write(filePath, content) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, content, 'utf8');
}

test('checkPaceCoreComponentLayout flags root-level component files', () => {
  const dir = makeTempDir();
  write(path.join(dir, 'src', 'components', 'Button.tsx'), 'export function Button() {}');
  const { checkPaceCoreComponentLayout } = require('./02-project-structure.cjs');
  const issues = checkPaceCoreComponentLayout(dir);
  assert.ok(issues.some((issue) => issue.type === 'componentFolderLayout'));
  fs.rmSync(dir, { recursive: true, force: true });
});

test('checkInternalExportLeak flags internal path re-exports', () => {
  const dir = makeTempDir();
  write(
    path.join(dir, 'src', 'components', 'index.ts'),
    "export { ListboxBase } from './overlays/select/internal/ListboxBase.js';",
  );
  const auditModule = require('./02-project-structure.cjs');
  const issues = auditModule.checkInternalExportLeak
    ? auditModule.checkInternalExportLeak(dir)
    : [];
  assert.ok(issues.some((issue) => issue.type === 'internalExportLeak'));
  fs.rmSync(dir, { recursive: true, force: true });
});

test('checkComponentFileSize warns above 800 lines', () => {
  const dir = makeTempDir();
  const lines = `${'export function Big() {\n'.repeat(810)}`;
  write(path.join(dir, 'src', 'components', 'primitives', 'Big.tsx'), lines);
  const { checkComponentFileSize } = require('./03-architecture.cjs');
  const issues = checkComponentFileSize(dir);
  assert.ok(issues.some((issue) => issue.type === 'componentFileSize' && issue.severity === 'warning'));
  fs.rmSync(dir, { recursive: true, force: true });
});
