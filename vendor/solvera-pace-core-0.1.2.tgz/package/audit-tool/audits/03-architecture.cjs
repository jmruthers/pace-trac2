/**
 * Standard 3: Architecture Audit
 * @package @solvera/pace-core
 * @module Audit/Standard3
 * 
 * Audits consuming apps for compliance with Standard 3: Architecture.
 * Validates SOLID principles, component boundaries, and API design patterns.
 * 
 * Reference: packages/core/docs/standards/2-architecture-standards.md
 */

const path = require('path');
const { findSourceFiles, readFileSafe, getRelativePath } = require('../utils/file-utils.cjs');
const { getLineNumber, getCodeSnippet, isInCommentOrString, parseImports } = require('../utils/code-utils.cjs');

/**
 * Check if a file is a test file or test utility file
 * @param {string} filePath - Full path to the file
 * @returns {boolean} - True if file is a test file
 */
function isTestFile(filePath) {
  const fileName = path.basename(filePath, path.extname(filePath));
  const fileNameLower = fileName.toLowerCase();
  const filePathLower = filePath.toLowerCase();
  
  // Standard test file patterns and test-utils
  if (filePath.includes('.test.') || filePath.includes('.spec.') || filePath.includes('test-utils')) {
    return true;
  }
  
  // Files in test directories
  if (filePath.includes('/test/') || 
      filePath.includes('/tests/') || 
      filePath.includes('__tests__') ||
      filePath.includes('__test__')) {
    return true;
  }
  
  // Files starting with "test" prefix
  if (fileNameLower.startsWith('test')) {
    return true;
  }
  
  // Test utility patterns in filename
  const testUtilityPatterns = [
    'testassertion', 'testverifier', 'testhelper', 'testutility',
    'testsetup', 'testteardown', 'testmock', 'testfixture',
    'testdata', 'testutil', 'testhelper', 'testutils'
  ];
  
  if (testUtilityPatterns.some(pattern => fileNameLower.includes(pattern))) {
    return true;
  }
  
  // Test utility patterns in path
  const testPathPatterns = [
    'testutils', 'testhelpers', 'testassertions', 'testverifiers',
    'testsetup', 'testmocks', 'testfixtures', 'testdata'
  ];
  
  if (testPathPatterns.some(pattern => filePathLower.includes(pattern))) {
    return true;
  }
  
  // Files ending with test utility suffixes
  if (fileNameLower.endsWith('testutil') || 
      fileNameLower.endsWith('testhelper') ||
      fileNameLower.endsWith('testassertion') ||
      fileNameLower.endsWith('testverifier')) {
    return true;
  }
  
  return false;
}

/**
 * Check for component boundary violations (domain logic in components)
 */
function checkComponentBoundaries(consumingAppPath) {
  const issues = [];
  
  const srcDir = path.join(consumingAppPath, 'src');
  if (!require('fs').existsSync(srcDir)) {
    return issues;
  }
  
  const componentFiles = findSourceFiles(srcDir).filter(file => {
    // Skip all test files
    if (isTestFile(file)) {
      return false;
    }
    
    const dir = path.dirname(file);
    const isComponentDir = dir.includes('/components/') || dir.includes('/pages/');
    // Only check .tsx files for component boundaries (React components)
    // .ts files are utilities, hooks, or test files and shouldn't be checked
    const isComponentFile = file.endsWith('.tsx');
    
    return isComponentDir && isComponentFile;
  });
  
  // For data fetching checks, include .tsx and .ts under pages/components but exclude hook files
  const filesForDataFetchingCheck = findSourceFiles(srcDir).filter(file => {
    // Skip all test files
    if (isTestFile(file)) {
      return false;
    }
    
    const dir = path.dirname(file);
    const isComponentDir = dir.includes('/components/') || dir.includes('/pages/');
    const isComponentFile = file.endsWith('.tsx') || file.endsWith('.ts');
    
    // Exclude hooks: files under hooks/ or whose basename starts with 'use'
    const basename = path.basename(file, path.extname(file));
    const isHookFile = dir.includes('/hooks/') || basename.startsWith('use');
    if (isHookFile) {
      return false;
    }
    
    return isComponentDir && isComponentFile;
  });
  
  // Check for data fetching in components (should be in hooks)
  // Check both .tsx and .ts files for data fetching
  filesForDataFetchingCheck.forEach(filePath => {
    const content = readFileSafe(filePath);
    if (!content) {
      return;
    }
  
    const relativePath = getRelativePath(filePath, consumingAppPath);
    
    const dataFetchingPatterns = [
      /\.from\s*\([^)]*\)\s*\.select/i,
      /\.rpc\s*\(/i,
      /fetch\s*\(/i,
      /axios\.(get|post|put|delete)/i,
    ];
    
    dataFetchingPatterns.forEach(pattern => {
      const match = content.match(pattern);
      if (match) {
        const index = content.indexOf(match[0]);
        if (!isInCommentOrString(content, index)) {
          // Check if it's in a hook (acceptable)
          const beforeMatch = content.substring(Math.max(0, index - 200), index);
          const isInHook = /use[A-Z]\w*\s*\(/.test(beforeMatch) || 
                          /const\s+\w+\s*=\s*use/.test(beforeMatch);
          
          if (!isInHook) {
            issues.push({
              type: 'componentBoundary',
              file: relativePath,
              line: getLineNumber(content, index),
              message: 'Data fetching detected in component. Move to a custom hook.',
              code: getCodeSnippet(content, index),
              severity: 'warning',
              fix: 'Extract data fetching logic to a custom hook (e.g., useEventData)',
              standardSection: 'Component Design Principles / SOLID (Single Responsibility)',
            });
          }
        }
      }
    });
  });
  
  // Check for complex business logic in components
  // Only check .tsx files (React components), not .ts files (utilities/hooks/test files)
  componentFiles.forEach(filePath => {
    // Safety check: explicitly skip .ts files (should already be filtered, but double-check)
    if (!filePath.endsWith('.tsx')) {
      return;
    }
    
    // Also skip test files as an extra safety measure
    if (isTestFile(filePath)) {
      return;
    }
    
    const content = readFileSafe(filePath);
    if (!content) {
      return;
    }
  
    const relativePath = getRelativePath(filePath, consumingAppPath);
    
    // All files in componentFiles are .tsx files, so we can check them directly
    // Only flag actual business logic patterns, not UI text or comments
    const businessLogicPatterns = [
      /if\s*\([^)]*permission[^)]*\)/i,  // Permission checks
      /if\s*\([^)]*role[^)]*\)/i,        // Role checks
      /calculate\w*\s*\(/i,              // Calculation functions
      /compute\w*\s*\(/i,                 // Computation functions
      /process\w+\s*\(/i,                 // Process functions (not "Processing..." text)
    ];
    
    // Exclude test utility functions - functions that start with test/verify/get/create
    // These are test helpers, not business logic
    const isTestUtilityFunction = (match, content, index) => {
      // Look backwards to extract the function name being called
      const beforeMatch = content.substring(Math.max(0, index - 200), index);
      
      // Extract identifier before the match (function name)
      // Look for word characters, dots, and spaces before the match
      const identifierMatch = beforeMatch.match(/(\w+)\s*$/);
      if (identifierMatch) {
        const functionName = identifierMatch[1];
        // Check if function name starts with test utility prefixes
        const testUtilityPrefixes = /^(verify|get|test|create|assert|check|expect|mock|setup|teardown)/i;
        if (testUtilityPrefixes.test(functionName)) {
          return true;
        }
      }
      
      // Also check if it's a function definition with test utility prefix
      return /(?:export\s+)?(?:async\s+)?function\s+(verify|get|test|create|assert|check|expect|mock|setup|teardown)\w*\s*\(/i.test(beforeMatch) ||
             // Check if it's a const/let/var assignment
             /(?:export\s+)?(?:const|let|var)\s+(verify|get|test|create|assert|check|expect|mock|setup|teardown)\w*\s*=\s*(?:async\s+)?\(/i.test(beforeMatch);
    };
    
    // This is a heuristic - look for complex logic that should be in hooks/utils
    // Exclude common UI text patterns
    const hasUIOnlyText = /Processing\.\.\.|processing\.\.\./i.test(content);
    const hasComplexLogic = businessLogicPatterns.some(pattern => {
      const matches = content.matchAll(new RegExp(pattern.source, pattern.flags + 'g'));
      for (const match of matches) {
        const index = match.index;
        if (!isInCommentOrString(content, index) && !isTestUtilityFunction(match, content, index)) {
          return true;
        }
      }
      return false;
    });
    
    if (hasComplexLogic && !hasUIOnlyText) {
      // Check if logic is in a hook call (acceptable)
      const hasHookCalls = /use[A-Z]\w*\s*\(/.test(content);
      // Check if it's just a simple conditional render (acceptable)
      const isSimpleConditional = /return\s*\([^)]*\?[^)]*:[^)]*\)/.test(content) ||
                                  /\{[^}]*\?[^}]*:[^}]*\}/.test(content);
      
      if (!hasHookCalls && !isSimpleConditional) {
        issues.push({
          type: 'componentBoundary',
          file: relativePath,
          line: 1,
          message: 'Complex business logic detected in component. Consider extracting to a hook or utility function.',
          severity: 'info',
          fix: 'Extract business logic to a custom hook or utility function',
          standardSection: 'Component Design Principles (UI Primitives Only, Stateless When Possible)',
        });
      }
    }
  });
  
  return issues;
}

/** Thresholds for ISP heuristic (see Standard 3).
 *  Line limits and named-export limit are enforced by ESLint only; this audit does not check them. */
const INTERFACE_MEMBER_LIMIT = 30;

/**
 * ISP heuristic: flag interfaces/types with many members.
 * Best-effort only; uses simple brace matching. See standard "Limitations".
 */
function checkLargeInterfaceHeuristic(consumingAppPath) {
  const issues = [];
  const srcDir = path.join(consumingAppPath, 'src');
  if (!require('fs').existsSync(srcDir)) {
    return issues;
  }

  const sourceFiles = findSourceFiles(srcDir).filter(file =>
    !isTestFile(file) &&
    (file.endsWith('.ts') || file.endsWith('.tsx')) &&
    !file.includes('.generated.')
  );

  sourceFiles.forEach(filePath => {
    const content = readFileSafe(filePath);
    if (!content) {
      return;
    }

    const re = /\b(?:interface|type)\s+\w+\s*(?:=\s*)?\{/g;
    let m;
    while ((m = re.exec(content)) !== null) {
      const start = m.index + m[0].length - 1;
      let depth = 1;
      let i = start + 1;
      for (; i < content.length; i++) {
        if (content[i] === '{') {
          depth++;
        } else if (content[i] === '}') {
          depth--;
          if (depth === 0) {
            break;
          }
        }
      }
      const block = content.substring(start, i + 1);
      const memberCount = (block.match(/\w+\s*[?:]?\s*:/g) || []).length + (block.match(/\w+\s*\(/g) || []).length;
      if (memberCount > INTERFACE_MEMBER_LIMIT) {
        issues.push({
          type: 'componentBoundary',
          file: getRelativePath(filePath, consumingAppPath),
          line: getLineNumber(content, m.index),
          message: `Interface/type has ${memberCount} members (threshold ${INTERFACE_MEMBER_LIMIT}). Consider interface segregation; focused interfaces.`,
          severity: 'info',
          fix: 'Split into smaller, focused interfaces; see Standard 3 SOLID (ISP heuristic).',
          standardSection: 'How we check SOLID (ISP heuristic)',
        });
      }
    }
  });

  return issues;
}

/**
 * Check ApiResult shape usage (cross-file validation)
 */
function checkApiResultUsage(consumingAppPath) {
  const issues = [];
  
  const srcDir = path.join(consumingAppPath, 'src');
  if (!require('fs').existsSync(srcDir)) {
    return issues;
  }
  
  const sourceFiles = findSourceFiles(srcDir);
  let hasApiResultType = false;
  let apiResultFiles = [];
  
  // First, check if ApiResult type is defined
  sourceFiles.forEach(filePath => {
    const content = readFileSafe(filePath);
    if (!content) {
      return;
    }
    
    if (/type\s+ApiResult|interface\s+ApiResult/.test(content)) {
      hasApiResultType = true;
    }
  });
  
  // Check for API functions that don't use ApiResult
  sourceFiles.forEach(filePath => {
    // Skip test files
    if (isTestFile(filePath)) {
      return;
    }
    
    const content = readFileSafe(filePath);
    if (!content) {
      return;
    }
    
    // Look for async functions that might be API functions
    const asyncFunctionPattern = /(?:export\s+)?(?:async\s+)?function\s+(\w+)\s*\([^)]*\)\s*:\s*Promise/gi;
    const matches = [...content.matchAll(asyncFunctionPattern)];
    
    matches.forEach(match => {
      const functionName = match[1];
      const functionIndex = match.index;
      
      // Skip if it's a hook
      if (functionName.startsWith('use')) {
        return;
      }
      
      // Check if function uses ApiResult
      const functionBody = content.substring(functionIndex, functionIndex + 500);
      const usesApiResult = /ApiResult|ok:\s*(true|false)/.test(functionBody);
      
      if (!usesApiResult && !hasApiResultType) {
        const relativePath = getRelativePath(filePath, consumingAppPath);
        issues.push({
          type: 'apiResult',
          file: relativePath,
          line: getLineNumber(content, functionIndex),
          message: `API function '${functionName}' does not use ApiResult shape. Consider using ApiResult<T> for consistent error handling.`,
          code: getCodeSnippet(content, functionIndex),
          severity: 'info',
          fix: 'Use ApiResult<T> type: type ApiResult<T> = { ok: true; data: T } | { ok: false; error: ApiError }',
          standardSection: 'API Design Principles (Type-Safe Results)',
        });
      }
    });
  });
  
  return issues;
}

/**
 * Run audit for Standard 3: Architecture
 * @param {string} consumingAppPath - Path to consuming app
 * @param {{ isPaceCorePackage?: boolean }} [auditContext] - Optional context (interface member limit already relaxed for all)
 * @returns {object} - Audit results with issues array
 */
function checkComponentFileSize(consumingAppPath) {
  const issues = [];
  const componentsDir = path.join(consumingAppPath, 'src', 'components');
  if (!require('fs').existsSync(componentsDir)) return issues;

  const sourceFiles = findSourceFiles(componentsDir).filter(
    (file) => file.endsWith('.tsx') && !isTestFile(file),
  );

  sourceFiles.forEach((file) => {
    const content = readFileSafe(file);
    if (!content) return;
    const lineCount = content.split('\n').length;
    const relativePath = getRelativePath(file, consumingAppPath);
    if (lineCount > 1000) {
      issues.push({
        type: 'componentFileSize',
        file: relativePath,
        line: 0,
        message: `Component file exceeds 1000 lines (${lineCount}). Split into focused modules.`,
        severity: 'error',
        fix: 'Extract toolbar, body, modals, or hooks into separate files under the feature folder.',
        standardSection: 'Component file size (pace-core package)',
      });
    } else if (lineCount > 800) {
      issues.push({
        type: 'componentFileSize',
        file: relativePath,
        line: 0,
        message: `Component file approaching split threshold (${lineCount} lines).`,
        severity: 'warning',
        fix: 'Split before reaching 1000 lines.',
        standardSection: 'Component file size (pace-core package)',
      });
    }
  });

  return issues;
}

function runStandard3Audit(consumingAppPath, auditContext = {}) {
  const issues = [];
  const isPaceCorePackage = auditContext.isPaceCorePackage === true;
  
  try {
    if (isPaceCorePackage) {
      issues.push(...checkComponentFileSize(consumingAppPath));
    }
    issues.push(...checkComponentBoundaries(consumingAppPath));
    issues.push(...checkLargeInterfaceHeuristic(consumingAppPath));
    issues.push(...checkApiResultUsage(consumingAppPath));
  } catch (error) {
    return {
      standard: '02-architecture',
      issues: [],
      error: error.message,
    };
  }
  
  return {
    standard: '02-architecture',
    issues,
    error: null,
  };
}

module.exports = {
  runStandard3Audit,
  checkComponentFileSize,
};
