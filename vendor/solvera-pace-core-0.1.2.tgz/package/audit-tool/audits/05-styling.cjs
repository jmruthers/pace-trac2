/**
 * Standard 07: Visual audit
 * @package @solvera/pace-core
 * @module Audit/VisualStandard07
 *
 * Deep checks for Part A of packages/core/docs/standards/7-visual-standards.md: app.css, @source, @theme
 * palettes, forbidden import paths, and Vite + Tailwind v4. Part B/C are enforced by ESLint and
 * cursor rules per the standard’s enforcement reference.
 *
 * Reference: packages/core/docs/standards/7-visual-standards.md (repository root)
 */

const path = require('path');
const fs = require('fs');
const { readFileSafe, getRelativePath, findConfigFiles } = require('../utils/file-utils.cjs');
const { isKebabCssName } = require('../../naming/naming-by-layer.cjs');

const STANDARD_PART_A = '7-visual-standards.md — Part A (#part-a-styling-platform)';

const PALETTE_SHADES = ['50', '100', '200', '300', '400', '500', '600', '700', '800', '900', '950'];

/**
 * @param {string} content - full app.css
 * @returns {string | null} inner body of first @theme block
 */
function extractAtThemeBody(content) {
  const match = content.match(/@theme\s+(?:static|inline)?\s*\{/);
  if (!match || match.index === undefined) return null;
  const openBrace = content.indexOf('{', match.index);
  if (openBrace === -1) return null;
  let depth = 0;
  for (let i = openBrace; i < content.length; i++) {
    const ch = content[i];
    if (ch === '{') depth++;
    else if (ch === '}') {
      depth--;
      if (depth === 0) return content.slice(openBrace + 1, i);
    }
  }
  return null;
}

/**
 * @param {string} themeBody
 * @param {string} relativePath
 * @param {Array} issues
 */
function validatePaletteCompleteness(themeBody, relativePath, issues) {
  if (!themeBody) return;
  for (const palette of ['main', 'sec', 'acc']) {
    const missing = [];
    if (!new RegExp(`--color-${palette}-raw\\b`).test(themeBody)) missing.push('raw');
    for (const shade of PALETTE_SHADES) {
      if (!new RegExp(`--color-${palette}-${shade}\\b`).test(themeBody)) missing.push(shade);
    }
    if (missing.length > 0) {
      const preview = missing.slice(0, 8).join(', ');
      issues.push({
        type: 'appCss',
        file: relativePath,
        line: 1,
        message: `@theme static: palette "${palette}" is incomplete (missing: ${preview}${missing.length > 8 ? ', …' : ''}).`,
        severity: 'error',
        fix: `Add all --color-${palette}-raw and --color-${palette}-50 … 950 (see @solvera/pace-core/templates/app.css).`,
        standardSection: STANDARD_PART_A,
      });
    }
  }
}

/**
 * @param {string} consumingAppPath
 * @returns {Array}
 */
function checkEntryImportsNoDirectCoreCss(consumingAppPath) {
  const issues = [];
  const candidates = [
    path.join(consumingAppPath, 'src', 'main.tsx'),
    path.join(consumingAppPath, 'src', 'main.ts'),
    path.join(consumingAppPath, 'src', 'main.jsx'),
    path.join(consumingAppPath, 'src', 'main.js'),
  ];
  for (const file of candidates) {
    if (!fs.existsSync(file)) continue;
    const text = readFileSafe(file);
    if (!text) continue;
    const rel = getRelativePath(file, consumingAppPath);
    if (
      /@solvera\/pace-core\/styles\/core\.css/.test(text) ||
      /@solvera\/pace-core\/src\/styles/.test(text)
    ) {
      issues.push({
        type: 'appCss',
        file: rel,
        line: 1,
        message:
          'Do not import pace-core core.css from JS entry. Import app.css only (it must import core.css once).',
        severity: 'error',
        fix: 'Remove direct core.css import; keep a single import of ./app.css (or your app CSS entry).',
        standardSection: STANDARD_PART_A,
      });
    }
  }
  return issues;
}

/**
 * Ensure JS entry imports app.css exactly once via app stylesheet.
 * @param {string} consumingAppPath
 * @returns {Array}
 */
function checkEntryImportsAppCss(consumingAppPath) {
  const issues = [];
  const candidates = [
    path.join(consumingAppPath, 'src', 'main.tsx'),
    path.join(consumingAppPath, 'src', 'main.ts'),
    path.join(consumingAppPath, 'src', 'main.jsx'),
    path.join(consumingAppPath, 'src', 'main.js'),
  ];
  for (const file of candidates) {
    if (!fs.existsSync(file)) continue;
    const text = readFileSafe(file);
    if (!text) continue;
    const rel = getRelativePath(file, consumingAppPath);
    const hasAppCssImport = /import\s+['"]\.\/app\.css['"]/.test(text) || /import\s+['"]\.\/[^'"]*app\.css['"]/.test(text);

    if (!hasAppCssImport) {
      issues.push({
        type: 'appCss',
        file: rel,
        line: 1,
        message: 'Main entry does not import app.css. pace-core styling must flow through app.css.',
        severity: 'error',
        fix: 'Add `import "./app.css";` in the JS/TS entry file used for rendering the app.',
        standardSection: STANDARD_PART_A,
      });
    }
  }
  return issues;
}

/**
 * Check app.css structure and required imports
 */
function checkAppCssStructure(consumingAppPath) {
  const issues = [];
  
  // Find app.css
  const appCssFiles = [
    path.join(consumingAppPath, 'src', 'app.css'),
    path.join(consumingAppPath, 'app.css'),
  ];
  
  let appCssFile = null;
  for (const file of appCssFiles) {
    if (fs.existsSync(file)) {
      appCssFile = file;
      break;
    }
  }
  
  if (!appCssFile) {
    issues.push({
      type: 'appCss',
      file: 'src/app.css (not found)',
      line: 0,
      message: 'app.css file not found. Required for pace-core styling.',
      severity: 'error',
      fix: 'Create src/app.css with required imports and @source directives',
      standardSection: STANDARD_PART_A,
    });
    return issues;
  }
  
  const content = readFileSafe(appCssFile);
  if (!content) {
    return issues;
  }
  
  const relativePath = getRelativePath(appCssFile, consumingAppPath);

  if (
    /@import\s+['"][^'"]*@solvera\/pace-core\/src\//.test(content) ||
    /@import\s+['"][^'"]*pace-core\/src\/styles/.test(content)
  ) {
    issues.push({
      type: 'appCss',
      file: relativePath,
      line: 1,
      message:
        'Wrong pace-core CSS import path. Use @import "@solvera/pace-core/styles/core.css"; (not a /src/styles/ path inside the package).',
      severity: 'error',
      fix: 'Replace with @import "@solvera/pace-core/styles/core.css"; per 7-visual-standards.md Part A.',
      standardSection: STANDARD_PART_A,
    });
  }
  
  // Check for required imports
  const requiredImports = [
    { pattern: /@import\s+['"]tailwindcss['"]/, name: '@import "tailwindcss"', required: true },
    { pattern: /@import\s+['"]@solvera\/pace-core\/styles\/core\.css['"]/, name: '@import "@solvera/pace-core/styles/core.css"', required: true },
  ];
  
  requiredImports.forEach(({ pattern, name, required }) => {
    if (!pattern.test(content)) {
      issues.push({
        type: 'appCss',
        file: relativePath,
        line: 1,
        message: `Missing required import: ${name}`,
        severity: required ? 'error' : 'warning',
        fix: `Add ${name}; to app.css`,
        standardSection: STANDARD_PART_A,
      });
    }
  });
  
  // Check for @source directives (Tailwind v4)
  const hasSourceDirective = /@source\s+/.test(content);
  if (!hasSourceDirective) {
    issues.push({
      type: 'appCss',
      file: relativePath,
      line: 1,
      message: 'Missing @source directives for Tailwind v4 content scanning',
      severity: 'error',
      fix: 'Add @source directives: @source "./**/*.{js,ts,jsx,tsx}"; @source "../node_modules/@solvera/pace-core/src/**/*.{js,ts,jsx,tsx}";',
      standardSection: STANDARD_PART_A,
    });
  } else {
    // Check for correct @source paths (relative to CSS file location)
    const sourcePattern = /@source\s+['"]([^'"]+)['"]/g;
    let match;
    const foundSources = [];
    
    while ((match = sourcePattern.exec(content)) !== null) {
      foundSources.push(match[1]);
    }
    
    // Check if app source files are included
    const hasAppSource = foundSources.some(src => src.includes('./**/*.') || src.includes('../src/**/*.'));
    if (!hasAppSource) {
      issues.push({
        type: 'appCss',
        file: relativePath,
        line: 1,
        message: '@source directive missing for app source files',
        severity: 'error',
        fix: 'Add: @source "./**/*.{js,ts,jsx,tsx}"; (if app.css is in src/)',
        standardSection: STANDARD_PART_A,
      });
    }

    // Check if pace-core source files are included (package path or monorepo packages/core)
    const hasPaceCoreSource = foundSources.some(src => src.includes('@solvera/pace-core') || src.includes('pace-core/src') || src.includes('packages/core/src'));
    if (!hasPaceCoreSource) {
      issues.push({
        type: 'appCss',
        file: relativePath,
        line: 1,
        message: '@source directive missing for pace-core source files',
        severity: 'error',
        fix: 'Add: @source "../node_modules/@solvera/pace-core/src/**/*.{js,ts,jsx,tsx}"; (if app.css is in src/)',
        standardSection: STANDARD_PART_A,
      });
    }
  }
  
  // Check for @theme block (required for color palettes)
  const hasThemeBlock = /@theme\s+(static|inline)?\s*\{/.test(content);
  if (!hasThemeBlock) {
    issues.push({
      type: 'appCss',
      file: relativePath,
      line: 1,
      message: 'Missing @theme block for color palettes. Required for pace-core styling.',
      severity: 'error',
      fix: 'Add @theme static { /* color palettes here */ } block to app.css',
      standardSection: STANDARD_PART_A,
    });
  } else {
    const themeBody = extractAtThemeBody(content);
    if (!themeBody) {
      issues.push({
        type: 'appCss',
        file: relativePath,
        line: 1,
        message: 'Could not parse @theme block body (check balanced braces).',
        severity: 'warning',
        fix: 'Ensure @theme static { ... } is well-formed.',
        standardSection: STANDARD_PART_A,
      });
    } else {
      validatePaletteCompleteness(themeBody, relativePath, issues);
    }
  }

  issues.push(...checkEntryImportsNoDirectCoreCss(consumingAppPath));
  issues.push(...checkEntryImportsAppCss(consumingAppPath));

  return issues;
}

/**
 * pace-core package only: custom classes and CSS variables must be kebab-case.
 * @param {string} consumingAppPath
 * @returns {Array}
 */
function checkCoreCssNaming(consumingAppPath) {
  const issues = [];
  const coreCssCandidates = [
    path.join(consumingAppPath, 'src', 'styles', 'core.css'),
    path.join(consumingAppPath, 'dist', 'styles', 'core.css'),
  ];
  let coreCssFile = null;
  for (const candidate of coreCssCandidates) {
    if (fs.existsSync(candidate)) {
      coreCssFile = candidate;
      break;
    }
  }
  if (!coreCssFile) return issues;

  const content = readFileSafe(coreCssFile);
  if (!content) return issues;

  const relativePath = getRelativePath(coreCssFile, consumingAppPath);
  const contentWithoutComments = content.replace(/\/\*[\s\S]*?\*\//g, '');
  const customPropPattern = /--[a-zA-Z0-9_-]+/g;
  let propMatch;
  while ((propMatch = customPropPattern.exec(contentWithoutComments)) !== null) {
    const fullName = propMatch[0];
    if (fullName.endsWith('-')) continue;
    if (!isKebabCssName(fullName)) {
      issues.push({
        type: 'cssNaming',
        file: relativePath,
        line: 1,
        message: `Custom property "${fullName}" must use kebab-case`,
        severity: 'warning',
        fix: 'Rename to kebab-case (e.g. --color-main-500, --print-event-name)',
        standardSection: '7-visual-standards.md — CSS naming',
      });
    }
  }

  const classPattern = /\.([a-zA-Z_][a-zA-Z0-9_-]*)/g;
  let classMatch;
  while ((classMatch = classPattern.exec(content)) !== null) {
    const className = classMatch[1];
    if (className.startsWith('pace-') || /^[a-z]/.test(className)) {
      if (!isKebabCssName(className)) {
        issues.push({
          type: 'cssNaming',
          file: relativePath,
          line: 1,
          message: `Custom class ".${className}" must use kebab-case`,
          severity: 'warning',
          fix: 'Use kebab-case custom classes (e.g. pace-background)',
          standardSection: '7-visual-standards.md — CSS naming',
        });
      }
    }
  }

  return issues;
}

/**
 * Check Tailwind v4 configuration in vite.config.ts
 */
function checkTailwindV4Config(consumingAppPath) {
  const issues = [];
  
  const viteConfigFiles = findConfigFiles(consumingAppPath, ['vite.config.ts', 'vite.config.js']);
  const viteConfigPath = viteConfigFiles['vite.config.ts'] || viteConfigFiles['vite.config.js'];
  
  if (!viteConfigPath) {
    return issues; // No vite config, skip
  }
  
  const content = readFileSafe(viteConfigPath);
  if (!content) {
    return issues;
  }
  
  const relativePath = getRelativePath(viteConfigPath, consumingAppPath);
  
  // Check for @tailwindcss/vite plugin
  const hasTailwindPlugin = /@tailwindcss\/vite|tailwindcss\(\)|from\s+['"]@tailwindcss\/vite['"]/.test(content);
  if (!hasTailwindPlugin) {
    issues.push({
      type: 'tailwindConfig',
      file: relativePath,
      line: 1,
      message: 'Tailwind v4 plugin not found in vite.config.ts. Required for Tailwind v4.',
      severity: 'error',
      fix: 'Add: import tailwindcss from "@tailwindcss/vite"; and add tailwindcss() to plugins array',
      standardSection: `${STANDARD_PART_A} — Vite + Tailwind v4`,
    });
  }
  
  return issues;
}

/**
 * Run audit for Standard 07 Visual (report key 07-visual)
 * @param {string} consumingAppPath - Path to consuming app
 * @param {{ isPaceCorePackage?: boolean }} [auditContext] - When isPaceCorePackage, skip app.css check (package does not have app.css)
 * @returns {object} - Audit results with issues array
 */
function runStandard5Audit(consumingAppPath, auditContext = {}) {
  const issues = [];
  const isPaceCorePackage = auditContext.isPaceCorePackage === true;

  try {
    if (!isPaceCorePackage) {
      issues.push(...checkAppCssStructure(consumingAppPath));
    } else {
      issues.push(...checkCoreCssNaming(consumingAppPath));
    }
    issues.push(...checkTailwindV4Config(consumingAppPath));
  } catch (error) {
    return {
      standard: '07-visual',
      issues: [],
      error: error.message,
    };
  }
  
  return {
    standard: '07-visual',
    issues,
    error: null,
  };
}

module.exports = { runStandard5Audit, checkCoreCssNaming };
