const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { collectPageNameIssuesFromSource } = require('../../naming/naming-by-layer.cjs');
const {
  checkRLSPolicies,
  runStandard6Audit,
  tableRequiresEventIdOnInsert,
} = require('./06-security-rbac.cjs');

function makeTempMigrationsDir() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'pace-s6-rls-audit-'));
  const migrationsDir = path.join(root, 'supabase', 'migrations');
  fs.mkdirSync(migrationsDir, { recursive: true });
  return { root, migrationsDir };
}

function makeTempAppWithPage(pageRelativePath, pageSource) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'pace-s6-page-guard-audit-'));
  const pagePath = path.join(root, 'src', pageRelativePath);
  fs.mkdirSync(path.dirname(pagePath), { recursive: true });
  fs.writeFileSync(pagePath, pageSource);
  return root;
}

function pageGuardNameIssues(auditResult) {
  return auditResult.issues.filter(
    (issue) => issue.type === 'rbacPageGuard' && /pageName/i.test(issue.message)
  );
}

const ORG_MINT_INSERT_POLICY = `
CREATE POLICY rbac_insert_mint_action_log ON mint_action_log
  FOR INSERT TO authenticated
  WITH CHECK (
    organisation_id IS NOT NULL
    AND (
      is_super_admin(safe_get_user_id_for_rls())
      OR check_rbac_permission_with_context(
        'create:page.billing-control-panel', 'billing-control-panel',
        organisation_id, NULL, get_app_id('MINT')
      )
    )
  );
`;

const EVENT_SCOPED_INSERT_POLICY = `
CREATE POLICY rbac_insert_trac_entry ON trac_entry
  FOR INSERT TO authenticated
  WITH CHECK (
    organisation_id IS NOT NULL
    AND (
      is_super_admin(safe_get_user_id_for_rls())
      OR check_rbac_permission_with_context(
        'create:page.events', 'events',
        organisation_id, event_id::text, get_app_id('TRAC')
      )
    )
  );
`;

describe('06-security-rbac pageName validation', () => {
  it('flags invalid pageName shapes', () => {
    const issues = collectPageNameIssuesFromSource(
      '<PagePermissionGuard pageName="not-valid" operation="read">',
      { legacyMode: 'reject', relativePath: 'src/pages/FooPage.tsx', fileStem: 'FooPage' }
    );
    assert.ok(issues.some((i) => i.severity === 'error'));
  });

  it('accepts PascalCase pageName', () => {
    const issues = collectPageNameIssuesFromSource(
      '<PagePermissionGuard pageName="DashboardPage" operation="read">',
      { legacyMode: 'reject', relativePath: 'src/pages/DashboardPage.tsx', fileStem: 'DashboardPage' }
    );
    assert.equal(issues.filter((i) => i.severity === 'error').length, 0);
  });
});

describe('06-security-rbac PagePermissionGuard pageName audit', () => {
  it('skips JSX expression pageName={CONSTANT.key} (no false positive)', () => {
    const root = makeTempAppWithPage(
      'app/pages/aggregation/AggregationPage.tsx',
      `export function AggregationPage() {
  return (
    <PagePermissionGuard pageName={GEAR_PAGE_NAMES.aggregation} operation="read">
      <main />
    </PagePermissionGuard>
  );
}
`
    );
    const result = runStandard6Audit(root);
    assert.equal(pageGuardNameIssues(result).length, 0);
    fs.rmSync(root, { recursive: true, force: true });
  });

  it('flags quoted legacy pageName strings', () => {
    const root = makeTempAppWithPage(
      'app/pages/aggregation/AggregationPage.tsx',
      `export function AggregationPage() {
  return (
    <PagePermissionGuard pageName="gear-aggregation" operation="read">
      <main />
    </PagePermissionGuard>
  );
}
`
    );
    const result = runStandard6Audit(root);
    assert.ok(
      result.issues.some(
        (issue) =>
          issue.type === 'legacyPageName' &&
          issue.message.includes('gear-aggregation')
      )
    );
    fs.rmSync(root, { recursive: true, force: true });
  });

  it('skips ShellLandingPage without PagePermissionGuard (BASE shell landing)', () => {
    const root = makeTempAppWithPage(
      'pages/shell/ShellLandingPage.tsx',
      `export function ShellLandingPage() {
  return <main>Events</main>;
}
`
    );
    const result = runStandard6Audit(root);
    assert.equal(
      result.issues.filter((issue) => issue.type === 'rbacPageGuard').length,
      0
    );
    fs.rmSync(root, { recursive: true, force: true });
  });

  it('flags quoted invalid pageName strings', () => {
    const root = makeTempAppWithPage(
      'app/pages/aggregation/AggregationPage.tsx',
      `export function AggregationPage() {
  return (
    <PagePermissionGuard pageName="not-valid" operation="read">
      <main />
    </PagePermissionGuard>
  );
}
`
    );
    const result = runStandard6Audit(root);
    assert.ok(pageGuardNameIssues(result).some((issue) => issue.severity === 'error'));
    fs.rmSync(root, { recursive: true, force: true });
  });
});

describe('02-project-structure naming by layer', () => {
  it('validates page file naming helper', () => {
    const { isPageFileName } = require('../../naming/naming-by-layer.cjs');
    assert.equal(isPageFileName('EventsPage.tsx'), true);
    assert.equal(isPageFileName('events-page.tsx'), false);
  });
});

describe('06-security-rbac MINT event_id INSERT heuristic', () => {
  it('tableRequiresEventIdOnInsert skips org-scoped MINT billing tables', () => {
    assert.equal(
      tableRequiresEventIdOnInsert('mint_action_log', ORG_MINT_INSERT_POLICY),
      false
    );
    assert.equal(
      tableRequiresEventIdOnInsert('mint_line_item', ORG_MINT_INSERT_POLICY),
      false
    );
  });

  it('tableRequiresEventIdOnInsert requires event_id for trac_ prefix tables', () => {
    assert.equal(
      tableRequiresEventIdOnInsert('trac_entry', EVENT_SCOPED_INSERT_POLICY),
      true
    );
  });

  it('tableRequiresEventIdOnInsert requires event_id for legacy mint_budgets', () => {
    assert.equal(
      tableRequiresEventIdOnInsert('mint_budgets', 'organisation_id IS NOT NULL'),
      true
    );
  });

  it('org-only MINT INSERT policy without event_id IS NOT NULL passes audit', () => {
    const { root, migrationsDir } = makeTempMigrationsDir();
    fs.writeFileSync(path.join(migrationsDir, '001_mint.sql'), ORG_MINT_INSERT_POLICY);
    const issues = checkRLSPolicies(root).filter(
      (i) => i.message.includes('event_id IS NOT NULL')
    );
    assert.equal(issues.length, 0);
    fs.rmSync(root, { recursive: true, force: true });
  });

  it('event-scoped INSERT without event_id IS NOT NULL still fails audit', () => {
    const { root, migrationsDir } = makeTempMigrationsDir();
    fs.writeFileSync(path.join(migrationsDir, '001_trac.sql'), EVENT_SCOPED_INSERT_POLICY);
    const issues = checkRLSPolicies(root).filter(
      (i) => i.message.includes('event_id IS NOT NULL')
    );
    assert.equal(issues.length, 1);
    assert.match(issues[0].message, /trac_entry/);
    fs.rmSync(root, { recursive: true, force: true });
  });
});
