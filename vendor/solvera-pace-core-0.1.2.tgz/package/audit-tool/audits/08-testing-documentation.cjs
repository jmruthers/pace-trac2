/**
 * Standard 8: Testing & Documentation Audit
 * @package @solvera/pace-core
 * @module Audit/Standard8
 * 
 * Audits consuming apps for compliance with Standard 8: Testing & Documentation.
 * Validates test structure, test timeout configuration, and testing tools.
 * 
 * Reference: packages/core/docs/standards/8-testing-documentation-standards.md
 */

const fs = require('fs');
const path = require('path');
const { findConfigFiles, readFileSafe, getRelativePath, findSourceFiles, directoryExists } = require('../utils/file-utils.cjs');

/**
 * Check test timeout configuration
 */
function checkTestTimeoutConfig(consumingAppPath) {
  const issues = [];
  
  // Check vitest.config.ts
  const vitestConfigFiles = findConfigFiles(consumingAppPath, ['vitest.config.ts', 'vitest.config.js']);
  const vitestConfigPath = vitestConfigFiles['vitest.config.ts'] || vitestConfigFiles['vitest.config.js'];
  
  // Also check package.json for test scripts
  const packageJsonPath = path.join(consumingAppPath, 'package.json');
  const packageJsonContent = readFileSafe(packageJsonPath);
  
  let hasTimeoutInConfig = false;
  let hasTimeoutInScripts = false;
  
  // Check vitest.config.ts
  if (vitestConfigPath) {
    const content = readFileSafe(vitestConfigPath);
    if (content) {
      const hasTestTimeout = /testTimeout\s*[:=]/.test(content);
      const hasHookTimeout = /hookTimeout\s*[:=]/.test(content);
      
      if (hasTestTimeout || hasHookTimeout) {
        hasTimeoutInConfig = true;
      } else {
        const relativePath = getRelativePath(vitestConfigPath, consumingAppPath);
        issues.push({
          type: 'testTimeout',
          file: relativePath,
          line: 1,
          message: 'vitest.config.ts missing test timeout configuration. Tests may hang indefinitely without timeouts.',
          severity: 'error',
          fix: 'Add: test: { testTimeout: 10000, hookTimeout: 10000, teardownTimeout: 5000 }',
          standardSection: 'Test Timeouts',
        });
      }
    }
  }
  
  // Check package.json scripts
  if (packageJsonContent) {
    try {
      const packageJson = JSON.parse(packageJsonContent);
      const scripts = packageJson.scripts || {};
      
      const testScripts = Object.values(scripts).filter(script => 
        typeof script === 'string' && script.includes('vitest')
      );
      
      hasTimeoutInScripts = testScripts.some(script => 
        script.includes('--test-timeout') || script.includes('testTimeout')
      );
      
      if (!hasTimeoutInConfig && !hasTimeoutInScripts && testScripts.length > 0) {
        issues.push({
          type: 'testTimeout',
          file: 'package.json',
          line: 1,
          message: 'Test scripts missing timeout configuration. Tests may hang indefinitely without timeouts.',
          severity: 'error',
          fix: 'Add --test-timeout=10000 to test scripts or configure in vitest.config.ts',
          standardSection: 'Test Timeouts',
        });
      }
    } catch (error) {
      // Skip if package.json can't be parsed
    }
  }
  
  return issues;
}

/**
 * Check testing tools (React Testing Library, userEvent, Vitest)
 */
function checkTestingTools(consumingAppPath) {
  const issues = [];
  
  const packageJsonPath = path.join(consumingAppPath, 'package.json');
  const packageJsonContent = readFileSafe(packageJsonPath);
  
  if (!packageJsonContent) {
    return issues;
  }
  
  let packageJson;
  try {
    packageJson = JSON.parse(packageJsonContent);
  } catch (error) {
    return issues;
  }
  
  const allDeps = {
    ...(packageJson.dependencies || {}),
    ...(packageJson.devDependencies || {}),
  };
  
  // Check for required testing tools
  const requiredTools = [
    { name: 'vitest', description: 'Test runner' },
    { name: '@testing-library/react', description: 'React Testing Library' },
    { name: '@testing-library/user-event', description: 'userEvent for interaction simulation' },
  ];
  
  requiredTools.forEach(({ name, description }) => {
    if (!allDeps[name]) {
      issues.push({
        type: 'testingTools',
        file: 'package.json',
        line: 1,
        message: `Missing required testing tool: ${name} (${description})`,
        severity: 'warning',
        fix: `Install: npm install --save-dev ${name}`,
        standardSection: 'Testing Tools',
      });
    }
  });
  
  return issues;
}

/**
 * Check test file structure (colocation, naming)
 */
function checkTestStructure(consumingAppPath) {
  const issues = [];
  
  const srcDir = path.join(consumingAppPath, 'src');
  if (!directoryExists(srcDir)) {
    return issues;
  }
  
  // Find all test files
  const testFiles = findSourceFiles(srcDir).filter(file => 
    file.includes('.test.') || file.includes('.spec.')
  );
  
  testFiles.forEach(testFile => {
    const content = readFileSafe(testFile);
    if (!content) {
      return;
    }
    
    const relativePath = getRelativePath(testFile, consumingAppPath);
    
    // Check if using .spec instead of .test
    if (testFile.includes('.spec.')) {
      issues.push({
        type: 'testStructure',
        file: relativePath,
        line: 1,
        message: 'Test file uses .spec extension. Should use .test extension for consistency.',
        severity: 'warning',
        fix: `Rename to ${testFile.replace('.spec.', '.test.')}`,
        standardSection: 'Test Structure / Test File Naming',
      });
    }
  });
  
  return issues;
}

/**
 * Check that coverage declares a supported provider (v8 or istanbul).
 */
function checkCoverageProvider(consumingAppPath) {
  const issues = [];
  const vitestConfigFiles = findConfigFiles(consumingAppPath, ['vitest.config.ts', 'vitest.config.js']);
  const vitestConfigPath = vitestConfigFiles['vitest.config.ts'] || vitestConfigFiles['vitest.config.js'];
  if (!vitestConfigPath) return issues;
  const content = readFileSafe(vitestConfigPath);
  if (!content || !/test\s*:\s*\{[\s\S]*?coverage\s*:/.test(content)) return issues;
  let hasIstanbul = /provider\s*:\s*['"]istanbul['"]/.test(content);
  let hasV8 = /provider\s*:\s*['"]v8['"]/.test(content);
  if (!hasIstanbul && !hasV8 && /coverageConfig/.test(content)) {
    const sharedCandidates = [
      path.join(consumingAppPath, 'vitest.shared.ts'),
      path.join(consumingAppPath, 'vitest.shared.js'),
      path.resolve(consumingAppPath, '..', '..', 'vitest.shared.ts'),
      path.resolve(consumingAppPath, '..', '..', 'vitest.shared.js'),
    ];
    for (const sharedPath of sharedCandidates) {
      const sharedContent = readFileSafe(sharedPath);
      if (!sharedContent) continue;
      hasIstanbul = hasIstanbul || /provider\s*:\s*['"]istanbul['"]/.test(sharedContent);
      hasV8 = hasV8 || /provider\s*:\s*['"]v8['"]/.test(sharedContent);
      if (hasIstanbul || hasV8) break;
    }
  }
  if (!hasIstanbul && !hasV8) {
    const relativePath = getRelativePath(vitestConfigPath, consumingAppPath);
    issues.push({
      type: 'coverageConfig',
      file: relativePath,
      line: 1,
      message: 'Set coverage.provider to "v8" (default for speed) or "istanbul" under test.coverage (see Standard 8).',
      severity: 'info',
      fix: 'Prefer provider "v8" for local/CI speed; use `test:coverage:istanbul` when Istanbul or HTML reports are required.',
      standardSection: 'Coverage setup (Vitest)',
    });
  }
  return issues;
}

/**
 * Parse domUnitTestTsFiles paths from vitest.shared.ts source.
 * @param {string} content
 * @returns {string[]}
 */
function parseDomUnitTestTsFiles(content) {
  if (!content) return [];
  const match = content.match(/export\s+const\s+domUnitTestTsFiles[^=]*=\s*\[([\s\S]*?)\];/);
  if (!match) return [];
  const bodyWithoutLineComments = match[1]
    .split('\n')
    .filter((line) => !line.trim().startsWith('//'))
    .join('\n');
  return [...bodyWithoutLineComments.matchAll(/['"]([^'"]+)['"]/g)]
    .map((entry) => entry[1])
    .filter((entry) => entry.length > 0);
}

/**
 * Check tiered test scripts in package.json.
 */
function checkTestTierScripts(consumingAppPath) {
  const issues = [];
  const packageJsonPath = path.join(consumingAppPath, 'package.json');
  const packageJsonContent = readFileSafe(packageJsonPath);
  if (!packageJsonContent) return issues;

  let packageJson;
  try {
    packageJson = JSON.parse(packageJsonContent);
  } catch {
    return issues;
  }

  const scripts = packageJson.scripts || {};
  const required = [
    { name: 'test:unit', mustInclude: 'vitest.unit.config' },
    { name: 'test:integration', mustInclude: 'vitest.integration.config' },
    { name: 'test:coverage', mustInclude: 'vitest.config' },
  ];

  for (const { name, mustInclude } of required) {
    const script = scripts[name];
    if (typeof script !== 'string' || !script.includes('vitest')) {
      issues.push({
        type: 'testTierScripts',
        file: 'package.json',
        line: 1,
        message: `Missing required script "${name}" for tiered Vitest runs (Standard 8).`,
        severity: 'error',
        fix: `Run npm run setup -- --force or add "${name}" pointing at the matching vitest config.`,
        standardSection: 'Test commands (tiered)',
      });
      continue;
    }
    if (!script.includes(mustInclude)) {
      issues.push({
        type: 'testTierScripts',
        file: 'package.json',
        line: 1,
        message: `Script "${name}" must use ${mustInclude}.ts (found: ${script}).`,
        severity: 'error',
        fix: `Update "${name}" to vitest run -c ${mustInclude}.ts`,
        standardSection: 'Test commands (tiered)',
      });
    }
  }

  return issues;
}

/**
 * Check node vs happy-dom environment split across vitest configs.
 */
function checkVitestEnvironmentSplit(consumingAppPath) {
  const issues = [];
  const mainPath = path.join(consumingAppPath, 'vitest.config.ts');
  const unitPath = path.join(consumingAppPath, 'vitest.unit.config.ts');
  const integrationPath = path.join(consumingAppPath, 'vitest.integration.config.ts');

  if (!fs.existsSync(mainPath)) {
    issues.push({
      type: 'vitestEnvironmentSplit',
      file: 'vitest.config.ts',
      line: 1,
      message: 'Missing vitest.config.ts for full test suite.',
      severity: 'error',
      fix: 'Run npm run setup -- --force to scaffold tiered Vitest configs.',
      standardSection: 'Vitest environment split (required)',
    });
    return issues;
  }

  const mainContent = readFileSafe(mainPath) || '';
  const unitContent = readFileSafe(unitPath) || '';
  const integrationContent = readFileSafe(integrationPath) || '';

  if (!/environment\s*:\s*['"]node['"]/.test(mainContent)) {
    issues.push({
      type: 'vitestEnvironmentSplit',
      file: getRelativePath(mainPath, consumingAppPath),
      line: 1,
      message: 'vitest.config.ts must default to environment: "node" for pure unit tests.',
      severity: 'error',
      fix: 'Set test.environment to "node" and route DOM tests via environmentMatchGlobs or split configs.',
      standardSection: 'Vitest environment split (required)',
    });
  }

  const hasMatchGlobs = /environmentMatchGlobs/.test(mainContent) && /happy-dom/.test(mainContent);
  const hasSplitConfigs = fs.existsSync(unitPath) && fs.existsSync(integrationPath);

  if (!hasMatchGlobs && !hasSplitConfigs) {
    issues.push({
      type: 'vitestEnvironmentSplit',
      file: getRelativePath(mainPath, consumingAppPath),
      line: 1,
      message: 'vitest.config.ts must use environmentMatchGlobs for happy-dom or provide unit/integration split configs.',
      severity: 'error',
      fix: 'Add environmentMatchGlobs for *.test.tsx and *.integration.test.*, or add vitest.unit.config.ts + vitest.integration.config.ts.',
      standardSection: 'Vitest environment split (required)',
    });
  }

  if (!fs.existsSync(unitPath)) {
    issues.push({
      type: 'vitestEnvironmentSplit',
      file: 'vitest.unit.config.ts',
      line: 1,
      message: 'Missing vitest.unit.config.ts for fast node-only unit runs.',
      severity: 'error',
      fix: 'Run npm run setup -- --force to scaffold vitest.unit.config.ts.',
      standardSection: 'Vitest environment split (required)',
    });
  } else if (!/environment\s*:\s*['"]node['"]/.test(unitContent)) {
    issues.push({
      type: 'vitestEnvironmentSplit',
      file: getRelativePath(unitPath, consumingAppPath),
      line: 1,
      message: 'vitest.unit.config.ts must use environment: "node".',
      severity: 'error',
      fix: 'Set test.environment to "node" in vitest.unit.config.ts.',
      standardSection: 'Vitest environment split (required)',
    });
  }

  if (!fs.existsSync(integrationPath)) {
    issues.push({
      type: 'vitestEnvironmentSplit',
      file: 'vitest.integration.config.ts',
      line: 1,
      message: 'Missing vitest.integration.config.ts for DOM/component test tier.',
      severity: 'error',
      fix: 'Run npm run setup -- --force to scaffold vitest.integration.config.ts.',
      standardSection: 'Vitest environment split (required)',
    });
  } else if (!/environment\s*:\s*['"]happy-dom['"]/.test(integrationContent)) {
    issues.push({
      type: 'vitestEnvironmentSplit',
      file: getRelativePath(integrationPath, consumingAppPath),
      line: 1,
      message: 'vitest.integration.config.ts must use environment: "happy-dom".',
      severity: 'error',
      fix: 'Set test.environment to "happy-dom" in vitest.integration.config.ts.',
      standardSection: 'Vitest environment split (required)',
    });
  }

  return issues;
}

/**
 * Check required test setup files exist.
 */
function checkTestSetupFiles(consumingAppPath) {
  const issues = [];
  const required = [
    'src/test-setup.ts',
    'src/test-setup-unit.ts',
    'src/test-polyfills.ts',
    'src/test-utils.ts',
  ];

  for (const relative of required) {
    const fullPath = path.join(consumingAppPath, relative);
    if (!fs.existsSync(fullPath)) {
      issues.push({
        type: 'testSetupFiles',
        file: relative,
        line: 1,
        message: `Missing required test setup file: ${relative}`,
        severity: 'error',
        fix: 'Run npm run setup -- --force to scaffold Standard 8 test setup files.',
        standardSection: 'Consuming app bootstrap checklist',
      });
    }
  }

  return issues;
}

/**
 * Check vitest.shared.ts exists and is imported by tier configs.
 */
function checkVitestSharedModule(consumingAppPath) {
  const issues = [];
  const sharedPath = path.join(consumingAppPath, 'vitest.shared.ts');
  if (!fs.existsSync(sharedPath)) {
    issues.push({
      type: 'vitestSharedModule',
      file: 'vitest.shared.ts',
      line: 1,
      message: 'Missing vitest.shared.ts for shared test includes, aliases, and runtime options.',
      severity: 'error',
      fix: 'Run npm run setup -- --force to scaffold vitest.shared.ts.',
      standardSection: 'Consuming app bootstrap checklist',
    });
    return issues;
  }

  const configFiles = ['vitest.config.ts', 'vitest.unit.config.ts', 'vitest.integration.config.ts'];
  let importCount = 0;
  for (const name of configFiles) {
    const configPath = path.join(consumingAppPath, name);
    if (!fs.existsSync(configPath)) continue;
    const content = readFileSafe(configPath) || '';
    if (/from\s+['"]\.\/vitest\.shared/.test(content)) {
      importCount++;
    }
  }

  if (importCount === 0) {
    issues.push({
      type: 'vitestSharedModule',
      file: 'vitest.shared.ts',
      line: 1,
      message: 'vitest.shared.ts is not imported by any vitest config file.',
      severity: 'error',
      fix: 'Import shared settings from ./vitest.shared.js in vitest.config.ts and tier configs.',
      standardSection: 'Consuming app bootstrap checklist',
    });
  }

  const sharedContent = readFileSafe(sharedPath) || '';
  if (!/@test-utils/.test(sharedContent)) {
    issues.push({
      type: 'vitestSharedModule',
      file: 'vitest.shared.ts',
      line: 1,
      message: 'vitest.shared.ts must define @test-utils alias for setupUser().',
      severity: 'error',
      fix: 'Add resolveAlias entry mapping @test-utils to src/test-utils.ts.',
      standardSection: 'Fast user interactions',
    });
  }

  return issues;
}

/**
 * Check happy-dom is installed.
 */
function checkHappyDomDependency(consumingAppPath) {
  const issues = [];
  const packageJsonPath = path.join(consumingAppPath, 'package.json');
  const packageJsonContent = readFileSafe(packageJsonPath);
  if (!packageJsonContent) return issues;

  let packageJson;
  try {
    packageJson = JSON.parse(packageJsonContent);
  } catch {
    return issues;
  }

  const allDeps = {
    ...(packageJson.dependencies || {}),
    ...(packageJson.devDependencies || {}),
  };

  if (!allDeps['happy-dom']) {
    issues.push({
      type: 'happyDomDependency',
      file: 'package.json',
      line: 1,
      message: 'Missing happy-dom devDependency required for DOM/integration test tier.',
      severity: 'error',
      fix: 'Run npm install --save-dev happy-dom or npm run setup to add required devDependencies.',
      standardSection: 'Vitest environment split (required)',
    });
  }

  return issues;
}

/**
 * Detect bare userEvent.setup() in test files (prefer setupUser from @test-utils).
 */
function checkPreferSetupUser(consumingAppPath) {
  const issues = [];
  const srcDir = path.join(consumingAppPath, 'src');
  if (!directoryExists(srcDir)) return issues;

  const testFiles = findSourceFiles(srcDir).filter(
    (file) => file.includes('.test.') || file.includes('.spec.')
  );

  const bareSetupPattern = /userEvent\.setup\s*\(\s*\)/;
  const allowedDelayNullPattern = /userEvent\.setup\s*\(\s*\{\s*delay\s*:\s*null\s*\}\s*\)/;

  for (const testFile of testFiles) {
    const content = readFileSafe(testFile);
    if (!content || !content.includes('userEvent.setup')) continue;
    if (allowedDelayNullPattern.test(content) && !bareSetupPattern.test(content)) continue;
    if (bareSetupPattern.test(content)) {
      issues.push({
        type: 'preferSetupUser',
        file: getRelativePath(testFile, consumingAppPath),
        line: 1,
        message: 'Use setupUser() from @test-utils instead of userEvent.setup() for fast interactions.',
        severity: 'error',
        fix: 'Import { setupUser } from "@test-utils" and replace userEvent.setup() with setupUser().',
        standardSection: 'Fast user interactions',
      });
    }
  }

  return issues;
}

/**
 * Flag .test.ts files using DOM APIs that are not in domUnitTestTsFiles allowlist.
 */
function checkDomInWrongTier(consumingAppPath) {
  const issues = [];
  const sharedPath = path.join(consumingAppPath, 'vitest.shared.ts');
  const sharedContent = readFileSafe(sharedPath) || '';
  const allowlist = new Set(parseDomUnitTestTsFiles(sharedContent));

  const srcDir = path.join(consumingAppPath, 'src');
  if (!directoryExists(srcDir)) return issues;

  const domSignals = [
    /\brender\s*\(/,
    /\brenderHook\s*\(/,
    /from\s+['"]@testing-library\/react['"]/,
  ];

  const testFiles = findSourceFiles(srcDir).filter(
    (file) => file.endsWith('.test.ts') && !file.includes('.integration.test.')
  );

  for (const testFile of testFiles) {
    const content = readFileSafe(testFile);
    if (!content) continue;
    const usesDom = domSignals.some((pattern) => pattern.test(content));
    if (!usesDom) continue;

    const relativePath = getRelativePath(testFile, consumingAppPath);
    if (allowlist.has(relativePath)) continue;

    issues.push({
      type: 'domInWrongTier',
      file: relativePath,
      line: 1,
      message:
        'This .test.ts file uses DOM/render APIs but is not in domUnitTestTsFiles. Move to .test.tsx/.integration.test.tsx or add to the allowlist in vitest.shared.ts.',
      severity: 'error',
      fix: 'Rename to .test.tsx or .integration.test.ts, or add the path to domUnitTestTsFiles in vitest.shared.ts.',
      standardSection: 'Vitest environment split (required)',
    });
  }

  return issues;
}

/**
 * Run tiered Vitest pattern checks (consuming apps only).
 */
function checkTieredVitestPattern(consumingAppPath) {
  return [
    ...checkTestTierScripts(consumingAppPath),
    ...checkVitestEnvironmentSplit(consumingAppPath),
    ...checkTestSetupFiles(consumingAppPath),
    ...checkVitestSharedModule(consumingAppPath),
    ...checkHappyDomDependency(consumingAppPath),
    ...checkPreferSetupUser(consumingAppPath),
    ...checkDomInWrongTier(consumingAppPath),
  ];
}

/**
 * Check required documentation and issue template artifacts.
 */
function checkDocumentationArtifacts(consumingAppPath, auditContext = {}) {
  const issues = [];
  const isPaceCorePackage = auditContext.isPaceCorePackage === true;
  const enforceIssueTemplates = auditContext.enforceIssueTemplates === true;
  const repoRootPath = path.resolve(consumingAppPath, '..', '..');

  const readmeCandidates = isPaceCorePackage
    ? [path.join(consumingAppPath, 'README.md'), path.join(repoRootPath, 'README.md')]
    : [path.join(consumingAppPath, 'README.md')];
  const hasReadme = readmeCandidates.some((candidatePath) => fs.existsSync(candidatePath));
  if (!hasReadme) {
    issues.push({
      type: 'documentationArtifacts',
      file: 'README.md',
      line: 1,
      message: 'Repository is missing README.md. Standard 8 expects baseline documentation for usage and maintenance.',
      severity: 'warning',
      fix: 'Add a root README.md describing setup, usage, and validation commands.',
      standardSection: 'Documentation',
    });
  }

  // Consumer apps keep requirements under app-local docs/requirements.
  // The pace-core package keeps requirements at the repository root docs/requirements.
  const requirementsCandidates = isPaceCorePackage
    ? [path.join(consumingAppPath, 'docs', 'requirements'), path.join(repoRootPath, 'docs', 'requirements')]
    : [path.join(consumingAppPath, 'docs', 'requirements')];
  const hasRequirementsDir = requirementsCandidates.some((candidatePath) => directoryExists(candidatePath));
  if (!hasRequirementsDir) {
    issues.push({
      type: 'documentationArtifacts',
      file: 'docs/requirements/ (not found)',
      line: 1,
      message: 'Missing docs/requirements directory. Standard 8 expects feature behavior to be captured in requirements docs.',
      severity: 'warning',
      fix: 'Create docs/requirements and add or update requirement documents for implemented features.',
      standardSection: 'Documentation',
    });
  }

  if (isPaceCorePackage) {
    // Canonical pace-core location is packages/core/docs/reference.
    // docs/api-reference remains accepted for backwards compatibility.
    const apiReferenceCandidates = [
      path.join(consumingAppPath, 'docs', 'reference'),
      path.join(consumingAppPath, 'docs', 'api-reference'),
      path.join(repoRootPath, 'docs', 'api-reference'),
    ];
    const hasApiReferenceDir = apiReferenceCandidates.some((candidatePath) => directoryExists(candidatePath));
    if (!hasApiReferenceDir) {
      issues.push({
        type: 'documentationArtifacts',
        file: 'docs/api-reference/ (not found)',
        line: 1,
        message: 'pace-core package is missing API reference docs. Expected packages/core/docs/reference (preferred) or docs/api-reference.',
        severity: 'error',
        fix: 'Add packages/core/docs/reference (preferred) or docs/api-reference with current public API documentation for components/hooks/utilities.',
        standardSection: 'Public API reference governance',
      });
    }
  }

  if (enforceIssueTemplates) {
    const issueTemplateDir = path.join(consumingAppPath, '.github', 'ISSUE_TEMPLATE');
    if (!directoryExists(issueTemplateDir)) {
      issues.push({
        type: 'issueTemplates',
        file: '.github/ISSUE_TEMPLATE/ (not found)',
        line: 1,
        message: 'Missing issue templates directory. Standard 8 requires bug and feature request templates.',
        severity: 'warning',
        fix: 'Add .github/ISSUE_TEMPLATE with bug and feature request templates.',
        standardSection: 'Bug Reports / Feature Requests',
      });
    } else {
      const templateFiles = fs.readdirSync(issueTemplateDir);
      const hasBugTemplate = templateFiles.some((name) => /bug/i.test(name));
      const hasFeatureTemplate = templateFiles.some((name) => /feature|enhancement/i.test(name));

      if (!hasBugTemplate) {
        issues.push({
          type: 'issueTemplates',
          file: '.github/ISSUE_TEMPLATE/',
          line: 1,
          message: 'No bug report template found in .github/ISSUE_TEMPLATE.',
          severity: 'warning',
          fix: 'Add a bug report template file (for example bug_report.md).',
          standardSection: 'Bug Reports',
        });
      }

      if (!hasFeatureTemplate) {
        issues.push({
          type: 'issueTemplates',
          file: '.github/ISSUE_TEMPLATE/',
          line: 1,
          message: 'No feature request template found in .github/ISSUE_TEMPLATE.',
          severity: 'warning',
          fix: 'Add a feature request template file (for example feature_request.md).',
          standardSection: 'Feature Requests',
        });
      }
    }
  }

  return issues;
}

/**
 * Run audit for Standard 8: Testing & Documentation
 * @param {string} consumingAppPath - Path to consuming app
 * @param {{ isPaceCorePackage?: boolean }} [auditContext] - When isPaceCorePackage, skip checkTestingTools (vitest may be at workspace root)
 * @returns {object} - Audit results with issues array
 */
function checkPaceCoreComponentTests(consumingAppPath) {
  const issues = [];
  const scriptPath = path.join(consumingAppPath, 'scripts', 'check-component-test-matrix.cjs');
  if (!fs.existsSync(scriptPath)) return issues;
  const { runComponentGovernance } = require(scriptPath);
  const componentsDir = path.join(consumingAppPath, 'src', 'components');
  const failures = runComponentGovernance(componentsDir);
  for (const message of failures) {
    issues.push({
      type: 'componentTestColocation',
      file: 'src/components',
      line: 0,
      message,
      severity: 'error',
      fix: 'Add colocated *.integration.test.tsx or *.test.ts per Standard 8 package-authoring rules.',
      standardSection: 'pace-core component test matrix',
    });
  }
  return issues;
}

function runStandard8Audit(consumingAppPath, auditContext = {}) {
  const issues = [];
  const isPaceCorePackage = auditContext.isPaceCorePackage === true;

  try {
    issues.push(...checkTestTimeoutConfig(consumingAppPath));
    if (!isPaceCorePackage) {
      issues.push(...checkTestingTools(consumingAppPath));
    }
    if (isPaceCorePackage) {
      issues.push(...checkPaceCoreComponentTests(consumingAppPath));
    }
    issues.push(...checkTestStructure(consumingAppPath));
    issues.push(...checkCoverageProvider(consumingAppPath));
    if (!isPaceCorePackage) {
      issues.push(...checkTieredVitestPattern(consumingAppPath));
    }
    issues.push(...checkDocumentationArtifacts(consumingAppPath, auditContext));
  } catch (error) {
    return {
      standard: '08-testing-documentation',
      issues: [],
      error: error.message,
    };
  }
  
  return {
    standard: '08-testing-documentation',
    issues,
    error: null,
  };
}

module.exports = {
  runStandard8Audit,
  parseDomUnitTestTsFiles,
  checkTestTierScripts,
  checkVitestEnvironmentSplit,
  checkTestSetupFiles,
  checkVitestSharedModule,
  checkHappyDomDependency,
  checkPreferSetupUser,
  checkDomInWrongTier,
  checkTieredVitestPattern,
};
