/**
 * Code Analysis Utilities for Audit Tool
 * @package @solvera/pace-core
 * @module Audit/utils/code-utils
 */

/**
 * Get line number from index in content
 * @param {string} content - File content
 * @param {number} index - Character index
 * @returns {number} - Line number (1-indexed)
 */
function getLineNumber(content, index) {
  return content.substring(0, index).split('\n').length;
}

/**
 * Get code snippet around a match for context
 * @param {string} content - File content
 * @param {number} index - Character index
 * @param {number} before - Characters before index
 * @param {number} after - Characters after index
 * @returns {string} - Code snippet
 */
function getCodeSnippet(content, index, before = 30, after = 50) {
  const start = Math.max(0, index - before);
  const end = Math.min(content.length, index + after);
  return content.substring(start, end).trim();
}

/**
 * Check if content is in a comment or string (for TypeScript/JavaScript)
 * @param {string} content - File content
 * @param {number} index - Character index
 * @returns {boolean} - True if in comment or string
 */
function isInCommentOrString(content, index) {
  const before = content.substring(0, index);
  
  // Check for line comments
  const lastLineComment = before.lastIndexOf('//');
  const lastNewline = before.lastIndexOf('\n');
  if (lastLineComment > lastNewline) {
    return true;
  }
  
  // Check for block comments
  const lastBlockCommentStart = before.lastIndexOf('/*');
  const lastBlockCommentEnd = before.lastIndexOf('*/');
  if (lastBlockCommentStart > lastBlockCommentEnd) {
    return true;
  }
  
  // Check for string literals (simple check)
  const singleQuoteMatches = [...before.matchAll(/'/g)];
  const doubleQuoteMatches = [...before.matchAll(/"/g)];
  const backtickMatches = [...before.matchAll(/`/g)];
  
  // Simple heuristic: if odd number of quotes before, might be in string
  const inSingleQuote = singleQuoteMatches.length % 2 === 1;
  const inDoubleQuote = doubleQuoteMatches.length % 2 === 1;
  const inBacktick = backtickMatches.length % 2 === 1;
  
  return inSingleQuote || inDoubleQuote || inBacktick;
}

/**
 * Check if content is in a comment or string (for SQL)
 * @param {string} content - SQL content
 * @param {number} index - Character index
 * @returns {boolean} - True if in comment or string
 */
function isInCommentOrStringSQL(content, index) {
  const before = content.substring(0, index);
  
  // Check for SQL line comments
  const lastLineComment = before.lastIndexOf('--');
  const lastNewline = before.lastIndexOf('\n');
  if (lastLineComment > lastNewline && !before.substring(lastLineComment, index).includes('\n')) {
    return true;
  }
  
  // Check for block comments
  const lastBlockCommentStart = before.lastIndexOf('/*');
  const lastBlockCommentEnd = before.lastIndexOf('*/');
  if (lastBlockCommentStart > lastBlockCommentEnd) {
    return true;
  }
  
  // Check for string literals (SQL uses single quotes)
  const singleQuoteMatches = [...before.matchAll(/'/g)];
  const inSingleQuote = singleQuoteMatches.length % 2 === 1;
  
  return inSingleQuote;
}

/**
 * Extract import statements from content
 * @param {string} content - File content
 * @returns {Array} - Array of import objects { source, specifiers, line }
 */
function parseImports(content) {
  const imports = [];
  const lines = content.split('\n');
  
  lines.forEach((line, index) => {
    // Match various import patterns
    const importPatterns = [
      /^import\s+.*\s+from\s+['"]([^'"]+)['"]/,
      /^import\s+['"]([^'"]+)['"]/,
    ];
    
    for (const pattern of importPatterns) {
      const match = line.match(pattern);
      if (match) {
        const source = match[1];
        const specifiers = [];
        
        // Try to extract named imports
        const namedMatch = line.match(/import\s+{([^}]+)}\s+from/);
        if (namedMatch) {
          namedMatch[1].split(',').forEach(spec => {
            const trimmed = spec.trim();
            if (trimmed) {
              specifiers.push(trimmed);
            }
          });
        }
        
        // Check for default import
        const defaultMatch = line.match(/import\s+(\w+)\s+from/);
        if (defaultMatch && !line.includes('{')) {
          specifiers.push('default');
        }
        
        imports.push({
          source,
          specifiers,
          line: index + 1,
          fullLine: line.trim(),
        });
        break;
      }
    }
  });
  
  return imports;
}

/**
 * Extract export statements from content
 * @param {string} content - File content
 * @returns {Array} - Array of export objects { name, type, line }
 */
function parseExports(content) {
  const exports = [];
  const lines = content.split('\n');
  
  lines.forEach((line, index) => {
    // Match export patterns
    const exportPatterns = [
      /^export\s+(?:function|const|class|interface|type)\s+(\w+)/,
      /^export\s+default\s+(?:function\s+)?(\w+)?/,
      /^export\s+{\s*(\w+)/,
    ];
    
    for (const pattern of exportPatterns) {
      const match = line.match(pattern);
      if (match) {
        const name = match[1] || 'default';
        const type = line.includes('function') ? 'function' :
                     line.includes('const') ? 'const' :
                     line.includes('class') ? 'class' :
                     line.includes('interface') ? 'interface' :
                     line.includes('type') ? 'type' :
                     'other';
        
        exports.push({
          name,
          type,
          line: index + 1,
          fullLine: line.trim(),
        });
        break;
      }
    }
  });
  
  return exports;
}

/**
 * Check if file imports from pace-core
 * @param {string} content - File content
 * @param {string} name - Component/hook/util name to check
 * @returns {boolean} - True if imports from pace-core
 */
function importsFromPaceCore(content, name) {
  const patterns = [
    new RegExp(`import\\s+.*\\b${name}\\b.*from\\s+['"]@solvera/pace-core`),
    new RegExp(`import\\s+.*\\b${name}\\b.*from\\s+['"]@solvera/pace-core/components`),
    new RegExp(`import\\s+.*\\b${name}\\b.*from\\s+['"]@solvera/pace-core/hooks`),
    new RegExp(`import\\s+.*\\b${name}\\b.*from\\s+['"]@solvera/pace-core/utils`),
    new RegExp(`import\\s+.*\\b${name}\\b.*from\\s+['"]@solvera/pace-core/rbac`),
  ];
  
  return patterns.some(pattern => pattern.test(content));
}

module.exports = {
  getLineNumber,
  getCodeSnippet,
  isInCommentOrString,
  isInCommentOrStringSQL,
  parseImports,
  parseExports,
  importsFromPaceCore,
};
