/**
 * File System Utilities for Audit Tool
 * @package @solvera/pace-core
 * @module Audit/utils/file-utils
 */

const fs = require('fs');
const path = require('path');

/**
 * Recursively find all source files matching extensions
 * @param {string} dir - Directory to search
 * @param {string[]} extensions - File extensions to match (e.g., ['.ts', '.tsx', '.js', '.jsx'])
 * @param {string[]} fileList - Accumulator for found files
 * @returns {string[]} - Array of file paths
 */
function findSourceFiles(dir, extensions = ['.ts', '.tsx', '.js', '.jsx'], fileList = []) {
  if (!fs.existsSync(dir)) {
    return fileList;
  }
  
  const files = fs.readdirSync(dir);
  
  files.forEach(file => {
    const filePath = path.join(dir, file);
    const stat = fs.statSync(filePath);
    
    if (stat.isDirectory()) {
      // Skip common build/dependency directories
      if (!['node_modules', 'dist', 'build', '.git', '.next', '.vite', 'coverage', '.turbo', '.cursor'].includes(file)) {
        findSourceFiles(filePath, extensions, fileList);
      }
    } else {
      const ext = path.extname(file);
      if (extensions.includes(ext)) {
        fileList.push(filePath);
      }
    }
  });
  
  return fileList;
}

/**
 * Recursively find all SQL files in a directory
 * @param {string} dir - Directory to search
 * @param {string[]} fileList - Accumulator for found files
 * @returns {string[]} - Array of SQL file paths
 */
function findSQLFiles(dir, fileList = []) {
  if (!fs.existsSync(dir)) {
    return fileList;
  }
  
  const files = fs.readdirSync(dir);
  
  files.forEach(file => {
    const filePath = path.join(dir, file);
    const stat = fs.statSync(filePath);
    
    if (stat.isDirectory()) {
      // Skip common build/dependency directories
      if (!['node_modules', 'dist', 'build', '.git', '.next', '.vite', 'coverage', '.turbo'].includes(file)) {
        findSQLFiles(filePath, fileList);
      }
    } else if (/\.sql$/.test(file)) {
      fileList.push(filePath);
    }
  });
  
  return fileList;
}

/**
 * Find configuration files by name
 * @param {string} dir - Directory to search
 * @param {string[]} configNames - Array of config file names to find
 * @returns {Object} - Object mapping config names to paths (or null if not found)
 */
function findConfigFiles(dir, configNames) {
  const results = {};
  
  for (const configName of configNames) {
    const possiblePaths = [
      path.join(dir, configName),
      path.join(dir, `.${configName}`),
    ];
    
    // Also check common variations
    if (configName.includes('.')) {
      const [base, ext] = configName.split('.');
      possiblePaths.push(
        path.join(dir, `${base}.js`),
        path.join(dir, `${base}.ts`),
        path.join(dir, `${base}.cjs`),
        path.join(dir, `${base}.mjs`),
        path.join(dir, `.${base}.js`),
        path.join(dir, `.${base}.ts`),
        path.join(dir, `.${base}.cjs`),
        path.join(dir, `.${base}.mjs`)
      );
    }
    
    let found = null;
    for (const configPath of possiblePaths) {
      if (fs.existsSync(configPath)) {
        found = configPath;
        break;
      }
    }
    
    results[configName] = found;
  }
  
  return results;
}

/**
 * Safely read a file with error handling
 * @param {string} filePath - Path to file
 * @returns {string|null} - File content or null if error
 */
function readFileSafe(filePath) {
  try {
    if (!fs.existsSync(filePath)) {
      return null;
    }
    return fs.readFileSync(filePath, 'utf8');
  } catch (error) {
    return null;
  }
}

/**
 * Get relative path from base path
 * @param {string} filePath - Absolute file path
 * @param {string} basePath - Base path to make relative to
 * @returns {string} - Relative path
 */
function getRelativePath(filePath, basePath) {
  try {
    return path.relative(basePath, filePath);
  } catch (error) {
    return filePath;
  }
}

/**
 * Find pace-core package.json
 * @param {string} consumingAppPath - Path to consuming app
 * @returns {string|null} - Path to pace-core package.json or null
 */
function findPaceCorePackageJson(consumingAppPath) {
  const possiblePaths = [
    path.resolve(__dirname, '../../package.json'), // From packages/core/audit-tool/utils
    path.resolve(__dirname, '../../../package.json'), // Alternative location (from root)
    path.join(consumingAppPath, 'node_modules', '@solvera', 'pace-core', 'package.json'),
  ];
  
  for (const packagePath of possiblePaths) {
    if (fs.existsSync(packagePath)) {
      return packagePath;
    }
  }
  
  return null;
}

/**
 * Check if a directory exists
 * @param {string} dirPath - Directory path
 * @returns {boolean} - True if directory exists
 */
function directoryExists(dirPath) {
  try {
    return fs.existsSync(dirPath) && fs.statSync(dirPath).isDirectory();
  } catch (error) {
    return false;
  }
}

/**
 * Check if a file exists
 * @param {string} filePath - File path
 * @returns {boolean} - True if file exists
 */
function fileExists(filePath) {
  try {
    return fs.existsSync(filePath) && fs.statSync(filePath).isFile();
  } catch (error) {
    return false;
  }
}

module.exports = {
  findSourceFiles,
  findSQLFiles,
  findConfigFiles,
  readFileSafe,
  getRelativePath,
  findPaceCorePackageJson,
  directoryExists,
  fileExists,
};
