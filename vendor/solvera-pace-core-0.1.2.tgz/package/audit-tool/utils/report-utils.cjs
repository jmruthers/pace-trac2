/**
 * Report Generation Utilities for Audit Tool
 * @package @solvera/pace-core
 * @module Audit/utils/report-utils
 */

const path = require('path');
const { STANDARD_META, STANDARD_ORDER } = require('../standard-keys.cjs');

function getDocsBaseUrl() {
  return process.env.PACE_CORE_AUDIT_DOCS_BASE_URL || 'https://github.com/solvera/pace-core/blob/main/packages/core/docs';
}

/**
 * Format a single issue for markdown report
 * @param {Object} issue - Issue object
 * @param {string} standard - Standard key (e.g., '05-pace-core-compliance')
 * @returns {string} - Formatted markdown
 */
function formatIssue(issue, standard) {
  const severity = issue.severity || 'error';
  const severityIcon = severity === 'error' ? '❌' : severity === 'warning' ? '⚠️' : 'ℹ️';
  
  let formatted = `\n#### ${severityIcon} ${issue.type || 'Issue'}\n\n`;
  
  if (issue.file) {
    formatted += `**File:** \`${issue.file}\`\n\n`;
  }
  
  if (issue.line) {
    formatted += `**Line:** ${issue.line}\n\n`;
  }
  
  if (issue.message) {
    formatted += `**Message:** ${issue.message}\n\n`;
  }
  
  if (issue.code) {
    formatted += `**Code:**\n\`\`\`\n${issue.code}\n\`\`\`\n\n`;
  }
  
  if (issue.fix) {
    formatted += `**Fix:** ${issue.fix}\n\n`;
  }
  
  if (issue.details) {
    formatted += `**Details:** ${issue.details}\n\n`;
  }
  
  if (issue.standardSection) {
    formatted += `**See standard:** ${issue.standardSection}\n\n`;
  }
  
  return formatted;
}

/**
 * Format a standard section in the report
 * @param {string} standard - Standard key (e.g., '05-pace-core-compliance')
 * @param {string} standardName - Human-readable standard name
 * @param {Array} issues - Array of issues
 * @param {string} standardDocPath - Path to standards documentation
 * @returns {string} - Formatted markdown section
 */
function formatStandardSection(standard, standardName, issues, standardDocPath) {
  if (issues.length === 0) {
    return `\n### ✅ Standard ${standard}: ${standardName}\n\nNo issues found.\n`;
  }
  
  let section = `\n### ❌ Standard ${standard}: ${standardName}\n\n`;
  section += `**Reference:** [${standardName}](${getDocsBaseUrl()}/standards/${standardDocPath})\n\n`;
  section += `**Issues Found:** ${issues.length}\n\n`;
  
  // Group issues by type
  const issuesByType = {};
  issues.forEach(issue => {
    const type = issue.type || 'other';
    if (!issuesByType[type]) {
      issuesByType[type] = [];
    }
    issuesByType[type].push(issue);
  });
  
  // Format each type group
  Object.entries(issuesByType).forEach(([type, typeIssues]) => {
    section += `\n#### ${type} (${typeIssues.length} issue${typeIssues.length > 1 ? 's' : ''})\n`;
    typeIssues.forEach(issue => {
      section += formatIssue(issue, standard);
    });
  });
  
  return section;
}

/**
 * Format dependency audit section for markdown report
 * @param {Object} dependencyResult - Dependency audit result
 * @returns {string} - Formatted markdown section
 */
function formatDependencyAuditSection(dependencyResult) {
  if (dependencyResult.error) {
    return `\n### ❌ Dependency Audit\n\n**Error:** ${dependencyResult.error}\n\n`;
  }
  
  const issues = dependencyResult.issues || {};
  const includedDeps = issues.includedDeps || [];
  const missingRequired = issues.missingRequired || [];
  const missingOptional = issues.missingOptional || [];
  const versionIssues = issues.versionIssues || [];
  const wrongLocation = issues.wrongLocation || [];
  const missingDevDeps = issues.missingDevDeps || [];
  const devVersionIssues = issues.devVersionIssues || [];
  
  const totalIssues = includedDeps.length + missingRequired.length + versionIssues.length + wrongLocation.length + missingDevDeps.length + devVersionIssues.length;
  
  if (totalIssues === 0 && missingOptional.length === 0) {
    return `\n### ✅ Dependency Audit\n\nNo issues found.\n`;
  }
  
  let section = `\n### ${totalIssues > 0 ? '❌' : '⚠️'} Dependency Audit\n\n`;
  section += `**Reference:** [Dependencies Guide](${getDocsBaseUrl()}/getting-started/dependencies.md)\n\n`;
  
  if (totalIssues > 0) {
    section += `**Issues Found:** ${totalIssues}\n\n`;
  }
  
  // Included dependencies (errors)
  if (includedDeps.length > 0) {
    section += `#### ❌ Included Dependencies (MUST REMOVE) - ${includedDeps.length} issue${includedDeps.length > 1 ? 's' : ''}\n\n`;
    section += `These packages are already included in pace-core and should NOT be installed in your app:\n\n`;
    includedDeps.forEach(issue => {
      section += `- **${issue.package}**@${issue.installed} (in ${issue.location})\n`;
      section += `  - Should NOT be installed (already included in pace-core)\n`;
      section += `  - Fix: \`npm uninstall ${issue.package}\`\n\n`;
    });
  }
  
  // Missing required dependencies (errors)
  if (missingRequired.length > 0) {
    section += `#### ❌ Missing Required Dependencies - ${missingRequired.length} issue${missingRequired.length > 1 ? 's' : ''}\n\n`;
    section += `These packages are required for pace-core to function:\n\n`;
    missingRequired.forEach(issue => {
      section += `- **${issue.package}** (required: ${issue.required})\n`;
      section += `  - Fix: \`npm install ${issue.package}@${issue.required}\`\n\n`;
    });
  }
  
  // Version issues (errors)
  if (versionIssues.length > 0) {
    section += `#### ⚠️ Version Issues - ${versionIssues.length} issue${versionIssues.length > 1 ? 's' : ''}\n\n`;
    section += `These packages have incorrect version ranges:\n\n`;
    versionIssues.forEach(issue => {
      section += `- **${issue.package}**\n`;
      section += `  - Installed: ${issue.installed}\n`;
      section += `  - Required: ${issue.required}\n`;
      section += `  - Fix: \`npm install ${issue.package}@${issue.required}\`\n\n`;
    });
  }
  
  // Wrong location (warnings)
  if (wrongLocation.length > 0) {
    section += `#### ⚠️ Wrong Location - ${wrongLocation.length} issue${wrongLocation.length > 1 ? 's' : ''}\n\n`;
    section += `These packages are in the wrong location in package.json:\n\n`;
    wrongLocation.forEach(issue => {
      section += `- **${issue.package}**\n`;
      section += `  - Currently in: ${issue.current}\n`;
      section += `  - Should be in: ${issue.shouldBe}\n`;
      section += `  - Fix: \`npm uninstall ${issue.package} && npm install -D ${issue.package}\`\n\n`;
    });
  }
  
  // Missing optional dependencies (info)
  if (missingOptional.length > 0) {
    section += `#### ℹ️ Missing Optional Dependencies - ${missingOptional.length} package${missingOptional.length > 1 ? 's' : ''}\n\n`;
    section += `These packages are optional and only needed if you use specific features:\n\n`;
    missingOptional.forEach(issue => {
      section += `- **${issue.package}** (required: ${issue.required})\n`;
      section += `  - Install only if you use this feature\n`;
      section += `  - Fix: \`npm install ${issue.package}@${issue.required}\`\n\n`;
    });
  }
  
  // Missing dev dependencies (errors)
  if (missingDevDeps.length > 0) {
    section += `#### ❌ Missing Required Dev Dependencies - ${missingDevDeps.length} issue${missingDevDeps.length > 1 ? 's' : ''}\n\n`;
    section += `These dev dependencies are required for a compatible development environment:\n\n`;
    missingDevDeps.forEach(issue => {
      section += `- **${issue.package}** (required: ${issue.required})\n`;
      section += `  - Fix: \`npm install -D ${issue.package}@${issue.required}\`\n\n`;
    });
  }
  
  // Dev version issues (errors)
  if (devVersionIssues.length > 0) {
    section += `#### ⚠️ Dev Dependency Version Issues - ${devVersionIssues.length} issue${devVersionIssues.length > 1 ? 's' : ''}\n\n`;
    section += `These dev dependencies have incorrect version ranges:\n\n`;
    devVersionIssues.forEach(issue => {
      section += `- **${issue.package}** (in ${issue.location})\n`;
      section += `  - Installed: ${issue.installed}\n`;
      section += `  - Required: ${issue.required}\n`;
      section += `  - Fix: \`npm install -D ${issue.package}@${issue.required}\`\n\n`;
    });
  }
  
  return section;
}

/**
 * Generate markdown report from audit results
 * @param {Object} results - Audit results object (standard audits)
 * @param {string} consumingAppPath - Path to consuming app
 * @param {Object} dependencyResult - Dependency audit result (optional)
 * @returns {string} - Complete markdown report
 */
function generateMarkdownReport(results, consumingAppPath, dependencyResult = null) {
  const now = new Date();
  const timestamp = now.toISOString();
  
  let report = `# pace-core Audit Report\n\n`;
  report += `**Generated:** ${timestamp}\n`;
  report += `**App Path:** ${consumingAppPath}\n\n`;
  report += `---\n\n`;
  report += `## Summary\n\n`;
  
  // Calculate totals
  let totalIssues = 0;
  const standardCounts = {};
  
  // Count issues per standard
  STANDARD_ORDER.forEach(standard => {
    const standardResult = results[standard];
    if (standardResult && standardResult.issues) {
      const count = Array.isArray(standardResult.issues) 
        ? standardResult.issues.length 
        : Object.values(standardResult.issues).flat().length;
      standardCounts[standard] = count;
      totalIssues += count;
    } else {
      standardCounts[standard] = 0;
    }
  });
  
  // Count dependency audit issues
  let dependencyIssues = 0;
  if (dependencyResult && !dependencyResult.error) {
    const depIssues = dependencyResult.issues || {};
    dependencyIssues = (depIssues.includedDeps?.length || 0) +
                      (depIssues.missingRequired?.length || 0) +
                      (depIssues.versionIssues?.length || 0) +
                      (depIssues.wrongLocation?.length || 0) +
                      (depIssues.missingDevDeps?.length || 0) +
                      (depIssues.devVersionIssues?.length || 0);
    totalIssues += dependencyIssues;
  }
  
  report += `**Total Issues:** ${totalIssues}\n\n`;
  const severitySummary = generateSummary(results).bySeverity;
  report += `**Severity Breakdown:** error=${severitySummary.error}, warning=${severitySummary.warning}, info=${severitySummary.info}\n\n`;
  report += `| Standard | Issues |\n`;
  report += `|----------|--------|\n`;
  
  // Add dependency audit to summary table first
  if (dependencyResult) {
    const depIcon = dependencyIssues === 0 ? '✅' : '❌';
    report += `| ${depIcon} Dependency Audit | ${dependencyIssues} |\n`;
  }
  
  Object.entries(standardCounts).forEach(([standard, count]) => {
    const icon = count === 0 ? '✅' : '❌';
    report += `| ${icon} ${STANDARD_META[standard].name} | ${count} |\n`;
  });
  
  report += `\n---\n\n`;
  report += `## Detailed Results\n\n`;
  
  // Add dependency audit section first
  if (dependencyResult) {
    report += formatDependencyAuditSection(dependencyResult);
  }
  
  // Generate sections for each standard
  STANDARD_ORDER.forEach(standard => {
    const standardResult = results[standard];
    if (standardResult) {
      const issues = Array.isArray(standardResult.issues) 
        ? standardResult.issues 
        : Object.values(standardResult.issues || {}).flat();
      
      report += formatStandardSection(
        standard,
        STANDARD_META[standard].name,
        issues,
        STANDARD_META[standard].docPath
      );
    }
  });
  
  report += `\n---\n\n`;
  report += `## Next Steps\n\n`;
  
  if (totalIssues === 0) {
    report += `✅ All audits passed! Your app is compliant with pace-core standards.\n\n`;
  } else {
    report += `Please review the issues above and address them according to the referenced standards.\n\n`;
    report += `For more information, see the [pace-core Standards Documentation](${getDocsBaseUrl()}/standards/README.md).\n\n`;
  }
  
  return report;
}

/**
 * Generate summary statistics
 * @param {Object} results - Audit results object
 * @returns {Object} - Summary object with counts
 */
function generateSummary(results) {
  const summary = {
    total: 0,
    byStandard: {},
    bySeverity: { error: 0, warning: 0, info: 0 },
  };
  
  STANDARD_ORDER.forEach(standard => {
    const standardResult = results[standard];
    if (standardResult && standardResult.issues) {
      const issues = Array.isArray(standardResult.issues) 
        ? standardResult.issues 
        : Object.values(standardResult.issues || {}).flat();
      
      const count = issues.length;
      summary.byStandard[standard] = count;
      summary.total += count;
      
      // Count by severity
      issues.forEach(issue => {
        const severity = issue.severity || 'error';
        if (summary.bySeverity[severity] !== undefined) {
          summary.bySeverity[severity]++;
        }
      });
    } else {
      summary.byStandard[standard] = 0;
    }
  });
  
  return summary;
}

module.exports = {
  formatIssue,
  formatStandardSection,
  formatDependencyAuditSection,
  generateMarkdownReport,
  generateSummary,
};
