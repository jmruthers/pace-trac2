/**
 * Canonical standard keys aligned to docs/standards numbering.
 * These keys are used for audit result sections and report output.
 */

const STANDARD_KEYS = {
  projectStructure: '01-project-structure',
  architecture: '02-architecture',
  securityRbac: '03-security-rbac',
  apiTechStack: '04-api-tech-stack',
  paceCoreCompliance: '05-pace-core-compliance',
  codeQuality: '06-code-quality',
  visual: '07-visual',
  testingDocumentation: '08-testing-documentation',
  operations: '09-operations',
};

const STANDARD_META = {
  [STANDARD_KEYS.projectStructure]: {
    name: 'Project Structure',
    docPath: '1-project-structure-standards.md',
  },
  [STANDARD_KEYS.architecture]: {
    name: 'Architecture',
    docPath: '2-architecture-standards.md',
  },
  [STANDARD_KEYS.securityRbac]: {
    name: 'Security & RBAC',
    docPath: '3-security-rbac-standards.md',
  },
  [STANDARD_KEYS.apiTechStack]: {
    name: 'API & Tech Stack',
    docPath: '4-api-tech-stack-standards.md',
  },
  [STANDARD_KEYS.paceCoreCompliance]: {
    name: 'pace-core Compliance',
    docPath: '5-pace-core-compliance-standards.md',
  },
  [STANDARD_KEYS.codeQuality]: {
    name: 'Code Quality',
    docPath: '6-code-quality-standards.md',
  },
  [STANDARD_KEYS.visual]: {
    name: 'Visual',
    docPath: '7-visual-standards.md',
  },
  [STANDARD_KEYS.testingDocumentation]: {
    name: 'Testing & Documentation',
    docPath: '8-testing-documentation-standards.md',
  },
  [STANDARD_KEYS.operations]: {
    name: 'Operations',
    docPath: '9-operations-standards.md',
  },
};

const STANDARD_ORDER = [
  STANDARD_KEYS.projectStructure,
  STANDARD_KEYS.architecture,
  STANDARD_KEYS.securityRbac,
  STANDARD_KEYS.apiTechStack,
  STANDARD_KEYS.paceCoreCompliance,
  STANDARD_KEYS.codeQuality,
  STANDARD_KEYS.visual,
  STANDARD_KEYS.testingDocumentation,
  STANDARD_KEYS.operations,
];

module.exports = {
  STANDARD_KEYS,
  STANDARD_META,
  STANDARD_ORDER,
};
