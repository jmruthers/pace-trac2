import path from 'path';
import { fileURLToPath } from 'url';

const repoRoot = path.dirname(fileURLToPath(import.meta.url));

/**
 * `.test.ts` files that use renderHook, document, or DOM APIs and require happy-dom.
 * Add paths relative to project root when a hook unit test needs DOM.
 */
export const domUnitTestTsFiles: string[] = [
  // Example: 'src/hooks/useMyHook.test.ts',
];

export const resolveAlias = {
  '@test-utils': path.resolve(repoRoot, 'src/test-utils.ts'),
  '@': path.resolve(repoRoot, './src'),
};

/** Standard 8 pace-core critical paths enforced at 100% during `npm run test:coverage`. */
export const criticalPathCoverageThresholds = {
  'src/providers/UnifiedAuthProvider.tsx': { statements: 100, lines: 100, branches: 100 },
} as const;

export const coverageConfig = {
  provider: 'v8' as const,
  reporter: ['text', 'html'],
  include: ['src/**/*.ts', 'src/**/*.tsx'],
  exclude: [
    '**/*.test.ts',
    '**/*.test.tsx',
    '**/*.integration.test.ts',
    '**/*.integration.test.tsx',
    '**/*.spec.ts',
    '**/index.ts',
    '**/dist/**',
    '**/coverage/**',
    '**/node_modules/**',
    'src/main.tsx',
  ],
  thresholds: {
    'src/utils/**/*.ts': { statements: 90, lines: 90 },
    'src/hooks/**/*.{ts,tsx}': { statements: 90, lines: 90 },
    'src/components/**/*.tsx': { statements: 70, lines: 70 },
    ...criticalPathCoverageThresholds,
  },
};

export const sharedTestOptions = {
  pool: 'threads' as const,
  testTimeout: 10000,
  hookTimeout: 10000,
  teardownTimeout: 5000,
  globals: false,
  css: false,
  onConsoleLog(log: string, type: 'stdout' | 'stderr') {
    if (type === 'stderr' && /not wrapped in act(\(\.\.\.\))?/i.test(log)) {
      throw new Error(`React act warning:\n${log}`);
    }
    return true;
  },
  deps: {
    optimizer: {
      web: {
        include: ['react', 'react-dom', '@testing-library/react', '@testing-library/user-event'],
      },
    },
  },
};

export const unitInclude = ['src/**/*.test.ts', 'src/**/*.spec.ts'];

export const unitExclude = [
  '**/*.integration.test.ts',
  '**/*.integration.test.tsx',
  ...domUnitTestTsFiles,
];

export const domInclude = [
  'src/**/*.test.tsx',
  'src/**/*.spec.tsx',
  'src/**/*.integration.test.ts',
  'src/**/*.integration.test.tsx',
  ...domUnitTestTsFiles,
];
