import userEvent from '@testing-library/user-event';
import { act } from '@testing-library/react';

/** Fast userEvent for integration tests (no artificial typing delay). */
export function setupUser() {
  return userEvent.setup({ delay: null });
}

/** Flush async React updates from effects and resolved promises inside act. */
export async function settleAsyncUpdates() {
  await act(async () => {
    await new Promise<void>((resolve) => {
      setTimeout(resolve, 0);
    });
  });
}
