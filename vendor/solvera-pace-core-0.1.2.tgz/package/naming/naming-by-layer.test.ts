import { describe, expect, it } from 'vitest';
import { createRequire } from 'node:module';
import fs from 'node:fs';
import path from 'node:path';

const require = createRequire(import.meta.url);
const {
  isLegacyPageName,
  isPascalCasePageName,
  isKebabRouteSegment,
  validateRoutePath,
  isPageFileName,
  isKebabPublicAssetFilename,
  validatePageName,
  isValidNewMigrationPageName,
  collectPageNameIssuesFromSource,
  getLegacyMigrationTarget,
  appPublicLogoPath,
  appPublicLogoRelativePath,
  isLegacyUnderscoreAppLogoFilename,
  collectAppPublicLogoIssues,
} = require('./naming-by-layer.cjs');

describe('naming-by-layer', () => {
  it('recognises legacy catalogue strings', () => {
    expect(isLegacyPageName('dashboard')).toBe(true);
    expect(isLegacyPageName('CommsLog')).toBe(true);
    expect(isLegacyPageName('DashboardPage')).toBe(false);
  });

  it('validates PascalCase page names', () => {
    expect(isPascalCasePageName('DashboardPage')).toBe(true);
    expect(isPascalCasePageName('dashboard')).toBe(false);
    expect(isPascalCasePageName('MemberRolesPage')).toBe(true);
  });

  it('validates kebab route segments', () => {
    expect(isKebabRouteSegment('member-roles')).toBe(true);
    expect(isKebabRouteSegment(':eventSlug')).toBe(true);
    expect(isKebabRouteSegment('MemberRoles')).toBe(false);
    expect(isKebabRouteSegment('member_roles')).toBe(false);
  });

  it('validates full route paths', () => {
    expect(validateRoutePath('/member-roles/edit').ok).toBe(true);
    expect(validateRoutePath('/MemberRoles').ok).toBe(false);
  });

  it('accepts catch-all route paths', () => {
    expect(validateRoutePath('*').ok).toBe(true);
    expect(validateRoutePath('/*').ok).toBe(true);
  });

  it('validates page file names', () => {
    expect(isPageFileName('DashboardPage.tsx')).toBe(true);
    expect(isPageFileName('events-page.tsx')).toBe(false);
  });

  it('allowlists platform-mandated public asset filenames', () => {
    expect(isKebabPublicAssetFilename('org-logo.svg')).toBe(true);
    expect(isKebabPublicAssetFilename('favicon.ico')).toBe(true);
    expect(isKebabPublicAssetFilename('.htaccess')).toBe(true);
    expect(isKebabPublicAssetFilename('_redirects')).toBe(true);
    expect(isKebabPublicAssetFilename('trac_logo.svg')).toBe(false);
  });

  it('builds canonical app public logo paths', () => {
    expect(appPublicLogoPath('TEAM', 'logo-square')).toBe('/logos/team-logo-square.svg');
    expect(appPublicLogoRelativePath('BASE', 'favicon')).toBe('logos/base-favicon.svg');
  });

  it('flags legacy underscore app logo filenames', () => {
    expect(isLegacyUnderscoreAppLogoFilename('base_logo_square.svg', 'base')).toBe(true);
    expect(isLegacyUnderscoreAppLogoFilename('base-logo-square.svg', 'base')).toBe(false);
  });

  it('collects missing required logo assets', () => {
    const tmpDir = path.join(process.cwd(), 'tmp-logo-audit-test');
    const logosDir = path.join(tmpDir, 'logos');
    fs.mkdirSync(logosDir, { recursive: true });
    fs.writeFileSync(path.join(logosDir, 'team-logo-square.svg'), '<svg></svg>');
    const issues = collectAppPublicLogoIssues(logosDir, 'TEAM');
    expect(issues.some((i) => i.severity === 'error' && i.message.includes('team-favicon.svg'))).toBe(true);
    fs.rmSync(tmpDir, { recursive: true, force: true });
  });

  it('accepts a complete required logo set', () => {
    const tmpDir = path.join(process.cwd(), 'tmp-logo-audit-complete');
    const logosDir = path.join(tmpDir, 'logos');
    fs.mkdirSync(logosDir, { recursive: true });
    for (const name of ['team-favicon.svg', 'team-logo-wide.svg', 'team-logo-square.svg']) {
      fs.writeFileSync(path.join(logosDir, name), '<svg></svg>');
    }
    const issues = collectAppPublicLogoIssues(logosDir, 'TEAM');
    expect(issues.filter((i) => i.severity === 'error')).toHaveLength(0);
    fs.rmSync(tmpDir, { recursive: true, force: true });
  });

  it('accepts canonical pageName with matching stem', () => {
    const result = validatePageName('DashboardPage', { fileStem: 'DashboardPage', legacyMode: 'reject' });
    expect(result.ok).toBe(true);
    expect(result.kind).toBe('canonical');
  });

  it('allows interim shared DashboardPage on event pages', () => {
    const result = validatePageName('DashboardPage', {
      fileStem: 'EventHubPage',
      legacyMode: 'reject',
    });
    expect(result.ok).toBe(true);
    expect(result.kind).toBe('interim-shared');
  });

  it('warns on legacy pageName during transition', () => {
    const result = validatePageName('dashboard', { legacyMode: 'allow-warn' });
    expect(result.ok).toBe(true);
    expect(result.warn).toBe(true);
    expect(getLegacyMigrationTarget('dashboard')).toBe('DashboardPage');
  });

  it('rejects legacy pageName in strict mode', () => {
    const result = validatePageName('dashboard', { legacyMode: 'reject' });
    expect(result.ok).toBe(false);
  });

  it('requires PascalCase for new migration inserts', () => {
    expect(isValidNewMigrationPageName('DashboardPage')).toBe(true);
    expect(isValidNewMigrationPageName('dashboard')).toBe(false);
  });

  it('collects invalid pageName from source', () => {
    const issues = collectPageNameIssuesFromSource(
      '<PagePermissionGuard pageName="dashboard" operation="read">',
      { legacyMode: 'reject', relativePath: 'src/pages/DashboardPage.tsx', fileStem: 'DashboardPage' }
    );
    expect(issues.some((i) => i.severity === 'error')).toBe(true);
  });
});
