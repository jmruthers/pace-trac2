/**
 * Shared naming-by-layer validators (Standard 1 — Naming by layer).
 * Consumed by audit tool, ESLint rules, and offline drift scripts.
 *
 * @package @solvera/pace-core
 */

const fs = require('fs');
const path = require('path');
const legacyData = require('./legacy-rbac-page-names.json');

/** Migrations on or after this version must insert PascalCase rbac_app_pages.page_name. */
const NAMING_MIGRATION_ENFORCE_VERSION = '20260610130000';

const PASCAL_PAGE_NAME_RE = /^[A-Z][a-zA-Z0-9]*Page$/;
const KEBAB_SEGMENT_RE = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
const KEBAB_BASENAME_RE = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;

const PUBLIC_ASSET_ALLOWLIST = new Set([
  'favicon.ico',
  'robots.txt',
  // Platform-mandated SPA routing filenames (Apache, Netlify); cannot be kebab-cased.
  '.htaccess',
  '_redirects',
]);

/** Canonical consuming-app logo variants under `public/logos/` (Standard 1 + CR05c/CR06). */
const APP_PUBLIC_LOGO_VARIANTS = ['favicon', 'logo-wide', 'logo-square', 'wordmark', 'avatar'];

const APP_PUBLIC_LOGO_REQUIRED_VARIANTS = ['favicon', 'logo-wide', 'logo-square'];

const APP_PUBLIC_LOGO_OPTIONAL_VARIANTS = ['wordmark', 'avatar'];

const APP_PUBLIC_LOGO_VARIANT_FILENAME = {
  favicon: 'favicon',
  'logo-wide': 'logo-wide',
  'logo-square': 'logo-square',
  wordmark: 'wordmark',
  avatar: 'avatar',
};

function normalizeAppSlug(appName) {
  return String(appName).trim().toLowerCase();
}

/**
 * Relative path under `public/` for a canonical app logo asset.
 * @param {string} appName
 * @param {string} variant
 */
function appPublicLogoRelativePath(appName, variant) {
  const appSlug = normalizeAppSlug(appName);
  const filename = APP_PUBLIC_LOGO_VARIANT_FILENAME[variant];
  if (!filename) {
    throw new Error(`Unknown app public logo variant: ${variant}`);
  }
  return `logos/${appSlug}-${filename}.svg`;
}

/**
 * Public URL path served from `public/logos/`.
 * @param {string} appName
 * @param {string} variant
 */
function appPublicLogoPath(appName, variant) {
  return `/${appPublicLogoRelativePath(appName, variant)}`;
}

/**
 * @param {string} filename
 * @param {string} appSlug
 */
function isLegacyUnderscoreAppLogoFilename(filename, appSlug) {
  if (!filename.endsWith('.svg')) return false;
  const basename = filename.slice(0, -4);
  const legacyPrefix = `${appSlug}_`;
  return basename.startsWith(legacyPrefix) && basename.includes('_');
}

/**
 * Walk src tree and return first canonical uppercase APP_NAME literal.
 * @param {string} srcDir
 * @param {typeof fs} fsModule
 */
function collectAppNameFromSource(srcDir, fsModule = fs) {
  if (!fsModule.existsSync(srcDir)) return null;

  const stack = [srcDir];
  while (stack.length > 0) {
    const current = stack.pop();
    const entries = fsModule.readdirSync(current, { withFileTypes: true });
    for (const entry of entries) {
      if (entry.name === 'node_modules') continue;
      const abs = path.join(current, entry.name);
      if (entry.isDirectory()) {
        stack.push(abs);
        continue;
      }
      if (!/\.(tsx?|jsx?)$/.test(entry.name)) continue;
      let text = '';
      try {
        text = fsModule.readFileSync(abs, 'utf8');
      } catch {
        continue;
      }
      const appNameMatches = text.match(/APP_NAME\s*=\s*['"]([^'"]+)['"]/g) || [];
      for (const match of appNameMatches) {
        const valueMatch = match.match(/['"]([^'"]+)['"]/);
        if (!valueMatch) continue;
        const value = valueMatch[1];
        if (/^[A-Z0-9_]+$/.test(value)) {
          return value;
        }
      }
    }
  }
  return null;
}

/**
 * @param {string} logosDir absolute path to public/logos
 * @param {string} appName
 * @param {{ fsModule?: typeof fs }} [options]
 */
function collectAppPublicLogoIssues(logosDir, appName, options = {}) {
  const fsModule = options.fsModule || fs;
  const issues = [];
  const appSlug = normalizeAppSlug(appName);

  if (!fsModule.existsSync(logosDir)) {
    issues.push({
      type: 'appPublicLogo',
      severity: 'error',
      message: `Missing public/logos directory for APP_NAME "${appName}"`,
      fix: 'Create public/logos/ and add canonical kebab-case logo files',
    });
    return issues;
  }

  const entries = fsModule.readdirSync(logosDir, { withFileTypes: true });
  const filenames = entries.filter((e) => e.isFile()).map((e) => e.name);

  for (const filename of filenames) {
    if (isLegacyUnderscoreAppLogoFilename(filename, appSlug)) {
      const canonical = appPublicLogoRelativePath(appName, inferVariantFromLegacyFilename(filename, appSlug));
      issues.push({
        type: 'appPublicLogo',
        severity: 'error',
        message: `Legacy underscore logo "${filename}" must be renamed to kebab-case (e.g. ${canonical})`,
        file: `public/logos/${filename}`,
        fix: `Rename to ${canonical.split('/').pop()}`,
      });
    }
  }

  for (const variant of APP_PUBLIC_LOGO_REQUIRED_VARIANTS) {
    const relative = appPublicLogoRelativePath(appName, variant);
    const filename = relative.split('/').pop();
    if (!filenames.includes(filename)) {
      issues.push({
        type: 'appPublicLogo',
        severity: 'error',
        message: `Missing required logo asset public/${relative} for APP_NAME "${appName}"`,
        file: `public/${relative}`,
        fix: `Add public/${relative} (via appPublicLogoPath contract)`,
      });
    }
  }

  const hasAnyOptionalVariant = APP_PUBLIC_LOGO_OPTIONAL_VARIANTS.some((variant) => {
    const filename = appPublicLogoRelativePath(appName, variant).split('/').pop();
    return filenames.includes(filename);
  });
  const hasOtherLogoAssets = filenames.some(
    (name) => name.endsWith('.svg') && name.startsWith(`${appSlug}-`)
  );

  if (hasOtherLogoAssets || hasAnyOptionalVariant) {
    for (const variant of APP_PUBLIC_LOGO_OPTIONAL_VARIANTS) {
      const relative = appPublicLogoRelativePath(appName, variant);
      const filename = relative.split('/').pop();
      if (!filenames.includes(filename)) {
        issues.push({
          type: 'appPublicLogo',
          severity: 'warning',
          message: `Missing optional logo asset public/${relative} for APP_NAME "${appName}"`,
          file: `public/${relative}`,
          fix: `Add public/${relative} for full brand asset set`,
        });
      }
    }
  }

  return issues;
}

/**
 * @param {string} filename
 * @param {string} appSlug
 */
function inferVariantFromLegacyFilename(filename, appSlug) {
  const basename = filename.slice(0, -4);
  const rest = basename.slice(appSlug.length + 1);
  const legacyToVariant = {
    favicon: 'favicon',
    logo_wide: 'logo-wide',
    logo_square: 'logo-square',
    wordmark: 'wordmark',
    avatar: 'avatar',
  };
  return legacyToVariant[rest] || 'logo-square';
}

function buildLegacySet() {
  const set = new Set(legacyData.global);
  for (const names of Object.values(legacyData.appExtensions || {})) {
    for (const name of names) {
      set.add(name);
    }
  }
  return set;
}

const LEGACY_PAGE_NAMES = buildLegacySet();

function isLegacyPageName(name) {
  return LEGACY_PAGE_NAMES.has(name);
}

function getLegacyMigrationTarget(name) {
  return legacyData.migratedTo?.[name] ?? null;
}

function isPascalCasePageName(name) {
  return PASCAL_PAGE_NAME_RE.test(name);
}

function isKebabRouteSegment(segment) {
  if (!segment || segment.length === 0) return true;
  if (segment === '*') return true;
  if (segment.startsWith(':')) return true;
  return KEBAB_SEGMENT_RE.test(segment) && !segment.includes('_');
}

function parseRoutePath(pathValue) {
  if (typeof pathValue !== 'string') return [];
  return pathValue.split('/').filter(Boolean);
}

function validateRoutePath(pathValue) {
  if (pathValue === '*' || pathValue === '/*') {
    return { ok: true };
  }
  const segments = parseRoutePath(pathValue);
  const invalid = segments.filter((seg) => !isKebabRouteSegment(seg));
  if (invalid.length === 0) {
    return { ok: true };
  }
  return {
    ok: false,
    message: `Route path "${pathValue}" has non-kebab static segments: ${invalid.join(', ')}`,
    invalidSegments: invalid,
  };
}

function isPageFileName(filename) {
  const base = filename.replace(/\.(tsx?|jsx?)$/, '');
  return /^[A-Z][a-zA-Z0-9]*Page$/.test(base);
}

function isKebabPublicAssetFilename(filename) {
  if (PUBLIC_ASSET_ALLOWLIST.has(filename)) return true;
  const dot = filename.lastIndexOf('.');
  const basename = dot === -1 ? filename : filename.slice(0, dot);
  return KEBAB_BASENAME_RE.test(basename);
}

function isKebabCaseCatalogueSlug(name) {
  return KEBAB_SEGMENT_RE.test(name);
}

/**
 * @param {string} name
 * @param {{ fileStem?: string, legacyMode?: 'allow-warn' | 'reject' }} [options]
 */
function validatePageName(name, options = {}) {
  const { fileStem, legacyMode = 'allow-warn' } = options;

  if (isLegacyPageName(name)) {
    if (legacyMode === 'reject') {
      const target = getLegacyMigrationTarget(name);
      return {
        ok: false,
        kind: 'legacy',
        message: target
          ? `Legacy pageName "${name}" must be migrated to "${target}"`
          : `Legacy pageName "${name}" is no longer allowed`,
      };
    }
    return {
      ok: true,
      kind: 'legacy',
      warn: legacyMode === 'allow-warn',
      migrationTarget: getLegacyMigrationTarget(name),
    };
  }

  if (!isPascalCasePageName(name)) {
    return {
      ok: false,
      kind: 'invalid',
      message: `pageName "${name}" must be PascalCase ending in Page (e.g. DashboardPage) or be a registered legacy catalogue string`,
    };
  }

  if (fileStem && name !== fileStem) {
    if (name === 'DashboardPage' && fileStem !== 'DashboardPage') {
      return { ok: true, kind: 'interim-shared' };
    }
    if (name === 'MemberProfilePage' && /Profile(?:View|EditProxy)Page$/.test(fileStem)) {
      return { ok: true, kind: 'shared-catalogue' };
    }
    if (name === 'ActivitiesPage' && fileStem === 'ActivityOfferingPage') {
      return { ok: true, kind: 'shared-catalogue' };
    }
    if (name === 'RegistrationTypesPage' && (fileStem === 'RegistrationTypeBuilderPage' || fileStem === 'FormBuilderPage')) {
      return { ok: true, kind: 'shared-catalogue' };
    }
    if (name === 'ScanningPage' && (fileStem === 'ScanningTrackingPage' || fileStem === 'ScanningSetupPage')) {
      return { ok: true, kind: 'shared-catalogue' };
    }
    if (name === 'ApplicationsPage' && fileStem === 'ApplicationDetailPage') {
      return { ok: true, kind: 'shared-catalogue' };
    }
    if (name === 'FormsPage' && fileStem === 'FormsListPage') {
      return { ok: true, kind: 'shared-catalogue' };
    }
    return {
      ok: false,
      kind: 'stem-mismatch',
      message: `pageName "${name}" must match page file stem "${fileStem}"`,
    };
  }

  return { ok: true, kind: 'canonical' };
}

function isValidNewMigrationPageName(name) {
  return isPascalCasePageName(name) && !isLegacyPageName(name);
}

/**
 * Scan source text for pageName literals and validate each.
 * @param {string} text
 * @param {{ fileStem?: string, legacyMode?: 'allow-warn' | 'reject', relativePath?: string }} [options]
 */
function isTestSourcePath(relativePath) {
  return /\.(?:test|spec)(?:\.(?:tsx?|jsx?))?$/.test(relativePath) ||
    /\.integration\.test\.(?:tsx?|jsx?)$/.test(relativePath);
}

function shouldValidatePageContextValue(value) {
  if (!value || value.length <= 2) return false;
  return true;
}

function collectPageNameIssuesFromSource(text, options = {}) {
  const { fileStem, legacyMode = 'allow-warn', relativePath = '', skipTestFiles = false } = options;
  if (skipTestFiles && isTestSourcePath(relativePath)) {
    return [];
  }
  const issues = [];
  const patterns = [
    { re: /pageName\s*=\s*["']([^"']+)["']/g, label: 'pageName', checkStem: true },
    { re: /pageName:\s*["']([^"']+)["']/g, label: 'pageName', checkStem: false },
    { re: /pageContext[=:]\s*["']([^"']+)["']/g, label: 'pageContext', checkStem: true, isPageContext: true },
    { re: /PAGE_CONTEXT\s*=\s*["']([^"']+)["']/g, label: 'PAGE_CONTEXT', checkStem: true },
    { re: /useResourcePermissions\s*\(\s*["']([^"']+)["']/g, label: 'useResourcePermissions', checkStem: false },
  ];

  for (const { re, label, checkStem, isPageContext } of patterns) {
    re.lastIndex = 0;
    let match;
    while ((match = re.exec(text)) !== null) {
      const pageName = match[1].trim();
      if (!pageName || pageName.includes('{')) continue;
      if (isPageContext && !shouldValidatePageContextValue(pageName)) continue;

      const result = validatePageName(pageName, {
        fileStem: checkStem ? fileStem : undefined,
        legacyMode,
      });
      if (!result.ok) {
        issues.push({
          type: 'rbacPageName',
          label,
          pageName,
          file: relativePath,
          severity: 'error',
          message: result.message,
          kind: result.kind,
        });
      } else if (result.warn) {
        const target = result.migrationTarget;
        issues.push({
          type: 'legacyPageName',
          label,
          pageName,
          file: relativePath,
          severity: 'warning',
          message: target
            ? `Legacy pageName "${pageName}" — migrate to "${target}"`
            : `Legacy pageName "${pageName}" — migrate to PascalCase matching page file stem`,
          migrationTarget: target,
        });
      }
    }
  }

  return issues;
}

/**
 * Validate custom CSS class / custom property names (pace-core templates).
 * @param {string} selectorOrName
 */
function isKebabCssName(name) {
  if (!name) return true;
  if (name.startsWith('--')) {
    return /^--[a-z0-9]+(?:-[a-z0-9]+)*$/.test(name);
  }
  return /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(name);
}

module.exports = {
  NAMING_MIGRATION_ENFORCE_VERSION,
  NAMING_EFFECTIVE_DATE: NAMING_MIGRATION_ENFORCE_VERSION,
  PASCAL_PAGE_NAME_RE,
  KEBAB_SEGMENT_RE,
  LEGACY_PAGE_NAMES,
  legacyData,
  APP_PUBLIC_LOGO_VARIANTS,
  APP_PUBLIC_LOGO_REQUIRED_VARIANTS,
  APP_PUBLIC_LOGO_OPTIONAL_VARIANTS,
  isLegacyPageName,
  getLegacyMigrationTarget,
  isPascalCasePageName,
  isKebabRouteSegment,
  parseRoutePath,
  validateRoutePath,
  isPageFileName,
  isKebabPublicAssetFilename,
  isKebabCaseCatalogueSlug,
  validatePageName,
  isValidNewMigrationPageName,
  collectPageNameIssuesFromSource,
  isKebabCssName,
  isTestSourcePath,
  shouldValidatePageContextValue,
  normalizeAppSlug,
  appPublicLogoRelativePath,
  appPublicLogoPath,
  isLegacyUnderscoreAppLogoFilename,
  collectAppNameFromSource,
  collectAppPublicLogoIssues,
};
