# CR30 – Attention queue (list rows)

*Shared “needs attention” queue for operator landings and context overviews across the PACE suite.*

## Overview

- **Purpose:** Single-sourced actionable-work list rows used across gear, mint, base, team, trac, and similar operator surfaces.
- **Scope:** Package export + demo example; v1 list-row layout only.
- **Dependencies:** [CR05a-primitives.md](./CR05a-primitives.md) (Card slots, Badge, Button); [CR06-forms-and-feedback.md](./CR06-forms-and-feedback.md) (EmptyState).
- **Standards:** 05 pace-core compliance, 07 Visual.

## Acceptance criteria

- [x] `AttentionSection` and `AttentionItem` exported from `@solvera/pace-core/components`.
- [x] List-row layout: tone bullet in header, title + kind badge, subtitle, optional amount in footer column.
- [x] Row surface: Card layer-0 panel classes on `<li>`; horizontal `CardHeader` | `CardContent` | (`CardFooter`) slot grid.
- [x] Row activation mirrors Card: `link` navigates whole row; `onClick` activates whole row; default row is static (footer may host buttons later).
- [x] Section shell: `<hgroup>` title block (default **Needs attention**), item count, optional `viewAll`, empty state via `EmptyState compact`.
- [x] Presentation-only — no data fetching; no routing-library dependency inside AttentionItem (link navigation uses shared Card link helper when router context exists).
- [x] Demo or styles showcase renders sample rows and empty state.

## API / Contract

**Exports:** `packages/core/src/components/advanced-ui/AttentionItem.tsx`, `AttentionSection.tsx`

### Types

- `AttentionItemTone`: `'warn' | 'bad' | 'info'` (default `'warn'`)

### AttentionSectionItem (row data)

- `id: string` — list key; passed to `AttentionItem` as `id` on the `<li>`
- `title: string`
- `kind?: string` — kind chip via `Badge variant="solid-sec-muted"`
- `sub?: string`
- `tone?: AttentionItemTone`
- `amount?: ReactNode` — optional footer value; `CardFooter` column omitted when absent
- `contextLabel?: string` — optional subtitle prefix (`"{contextLabel} · {sub}"`)
- `link?: string | null` — whole-row URL navigation (Card parity)
- `href?: string` — deprecated alias for `link` (resolved as `link ?? href`)
- `onClick?: () => void` — whole-row callback activation; wins over `link`/`href` when both set

### AttentionItem props

Same fields as `AttentionSectionItem`. `id` optional when used standalone inside a list.

### AttentionSection props

- `items: AttentionSectionItem[]`
- `title?: string` (default **Needs attention**)
- `emptyTitle?: string` (default **Nothing needs attention**)
- `emptyDescription?: string` (default **You are all caught up — nothing to action right now.**)
- `viewAll?: { label: string; onClick: () => void }`
- `className?: string` — layout classes on the title `<hgroup>` only

### App adapters

Consuming apps map domain attention data into `AttentionSectionItem[]`; the package stays presentation-only. Example: pace-gear **`OrganisationAttentionSection`** maps org-landing metrics and wires `onClick` to `setSelectedEvent` + router navigation. Do not add app-specific routing or RBAC inside pace-core.

## Visual specification

Global tokens and size groups: [7-visual-standards.md](../standards/7-visual-standards.md) Part C.

Bullet utility: `bullet-triangle-alert` via `--bullet-mask-triangle-alert` in `core.css` `@theme` (Lucide TriangleAlert mask; same `@utility bullet-*` mechanism as CR29 `bullet-calendar` / `bullet-map-pin`).

### AttentionSection

- Root: React Fragment (`<>...</>`); no outer `<section>`.
- Title block: `<hgroup className={cn('grid w-full items-baseline gap-2', className, viewAll grid cols)}>` containing `<h2>` title, `<small>` count (`N item` / `N items`), optional `viewAll` ghost `Button` with trailing `ArrowRight`.
- `viewAll` grid: `grid-cols-[1fr_auto_auto]`; without `viewAll`: `grid-cols-[1fr_auto]`.
- Empty: `Card` > `CardContent` > `EmptyState compact` (below `hgroup`, spaced with margin).
- List: `<ul className="mt-4 grid w-full gap-2 ps-0">` mapping items directly to `<AttentionItem />` — **no wrapper `<li>` in the section**.

### AttentionItem (list row)

- Root: `<li>` with border-only layer-0 frame: `overflow-hidden rounded-2xl border border-main-300 text-main-950` — **omit** `bg-main-100` (transparent row; tone column provides colour).
- Layout: horizontal slot grid on `<li>`:
  - With `amount`: `grid w-full grid-cols-[auto_1fr_auto] items-center`
  - Without `amount`: `grid w-full grid-cols-[auto_1fr] items-center`
- Slots: `CardHeader` | `CardContent` | (`CardFooter` when `amount` present).
- **CardHeader:** `<h2 className="bullet-triangle-alert {toneHeaderClass}" aria-label={tone}>` — no child nodes; `::before` bullet uses `currentColor`.
- **Tone header class map** (text/bullet + background):
  - `warn` → `text-acc-600 bg-acc-200`
  - `bad` → `text-acc-800 bg-acc-200`
  - `info` → `text-main-700 bg-main-200`
- **CardContent:** `<h5>{title}</h5>` with optional inline `<Badge variant="solid-sec-muted">{kind}</Badge>`; `<small>{mergedSubtitle}</small>` when subtitle present.
- **CardFooter:** optional `<p>{amount}</p>` only (no default action button).
- **Linked / active row classes:** same as Card `cardLinkedClasses` when `link`/`href` or `onClick` is set; nested `a` / `button` / `[role=button]` are decorative when row `link` is active (Card parity).
- **No `className` prop on `AttentionItem`.**

## Behaviour

- `AttentionItem` MUST render as `<li>` and MUST only be used inside `<ul>` or `<ol>`.
- When `link`/`href` is set (and `onClick` is not): whole `<li>` is keyboard focusable (`tabIndex={0}`), `role="link"`, Enter/Space navigates via shared Card link helper.
- When `onClick` is set: whole `<li>` is keyboard focusable, `role="button"`, Enter/Space invokes `onClick`; `onClick` wins when both `link` and `onClick` are provided.
- When neither `link`/`href` nor `onClick` is set: row is static; footer may contain interactive controls.
- `CardFooter` MUST be omitted when `amount` is `undefined` or `null`.
- `contextLabel` MUST prefix `sub` with `" · "` only when both are non-empty.
- `kind` badge MUST be omitted when `kind` is blank/whitespace.
- Tone column MUST expose the raw `tone` enum value (`warn` | `bad` | `info`) to assistive tech via `aria-label` on the tone `<h2>`, not human-readable labels.
- `AttentionSection` MUST render empty state when `items.length === 0`.

## Do not

- Do not wrap `AttentionItem` in `Card`; apply shared layer-0 surface on `<li>` and compose `CardHeader` / `CardContent` / `CardFooter` slots only.
- Do not embed `react-router` in AttentionItem — use shared link navigation helper (same as Card).
- Do not fetch summaries or permissions inside these components.
- Do not implement tile-grid `style="cards"` in v1 (follow-up CR amendment if needed).
- Do not port prototype `.atn-*` rules into `core.css`.

## References

- Prototype: `pace-prototype/apps/_pace-core/prototype-only/AttentionQueue.jsx`
- pace-gear: `OrganisationAttentionSection`, `DashboardAttentionSection`

---

## Prompt to use with Cursor

Implement the feature described in this document. Follow the standards and guardrails provided. Add or update tests and demo as specified. Run validate and fix any issues until it passes.
