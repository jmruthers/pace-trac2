# CR07a – DataTable: Core table, sort, pagination, export

*CR07a of 2. This slice is sized for one Cursor prompt. CR07b (see [CR07b-datatable.md](./CR07b-datatable.md)): server-side pagination, filtering UI, grouping/aggregation, import modal, inline edit, hierarchical.*

## Overview

- **Purpose:** DataTable component with columns, client-side sorting, client-side pagination, loading/empty states, and CSV export so the demo and apps can display tabular data with RBAC-aware visibility (e.g. show Export only when permitted).
- **Scope:** Package (DataTable, ColumnFactory, useDataTableState, export utils) + demo (one page with a DataTable: sort, pagination, export CSV).
- **Dependencies:** 02-foundation, 05a-primitives (Table primitives), 04-rbac (for permission-aware toolbar/actions). 06-forms not required for this slice.
- **Standards:** 05 pace-core compliance, 02 Architecture, 03 Security & RBAC (for action visibility), 07 Visual.

## Source layout

Implementation lives under `packages/core/src/components/data-table/`: thin orchestrator (`DataTable.tsx`), layout submodules (`DataTableLayout.tsx`, `DataTableCaptionToolbar.tsx`, `DataTableColumnSettingsMenu.tsx`, `DataTableFilterRow.tsx`, `DataTableBody.tsx`, `DataTablePaginationFooter.tsx`), modals (`DataTableModals.tsx`, `ImportModal.tsx`), controller hooks (`useDataTableController.ts`, etc.), pure utilities (`filterData.ts`, `sortData.ts`, `parseCsv.ts`, `useServerSideData.ts`, `dataTableHelpers.ts`, `columnFactory.tsx` — camelCase **utility** module, not a React component), and `types.ts`. Public exports surface through `components/index.ts` only.

## In scope for this slice

- DataTable: accepts `data`, `columns`, `rbac`; supports sorting, client-side pagination, loading state, empty state; uses Table primitives and design tokens; optional export (toolbar or prop) gated by RBAC. DataTable root is a single `<table>` (via Table primitive) with default `layer={0}` for surface framing. **Defaults to sorting ascending on the first (sortable) column** so consuming apps get consistent initial order without configuration.
- Column definitions: `DataTableColumn` (id?, accessorKey, header, sortable?, cell?) and optional `SimpleColumn` (key, label, sortable?) for convenience.
- `useDataTableState`: client-side state for sorting, pagination (pageIndex, pageSize), optional columnFilters/expanded/selectedRows; optional `initialSorting`; returns state, actions, computed (paginatedData, totalPages, hasNextPage, hasPreviousPage). DataTable passes a default `initialSorting` (first sortable column ascending) so tables are sorted by default.
- ColumnFactory: helpers to build column defs — `createTextColumn`, `createNumberColumn`, `createDateColumn`, `createBooleanColumn`, `createActionColumn` (minimal options: key/accessorKey, label/header, sortable?).
- Export: `exportToCSV`, `generateCSVContent` with clear signatures; DataTable exposes export (e.g. toolbar button) when `onExport` or built-in export is enabled and RBAC allows.

## Out of scope for this slice (do not implement here)

- Server-side pagination (ServerSideConfig, fetchData, totalCount).
- Hierarchical rows (expand/collapse parent/child).
- Column filtering UI (filter row, filter dropdowns).
- Grouping and aggregation UI (group by column, aggregate functions).
- Import modal and CSV import handlers.
- Inline editing, create/edit/delete modals, row selection and bulk delete.
- Virtual scrolling / performance config (chunking, search index).
- Toolbar beyond a single Export action (no search bar, column visibility, etc. in CR07a).

Implement only the in-scope items. CR07b covers the above features. CR07b also defines toolbar layout (single row: search left, row count, actions right), filter row hidden by default with toggle, Lucide icons for toolbar/row actions and sort, row count display (x / y when filtered), and page-jump control.

---

## Acceptance criteria

- [x] DataTable component: accepts columns, data, loading state; supports sorting and client-side pagination; uses Table primitives and design tokens; requires `rbac` config; renders as a root `<table>` with default `layer={0}` surface framing. Defaults to sorting ascending on the first (sortable) column when sorting is enabled.
- [x] Column definitions: at least id/accessorKey/header and optional sortable, cell renderer; SimpleColumn (key, label, sortable?) supported.
- [x] useDataTableState(options): options include initialPageSize?, initialSorting?, data. Returns state (sorting, columnFilters, expanded, pageSize, pageIndex, selectedRows), actions (setSorting, setColumnFilters, setExpanded, setPageSize, setPageIndex, setSelectedRows, resetState), computed (paginatedData, totalPages, hasNextPage, hasPreviousPage). DataTable supplies default initialSorting (first sortable column ascending) so no consumer config is required.
- [x] ColumnFactory: createTextColumn, createNumberColumn, createDateColumn, createBooleanColumn, createActionColumn (and optionally createColumnsFromConfig) to build column defs.
- [x] Export: exportToCSV(data, columns, filename?), generateCSVContent(data, columns, options?) with types; DataTable can trigger export (e.g. toolbar button) when permitted by RBAC.
- [x] Demo: one page with a DataTable (e.g. name, email, role), sort by column, change page size / navigate pages, export CSV; if RBAC is integrated, export visibility respects permission.

---

## API / Contract

**Exports:** From `packages/core`: DataTable, ColumnFactory (or equivalent), types (DataTableColumn, SimpleColumn, DataTableRBACConfig, etc.); from hooks: useDataTableState; from DataTable utils: exportToCSV, generateCSVContent.

### DataTableProps (CR07a — minimal)

- **Required:** `data: TData[]`, `columns: (DataTableColumn<TData> | SimpleColumn<TData>)[]`, `rbac: DataTableRBACConfig`.
- **Optional:** `title?: string`, `description?: string`, `variant?: 'default' | 'compact' | 'spacious'`, `className?: string` (applied to root `<table>`), `layer?: 0 | 1 | 2` (default `0`; passthrough to Table), `initialPageSize?: number`, `getRowId?: (row: TData, index: number) => string`, `isLoading?: boolean`, `emptyState?: { title?: string, description?: string }`, `onExport?: (options?: ExportOptions) => void | Promise<void>`.

**DataRecord:** Row type must have a stable id (e.g. `id: string`) or consumer provides `getRowId`.

**DataTableRBACConfig:** `{ pageName?: string, pageId?: string }`. Used to resolve permissions for showing export (and later edit/delete) actions.

**DataTableColumn (CR07a):** `id?: string`, `accessorKey?: string`, `header: string`, `sortable?: boolean`, `cell?: (info: { row, getValue, ... }) => ReactNode`. (Other column options such as enableColumnFilter, enableGrouping, fieldType are in CR07b.)

**SimpleColumn:** `key: string`, `label: string`, `sortable?: boolean`.

### useDataTableState

- **Options:** `{ data: TData[], initialPageSize?: number, initialSorting?: SortingState }`. When used by DataTable, `initialSorting` is derived from the first sortable column (ascending) when `features.sorting` is enabled; consumers may pass their own when using the hook directly.
- **Returns:**
  - `state`: { sorting, columnFilters, expanded, pageSize, pageIndex, selectedRows } (types from TanStack where applicable).
  - `actions`: setSorting, setColumnFilters, setExpanded, setPageSize, setPageIndex, setSelectedRows, resetState.
  - `computed`: { paginatedData, totalPages, hasNextPage, hasPreviousPage } (paginatedData = data.slice(pageIndex * pageSize, (pageIndex + 1) * pageSize).

### ColumnFactory (CR07a)

- `createTextColumn(options): ColumnDef` — options: accessorKey/key, header/label, sortable?.
- `createNumberColumn(options): ColumnDef` — same + optional format?(value: number) => string.
- `createDateColumn(options): ColumnDef` — same + optional format?(date: Date) => string, locale?.
- `createBooleanColumn(options): ColumnDef` — same + optional render?(value: boolean) => ReactNode.
- `createActionColumn(options): ColumnDef` — options: header?, render?(row, actions) => ReactNode (actions can be empty in CR07a).
- Optional: `createColumnsFromConfig(config): ColumnDef[]` — config: array of { key, type: 'text'|'number'|'date'|'boolean', label?, sortable? }.

### Export

- `exportToCSV<TData>(data: TData[], columns: ExportColumn[], filename?: string): void` — triggers browser download. ExportColumn: { key: string, header: string } or equivalent derived from column defs.
- `generateCSVContent<TData>(data: TData[], columns: ExportColumn[], options?: { delimiter?: string }): string` — returns CSV string.

---

## Behaviour

- DataTable MUST receive `rbac` config; MUST use design tokens and Table primitives (Table, TableHeader, TableBody, TableRow, TableHead, TableCell, etc.). DataTable MUST NOT wrap Table in Card; surface framing comes from Table `layer` on the root `<table>`. MUST support client-side sorting and client-side pagination (slice data by pageIndex/pageSize). **When sorting is enabled, DataTable MUST default to sorting ascending on the first column that has `sortable: true` and a valid id/accessorKey**, so consuming apps get a consistent initial order without setting any props. Column definitions MUST support at least id/accessorKey/header and optional sortable, cell. Export MUST be gated by RBAC when RBAC is integrated (e.g. use pageName/pageId to resolve canExport and show/hide export control). Loading and empty states MUST be renderable via isLoading and emptyState.
- DataTable title markup contract: when `title` is provided, render exactly one copy as an `h4`, and render it as the first element inside `TableCaption`.
- This slice owns table-level CSV export primitives only. Cross-surface print/export composition (multi-section documents and shared print/export orchestration) remains out of scope for this slice.

---

## Demo app requirements

- One route (e.g. `/data-table-showcase`) with a DataTable: columns (e.g. name, email, role), sortable columns, pagination (page size + next/prev), and an Export CSV action. If RBAC is integrated, Export button visibility respects useCan/useResourcePermissions (or equivalent) for the page.
- **Step-by-step:** User opens DataTable Showcase → sees a table with columns (e.g. name, email, role) **already sorted ascending by the first column** → can sort by clicking a column header (toggles asc/desc) → can change page size and navigate pages → can click Export and get a CSV download. With RBAC, Export is only shown when the user has export permission for that page.

---

## Verification

- **Core behaviour:** Verify default first-sortable-column ascending order, column sorting toggles, and client-side pagination.
- **Utility contract:** Verify `useDataTableState`, `ColumnFactory`, and CSV export helpers are exported and function per signatures.
- **RBAC action visibility:** Verify export action visibility is controlled by RBAC configuration when integrated.

---

## Testing requirements

- Unit tests: useDataTableState (initial state, initialSorting, setPageSize/setPageIndex, setSorting, resetState, computed paginatedData/totalPages); exportToCSV / generateCSVContent (output shape, delimiter); `columnFactory.tsx` (`createTextColumn`, `createNumberColumn`, `createDateColumn`, `createBooleanColumn`, `createActionColumn`, `createColumnsFromConfig`) in `columnFactory.test.ts`. Integration tests: DataTable renders with columns and data; **table defaults to first-column ascending sort** (sort indicator and row order); sort changes order on header click; pagination changes visible rows; export triggers download or returns correct content. Coverage per Standard 08.

---

## Do not

- Do not implement server-side pagination, hierarchical rows, column filtering UI, grouping, aggregation, import modal, inline edit, create/delete modals, or virtual scrolling in this slice. Do not copy old implementation; implement from this spec and the standards. Demo uses generic placeholder data (e.g. users with name, email, role), not domain-specific columns.

---

## References

- [2-architecture-standards.md](../../../packages/core/docs/standards/2-architecture-standards.md), [3-security-rbac-standards.md](../../../packages/core/docs/standards/3-security-rbac-standards.md), [7-visual-standards.md](../../../packages/core/docs/standards/7-visual-standards.md). implementation-guides/data-tables (reference only; do not implement all features there in this slice).

**Minimal column:** `{ id: 'name', accessorKey: 'name', header: 'Name', sortable: true }`.

**Minimal DataTable:** `<DataTable data={rows} columns={columns} rbac={{ pageName: 'users' }} />`. Table is sorted ascending by the first sortable column by default; no props required.

**DataTable with export:** `<DataTable data={rows} columns={columns} rbac={{ pageName: 'users' }} onExport={() => exportToCSV(rows, columns, 'users.csv')} />` (export button shown when RBAC allows).

**useDataTableState:** `const { state, actions, computed } = useDataTableState({ data: rows, initialPageSize: 10 });` then pass state/actions into DataTable or use computed.paginatedData for display.

---

## Prompt to use with Cursor

Implement the feature described in this document. Implement only the in-scope items; do not add server-side pagination, hierarchical data, column filtering UI, grouping, aggregation, import modal, inline editing, or virtual scrolling (those are CR07b). Follow the standards and guardrails provided. Add or update tests and demo as specified. Run validate and fix any issues until it passes.
