# CR31 – Filter sidebar

*Shared category/filter navigation panel for browse screens across the PACE suite.*

## Overview

- **Purpose:** Single-sourced filter sidebar used for category navigation with item counts (catalogue, supply aggregation, and similar browse surfaces).
- **Scope:** Package export + demo example; sectioned filter list for category browse and master-detail selection sidebars (orders, dockets) with optional row metadata.
- **Dependencies:** [CR05a-primitives.md](./CR05a-primitives.md) (Card, Button, Badge).
- **Standards:** 05 pace-core compliance, 07 Visual.

## Acceptance criteria

- [x] `FilterSidebar`, `FilterSidebarSection`, and `FilterSidebarItem` exported from `@solvera/pace-core/components`.
- [x] Composed only from CR05a primitives — no hand-rolled panel chrome, no native `<button>` duplicates, no new CSS files.
- [x] Data-driven `FilterSidebar` API with sectioned filter items (`id`, `label`, `count`, optional `countLabel`, optional `description`, optional `meta`, optional `metaBadge`).
- [x] Active row: `Button` `variant="default"` + `aria-current="true"`; inactive: `variant="ghost"`.
- [x] Count via `Badge variant="outline-sec-muted"`.
- [x] Panel chrome via `Card layer={1}` inside `<aside>` landmark.
- [x] Full-width rows via `Button block` (CR05a layout affordance).
- [x] Presentation-only — no data fetching; no routing-library dependency.
- [x] Demo styles showcase renders sample sections and active state.
- [x] Integration tests cover sections, selection, and `onSelect`.

## API / Contract

**Exports:** `packages/core/src/components/advanced-ui/FilterSidebar.tsx`, `FilterSidebarItem.tsx`

### Types

- `FilterSidebarItemData`: `{ id: string; label: string; count: number; countLabel?: string; description?: string; meta?: string; metaBadge?: FilterSidebarMetaBadge }`
- `FilterSidebarMetaBadge`: `{ label: string; variant: 'solid-acc-normal' | 'solid-sec-normal' | 'solid-main-normal' }`
- `FilterSidebarSectionData`: `{ title: string; items: FilterSidebarItemData[] }`

### FilterSidebar props

- `ariaLabel: string` — forwarded to root `<aside>`
- `activeId: string` — currently selected item `id`
- `onSelect: (id: string) => void` — called when a filter row is activated
- `sections: FilterSidebarSectionData[]` — one or more titled groups; caller omits empty sections
- `className?: string` — layout-only classes on root `<aside>`

### FilterSidebarSection props (compound)

- `title: string`
- `children: ReactNode` — typically `FilterSidebarItem` rows inside `<li>` elements

### FilterSidebarItem props (compound)

- `label: string`
- `count: number`
- `countLabel?: string` — optional badge text override (e.g. `"12 items"`); defaults to `String(count)` when omitted
- `description?: string` — secondary line (e.g. PO reference)
- `meta?: string` — tertiary context (e.g. expected date or "not placed")
- `metaBadge?: FilterSidebarMetaBadge` — optional semantic status chip (e.g. receiving reconciliation short/over/reconciled)
- `isActive: boolean`
- `onClick: () => void`

### App adapters

Consuming apps map domain counts into `FilterSidebarSectionData[]`. Example: pace-gear catalogue maps `CatalogueCategoryCounts` into Categories + optional Governance sections. Do not add app-specific filter logic inside pace-core.

## Primitive composition (required)

| Part | Primitive | Role |
|------|-----------|------|
| Panel chrome | `Card` (`layer={1}`) | Bordered/sticky panel surface. Layout-only `className` on `Card` for `grid gap-4 p-2.5 lg:sticky lg:top-20`. |
| Landmark | `<aside>` | Wraps `Card`; carries `aria-label` only. |
| Section title | `<h2>` | One per section (not `CardTitle`). |
| Filter row | `Button` | `block`, `size="small"`; `default` / `ghost`; `aria-current` when active. |
| Count | `Badge` | `variant="outline-sec-muted"`. |
| List structure | Semantic HTML | `<section>`, `<nav aria-label={title}>`, `<ul>` / `<li>`. |

## Visual specification

Global tokens and size groups: [7-visual-standards.md](../standards/7-visual-standards.md) Part C.

### FilterSidebar

- Root: `<aside aria-label={ariaLabel} className={cn('self-start', className)}>` > `Card layer={1}` with `className="grid gap-4 p-2.5 lg:sticky lg:top-20"`.
- Each section: `FilterSidebarSection` renders `<section className="grid gap-1">` + `<h2>` + `<nav aria-label={title}>` > `<ul className="grid list-none gap-0.5 ps-0">`.

### FilterSidebarItem

- Row: `Button block size="small"` with `grid-cols-[1fr_auto]` content — left column `<span className="grid">` with label `<span>`, optional `<small>` description, optional `<small>` meta, optional `Badge` from `metaBadge`; right column `Badge` showing `countLabel ?? String(count)`.
- Active: `variant="default"`, `aria-current="true"`.
- Inactive: `variant="ghost"`.

## Behaviour

- `FilterSidebar` MUST call `onSelect(item.id)` when a row is clicked.
- `FilterSidebar` MUST set `aria-current="true"` only on the active row.
- Sections with zero items MUST be omitted by the caller (component does not filter empty sections).
- `FilterSidebarItem` MUST NOT accept `className` overrides.

## Do not

- Do not hand-roll panel borders/backgrounds on `<aside>` — use `Card`.
- Do not use native `<button>` or duplicate Button variant maps in advanced-ui.
- Do not add `className` on `Button` or `Badge` at FilterSidebar call sites.
- Do not port prototype `.cat-tree` / `.supply-sidebar` CSS into `core.css` — use FilterSidebar composition only.

## References

- Prototype: `pace-prototype/apps/pace-gear/pages/CataloguePages.jsx` (`.cat-tree`)
- pace-gear: `CatalogueCategorySidebar` → `FilterSidebar` adapter

---

## Prompt to use with Cursor

Implement the feature described in this document. Follow the standards and guardrails provided. Add or update tests and demo as specified. Run validate and fix any issues until it passes.
