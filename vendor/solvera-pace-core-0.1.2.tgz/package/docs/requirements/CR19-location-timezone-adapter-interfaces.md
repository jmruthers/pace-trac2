# CR19 – Location cache and timezone adapter interfaces

## Overview

- Purpose: define provider-agnostic contracts for location lookup caching and timezone adaptation so apps can integrate mapping/geocoding providers without coupling pace-core to vendor-specific implementations.
- Scope: package interfaces, cache-key contracts, adapter helpers, orchestration primitives, and verification expectations. Provider implementations and provider-specific policy remain app-owned.
- Dependencies: CR02-foundation-types-utils-styles (timezone utility foundation), CR09-public-pages (public-route consumers), CR15-dynamic-theming (context integration boundaries).
- Standards: 02 Architecture, 04 API and tech stack, 06 Code quality, 08 Testing and documentation.

## Acceptance criteria

- [x] Define interfaces for location lookup adapters and timezone resolution adapters that are provider-neutral.
- [x] Define cache contracts (keys, TTL semantics, invalidation hooks) for location/timezone lookup results.
- [x] Ensure adapters accept and return normalized types suitable for cross-app consumption.
- [x] Document that provider implementations (for any specific mapping/geocoding service) must live in consuming apps, not pace-core.
- [x] Provide utility helpers for cache orchestration and adapter composition without enforcing one provider stack.
- [x] Ensure fallback behavior is defined when adapter resolution fails or returns incomplete data.
- [x] Define a provider-chain contract for ordered adapter execution/fallback without embedding provider-specific logic.
- [x] Define query normalization requirements so equivalent queries generate deterministic cache keys.
- [x] Define a standard adapter error taxonomy for common location/timezone resolution failures.
- [x] Include an optional batch-resolution contract for future high-throughput consumers without forcing immediate implementation.

## API / Contract

- Public exports from `packages/core/src/location/` (or equivalent):
  - `LocationAdapter` interface
  - `TimezoneAdapter` interface
  - `LocationProviderChain` (or equivalent)
  - `normalizeLocationQuery(...)` (or equivalent)
  - `createLocationCacheKey(...)` (or equivalent)
  - `createLocationCache(...)`
  - `resolveLocationTimezone(...)` (or equivalent orchestrator)
  - `resolveLocationTimezoneMany(...)` (optional batch variant)
- Expected contract-level types (names may vary if equivalent):
  - `LocationQueryInput`: address fragments/coordinates/context identifiers
  - `NormalizedLocationResult`: canonical location payload (display name, coordinates, optional structured fields)
  - `NormalizedTimezoneResult`: canonical timezone payload (iana name, source, confidence)
  - `AdapterResolutionResult<T>`: `{ ok: boolean; data?: T; error?: { code: string; message: string } }`
  - `LocationCacheEntry<T>`: value + metadata (createdAt, expiresAt, sourceKey)
  - `LocationAdapterErrorCode` enum/string-union for shared failure classes, e.g.:
    - `NOT_FOUND`
    - `AMBIGUOUS`
    - `RATE_LIMITED`
    - `UPSTREAM_UNAVAILABLE`
    - `INVALID_INPUT`
    - `TIMEOUT`
    - `UNKNOWN`
- Cache contract:
  - deterministic cache key generator for equivalent queries
  - TTL-based freshness check
  - explicit invalidate operation by key and scoped-clear operation
- Provider-chain contract:
  - ordered adapter execution
  - short-circuit on first acceptable result
  - explicit fallback behavior when adapter returns incomplete data or classified errors
- Query normalization contract:
  - deterministic normalization for equivalent location inputs before key generation
  - normalized output is the canonical key input for cache lookup/write
- Batch contract (optional):
  - supports resolving many inputs with bounded concurrency
  - preserves per-item success/error metadata with the same `AdapterResolutionResult` shape

## Visual specification

Not applicable (non-UI contract slice).

## Verification

- pace-core: verify interfaces compile and can be consumed by at least one mock adapter in tests.
- pace-core: verify cache helper behavior (hit/miss/expiry/invalidate) through contract tests.
- pace-core: verify query normalization + cache key determinism for equivalent inputs.
- pace-core: verify provider-chain fallback semantics and error classification behavior.
- Consuming apps: verify a provider-specific adapter implementation can plug into these interfaces without changing pace-core contracts.
- Consuming apps: verify app-level provider policy (selection, ranking, quotas, credentials) remains outside pace-core.

Implemented verification:
- Added `packages/core/src/location/` with provider-agnostic contracts and helpers:
  - `LocationAdapter`, `TimezoneAdapter`, `LocationProviderChain`
  - `normalizeLocationQuery(...)`, `createLocationCacheKey(...)`
  - `createLocationCache(...)`
  - `resolveLocationTimezone(...)`
  - `resolveLocationTimezoneMany(...)`
- Added adapter error taxonomy + classifier for shared failure classes:
  - `NOT_FOUND`, `AMBIGUOUS`, `RATE_LIMITED`, `UPSTREAM_UNAVAILABLE`, `INVALID_INPUT`, `TIMEOUT`, `INCOMPLETE_DATA`, `UNKNOWN`
- Confirmed fallback semantics:
  - ordered location adapter execution
  - short-circuit on first complete result
  - fallback continuation for incomplete/non-fatal failures
  - fail-fast on `INVALID_INPUT`
  - timezone fallback to location-sourced IANA value when present
- Added scoped cache behavior contracts (deterministic keying, TTL expiry, invalidate by key, scoped clear).
- Added scoped consumer entrypoint `@solvera/pace-core/location` and export-governance ownership wiring.

## Testing requirements

- Unit tests for cache key stability, TTL behavior, and invalidation.
- Unit tests for adapter orchestrator fallback behavior and normalized output.
- Unit tests for query normalization equivalence and deterministic key generation.
- Unit tests for shared adapter error taxonomy mapping.
- Integration-style test with mock location and timezone adapters to validate composition contract.
- Optional integration-style test for batch resolution semantics if batch API is implemented.

Implemented tests:
- Unit: `packages/core/src/location/normalize.test.ts`
  - query normalization equivalence
  - deterministic key generation
- Unit: `packages/core/src/location/cache.test.ts`
  - hit/miss and TTL expiry
  - key invalidation
  - scoped clear semantics
- Unit + integration-style: `packages/core/src/location/resolveLocationTimezone.test.ts`
  - provider-chain fallback and short-circuit behavior
  - incomplete-result fallback handling
  - fail-fast error classification (`INVALID_INPUT`)
  - cache write/read orchestration behavior
  - batch resolution bounded concurrency semantics
  - adapter error taxonomy mapping

Validation:
- `npm run validate` passes after implementation updates.

## Do not

- Do not embed vendor-specific SDK assumptions in pace-core adapter interfaces.
- Do not store provider credentials or provider-specific configuration in this slice.
- Do not duplicate foundational timezone helpers already owned by CR02.
- Do not move provider selection policy, ranking heuristics, or quota strategies from consuming apps into pace-core.

## References

- [CR02-foundation-types-utils-styles.md](./CR02-foundation-types-utils-styles.md)
- [CR09-public-pages.md](./CR09-public-pages.md)
- [CR15-dynamic-theming.md](./CR15-dynamic-theming.md)
- [2-architecture-standards.md](../../../packages/core/docs/standards/2-architecture-standards.md)
- [4-api-tech-stack-standards.md](../../../packages/core/docs/standards/4-api-tech-stack-standards.md)

---

## Prompt to use with Cursor

Implement the feature described in this document. Follow the standards and guardrails provided. Add or update tests and verification flows as specified in Testing requirements and Verification. Run validate and fix any issues until it passes.

