# Demo pages

*Enrichment complete (reverse-engineering pass): Route list, page-to-requirement mapping, full step-by-step verification, References.*

## Overview

- **Purpose:** All demo pages and routes that showcase the package: home, styles showcase, data table showcase, auth/organisation flows, storage showcase, calendar, super-admin test (if applicable), and any other pages needed to verify behaviour from requirements 02–10.
- **Scope:** Demo app only (repo root). Package is already implemented in 02–10.
- **Dependencies:** All previous requirements (02–10). Demo consumes the package via workspace.
- **Standards:** 01 Project structure, 05 pace-core compliance, 07 Visual, 08 Testing (demo is not a substitute for tests).

## Candidate integration scope (TRAC2 pace-core2)

- Candidate 3 (route/page permission mapping helper): demo route metadata should remain synchronized with permission requirements through a typed mapping source and parity checks.
- Candidate 7 (print/export primitives): demo print/export route examples are deferred until print/export composition is promoted into scope for at least one additional app.

## Acceptance criteria

- [x] Routes and pages exist for: home, login, styles/showcase (or equivalent), data table showcase, organisation showcase (if applicable), storage showcase, calendar test (if applicable), super-admin test (if applicable), public page example.
- [x] Each page uses only package exports (no duplicate components); follows project structure and styling standards.
- [x] Demo MUST use PaceAppLayout with pace-core’s NavigationMenu (inline pills at `lg+`, compact Select below `lg`) and PaceFooter; no custom nav or footer. Navigation allows user to reach each showcase; protected routes use ProtectedRoute; public route uses PublicPageLayout/Provider.
- [x] Demo runs with `npm run dev` and passes `npm run validate` (typecheck, lint, build, tests, audit). Reports are written to `audit/` (ESLint report and pace-core audit(s); in this repo, two audits: demo app and package).

## API / Contract

- **Not applicable** (demo app is consumer). Demo lives at repo root: `src/`, routes under `src/App.tsx`, pages under `src/pages/`, nav items and route list as implemented. State: Demo at repo root; routes under src/; pages under src/pages/; customNavItems define nav labels and hrefs.

## Behaviour

- Each page MUST use only package exports; MUST follow project structure and styling standards. The demo MUST use the navigation and footer exactly as pace-core provides them (via PaceAppLayout, which uses pace-core’s NavigationMenu and PaceFooter). The demo MUST NOT implement its own nav or footer, or override pace-core’s layout. Protected routes MUST use ProtectedRoute; public routes MUST use PublicPageLayout/Provider. Navigation MUST allow reaching each showcase.
- For shell-routed demo pages rendered inside PaceAppLayout, the page component root MUST NOT be `<main>` because PaceAppLayout already provides the page-level main landmark. Use `<section>`, `<article>`, or fragments for page roots.
- For shell-routed demo pages, page-specific shell main metadata should be declared in each page file using `usePaceMain` (including layout classes and print metadata), not embedded in central route config.

## Demo app requirements

- User can open the app, sign in, navigate to each showcase page, exercise key behaviours (forms, DataTable, file upload, context switch, inactivity modal, public page), and sign out. All behaviour verifiable manually; automated tests cover package code, not full E2E of every demo page.

### Route list and page-to-requirement mapping

| Route | Page / component | Requirement doc |
|-------|------------------|-----------------|
| `/login` | PaceLoginPage | 03-auth-and-context, 06-forms-and-feedback |
| `/unauthorized` | UnauthorizedPage | 03, 04-rbac |
| `/events/*` | PublicPageApp (public) | 09-public-pages |
| `/` | RootRedirect → UserDashboardPage | 03, 05 |
| `/user-dashboard` | UserDashboardPage | 03, 05 |
| `/organisation-showcase` | OrganisationShowcasePage | 03, 10-services-and-providers |
| `/ui-showcase` | UIShowcasePage | 05-primitives-and-layout |
| `/data-table-showcase` | DataTableShowcasePage | 07-datatable |
| `/styles-showcase` | StylesShowcasePage | 05-primitives-and-layout, 02-foundation |
| `/storage-showcase` | StorageShowcasePage | 08-advanced-ui |
| `/calendar-test` | CalendarTestPage | 08-advanced-ui |
| `/super-admin-test` | SuperAdminTestPage | 04-rbac |
| `/shell-minimal-showcase` | ShellMinimalShowcasePage | CR05c (minimal `layoutVariant`) |

Protected routes are wrapped in `<ProtectedRoute>` and `<PaceAppLayout>`; public routes use `PublicPageApp` under `/events/*`.
Protected page files may declare shell main metadata using `usePaceMain` (layout + print metadata).

### CR05c shell demo wiring

The demo app exercises CR05c shell extensions as follows:

- **Default layout** (`layoutVariant="default"`): all standard protected routes use `DemoAppShell` with custom `appSwitcherItems` (labels `CORE (custom list)`, `PORTAL`, `BASE`) and `extraMenuActions` (`Run profile setup wizard` navigates to the minimal showcase).
- **Minimal layout** (`layoutVariant="minimal"`): `/shell-minimal-showcase` uses `DemoAppShell` with `navItems={[]}` — hides app switcher, navigation menu, and context selector; logo link and user menu remain.

```tsx
<PaceAppLayout
  layoutVariant="minimal"
  navItems={[]}
  userFullName={...}
  userEmail={...}
  onUserMenuSignOut={...}
  onUserMenuChangePassword={...}
>
  {/* wizard or focused-flow content */}
</PaceAppLayout>
```

### Step-by-step verification

User opens app → (if unauthenticated) redirected to `/login`. User signs in → lands on `/` (UserDashboard). User navigates via nav: User Dashboard, Organisation Features, UI Showcase, DataTable Showcase, Styles Showcase, Storage Showcase, Calendar Test, Super Admin Test. User opens each and verifies: organisation context, UI components, DataTable (sort, paginate, export), styles/palette, file upload/display, calendar, super-admin (if applicable). User visits `/events/:code/public-showcase` (or equivalent public path) without signing in → sees public content. User signs out → redirected to login. All verifiable manually; validate passes (typecheck, lint, build, tests, audit).

## Verification

- **Route coverage:** Verify each documented demo route is reachable and maps to the intended requirement slice.
- **Layout and guards:** Verify protected routes use `ProtectedRoute` + `PaceAppLayout`, and public routes use public-page wrappers.
- **Main landmark parity:** Verify protected showcase pages under PaceAppLayout do not render nested `<main>` landmarks.
- **Permission-map parity:** Verify each protected demo route has a corresponding typed route/page permission mapping entry and that parity checks fail when an entry is missing.
- **Quality gates:** Verify demo wiring still allows `npm run validate` to pass with package and app checks.

## Testing requirements

- No new package tests in this slice. Demo may have smoke or E2E tests if desired; not required by this doc. Validate must pass (package tests + lint + build + audit).

## Do not

- Do not add new package exports; only wire and present existing package functionality in the demo. Do not duplicate package components in the demo.

## References

- [1-project-structure-standards.md](../../../packages/core/docs/standards/1-project-structure-standards.md), [5-pace-core-compliance-standards.md](../../../packages/core/docs/standards/5-pace-core-compliance-standards.md). Existing demo app structure (reference only). Route list and mapping above; see `src/App.tsx` and `src/pages/` for current implementation.

---

## Prompt to use with Cursor

Implement the feature described in this document. Follow the standards and guardrails provided. Ensure all showcase pages are wired and validate passes. Run validate and fix any issues until it passes.
