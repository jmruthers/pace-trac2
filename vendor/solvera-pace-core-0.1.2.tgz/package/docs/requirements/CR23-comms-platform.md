# CR23 – Shared communications platform (PUMP integration)

## Filename convention

This file is **`CR23-comms-platform.md`** — pace-core requirement slice **CR23** (see [CR00-core-project-brief.md](./CR00-core-project-brief.md)).

---

## Overview

- **Purpose and scope:** implement the `pace-core2` layer of the **shared communications platform** described in **Communications architecture (canonical)** below: recipient pool descriptor contracts, `CommComposer` UI, merge field toolbar, message preview, send/schedule adapter contracts, the type surface consumed by all apps that send communications, and the `sendSystemNotification()` helper for system-triggered transactional notifications. Scope is package + demo verification only.
- **PUMP as a service:** PUMP is the authoritative backend for all communications in the PACE suite. It owns gateway integration, send execution, delivery tracking, **send-time address suppression** (skip recipients on the suppression registry — see **Send-time suppression vs user/operator unsubscribe** below), and audit logging. Other apps (`BASE`, `TEAM`, `TRAC`, etc.) compose and send messages through PUMP's Edge Functions — they do not implement gateway logic directly.
- **What this slice is NOT:** PUMP's management application (template library UI, platform-managed sender-identity tooling outside PUMP, delivery analytics dashboards) is out of scope for this `pace-core2` slice. That application depends on this package but is developed and deployed independently. This slice defines only the shared package surface that all consuming apps rely on.
- **External prerequisites:** PUMP Edge Functions (`pump-send`, `pump-resolve-pool`, `pump-schedule`, `pump-cancel`, `pump-send-test`), the `pump_*` database schema, **platform** gateway credential storage (`pump_gateway_config`), per-org sender identity defaults (`pump_org_settings`), platform-managed email shell branding, and RLS are owned outside this repo and are prerequisites to real integration. Structural DDL and policy rollout are **DB-404`–`DB-411** in [`DB-change-decisions-p4.md`](../../../../docs/database/decisions/DB-change-decisions-p4.md) (including **DB-405** reporting view, **DB-407** legacy drop, **DB-408`–`DB-411** recipient hardening and RLS). **DB-407** must be applied before **DB-404**.
- **Dependencies:** [CR06-forms-and-feedback.md](./CR06-forms-and-feedback.md), [CR10-services-and-providers.md](./CR10-services-and-providers.md), [CR12-supabase-react-query-error-handling.md](./CR12-supabase-react-query-error-handling.md), [CR18-composite-resilience-utilities.md](./CR18-composite-resilience-utilities.md), [CR21-workflow-forms-runtime.md](./CR21-workflow-forms-runtime.md) (adapter pattern), [CR22-shared-reporting-foundations.md](./CR22-shared-reporting-foundations.md) (`pump_comms_log` reporting domain).
- **Standards:** 02 Architecture, 03 Security and RBAC, 04 API and tech stack, 05 pace-core compliance, 06 Code quality, 07 Visual ([7-visual-standards.md](../standards/7-visual-standards.md)), 08 Testing and documentation, 09 Operations.

---

## Communications architecture (canonical)

This section is the authoritative description of how communications work across the PACE suite and how `pace-core2` fits into that picture. **This CR is the source of truth** for the shared package contract; PUMP's internal application requirements are tracked separately in the PUMP repo.

### Architecture decision: PUMP as service, shared composer in pace-core2

Three options were considered:

- **Shared components only** — `pace-core2` exposes a `CommComposer` that each consuming app wires up independently, including gateway calls. Results in duplicated gateway logic, fragmented delivery tracking, and fragmented **send-time suppression** / delivery behaviour across apps.
- **Deep link to PUMP** — consuming apps build a recipient list and hand off to PUMP via URL params. Avoids duplication but creates context-switching UX, makes recipient list serialisation fragile, and requires RBAC to span two apps explicitly.
- **PUMP as service with shared composer (chosen)** — `pace-core2` exposes a `CommComposer` component and a typed adapter contract. The adapter always calls PUMP's Edge Functions. PUMP owns gateway routing, delivery tracking, and **send-time suppression** (registry consulted at send; see below). Consuming apps pass a typed `RecipientPoolDescriptor` and a scoped adapter; the send pipeline is identical regardless of which app the message originates from.

### Send-time suppression vs user/operator unsubscribe (normative for v1)

| In scope (platform / Edge) | Out of scope (PUMP v1 **product**) |
| --- | --- |
| **`pump-send`** checks the suppression registry (`pump_suppression`) and **skips** matching addresses; skipped recipients are reflected in results (e.g. `suppression_skipped`, pool warnings). | **End-user unsubscribe journeys** hosted in PUMP (e.g. public “unsubscribe from marketing” pages). |
| **`pump-webhook/{gateway}`** may **append** suppression rows from provider signals (hard bounces, spam complaints, etc.). | **Operator / admin screens** in the PUMP management app to browse, edit, or manage subscriber opt-outs as a **marketing list** feature. |
| **`CommPoolWarning`** / recipient status may surface that addresses were skipped. | **List-unsubscribe** or bulk **compliance** product flows; treat as future product unless explicitly scoped. |
| **`CommSendRequest.bypass_suppression: true`** instructs `pump-send` to skip the suppression registry for that send — used exclusively by **system-triggered transactional notifications** (e.g. payment failed, application approved). `pump-send` still creates full audit rows. | **Operator-initiated sends**: `bypass_suppression` defaults to `false` and is never exposed as a UI option in `CommComposer`. |

**Naming:** The table is still called `pump_suppression` in schema for historical reasons; behaviour in v1 is **suppression for safe sending**, not a commitment to ship **user unsubscribe management** in the PUMP UI.

Concretely:

| Concern | Location |
| --- | --- |
| Send pipeline, gateway routing | PUMP Edge Functions (`pump-send`) |
| Delivery tracking, webhook handling | PUMP Edge Functions (`pump-webhook/{gateway}`) |
| Send-time suppression registry | `pump_suppression` — Edge-maintained; **send-time skips** + provider-driven rows; **not** operator “user unsub” management in PUMP v1 |
| Template library | `pump_organisation_templates` table; managed in PUMP app |
| Audit log | `pump_message` + `pump_message_recipient` (reporting surface: `pump_comms_log` view — see DB-405) |
| Merge field definitions | **`core_field_list`** rows with **`pump_merge_availability = true`** (platform catalogue; see **Merge field system**) |
| Composer UI, pool preview, merge toolbar | `pace-core2` (this package) |
| Pool resolution logic | PUMP Edge Function (`pump-resolve-pool`) |
| PUMP management screens | PUMP application (separate repo/deployment) |
| App-scoped send surface | Consuming app mounts `CommComposer` with pool + adapter |

### Three layers

- **`pace-core2` (this package)** — `CommComposer` UI, `RecipientPoolPreview`, `MergeFieldToolbar`, `MessagePreview`, adapter contracts, pool descriptor types, all shared type contracts.
- **PUMP service layer** — Edge Functions that own the send pipeline, gateway abstraction, delivery tracking, **send-time suppression checks**, webhook-driven suppression updates, and audit logging. Transport-agnostic adapters in consuming apps call these functions.
- **PUMP management application** — template library management, delivery analytics, and compose/send UX. **Org sender identity** comes from platform-managed `pump_org_settings`; **provider API keys** live in **platform** `pump_gateway_config`; the master email shell/branding source is also platform-managed outside the PUMP UI. **No** sender-identity settings screen, **no** user/operator **unsubscribe management** product surface, and **no** platform-gateway credential screen in v1. Suppression remains **Edge/registry** behaviour per **Send-time suppression vs user/operator unsubscribe**. Consumes the same `pace-core2` components.

### Recipient pool descriptor

The pool descriptor is the **typed contract** by which a consuming app tells PUMP who should receive a message. Resolution — turning the descriptor into an actual list of recipients with merge data — is always performed server-side by `pump-resolve-pool`. The UI uses the resolved preview (count + sample) for display only; it never constructs the recipient list in-browser.

Pool descriptor is a discriminated union:

```typescript
type RecipientPoolDescriptor =
  | OrgMembersPool
  | EventParticipantsPool
  | ManualPool
  | CustomFilterPool;
```

**`OrgMembersPool`** — TEAM use case: members of an organisation.
```typescript
{
  type: 'org_members';
  organisation_id: string;
  filters?: {
    member_type_ids?: string[];
    unit_ids?: string[];
    include_inactive?: boolean;
    age_min?: number;
    age_max?: number;
  };
}
```

**`EventParticipantsPool`** — BASE use case: participants registered for an event.
```typescript
{
  type: 'event_participants';
  event_id: string;
  filters?: {
    registration_type_ids?: string[];
    status?: Array<'submitted' | 'under_review' | 'approved' | 'rejected' | 'withdrawn'>;
    unit_ids?: string[];
  };
}
```

`event_participants.filters.status` is an application-domain filter and maps 1:1 to `base_application.status`.
`waitlisted` is a booking-domain status (`base_activity_booking.status`) and must not appear in this filter.
No compatibility translation (legacy-to-current mapping) is permitted in the resolver contract.

**`ManualPool`** — explicit list of member IDs; used when the sending context has already performed its own selection.
```typescript
{
  type: 'manual';
  member_ids: string[];
}
```

**`CustomFilterPool`** — extensible escape hatch for future apps or complex filter shapes not covered by the named variants.
```typescript
{
  type: 'custom_filter';
  filter_key: string;           // a registered server-side filter key (e.g. 'trac.unconfirmed_assignments')
  params: Record<string, unknown>;
}
```

**Design invariants:**
- Pool descriptors are serialisable JSON — safe to persist as `jsonb` on `pump_message.recipient_pool_descriptor` for audit.
- **Additional contact auto-resolution for member-context sends:** `pump-resolve-pool` and `pump-send` automatically include any additional contacts linked to a member with `Full` or `Notify` access (see **Additional contact access tiers** in PR08) when resolving standard member-context sends. This applies to operator-initiated sends and to system notifications that explicitly target the member context. The pool preview count reflects the resolved total including additional contacts.
- **System recipient override:** system-triggered notifications may use an explicit `SystemNotificationRecipientDescriptor` instead of generic additional-contact expansion. When a system notification uses `canonical_parent_contact`, recipient resolution must use the canonical parent-contact mapping only and must not fall back to generic additional-contact inclusion.
- Apps must never construct recipient lists in-browser and pass them to the send function. Only `ManualPool` accepts explicit IDs, and even then, merge data resolution happens server-side.

### Merge field system

**Authoritative catalogue:** merge tokens available in **`CommSendAdapter.loadMergeFields`** are rows in **`core_field_list`** where **`pump_merge_availability = true`**. There is **no** `pump_merge_field` table — see `docs/database/domains/pump.md` and **DEC-008** in [`DB-change-decisions-p1.md`](../../../../docs/database/decisions/DB-change-decisions-p1.md). Apps must consume the named **`pump_list_merge_fields(...)`** read contract for this catalogue rather than each browser querying raw metadata tables independently. **`pump_*` RPC names** are platform contract surfaces (exempt from consuming-app `data_*` / `app_*` lint); see Standard 4. Adding a new merge-safe field is a **platform** process: DDL + row in **`core_field_list`** with the flag set.

The tables below are **illustrative** tokens and resolution sources — each must be represented in **`core_field_list`** (and flagged) before the composer treats it as a first-class merge field.

**Commonly enabled merge fields** (available when the corresponding **`core_field_list`** rows are flagged):

| Token | Key | Resolved from |
| --- | --- | --- |
| `{{first_name}}` | `first_name` | `core_person.first_name` |
| `{{last_name}}` | `last_name` | `core_person.last_name` |
| `{{full_name}}` | `full_name` | computed |
| `{{email}}` | `email` | member's primary email |
| `{{phone}}` | `phone` | member's primary phone |
| `{{organisation_name}}` | `organisation_name` | `core_organisations.name` |

**Context-dependent fields** (available when flagged in **`core_field_list`** and the pool provides the data):

For `event_participants` pools:

| Token | Key | Resolved from |
| --- | --- | --- |
| `{{event_name}}` | `event_name` | `core_events.name` |
| `{{event_start_date}}` | `event_start_date` | `core_events.start_date` |
| `{{event_location}}` | `event_location` | `core_events.location` |
| `{{registration_type}}` | `registration_type` | `base_registration_type.name` |
| `{{unit_name}}` | `unit_name` | `base_units.name` if assigned |

For `org_members` pools:

| Token | Key | Resolved from |
| --- | --- | --- |
| `{{member_type}}` | `member_type` | member type label |
| `{{unit_name}}` | `unit_name` | unit name if assigned |

**Resolution rules:**
- All tokens are resolved server-side at send time using the resolved recipient context in Supabase. For member-context sends this is the recipient's membership data plus supplied workflow context. For canonical parent-contact system notifications this is the resolved parent-contact data plus supplied workflow context.
- Apps may inject additional context-specific merge data via `CommDraft.extraMergeContext` (a `Record<string, string>` bag); these are passed through to the Edge Function and stored per-recipient in `pump_message_recipient.merge_data`.
- The `MergeFieldToolbar` component presents only the merge fields available for the current pool context (passed via `CommSendAdapter.loadMergeFields`).

**Two-phase token validation:**

Token validation operates in two phases with deliberately different roles:

*Phase 1 — Compose time (UI, primary gate):* `MessagePreview` renders the message body with merge tokens resolved against the pool's sample recipient. Any token that `loadMergeFields` did not return for the current pool context is rendered with a visually distinct treatment (amber highlight + tooltip: "This token could not be previewed"). This is the primary operator-facing guard — the problem is visible before send. `CommComposer` accepts a `blockSendOnUnresolvedTokens?: boolean` prop; when `true`, the send CTA is disabled while any unresolved tokens remain in the preview. Consuming apps set this based on context — BASE event comms should default to `true`; PUMP ad-hoc composition may leave it `false`.

*Phase 2 — Send time (Edge Function, safety net):* `pump-send` attempts to resolve every token against the recipient's data. Tokens that cannot be resolved (unknown key, null data) are left as their literal form (e.g. `{{event_name}}`) and recorded in `CommSendResult.warnings` as `CommTokenWarning` entries. The send is **not** blocked — the warning is a post-send record. This permissive behaviour is the default for all sends.

*Template-level strict mode:* `pump_organisation_templates.require_merge_field_validation` (boolean, default `false`) switches the Edge Function to strict behaviour for messages sent from that template. When `true`, `pump-send` rejects the send if any referenced merge field in the message cannot be resolved, returning a validation error rather than proceeding. PUMP admins use this to mark templates where unresolved merge fields are unacceptable (e.g. a registration confirmation that must always have `{{first_name}}` and `{{event_name}}`). Ad-hoc messages (no template) always use the permissive default.

The UI phase is the primary protection; the Edge Function phase is the safety net. Never rely solely on Edge Function token validation as the UX guard — by the time it fires, the message has already been composed and submitted.

### PUMP database schema (normative contracts)

DDL is **DB-404** and **DB-405** (plus **DB-407`–`DB-411** for pre-migration, recipient hardening, and RLS) in [`DB-change-decisions-p4.md`](../../../../docs/database/decisions/DB-change-decisions-p4.md). Normative intent below; exact column types and constraints live in migrations.

**`pump_organisation_templates`** — template library per organisation.

| Column | Type | Notes |
| --- | --- | --- |
| `id` | uuid pk | |
| `organisation_id` | uuid fk | `core_organisations` |
| `name` | text | |
| `description` | text | optional |
| `channel` | `comm_channel` | `'email' \| 'sms'` |
| `subject` | text | email only; may contain merge tokens |
| `body_html` | text | email only |
| `body_text` | text | email + sms |
| `merge_fields_used` | text[] | token list e.g. `['{{first_name}}', '{{event_name}}']` |
| `is_active` | boolean | |
| `require_merge_field_validation` | boolean | default `false`; when `true`, `pump-send` rejects sends with unresolvable referenced merge fields |
| `created_by` | uuid fk | `auth.users` |
| `created_at` | timestamptz | |
| `updated_at` | timestamptz | |

**`pump_system_templates`** — platform-owned system-message copy.

| Column | Type | Notes |
| --- | --- | --- |
| `id` | uuid pk | |
| `system_key` | text | immutable runtime key |
| `channel` | `comm_channel` | `'email' \| 'sms'` |
| `locale` | text | nullable in MVP |
| `subject` | text | email only; may contain merge fields |
| `body_html` | text | email only |
| `body_text` | text | email + sms |
| `require_merge_field_validation` | boolean | default `true`; when `true`, `pump-send` rejects sends with unresolvable referenced merge fields |
| `is_active` | boolean | soft-disable without deleting seeded copy |
| `created_at` | timestamptz | |
| `updated_at` | timestamptz | |

**`pump_message`** — the send-batch envelope; one row per send action.

| Column | Type | Notes |
| --- | --- | --- |
| `id` | uuid pk | |
| `organisation_id` | uuid fk | |
| `channel` | `comm_channel` | |
| `subject` | text | email only |
| `body_html` | text | email only |
| `body_text` | text | |
| `template_id` | uuid fk | nullable; ref to `pump_organisation_templates` |
| `sender_name` | text | |
| `sender_email` | text | email only |
| `sender_phone` | text | sms only |
| `reply_to_email` | text | email only, nullable |
| `status` | `pump_message_status` | `'draft' \| 'scheduled' \| 'sending' \| 'sent' \| 'cancelled' \| 'failed'` |
| `scheduled_at` | timestamptz | nullable |
| `sent_at` | timestamptz | nullable |
| `source_app` | text | `'pump' \| 'base' \| 'team' \| 'trac' \| 'mint' \| …` |
| `source_context_type` | text | `'event' \| 'organisation' \| null` |
| `source_context_id` | uuid | nullable |
| `recipient_pool_descriptor` | jsonb | serialised `RecipientPoolDescriptor` at send time |
| `total_recipients` | integer | resolved at send time |
| `created_by` | uuid fk | |
| `created_at` | timestamptz | |
| `updated_at` | timestamptz | |

**`pump_message_recipient`** — one row per recipient per message.

| Column | Type | Notes |
| --- | --- | --- |
| `id` | uuid pk | |
| `message_id` | uuid fk | `pump_message` |
| `organisation_id` | uuid fk | tenant anchor for RLS (**DB-408**); denormalised from parent message |
| `member_id` | uuid fk | nullable (manual sends may not have member IDs) |
| `address` | text | email address or phone number |
| `merge_data` | jsonb | resolved merge values stored at send time |
| `status` | `pump_recipient_status` | `'pending' \| 'queued' \| 'delivered' \| 'bounced' \| 'failed' \| 'suppression_skipped'` |
| `gateway_message_id` | text | provider-issued message ID for webhook correlation |
| `delivered_at` | timestamptz | nullable |
| `opened_at` | timestamptz | nullable (email only) |
| `clicked_at` | timestamptz | nullable (email only) |
| `failed_at` | timestamptz | nullable |
| `failure_reason` | text | nullable |
| `created_at` | timestamptz | |

**`pump_delivery_event`** — immutable webhook log; source of truth for delivery status transitions.

| Column | Type | Notes |
| --- | --- | --- |
| `id` | uuid pk | |
| `recipient_id` | uuid fk | `pump_message_recipient` |
| `event_type` | text | normalized provider event type: `'queued' \| 'delivered' \| 'delivery_delayed' \| 'opened' \| 'clicked' \| 'bounced' \| 'failed' \| 'spam_complaint' \| 'unsubscribed' \| 'suppressed'` |
| `gateway` | text | e.g. `'resend' \| 'twilio' \| 'sendgrid' \| 'mailgun' \| …` |
| `provider_event_id` | text | nullable gateway event id when the provider supplies one |
| `dedupe_key` | text | deterministic webhook replay key; unique with `gateway` |
| `raw_payload` | jsonb | full provider webhook body |
| `occurred_at` | timestamptz | |
| `created_at` | timestamptz | |

**`pump_suppression`** — **suppression registry** per org per channel (send-time skips; provider/webhook-driven rows). Infrastructure only — not a PUMP v1 feature for operators to manage end-user opt-outs. System-triggered transactional notifications (see **System-triggered notifications**) bypass this registry via `bypass_suppression: true`.

| Column | Type | Notes |
| --- | --- | --- |
| `id` | uuid pk | |
| `organisation_id` | uuid fk | |
| `member_id` | uuid fk | nullable |
| `address` | text | email/phone **suppressed** for sends on this channel |
| `channel` | `comm_channel` | |
| `reason` | text | `'recipient_request' \| 'hard_bounce' \| 'spam_complaint' \| 'manual'` — **audit provenance** (e.g. provider event); **`recipient_request`** does **not** imply PUMP v1 ships a subscriber-facing unsub product |
| `source_message_id` | uuid fk | nullable; originating message when known |
| `created_at` | timestamptz | |

**`pump_gateway_config`** — **platform-wide** outbound gateway credentials (**one row per `channel`** for the deployment; not per organisation).

| Column | Type | Notes |
| --- | --- | --- |
| `channel` | `comm_channel` | **primary key** — `email` \| `sms` |
| `gateway_type` | text | e.g. `'resend' \| 'twilio' \| 'sendgrid' \| 'mailgun' \| 'ses'` |
| `config` | jsonb | provider API keys and options; **Edge** only at send time — not edited via PUMP org UI |
| `is_active` | boolean | |
| `updated_at` | timestamptz | |

**`pump_org_settings`** — **per-organisation** sender identity defaults only (`default_sender_name`, `default_from_address`, `default_reply_to_address`, `sms_from_number`). **Not** provider secrets and **not** arbitrary HTML chrome — those stay in **`pump_gateway_config`** and the separate platform-managed email shell/branding source. Exact columns follow migrations / domain docs.

### Effective sender identity contract (platform-managed)

The shared comms surface and the PUMP service layer must consume **one server-resolved sender-identity contract**. Browser code must not traverse `pump_org_settings` or org-hierarchy tables directly to rebuild fallback logic.

```ts
interface EffectivePumpSenderIdentity {
  organisationId: string;
  sourceContextType?: 'event' | 'organisation';
  sourceContextId?: string;
  senderName: string | null;
  fromAddress: string | null;
  replyToAddress: string | null;
  senderPhone: string | null;
  resolvedFrom: 'source_context' | 'organisation' | 'ancestor' | 'unresolved';
  resolvedOrganisationId: string | null;
  canSendEmail: boolean;
  canSendSms: boolean;
}
```

**Resolution order:** source-context override supplied by the source app → active-org `pump_org_settings` → ancestor chain via server-side hierarchy helpers → unresolved terminal state when no tier matches.

**Contract rules**

- The same resolved contract is used for compose-time display and send-time validation.
- `canSendEmail` requires `senderName` and `fromAddress`.
- `canSendSms` requires `senderPhone`.
- `resolvedFrom` and `resolvedOrganisationId` are operational audit fields so operators can see where the identity came from without receiving edit controls.
- Concrete read contract: **`pump_get_effective_sender_identity(organisation_id uuid, source_context_type text default null, source_context_id uuid default null)`** returns exactly one `EffectivePumpSenderIdentity` row for the caller's permitted scope.

**Merge field catalogue:** use existing **`core_field_list`** with **`pump_merge_availability`** — not a `pump_*` table. **`CommMergeField`** / toolbar data is derived from those rows through **`pump_list_merge_fields(organisation_id uuid, channel comm_channel, recipient_pool jsonb, source_context_type text default null, source_context_id uuid default null)`**, which returns rows aligned to `CommMergeField`.

**No new `core_*` tables for MVP** solely for PUMP. Comms **payload** tables use the `pump_` prefix; **merge metadata** reuses **`core_field_list`**.

### PUMP Edge Function contracts (normative)

These functions are owned and deployed by PUMP. `pace-core2` components call them only through the `CommSendAdapter` interface — the package never imports or depends on PUMP Edge Function code directly.

**`pump-send`** — execute a send.

- Receives: `CommSendRequest` (serialised)
- Validates: `organisation_id` auth claim matches pool scope; sender identity sufficient for channel (from request and/or the shared **effective sender identity** contract); body non-empty; pool does not violate product rules.
- Resolves: pool descriptor → actual recipients with merge data.
- Checks: `pump_suppression` (**suppression registry**) — skips recipients with matching org/channel/address; records them as `suppression_skipped` ( **send-time skip** , not an operator unsub workflow).
- Resolves: merge tokens per recipient.
- Creates: `pump_message` + `pump_message_recipient` rows.
- Dispatches: to gateway using **platform** `pump_gateway_config` for the message **`channel`** (credentials are **not** per-org).
- Returns: `CommSendResult` with message ID, recipient count, any token-resolution warnings.

**`pump-resolve-pool`** — preview a pool without sending.

- Receives: `RecipientPoolDescriptor` + `organisation_id`.
- Validates: caller is authorised for the pool's scope.
- Returns: `CommRecipientPreview` — estimated count, sample of up to 5 first names, and a list of any pool filter warnings (e.g. "12 recipients have no email address").

**`pump-schedule`** — queue a message for future sending.

- Receives: `CommScheduleRequest` (same shape as `CommSendRequest` + `scheduled_at` timestamp).
- Validates and resolves pool same as `pump-send`; does not dispatch to gateway.
- Creates: `pump_message` with `status = 'scheduled'`.
- Returns: `CommScheduleResult` with message ID.

**`pump-send-test`** — send the current message content to the current signed-in user only.

- Receives: `CommSendTestRequest`.
- Validates: caller is authenticated for the requested organisation scope; selected channel is permitted; sender identity is sufficient for the channel; the current signed-in user has an email address or phone number for that channel.
- Resolves: the destination from the caller's current user identity only. It does **not** accept a `pool`, `system_key`, `system_recipient`, or arbitrary typed recipient input.
- Dispatches: through the same gateway path as `pump-send`.
- Returns: `CommSendResult` with a single-recipient outcome or a validation error if the caller lacks a usable destination.

**`pump-cancel`** — cancel a scheduled message.

- Receives: message ID.
- Validates: caller owns the message; status is `'scheduled'`.
- Updates: `pump_message.status = 'cancelled'`.
- Returns: updated message ID.

**`pump-webhook/{gateway}`** — receive delivery status callbacks from gateways.

- Receives: gateway-specific webhook payload.
- Creates: `pump_delivery_event` rows.
- Idempotency: persists `provider_event_id` when present and a deterministic `dedupe_key` for every event; duplicate `(gateway, dedupe_key)` deliveries are ignored after first successful application.
- Updates: `pump_message_recipient.status`, `delivered_at`, `opened_at`, `clicked_at`, `failed_at`.
- On bounce / spam / provider **unsubscribe** signals: may create or update **`pump_suppression`** (**suppression**) rows so future sends skip those addresses (**platform behaviour**; still **no** PUMP v1 user/operator unsub management UI).
- Never called by consuming apps; invoked by gateway providers.

**Webhook provider mapping (v1):** mappings are provider protocol logic in PUMP Edge code, not DB-configurable product settings. Store the original provider event/status in `raw_payload`; `event_type` is the normalized PUMP category.

| Gateway | Provider event / status | Normalized `event_type` | Recipient side effect | Suppression side effect | Dedupe source |
| --- | --- | --- | --- | --- | --- |
| Resend | `email.sent` | `queued` | Set recipient `status = 'queued'` unless already terminal or delivered. Correlate by `data.email_id = gateway_message_id`. | None | `svix-id` header |
| Resend | `email.delivered` | `delivered` | Set `status = 'delivered'`; set `delivered_at` from provider event time. | None | `svix-id` header |
| Resend | `email.delivery_delayed` | `delivery_delayed` | Insert event only; do not regress status. | None | `svix-id` header |
| Resend | `email.opened` | `opened` | Set `opened_at`; do not change main status. | None | `svix-id` header |
| Resend | `email.clicked` | `clicked` | Set `clicked_at`; do not change main status. | None | `svix-id` header |
| Resend | `email.bounced` | `bounced` | Set `status = 'bounced'`; set `failed_at`; set `failure_reason` from bounce payload when present. | If hard/permanent bounce, upsert `pump_suppression.reason = 'hard_bounce'`. | `svix-id` header |
| Resend | `email.complained` | `spam_complaint` | Set `status = 'failed'`; set `failed_at`; set `failure_reason = 'spam_complaint'`. | Upsert `pump_suppression.reason = 'spam_complaint'`. | `svix-id` header |
| Resend | `email.failed` | `failed` | Set `status = 'failed'`; set `failed_at`; set `failure_reason` from provider payload when present. | None unless provider also sends bounce/complaint/suppression signal. | `svix-id` header |
| Resend | `email.suppressed` | `suppressed` | Set `status = 'suppression_skipped'`; set `failure_reason` from provider payload when present. | Ensure local suppression row exists if enough address/channel context is available; preserve provider details in `raw_payload`. | `svix-id` header |
| Twilio SMS status callback | `queued`, `sent` | `queued` | Set `status = 'queued'` unless already delivered or terminal. | None | Deterministic key from `MessageSid` + status |
| Twilio SMS status callback | `sending` | `queued` | Diagnostic event only; do not change status if already `queued` or later. | None | Deterministic key from `MessageSid` + status |
| Twilio SMS status callback | `delivered` | `delivered` | Set `status = 'delivered'`; set `delivered_at` from callback receipt time; keep `RawDlrDoneDate` in `raw_payload` if supplied. | None | Deterministic key from `MessageSid` + status + `RawDlrDoneDate` when present |
| Twilio SMS status callback | `undelivered` | `bounced` | Set `status = 'bounced'`; set `failed_at`; set `failure_reason` from `ErrorCode` when present. | If `ErrorCode = 21610`, upsert `pump_suppression.reason = 'recipient_request'`. | Deterministic key from `MessageSid` + status + `ErrorCode` + `RawDlrDoneDate` when present |
| Twilio SMS status callback | `failed` | `failed` | Set `status = 'failed'`; set `failed_at`; set `failure_reason` from `ErrorCode` when present. | If `ErrorCode = 21610`, upsert `pump_suppression.reason = 'recipient_request'`. | Deterministic key from `MessageSid` + status + `ErrorCode` when present |

**Status precedence:** `opened` and `clicked` are additive timestamps and never change `pump_message_recipient.status`. `delivery_delayed` never changes status. `queued`/`sent`/`sending` must not overwrite `delivered`, `bounced`, `failed`, or `suppression_skipped`. Negative terminal events (`bounced`, `failed`, `spam_complaint`, `suppressed`, provider opt-out) may supersede `queued` or `delivered` while preserving earlier timestamps in their dedicated columns.

**Twilio Event Streams note:** if PUMP later consumes Twilio Event Streams instead of classic status callbacks, map uppercase `messageStatus` values to the same Twilio rows above and use the CloudEvents `id` (or `{source}:{id}`) as `provider_event_id` / `dedupe_key`.

### RBAC model

**Normative standard:** [3-security-rbac-standards.md](../standards/3-security-rbac-standards.md) — PACE uses **page-level** permissions with the shape **`{operation}:page.{page-slug}`** (kebab-case slug identical to `rbac_app_pages.page_name`), RLS via `data_data_check_rbac_permission_with_context(..., data_get_app_id('PUMP'))`, UI via `PagePermissionGuard` and pace-core RBAC hooks, and Edge Functions via `setupRBAC()` + `isPermitted()`. **Do not** introduce a parallel `pump:*` permission namespace for new work; registry rows and role templates should grant the page actions below.

**PUMP app pages (clean redesign):**

| Page (RLS / RBAC context key) | Typical actions | Primary surfaces / tables |
| --- | --- | --- |
| `comms-log` | `read`, `create`, `update`, `delete` | Communications log / home, `pump_message`, read paths on `pump_message_recipient`; permission strings e.g. `read:page.comms-log`, `create:page.comms-log`, `update:page.comms-log`, `delete:page.comms-log` |
| `comms-templates` | `read`, `create`, `update`, `delete` | Template library UI, `pump_organisation_templates` |
| `comms-settings` | `read`, `create`, `update`, `delete` | Sender identity / org comms settings, `pump_org_settings` |

Exact page names MUST stay aligned with `rbac_app_pages` and RLS policies (see **DB-409**, **DB-410**, **DB-411** in [`DB-change-decisions-p4.md`](../../../../docs/database/decisions/DB-change-decisions-p4.md)).

**`CommRbacContext` — derived booleans, not separate permissions:**

The shared composer accepts a small boolean surface for UX. Populate it from the **same** page grants the database enforces (typically **`comms-log`** for send flows):

| Prop | Suggested source (v1) |
| --- | --- |
| `canCompose` | `create:page.comms-log` |
| `canSend` | `update:page.comms-log` |
| `canSchedule` | `update:page.comms-log` |

PUMP management app behaviour (e.g. operators with `update:page.comms-log` updating any in-org row including `status`, vs draft-only author policies) is defined in application and DB decision docs — not via extra permission namespaces.

**Cross-app scope:**

Consuming apps assign roles that include the page actions above for the relevant organisation (and, where product requires, tighter scope enforced in Edge). The `CommRbacContext` prop carries the **UI** scope for labels and validation; Edge Functions still re-check using `isPermitted` and payload rules (e.g. `source_context_id`).

```typescript
interface CommRbacContext {
  canCompose: boolean;
  canSend: boolean;
  canSchedule: boolean;
  scopeType: 'event' | 'organisation';
  scopeId: string;             // event_id or organisation_id the user is authorised for
}
```

**Enforcement invariant:** even if a UI passes `canSend: true`, PUMP Edge Functions (`pump-send`, `pump-schedule`, etc.) MUST call pace-core **`isPermitted()`** with the appropriate **`{operation}:page.{page-slug}`** strings and organisation scope, and MUST validate that `source_context_id` (and related fields) match a scope the caller is allowed to act in. UI and `CommRbacContext` control UX only; **RLS + Edge** are the security boundary.

**Suppression registry (`pump_suppression`):** Used at **send time** to skip suppressed addresses and updated from **webhooks** / provider signals. This is **not** “user unsubscribe management” as a PUMP v1 product (no subscriber journeys, no operator marketing opt-out console). There is **no** `pump:manage_unsubscribes` (or similar) page permission in v1; if a future **operator** suppression admin UI is explicitly scoped, register a **page** per Standard 03 (e.g. a new dedicated page — not implied by any v1 sender-identity surface).

### App vs shared-package responsibilities

**Each consuming app:**
- Constructs a `RecipientPoolDescriptor` appropriate to its domain context.
- Uses the shared `useCommSendAdapter(...)` hook by default to call PUMP's Edge Functions through the secure Supabase client/session (with the user's auth claim), or provides an app-specific `CommSendAdapter` only when approved product requirements need custom transport behavior.
- Provides a `CommRbacContext` derived from **page** grants (`comms-log`, etc.) using the same **`{operation}:page.{page-slug}`** strings as RLS (pace-core RBAC hooks / guards).
- Mounts `CommComposer` with the pool, adapter, and RBAC context.
- Does **not** implement gateway logic, delivery tracking, or **operator / user unsubscribe management** (suppression is **PUMP Edge + registry** only).

**Shared package (`pace-core2`):**
- Validates that a `CommDraft` has the required fields before the adapter is called.
- Renders the pool preview, merge field toolbar, message preview, send/schedule controls.
- Exposes all types consumed by both PUMP and consuming apps.
- Does **not** call gateway providers, persist messages, or resolve merge fields — these are adapter and Edge Function concerns.

**PUMP application:**
- Mounts `CommComposer` without pool scope restrictions (full org access).
- Adds template management, compose/send UX, and analytics screens. Sender identity remains platform-managed outside the PUMP UI; **platform** gateway credentials are also maintained outside this app (ops / migrations).
- Uses the same `pace-core2` components as any other consuming app.
- **v1:** does **not** add subscriber-facing unsubscribe flows or operator **marketing opt-out management** UIs; **`pump_suppression`** is maintained by **Edge** for **send-time suppression** only (see **Send-time suppression vs user/operator unsubscribe**).

### Consuming app integration pattern

The integration is deliberately thin. A BASE event organiser screen would look like this (illustrative, not prescriptive):

```tsx
// In BASE: EventCommsPage.tsx (illustrative — use pace-core RBAC hooks that evaluate
// the same strings as RLS, e.g. create:page.comms-log / update:page.comms-log)
const pool: RecipientPoolDescriptor = {
  type: 'event_participants',
  event_id: event.id,
  filters: { status: ['approved'] },
};

const adapter = useCommSendAdapter({
  organisationId: event.organisation_id,
  sourceApp: 'base',
  sourceContextType: 'event',
  sourceContextId: event.id,
}); // shared pace-core transport adapter — calls PUMP Edge/read contracts

// Derive booleans from the same page grants as RLS (pace-core RBAC hooks / guards).
// Strings must match policies, e.g. create:page.comms-log, update:page.comms-log.
const commsLogCanCreate = /* useResourcePermissions or equivalent */;
const commsLogCanUpdate = /* useResourcePermissions or equivalent */;
const rbac: CommRbacContext = {
  canCompose: commsLogCanCreate,
  canSend: commsLogCanUpdate,
  canSchedule: commsLogCanUpdate,
  scopeType: 'event',
  scopeId: event.id,
};

return (
  <CommComposer
    recipientPool={pool}
    adapter={adapter}
    rbac={rbac}
    onCancel={() => navigate(-1)}
  />
);
```

The same pattern applies in TEAM (using `org_members` pool), TRAC (using `custom_filter` pool for assignment-related sends), and MINT (using `manual` pool for payment-related comms).

### System-triggered notifications

Not all sends are operator-initiated. Many PACE events require the platform to send a notification automatically — an application being approved or rejected, a payment failing, a photo being rejected, and similar transactional signals. These are system-triggered sends: no human composes them, no `CommComposer` is mounted, and they fire as a side effect of an action that already occurred inside an Edge Function.

The send pipeline (`pump-send`) is identical for both operator-initiated and system-triggered sends. What differs is who constructs the request and when.

#### Pattern

A system-triggered notification is a call to `pump-send` (via `CommSendAdapter.send`) made from within the orchestrating Edge Function for the triggering action. It uses a platform-owned row in `pump_system_templates` identified by immutable `system_key` and an explicit `SystemNotificationRecipientDescriptor` that tells PUMP how to resolve the recipient. No `CommComposer` is involved.

The shared package exposes a `sendSystemNotification()` utility that constructs a correctly shaped `CommSendRequest` and calls the adapter — consuming app Edge Functions call this rather than constructing the request shape manually.

```typescript
// Example: inside a BASE Edge Function that approves an application
await sendSystemNotification(adapter, {
  systemKey: 'base.application_approved',
  recipient: {
    type: 'member_context',
    member_id: application.member_id,
  },
  organisationId: event.organisation_id,
  sourceApp: 'BASE',
  sourceContextType: 'event',
  sourceContextId: event.id,
  extraMergeContext: {
    event_name: event.name,
    registration_type: application.type_label,
  },
});
```

#### Notification template conventions

System notification templates live in `pump_system_templates`, are keyed by immutable `system_key`, and are seeded / maintained outside normal PUMP template CRUD. Merge fields resolve through the same server-side `core_field_list` catalogue as operator-initiated sends, but the available recipient fields depend on the system recipient mode. Sender identity and email shell branding still resolve through the same event → org → ancestor → root fallback chain.

**System recipient modes:**

| Mode | Resolution rule | Merge basis |
| --- | --- | --- |
| `member_context` | Resolve the member plus any linked additional contacts with `Full` or `Notify` access | Member details |
| `canonical_parent_contact` | Resolve linked contacts only through the canonical parent-contact mapping (`core_contact_type.id = 1`) | Parent/contact details only |

For `canonical_parent_contact`, only parent/contact name and contact-info fields guaranteed by the additional-contact contract are assumed to be available for merge resolution. If no canonical parent contact is found, `pump-send` returns a warning and the notification failure remains non-fatal to the triggering action.

**System notification template keys (namespaced):**

All keys use the `{app}.{event}` pattern. Plain keys from the initial CR23 seed (`registration_approved`, `registration_rejected`, `payment_failed`, `photo_rejected`) are **deprecated** (`is_active = false`) as of `20260611110920_pump_system_notification_templates_v2.sql`.

| App | `system_key` | Trigger |
| --- | --- | --- |
| BASE | `base.guardian_request_issued` | Guardian approval requested |
| BASE | `base.guardian_request_reissued` | Guardian approval reminder |
| BASE | `base.referee_request_issued` | Referee request issued |
| BASE | `base.referee_request_reissued` | Referee request reminder |
| BASE | `base.application_submitted` | Applicant submits event application |
| BASE | `base.application_approved` | Application approved |
| BASE | `base.application_rejected` | Application rejected |
| TEAM | `team.member_request_received` | Join or transfer request submitted |
| TEAM | `team.member_request_approved` | Admin approves member request |
| TEAM | `team.member_request_rejected` | Admin rejects member request |
| TEAM | `team.member_request_on_hold` | Admin places request on hold |
| TEAM | `team.photo_rejected` | Photo moderation rejects submitted photo |
| MINT | `mint.invoice_issued` | Invoice created and dispatched |
| MINT | `mint.payment_received` | Payment successfully processed |
| MINT | `mint.payment_failed` | Payment processing failed |
| MINT | `mint.payment_reminder` | Overdue invoice reminder (admin-triggered) |
| MINT | `mint.refund_issued` | Refund processed |

`{{first_name}}` is auto-resolved by the PUMP edge service. `{{organisation_name}}` must be passed via `extraMergeContext` by the calling Edge Function for TEAM templates and selected MINT templates.

This list is extensible; add rows to `pump_system_templates` and a corresponding call point in the relevant Edge Function. New `system_key` values do not require changes to the shared package.

#### Transactional sends and suppression

System-triggered notifications are transactional — recipients cannot be expected to opt out of being told their payment failed or their application was rejected. These sends use `bypass_suppression: true` in the `CommSendRequest` (see **`CommSendRequest`** contract notes), which instructs `pump-send` to skip the `pump_suppression` registry check for that send. `pump-send` still creates `pump_message` and `pump_message_recipient` rows and records delivery events normally.

Operator-initiated sends (via `CommComposer`) always consult the suppression registry — `bypass_suppression` defaults to `false` and should not be exposed as a UI option.

#### Call point responsibility

The Edge Function that performs the action is responsible for triggering its notification. The notification call is placed **after** the primary action has succeeded and its database writes have committed. If the notification send fails, the error is logged and surfaced in `CommSendResult.warnings` — it does **not** roll back the primary action.

### Relationship to reporting (CR22)

CR22 listed `Communication | PUMP | pump_comms_log | organisation_id` as a deferred reporting domain. Once PUMP is live, this becomes the `pump.communication` reporting explore. The shared reporting engine requires no changes; PUMP registers its explore in the TypeScript configuration. **No cross-cutting schema changes are needed between CR22 and CR23.**

### Decisions recorded

| Topic | Outcome |
| --- | --- |
| Architecture | PUMP as service + shared composer in pace-core2 |
| Gateway logic location | PUMP Edge Functions only; never in consuming apps |
| Pool resolution location | Server-side (Edge Function) only; no client-side resolution |
| Recipient list in browser | Not permitted; only pool descriptor is passed to send |
| Merge field resolution | Server-side at send time |
| Token validation — primary gate | `MessagePreview` highlights unresolved tokens (amber) at compose time; `CommComposer` prop `blockSendOnUnresolvedTokens?: boolean` disables send CTA while unresolved tokens are present |
| Merge-field validation — Edge Function | Permissive default: unresolved merge fields left as literal form, recorded in `CommSendResult.warnings`; send is never blocked unless `require_merge_field_validation = true` on the source template |
| Template strict mode | `pump_organisation_templates.require_merge_field_validation` (boolean, default `false`); when `true`, `pump-send` rejects the send on any unresolvable referenced merge field; managed by PUMP admins per template |
| Send-time suppression | Edge (`pump-send`) consults `pump_suppression` before dispatch — **skips** only; **no** PUMP v1 user/operator unsub management product |
| RBAC enforcement | UI (`CommRbacContext` / `PagePermissionGuard` / pace-core hooks) + RLS (`data_data_check_rbac_permission_with_context`) + Edge `isPermitted` (hard boundary) |
| Template library ownership | PUMP app; loaded via adapter |
| New `core_*` tables | None required for MVP; **merge catalogue** uses existing **`core_field_list`** |
| Gateway credentials | **Platform** `pump_gateway_config` by **`channel`**; **org** sender identity defaults in **`pump_org_settings`**; email shell branding sourced separately |
| Additional contact inclusion | `pump-resolve-pool` / `pump-send` auto-include contacts with `Full` or `Notify` access for member-context sends; additive (not substitution) — member row plus contact rows in `pump_message_recipient` |
| Parent approval recipient resolution | System notifications may use `canonical_parent_contact`, resolved only through the canonical parent-contact mapping (`core_contact_type.id = 1`); never via generic additional-contact inclusion |
| System-triggered notifications | `sendSystemNotification()` helper in `pace-core2`; Edge Function call point pattern; platform-owned `pump_system_templates` row by `system_key` plus explicit `SystemNotificationRecipientDescriptor` |
| Transactional suppression bypass | `CommSendRequest.bypass_suppression: true` — set only by `sendSystemNotification()`, never by `CommComposer`; `pump-send` skips `pump_suppression` check but still writes full audit rows |
| Notification template ownership | Seeded / managed as platform-owned system templates; not part of organisation template CRUD |
| Notification send failure | Non-fatal to the primary action; logged in `CommSendResult.warnings`; does not trigger rollback |

---

## Acceptance criteria

- [x] `pace-core2` exposes a typed `RecipientPoolDescriptor` discriminated union covering `org_members`, `event_participants`, `manual`, and `custom_filter` pool types.
- [x] `CommSendAdapter` is a transport-agnostic interface: `resolvePool`, `loadTemplates`, `loadMergeFields`, `send`, `sendTest`, `schedule`, and `saveDraft` are declared as typed async operations returning `ApiResult`-aligned outcomes; no concrete gateway, Supabase client, or Edge Function import appears in the shared package.
- [x] `CommComposer` renders: channel selector, recipient pool preview (count + sample via `resolvePool`), template selector, subject field (email only), body editor with merge field toolbar, message preview pane, and send / schedule CTA — all driven by adapter-provided data.
- [x] `MergeFieldToolbar` presents only the merge fields returned by `loadMergeFields` for the current pool context; clicking a token inserts it at the cursor position in the active body field.
- [x] `MessagePreview` renders the message body with merge tokens resolved against a sample recipient drawn from the resolved pool preview; it falls back gracefully when no sample is available.
- [x] `MessagePreview` never injects unsanitized `body_html` into the browser. Email HTML preview is sanitized before render and shown in a bounded preview container so author-authored template HTML cannot execute active browser content.
- [x] `RecipientPoolPreview` renders the resolved pool's estimated recipient count, first-name sample, and any pool warnings (e.g. recipients without an email address) returned by `resolvePool`.
- [x] `CommRbacContext` gates the send/schedule CTAs and body editing controls; a user without `canSend` sees a read-only composer with an explicit permission message.
- [x] `MessagePreview` renders unresolved tokens (those absent from `loadMergeFields` for the current pool context) with amber highlight and a tooltip; when `blockSendOnUnresolvedTokens` is `true` and unresolved tokens are present, a warning banner appears and the send/schedule CTAs are disabled.
- [x] `CommTemplate.require_merge_field_validation` is surfaced in the template selector so operators can see which templates enforce strict send-time validation.
- [x] `CommComposer` exposes `lockSenderIdentity?: boolean`; when `true`, sender identity fields are rendered read-only so consuming apps can enforce platform-managed sender identity at the UI layer.
- [x] Draft state is fully controlled via `CommDraft`; the component never manages gateway state or send results — those are adapter and consumer concerns.
- [x] Demo verification exists covering: email compose with event participant pool, SMS compose with org members pool, merge field insertion and preview (including an unresolved token highlight), template selection (including a `require_merge_field_validation = true` template), send adapter mock result (success + token warning), `blockSendOnUnresolvedTokens` blocking the CTA, `blockSendWhenPoolEmpty` blocking the CTA when `estimated_count === 0`, and RBAC-gated read-only state.
- [x] `sendSystemNotification()` is exported from `@solvera/pace-core/comms`, accepts a `SystemNotificationRequest`, constructs a `CommSendRequest` with `bypass_suppression: true`, `system_key`, and `system_recipient`, and calls `adapter.send` — returning `ApiResult<CommSendResult>`.
- [x] `sendSystemNotification()` does not accept or set `bypass_suppression` as a caller-provided field — it is always `true` and set internally; callers cannot override it to `false`.
- [x] `CommSendAdapter.sendTest()` accepts a `CommSendTestRequest`, never accepts a recipient pool or arbitrary typed destination, and sends only to the current signed-in user's destination for the selected channel.
- [x] `useCommSendAdapter(options)` is exported from `@solvera/pace-core/comms` and returns a `CommSendAdapter` wired to the secure Supabase client and approved PUMP contracts (`pump-resolve-pool`, `pump-send`, `pump-send-test`, `pump-schedule`, and approved template/merge-field read contracts).
- [x] `SystemNotificationRecipientDescriptor` supports `member_context` and `canonical_parent_contact` modes.
- [x] `member_context` system notifications resolve the member plus any linked additional contacts with `Full` or `Notify` access and use member merge data.
- [x] `canonical_parent_contact` system notifications resolve linked parent contacts only through the canonical parent-contact mapping (`core_contact_type.id = 1`), do not fall back to generic additional-contact inclusion, and use parent/contact merge data only.
- [x] If `canonical_parent_contact` resolution returns no linked parent contacts, `pump-send` records a warning and the notification failure remains non-fatal to the triggering action.
- [x] `CommTemplate` does **not** expose a category field in MVP; template organisation/filtering is driven by name, channel, active state, and search rather than a fixed category enum.
- [x] `bypass_suppression: boolean` is present on `CommSendRequest`; `CommComposer` never sets it (defaults to `false` for all operator-initiated sends).
- [x] A seed migration exists creating the initial `pump_system_templates` rows (`system_key`: `registration_approved`, `registration_rejected`, `payment_failed`, `photo_rejected`) for the platform default locale; templates include a subject and body with standard merge fields (`{{first_name}}`).

### Implementation notes (2026-04-26 remediation)

- Edge-function source was added under `packages/core/supabase/functions` (`pump-send`, `pump-resolve-pool`, `pump-send-test`, `pump-schedule`, `pump-cancel`, `pump-webhook`) with shared runtime entrypoints in `_shared`.
- Read-contract handlers are available under `packages/core/supabase/functions` as `pump-load-templates` and `pump-load-merge-fields` so `useCommSendAdapter` maps every declared adapter method to a concrete transport endpoint.
- Runtime bootstrap support is available in `packages/core/supabase/functions/_shared/runtime.ts` (`registerPumpRuntimeFactory` / `registerPumpRuntimeBootstrap`) so host runtimes can provide concrete RBAC, store, and gateway wiring.
- Shared edge behavior contracts are implemented and covered by tests in `packages/core/src/comms/edge-service.ts` and `packages/core/src/comms/edge-service.test.ts`.
- Controlled composer, preview/token handling, and fixture verification coverage is exercised by `packages/core/src/comms/components.integration.test.tsx` and `src/CommsShowcase.integration.test.tsx`.

---

## API / Contract

Public exports from `packages/core/src/comms/` via a dedicated **`@solvera/pace-core/comms`** entrypoint.

**Implementation gate:** this contract is shipped via the `./comms` package subpath; consuming apps must import from `@solvera/pace-core/comms` and must not ship app-local substitutes for this surface.

### Components

- `CommComposer`
- `RecipientPoolPreview`
- `MergeFieldToolbar`
- `MessagePreview`

### Hooks

- `useCommDraft` — manage `CommDraft` state with dirty/reset helpers
- `useCommSendAdapter` — return a `CommSendAdapter` wired to secure Supabase transport for approved PUMP contracts; accepts `{ organisationId, sourceApp, sourceContextType?, sourceContextId? }`
- `useResolvedPool` — call `CommSendAdapter.resolvePool`, cache result, expose loading/error state
- `useCommTemplates` — call `CommSendAdapter.loadTemplates`, expose list + selection helper
- `useCommMergeFields` — call `CommSendAdapter.loadMergeFields` for current pool context

### Utilities

- `sendSystemNotification(adapter: CommSendAdapter, request: SystemNotificationRequest): Promise<ApiResult<CommSendResult>>` — constructs a correctly shaped `CommSendRequest` (with `bypass_suppression: true`, the system template resolved by `systemKey`, and explicit `system_recipient` resolution) and calls `adapter.send`. For use in Edge Functions only — not for client-side or UI code.

### Types

- **Pool descriptors:** `RecipientPoolDescriptor`, `OrgMembersPool`, `OrgMembersPoolFilters`, `EventParticipantsPool`, `EventParticipantsPoolFilters`, `ManualPool`, `CustomFilterPool`
- **Channels and status:** `CommChannel` (`'email' | 'sms'`), `CommMessageStatus`, `CommRecipientStatus`
- **Draft and request:** `CommDraft`, `CommSendRequest`, `CommSendTestRequest`, `CommScheduleRequest`
- **System notifications:** `SystemNotificationRecipientDescriptor`, `SystemNotificationRequest` — `SystemNotificationRecipientDescriptor` is a discriminated union of `{ type: 'member_context'; member_id: string }` and `{ type: 'canonical_parent_contact'; member_id: string }`; `SystemNotificationRequest` carries `systemKey: string`, `recipient: SystemNotificationRecipientDescriptor`, `organisationId: string`, `sourceApp: string`, `sourceContextType?: string`, `sourceContextId?: string`, `extraMergeContext?: Record<string, string>`
- **Results:** `CommSendResult`, `CommScheduleResult`, `CommRecipientPreview`, `CommPoolWarning`, `CommTokenWarning`
- **Merge fields:** `CommMergeField`, `CommMergeContext`, `CommMergeScope`
- **Templates:** `CommTemplate` (includes `require_merge_field_validation: boolean`)
- **Adapter:** `CommSendAdapter`
- **RBAC:** `CommRbacContext`

### Authoritative contract notes

- `CommChannel` must be exactly `'email' | 'sms'` in MVP. Future channels (e.g. `'push'`) are added as extensions.
- `RecipientPoolDescriptor` must use a `type` discriminant. New pool types are added here; the Edge Functions must understand any type used by a consuming app.
- `CommSendAdapter` must be transport-agnostic. The shared `useCommSendAdapter` hook is the default implementation and must use the secure Supabase client/session boundary for all Edge/read calls. App-specific adapters remain allowed for approved product-specific behavior, but must preserve this contract shape and security boundary.
- `CommSendAdapter.loadMergeFields` must consume one approved read contract backed by `core_field_list` (`pump_merge_availability = true`). The shared package must not require each consuming browser to query raw metadata tables directly.
- `CommSendAdapter.sendTest` is part of the shared contract because test-send is still a compose-adjacent action, but scheduled-message cancellation is **not** part of the shared adapter surface. `pump-cancel` remains a PUMP-local lifecycle action owned by the consuming app's log/detail workflow.
- `useCommSendAdapter.saveDraft` default behavior is an in-memory pass-through success (`ApiResult<CommDraft>`) unless a consuming app deliberately supplies a custom persistence adapter.
- `MessagePreview` must sanitize `body_html` before browser render. Raw authored HTML may be stored in drafts/templates, but preview rendering must use a safe sanitization step and must not rely on direct `dangerouslySetInnerHTML` of unsanitized content.
- `CommSendRequest` must carry: `organisation_id`, `channel`, `subject?` (email), `body_html?` (email), `body_text`, and exactly one recipient input contract: `pool` for operator/member-context sends, or `system_key` + `system_recipient` for system notifications. It must also carry `sender_name`, `sender_email?`, `sender_phone?`, `reply_to?`, `source_app`, `source_context_type?`, `source_context_id?`, `extra_merge_context?`, `template_id?`, `bypass_suppression?: boolean` (default `false`; when `true`, `pump-send` skips the `pump_suppression` registry check — for transactional system notifications only; never set by `CommComposer`).
- `CommSendTestRequest` must carry the same message-content and sender fields as `CommSendRequest` (`organisation_id`, `channel`, `subject?`, `body_html?`, `body_text`, `sender_name`, `sender_email?`, `sender_phone?`, `reply_to?`, `source_app`, `source_context_type?`, `source_context_id?`, `extra_merge_context?`, `template_id?`), but must not accept `pool`, `system_key`, `system_recipient`, or `bypass_suppression`. The server resolves the destination from the current signed-in user only.
- `CommSendResult` must carry: `message_id`, `total_recipients`, `suppression_skipped`, `warnings: CommTokenWarning[]`. Partial success (some recipients failed at gateway) is reported via `warnings`, not as a thrown error. Token warnings and gateway partial-failure warnings share the same `warnings` array and are distinguished by `CommTokenWarning.type`.
- `CommTemplate` must carry `require_merge_field_validation: boolean` (mirrors `pump_organisation_templates.require_merge_field_validation`). When `true`, consuming UI should communicate to the operator that this template enforces strict merge-field resolution at send time.
- `CommScheduleRequest` extends `CommSendRequest` with `scheduled_at: string` (ISO 8601).
- `CommRecipientPreview` must carry: `estimated_count`, `sample_names: string[]` (up to 5), `warnings: CommPoolWarning[]`.
- `CommPoolWarning` must carry: `type` (`'no_email' | 'no_phone' | 'suppressed' | 'unknown'`), `count`, `message`.
- `CommTokenWarning` must carry: `type` (`'unresolved_token' | 'gateway_partial_failure'`), `token?: string` (the literal token string that failed, e.g. `'{{event_name}}'`; present for `unresolved_token`, omitted for `gateway_partial_failure`), `count: number` (number of recipients affected), `message: string`.
- `CommDraft` must carry: `channel`, `subject?`, `body_html?`, `body_text?`, `template_id?`, `sender_name?`, `sender_email?`, `sender_phone?`, `reply_to?`, `extra_merge_context?`. Recipient pool is not part of the draft — it is provided externally by the consuming app.
- `CommRbacContext` must carry: `canCompose: boolean`, `canSend: boolean`, `canSchedule: boolean`, `scopeType: 'event' | 'organisation'`, `scopeId: string`.
- `CommComposer` must accept `blockSendOnUnresolvedTokens?: boolean` (default `false`). When `true`, the send and schedule CTAs are disabled while `MessagePreview` reports any token that `loadMergeFields` did not return for the current pool context. This prop controls UI gating only; Edge Function strict-mode validation is governed by `CommTemplate.require_merge_field_validation` on the server side.
- `CommComposer` must accept `blockSendWhenPoolEmpty?: boolean` (default `false`). When `true`, send and schedule CTAs are disabled when `recipientPreview` (or the resolved pool preview) is present and `estimated_count === 0`. BASE event comms leave this `false` (empty pool is not blocked at UI); TEAM communications (TM13) sets `true`.
- `CommComposer` must accept `lockSenderIdentity?: boolean` (default `false`).
  - When `true`, sender identity inputs are non-editable (`sender_name`, `sender_email`, `sender_phone`, and `reply_to` where rendered).
  - This is a UI constraint only; send-time identity enforcement remains a server-side contract via effective sender identity resolution.
- Component props types are exported alongside components (e.g. `CommComposerProps`).

### File paths

- Package contracts, hooks, and components live under `packages/core/src/comms/`.
- `useCommSendAdapter` lives under `packages/core/src/comms/` and is exported from the `./comms` subpath.
- `sendSystemNotification()` and `SystemNotificationRequest` live at `packages/core/src/comms/system-notification.ts` and are exported from the `./comms` subpath.
- `CommSendTestRequest` and `CommSendAdapter.sendTest()` live under `packages/core/src/comms/` and are exported from the `./comms` subpath with the rest of the shared comms contract.
- Export governance must include `packages/core/package.json`, the generated exports index, and public API reference updates for the `./comms` subpath.
- Demo verification page lives at `src/pages/CommsShowcasePage.tsx` (imported from the demo app route; re-exported through `src/pages/index.ts`).

## Package implementation map (rebuild reference)

Use this section to recreate or audit the CR23 surface without relying on chat history. Paths are relative to `packages/core/` unless noted.

### Exported from `@solvera/pace-core/comms`

| Symbol group | Source file | Role |
| --- | --- | --- |
| Comms types (`CommSendRequest`, `RecipientPoolDescriptor`, `CommTemplate`, `SystemNotificationRequest`, etc.) | `src/comms/types.ts` | Canonical shared communications type contracts. |
| Comms utilities (`validateCommDraft`, token helpers, sanitization, request builder, pool warning labels) | `src/comms/utils.ts` | Pure helper/validation/token-processing utilities. |
| Hooks (`useCommDraft`, `useCommSendAdapter`, `useResolvedPool`, `useCommTemplates`, `useCommMergeFields`) | `src/comms/hooks.ts` | Draft and adapter-backed state/query hooks. |
| `sendSystemNotification` | `src/comms/system-notification.ts` | Server-side helper that enforces `bypass_suppression: true` for transactional notifications. |
| UI components (`CommComposer`, `RecipientPoolPreview`, `MergeFieldToolbar`, `MessagePreview`) + props | `src/comms/CommComposer.tsx`, `src/comms/RecipientPoolPreview.tsx`, `src/comms/MergeFieldToolbar.tsx`, `src/comms/MessagePreview.tsx` | Shared compose and preview primitives; one PascalCase module per component per Standard 1. |

### Internal support modules

| Symbol | Source file | Role |
| --- | --- | --- |
| Edge service helper wrappers | `src/comms/edge-service.ts` | Shared edge behavior contract helpers and fixtures/tests. |

### Demo app (repo root)

| Artifact | Path | Role |
| --- | --- | --- |
| Comms showcase page | `src/pages/CommsShowcasePage.tsx` | Fixture pools/channels/templates, unresolved-token UI, RBAC read-only state, send result handling. |

### Key tests (minimum rebuild parity)

| Area | Location |
| --- | --- |
| Utility and draft validation/token/sanitization | `src/comms/utils.test.ts` |
| Hook behavior | `src/comms/hooks.test.tsx` |
| Component integration (`CommComposer`, preview, RBAC, unresolved tokens) | `src/comms/components.integration.test.tsx` |
| Edge contract helpers | `src/comms/edge-service.test.ts` |
| Demo integration | `src/CommsShowcase.integration.test.tsx` (repo root) |

### Build/export governance notes

- Subpath export ownership:
  - `packages/core/package.json` (`./comms`)
  - `src/comms/index.ts`
- If adding/removing public comms symbols, run:
  - `npm run build -w @solvera/pace-core`
  - `npm run docs:exports-index`
  - `npm run export:check-governance`

---

## Visual specification

- Use [7-visual-standards.md](../standards/7-visual-standards.md) Part A and Part C for global spacing, semantic colours, elevation, and size groups.
- `CommComposer` layout recipe:
  - **Desktop and mobile:** single-column composer card with recipient preview rendered as a sibling card below it.
  - In-card order: channel selector, templates, sender identity, preview/edit toggle, subject/body editors, merge field toolbar, and send/schedule actions.
  - Recipient pool summary card (`RecipientPoolPreview`): shows channel icon + "X recipients" count with a "View sample" expand to reveal first-name chips. Pool warnings render as amber inline banners beneath the count.
  - Template selector: renders as a "Use a template" trigger that opens a sheet/dialog with a searchable list; selecting a template populates subject + body and marks the draft with `template_id`. User may edit after selection.
  - Merge field toolbar (`MergeFieldToolbar`): a compact horizontal chip list above the body editor, grouped by scope (Person / Event / Organisation). Clicking a chip inserts the token. On mobile, a "Merge fields" pill opens a bottom sheet picker.
  - Message preview (`MessagePreview`): a toggle ("Preview / Edit") switches the body from editor to rendered HTML/text view. The preview resolves merge tokens using the first name from `CommRecipientPreview.sample_names`. Tokens that `loadMergeFields` did not return for the current pool context are rendered with an amber highlight and a tooltip reading "This token could not be previewed — it may not resolve for all recipients." When any unresolved tokens are present and `blockSendOnUnresolvedTokens` is `true`, a soft warning banner appears below the preview: "Resolve all tokens before sending." Email preview renders in a bounded container using **sanitized HTML only** so author-authored template content cannot execute active browser content.
  - Send CTA: primary button "Send now"; secondary "Schedule" opens a datetime picker. Both are disabled when `!rbac.canSend` or draft has empty body. A loading state shows a spinner with "Sending…"; success transitions to a confirmation state before the consumer-provided `onSend` callback fires.
  - `lockSenderIdentity` mode: sender identity inputs render read-only while message content remains editable (subject/body/merge fields), unless broader RBAC read-only mode is also active.
  - RBAC-gated read-only state: all inputs rendered as read-only; CTA area replaced by a muted callout ("You have view-only access to this message").
- Deltas:
  - This slice introduces the composer pattern; PUMP's management screens (template library, delivery logs, compose/send page shell) define their own layout recipes in the PUMP application and do not belong in this slice.
  - Consuming apps own the page shell and navigation chrome around `CommComposer`; this slice defines only the component's internal layout.

---

## Verification

**pace-core demo:** add a comms showcase page with fixture adapter and pool descriptors for:
- Email compose with `event_participants` pool (mock event, 47 approved participants, 2 without email addresses → pool warning shown)
- SMS compose with `org_members` pool (mock organisation, 120 active members)
- Merge field insertion: click tokens in `MergeFieldToolbar`, verify insertion at cursor, verify preview resolves using sample name
- Unresolved token: body pre-seeded with `{{unknown_field}}` not in the `loadMergeFields` result; verify amber highlight and tooltip in preview
- `blockSendOnUnresolvedTokens` fixture: composer mounted with `blockSendOnUnresolvedTokens={true}` and a body containing `{{unknown_field}}`; verify send CTA is disabled and warning banner is shown; verify CTA re-enables after removing the unknown token
- Template selection: choose a fixture template with `require_merge_field_validation: false`, verify subject + body populate; choose a second fixture template with `require_merge_field_validation: true`, verify a strict-mode indicator is shown in the template selector
- Send with mock adapter: simulate success result (`total_recipients: 45`, `suppression_skipped: 2`, `warnings: [{ type: 'unresolved_token', token: '{{event_name}}', count: 3, message: '…' }]`) and verify the result state renders the warning correctly
- RBAC-gated state: render with `canSend: false` and verify inputs are read-only and CTA is replaced by access callout

Concrete verification flow:
- Open the comms showcase route and switch between email and SMS channels; verify fields that are channel-specific (subject, body_html, sender_email vs sender_phone) appear/disappear correctly.
- Open pool preview expand on both fixture pools and verify warning banners.
- Insert multiple merge tokens and verify body value is correct.
- Toggle to preview mode with a body containing a known token (`{{first_name}}`) and an unknown token (`{{unknown_field}}`); verify `{{first_name}}` renders with the sample value and `{{unknown_field}}` renders with amber highlight and tooltip.
- With `blockSendOnUnresolvedTokens={true}`: verify the send CTA is disabled and the warning banner is visible while `{{unknown_field}}` is in the body; remove it and verify the CTA becomes enabled.
- Select each fixture template in the template selector; verify the strict-mode indicator appears only on the `require_merge_field_validation: true` template.
- Select a template, edit the body, verify draft is marked dirty.
- Submit with mock adapter and verify the composer transitions to a confirmed state; verify token warning is shown in the result.
- Switch to RBAC read-only fixture and verify no inputs are editable.
- Confirm all required exports in **Package implementation map** are importable from `@solvera/pace-core/comms`.

---

## Testing requirements

- **Unit tests:**
  - `CommDraft` validation: empty body, missing channel, missing sender email for email channel, missing sender phone for SMS channel
  - `useCommSendAdapter`: method-to-contract mapping (`resolvePool`, `loadTemplates`, `loadMergeFields`, `send`, `sendTest`, `schedule`) and `ApiResult` error normalization
  - `useCommSendAdapter`: stable adapter identity across rerenders when options are unchanged
  - `useCommSendAdapter`: safe fallback behavior when secure Supabase client is unavailable
  - `useCommSendAdapter.saveDraft`: in-memory pass-through default behavior
  - `RecipientPoolDescriptor` type narrowing: each pool type correctly discriminated
  - Pool warning display logic: `no_email`, `no_phone`, `suppressed`, and `unknown` banners render with correct counts
  - Merge token insertion: caret position tracking and insertion output for toolbar click
  - Token resolution in preview: tokens present in `loadMergeFields` result render normally; tokens absent render with amber highlight
  - `blockSendOnUnresolvedTokens`: CTA disabled when unresolved tokens present and prop is `true`; CTA enabled when all tokens resolve or prop is `false`
  - Template selection: draft mutation after template selection (subject + body populated, `template_id` set); `require_merge_field_validation = true` templates display a strict-mode indicator
  - RBAC gating: `canSend: false` disables CTA; `canCompose: false` renders read-only state
- **Integration tests:**
  - `CommComposer` with fixture adapter: pool preview loads, template list loads, send triggers adapter with correctly shaped `CommSendRequest`
  - `MessagePreview` renders HTML body in bounded container with tokens resolved from sample
  - `useResolvedPool` hook: loading state → resolved state → warning display
  - `useCommTemplates` hook: list loads, selection mutates draft
  - `CommSendAdapter.sendTest`: current-user-only request shape excludes recipient pool / arbitrary destinations and returns a normal success or validation error result
  - Channel switching: switching email → SMS clears `subject` and `body_html` from draft state
  - Adapter error path: `CommSendAdapter.send` returns `ApiResult` error; composer shows inline error and does not clear draft
- **Coverage expectations per Standard 08:**
  - Validator utilities and hook logic target unit-level coverage expectations
  - Composer and preview composition receive integration coverage for all fixture scenarios listed in **Verification**

---

## Do not

- Do not import or depend on any PUMP Edge Function, gateway SDK, or PUMP application code from `pace-core2`; all transport is mediated through `CommSendAdapter`.
- Do not resolve merge fields in the browser; token preview is display-only and approximate; authoritative resolution is always server-side at send time.
- Do not construct or accept a fully resolved recipient list as a prop; only `RecipientPoolDescriptor` is permitted as the recipient input. (`ManualPool` accepts IDs, not resolved addresses or merge data.)
- Do not persist draft state in the shared package; `CommDraft` is a controlled value — consuming apps own persistence (URL state, local state, Supabase draft row, etc.).
- Do not add app-specific pool types to the shared type surface without a corresponding Edge Function implementation and an update to this CR.
- Do not put scheduled-message cancellation into `CommSendAdapter`; `pump-cancel` is a PUMP-local lifecycle action, not part of the shared compose/send surface.
- Do not gate the send CTA only in the UI; always rely on Edge Function `isPermitted` + scope validation as the authoritative security boundary, using the same **`{operation}:page.{page-slug}`** strings as RLS.
- Do not add `pump_comms_log` as a new table; the existing CR22 reporting domain reference uses `pump_message` + `pump_message_recipient` as the underlying source; a view or alias may be introduced for the reporting explore.
- Do not call `sendSystemNotification()` from client-side or UI code; it is for Edge Function use only. System notifications are a server-side side effect of a completed action, not a client-initiated send.
- Do not expose `bypass_suppression` in the `CommComposer` UI or as an operator-accessible flag; operator-initiated sends must always consult the suppression registry.
- Do not use `sendSystemNotification()` for operator-initiated or scheduled bulk sends; use `CommComposer` + `CommSendAdapter.send` directly for those flows.
- Do not add new system-key enums to the shared package types — `systemKey` is a runtime string convention, not a TypeScript enum. New notification types are additions to the `pump_system_templates` seed migration and call points only.
- Do not roll back the primary action if `sendSystemNotification()` fails; notification send failure is logged and surfaced as a warning, not a transaction blocker.

---

## References

- [CR06-forms-and-feedback.md](./CR06-forms-and-feedback.md)
- [CR10-services-and-providers.md](./CR10-services-and-providers.md)
- [CR12-supabase-react-query-error-handling.md](./CR12-supabase-react-query-error-handling.md)
- [CR18-composite-resilience-utilities.md](./CR18-composite-resilience-utilities.md)
- [CR21-workflow-forms-runtime.md](./CR21-workflow-forms-runtime.md) (adapter pattern precedent)
- [CR22-shared-reporting-foundations.md](./CR22-shared-reporting-foundations.md) (`pump.communication` reporting domain)
- [7-visual-standards.md](../standards/7-visual-standards.md)
- [3-security-rbac-standards.md](../standards/3-security-rbac-standards.md) (page permissions, RLS helpers, Edge `isPermitted`)
- [docs/XX00-template-requirements.md](../../../../docs/XX00-template-requirements.md)
- Database traceability: [`DB-change-decisions-p4.md`](../../../../docs/database/decisions/DB-change-decisions-p4.md) (**DB-404`–`DB-411** — schema, reporting view, RLS including **DB-409`–`DB-410**, **FORCE RLS** **DB-411**)

---

## Prompt to use with Cursor

Implement the feature described in this document. Follow the standards and guardrails provided. Read **Package implementation map (rebuild reference)** for expected files and exports. Add or update tests and demo verification as specified in **Testing requirements** and **Verification**. If public comms exports change, run `npm run build -w @solvera/pace-core` before repo-wide validate so `dist/` stays aligned. Then run `npm run validate` and fix issues until it passes.

---

**Checklist before running Cursor:** [CR00-core-project-brief.md](./CR00-core-project-brief.md) · [CR00-core-architecture.md](./CR00-core-architecture.md) · Cursor rules · ESLint config · this requirements doc.
