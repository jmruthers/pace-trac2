# CR07c – DataTable: Derived values, alignment, row styling, sizing, empty CTA, count label

*CR07c of 3. Builds on [CR07a-datatable.md](./CR07a-datatable.md) and [CR07b-datatable.md](./CR07b-datatable.md). This slice adds six optional, additive API fields needed by consuming apps porting prototype tables. No breaking changes.*

## Overview

- **Purpose:** Close gaps between the prototype kit DataTable surface and the canonical pace-core DataTable so screens can lift without compatibility shims.
- **Scope:** Optional column and props extensions; central value resolver; tests and demo updates.
- **Dependencies:** CR07a, CR07b.
- **Standards:** 05 pace-core compliance, 07 Visual.

## In scope for this slice

### E1 — `column.accessorFn` (derived column values)

- **Type:** `accessorFn?: (row: TData) => unknown`
- **Behaviour:** Value resolution is `accessorFn?.(row) ?? row[accessorKey]` everywhere a cell value is read: sort, filter, global search, export, grouping, and `cell` `getValue()`.
- **When absent:** Behaviour is identical to CR07a/CR07b.
- **Server-side caveat:** `accessorFn` applies to client-side sort, filter, search, and export only. Server-side tables must sort/filter computed fields on the backend.

### E2 — `column.align` (column alignment)

- **Type:** `align?: 'left' | 'right' | 'center'` (default `'left'`)
- **Behaviour:** Applies to header and body cells. Right-aligned columns use `text-right` and `tabular-nums`. Header sort controls respect alignment.
- **Factory defaults:** `createNumberColumn` and `createDateColumn` default to `align: 'right'`.

### E3 — `rowClassName` (state-driven row styling)

- **Type:** `rowClassName?: (row: TData) => string | undefined` on `DataTableProps`
- **Behaviour:** Merged into each data `TableRow` className alongside hierarchical `parentRowClassName` / `childRowClassName` and `onRowActivate` cursor class. No-op when not supplied.
- **Note:** pace-core does not ship semantic row-state classes (e.g. overdue, inactive); consuming apps provide class names.

### E4 — `column.width` (column sizing)

- **Type:** `width?: number | string` (e.g. `96`, `'12rem'`, `'20%'`)
- **Behaviour:** Emits one `<col>` per visible data column. When `width` is provided, set column width (numbers as pixels). When absent, column uses auto width.
- **Styling:** `<col>` width may use inline `style` as a narrow exception for data-driven table column sizing.

### E5 — `emptyState.icon` and `emptyState.action`

- **Type extension:**

```ts
emptyState?: {
  title?: string;
  description?: ReactNode;
  icon?: ComponentType<{ size?: number; className?: string; 'aria-hidden'?: boolean }>;
  action?: ReactNode;
};
```

- **Behaviour:** Icon renders decoratively above title; action renders below description in the empty cell. Backwards-compatible with existing `title` / `description` only usage.

### E6 — `rowNoun` (humanised count label)

- **Type:** `rowNoun?: string` on `DataTableProps` (default `'rows'`)
- **Behaviour:** Used only for toolbar count string: `{shown} / {total} {rowNoun}` or `{total} {rowNoun}`.

## Out of scope

- `cellClassName` / `column.className` — redundant with `cell` renderer.
- Toolbar slot injection (custom search/filters/actions nodes) — page-level or built-in features.
- Aggregates on `accessorFn` columns — `AggregateConfig.field` remains a raw row key.
- Virtual scrolling.

## API / Contract (extensions beyond CR07b)

### DataTableColumn additions

- `accessorFn?: (row: TData) => unknown`
- `align?: 'left' | 'right' | 'center'`
- `width?: number | string`

### DataTableProps additions

- `rowClassName?: (row: TData) => string | undefined`
- `rowNoun?: string`
- `emptyState` extended with optional `icon` and `action` (see E5).

### Internal helper

- `resolveColumnValue(row, column)` — single source of truth for column value resolution; used by sort, filter, body, export, grouping.

### ColumnFactory

- Factory option types accept optional `accessorFn`, `align`, `width` and pass through to returned column defs.

## Behaviour

- All six fields are optional with defaults equal to current behaviour.
- Derived columns with `accessorFn` and custom `cell` MUST sort, filter, search, and export on the resolved value, not only the raw `accessorKey`.
- Inline edit/create modals bind to `accessorKey`; display-only derived columns (`accessorFn` without editable row key) MUST use `editable: false`.

## Acceptance criteria

- [ ] `accessorFn` resolves values for sort, filter, global search, export, grouping, and `getValue()` in cells.
- [ ] `align` applies to header and body; number/date factory columns default to right alignment.
- [ ] `rowClassName` merges into row classNames for flat and grouped rows.
- [ ] `width` emits per-column `<col>` elements when set.
- [ ] `emptyState.icon` and `emptyState.action` render in empty table cells.
- [ ] `rowNoun` customises toolbar count label; defaults to `rows`.
- [ ] Unit and integration tests cover each addition.
- [ ] DataTable showcase demonstrates new fields.
- [ ] `npm run validate` passes.

## Guardrails

- Do not break CR07a/CR07b behaviour.
- Do not add toolbar slot APIs or per-cell className fields.
- Requirements-first: this document precedes implementation.

## Related

- [CR07a-datatable.md](./CR07a-datatable.md), [CR07b-datatable.md](./CR07b-datatable.md), [7-visual-standards.md](../standards/7-visual-standards.md)
