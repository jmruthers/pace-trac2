# CR12 – Supabase and React Query error handling

*Backlog. Implement after CR02; required for CR06 mutation feedback helpers.*

## Overview

- **Purpose:** Normalise Supabase/Postgrest errors to user-facing messages and standardise React Query retry and onError behaviour so all pace apps share the same error-handling and retry policy.
- **Scope:** Package only (utils). No Supabase client creation; only error handling and retry policy.
- **Dependencies:** CR02-foundation-types-utils-styles (Logger, sanitizeUserInput).
- **Standards:** 04 API & tech stack, 06 Code quality, 09 Operations (error handling).

## Candidate integration scope (TRAC2 pace-core2)

- Candidate 5 (composite resilience utilities): this slice remains Supabase/React Query specific; broader multi-source resilience contracts are promoted into CR18 and consumed by callers when combining multiple data sources.

## Acceptance criteria

- [x] NormalizeSupabaseError(error, defaultMessage?) returns a consistent SupabaseErrorResult; handles PostgrestError-like, Error, or unknown; maps common PG codes to user-facing messages; sanitises message via pace-core sanitizeUserInput.
- [x] HandleSupabaseError(error, context, toast?) normalises error, logs (via pace-core Logger), optionally toasts (destructive variant).
- [x] QueryRetryHandler(failureCount, error): boolean — no retry for 401/403/422/400 or network-like errors; up to 3 retries otherwise.
- [x] queryErrorHandler(error, context, toast?) for use as React Query default meta.onError; delegates to HandleSupabaseError.
- [x] Type SupabaseErrorResult exported (message, details?, hint?, code?).
- [x] Document recommended QueryClient defaultOptions (retry: QueryRetryHandler, meta.onError: queryErrorHandler).

## API / Contract

- **Exports:** From `packages/core/src/utils/supabase/` (or under existing utils): NormalizeSupabaseError, HandleSupabaseError, QueryRetryHandler, queryErrorHandler, type SupabaseErrorResult. Use a type guard for PostgrestError-like shape; avoid hard dependency on `@supabase/supabase-js` types in the public contract if desired.
- **SupabaseErrorResult:** { message: string; details?: string; hint?: string; code?: string }.
- **NormalizeSupabaseError(error: unknown, defaultMessage?: string): SupabaseErrorResult.**
- **HandleSupabaseError(error: unknown, context: string, toast?: ToastFn): SupabaseErrorResult.**
- **QueryRetryHandler(failureCount: number, error: unknown): boolean.**
- **queryErrorHandler(error: unknown, context: string, toast?): void** (for React Query meta.onError).

## Behaviour

- No retry for 401, 403, 422, 400 or network-like errors; up to 3 retries for other errors.
- Map common Postgres/Supabase error codes to user-facing messages.
- Sanitise user-facing message via pace-core sanitizeUserInput.
- This requirement defines Supabase/React Query specific error normalization and retry policy only. Generic multi-source composition resilience utilities are defined in `CR18-composite-resilience-utilities.md`.

## Demo app requirements

- Optional: demo or docs show recommended QueryClient setup (defaultOptions). No mandatory demo page if this is utils-only.

## Verification

- **Package:** Run a small harness or unit tests that exercise `NormalizeSupabaseError`, `HandleSupabaseError`, `QueryRetryHandler`, and `queryErrorHandler` with Postgrest-like, `Error`, and unknown inputs; confirm normalized output and retry behaviour match this contract.
- **Consuming apps:** Confirm QueryClient default options use `retry: QueryRetryHandler` and `meta.onError: queryErrorHandler`, and that user-facing error messages are sanitized and consistent.

## Testing requirements

- Unit tests for NormalizeSupabaseError (PostgrestError-like, Error, unknown); QueryRetryHandler (retry vs no-retry cases); HandleSupabaseError (log + optional toast). Coverage per Standard 08.

## Do not

- Do not create or configure Supabase client; only error handling and retry. Do not copy old implementation; implement from this spec.

## References

- [9-operations-standards.md](../../../packages/core/docs/standards/9-operations-standards.md), [4-api-tech-stack-standards.md](../../../packages/core/docs/standards/4-api-tech-stack-standards.md). pace-admin `supabase-utils.ts` as reference for behaviour only.
- [CR18-composite-resilience-utilities.md](./CR18-composite-resilience-utilities.md)

---

## Prompt to use with Cursor

Implement the feature described in this document. Follow the standards and guardrails provided. Add or update tests as specified in "Testing requirements". Run validate and fix any issues until it passes.
