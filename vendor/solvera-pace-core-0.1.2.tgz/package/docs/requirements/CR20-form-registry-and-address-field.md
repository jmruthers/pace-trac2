# CR20 – Dynamic form field registry and AddressField provider adapters

## Filename convention

This file is **`CR20-form-registry-and-address-field.md`** — pace-core requirement slice **CR20** (see [CR00-core-project-brief.md](./CR00-core-project-brief.md)).

---

## Overview

- Purpose and scope: introduce a domain-neutral **dynamic field registry** for metadata-driven forms (map server `field_type` to Zod fragments and pace-core controls), an **`AddressField`** that is registry-compatible, and **provider-agnostic address lookup** contracts with a robust **Google Maps JavaScript Places** adapter strategy (session tokens, restrictions, manual fallback). Package + tests; demo verification follows Standard 08.
- Relationship to [CR21-workflow-forms-runtime.md](./CR21-workflow-forms-runtime.md): CR20 owns **primitive field types**, registry composition, and address providers. CR21 adds **workflow typing**, **`field_key`**-driven payloads, entrypoint UX, and submission adapters — it **composes** this registry rather than replacing it. Workflow orchestration and database contracts are defined in CR21, not here.
- Dependencies: [CR06-forms-and-feedback.md](./CR06-forms-and-feedback.md), [CR05a-primitives.md](./CR05a-primitives.md), [CR05b-dialog-select-tabs.md](./CR05b-dialog-select-tabs.md), [CR08-advanced-ui.md](./CR08-advanced-ui.md), [CR12-supabase-react-query-error-handling.md](./CR12-supabase-react-query-error-handling.md), [CR18-composite-resilience-utilities.md](./CR18-composite-resilience-utilities.md).
- Standards: 02 Architecture, 04 API and tech stack, 05 pace-core compliance, 06 Code quality, 07 Visual ([7-visual-standards.md](../standards/7-visual-standards.md)), 08 Testing and documentation, 09 Operations.

## Acceptance criteria

- [x] Field registry contract exists: `fieldType -> schema builder + renderer registration`.
- [x] Runtime schema composition supports metadata-driven field sets for `useZodForm`.
- [x] Unsupported field types render explicit fallback UI and do not crash rendering.
- [x] `AddressField` is available as a first-class registry-compatible field type.
- [x] Address provider adapter contract supports prediction + details + mapping seams.
- [x] Google-backed adapter behavior uses correct **session token** lifecycle when `google.maps.places` is available.
- [x] Address flow supports deterministic fallback to manual entry on provider failure or unavailability.
- [x] Search-enabled address UX is search-first: structured manual fields stay hidden initially and reveal when lookup cannot return predictions for a valid query (or when degraded/manual fallback paths apply).
- [x] Error outputs use `ApiResult`-style outcomes and align with CR12/CR18 composition patterns at boundaries.
- [x] Public exports are documented and tested under `@solvera/pace-core/forms` (and `useAddressFieldSessionToken` under `@solvera/pace-core/hooks`; see API / Contract).

## API / Contract

- Public exports from `packages/core/src/forms/` (published as `@solvera/pace-core/forms`):
  - `createFieldRegistry`
  - `createDefaultFieldRegistryEntries`
  - `composeSchemaFromFieldMetadata`
  - `resolveFieldRenderer`
  - `UnsupportedFieldFallback`
  - `AddressField`
  - `createManualAddressProviderAdapter`
  - `createGoogleMapsJsAddressProviderAdapter`
  - `parseGooglePlaceDetailsToAddressValue`
  - Types: `FormFieldMeta`, `FieldRegistryEntry`, `AddressValue`, `AddressProviderAdapter`, `AddressPrediction`, `AddressDetails`, `AddressFieldProps`, `AddressProviderStatus`
- **`useAddressFieldSessionToken`** is exported from `packages/core/src/hooks/` as **`@solvera/pace-core/hooks`** (hooks remain a single export surface per export governance; `AddressField` uses this hook internally).
- Contract shapes:
  - **FormFieldMeta:** `{ id: string; fieldType: string; label?: string; required?: boolean; [key: string]: unknown }`
  - **FieldRegistryEntry:** `fieldType`, `buildSchema(meta)`, `render(props)`; optional `normalize`
  - **AddressValue:** structured fields (`line1`, `line2?`, `locality`, `region`, `postalCode`, `countryCode`) plus optional `placeId?`, `formattedAddress?`
  - **AddressProviderAdapter:** `searchPredictions`, `getPlaceDetails`, `parsePlaceDetailsToAddressValue` (all `Promise<ApiResult<...>>`)
  - **Session token:** `useAddressFieldSessionToken` (from `@solvera/pace-core/hooks`) creates/rotates an opaque token object for one autocomplete session; adapter receives token for prediction + details calls; rotate after selection, cancel, or timeout.
  - **Provider options:** component restrictions (regions), language, debounce, minimum query length.
  - **Status:** `ready | loading | degraded | manual` exposed for UI state (no typography overrides at call site; use primitives and Standard 07).
- Google adapter contract: requires consumer-loaded Maps JavaScript API with Places library; if `window.google?.maps?.places` is missing, adapter returns structured errors and `AddressField` degrades to manual entry.

## Package implementation map (rebuild reference)

Use this section to recreate or audit the CR20 surface without relying on chat history. Paths are relative to `packages/core/` unless noted.

### Exported from `@solvera/pace-core/forms`

| Symbol | Source file | Role |
| --- | --- | --- |
| `createFieldRegistry`, `createDefaultFieldRegistryEntries`, `resolveFieldRenderer`, `UnsupportedFieldFallback` | `src/forms/createFieldRegistry.tsx` | Registry contract (`fieldType -> schema + renderer`) and unsupported fallback rendering. |
| `composeSchemaFromFieldMetadata` | `src/forms/composeSchemaFromFieldMetadata.ts` | Schema composition helper for metadata-driven forms. |
| `AddressField`, `AddressFieldProps` | `src/forms/address/AddressField.tsx` | Registry-compatible address field with provider lookup + manual fallback. |
| `buildAddressValueSchema`, `AddressValue` | `src/forms/address/addressValueSchema.ts` | Canonical structured address schema and value type. |
| `createManualAddressProviderAdapter`, `defaultManualAddressProviderAdapter` | `src/forms/address/manualAddressProvider.ts` | Manual-mode provider adapter. |
| `createGoogleMapsJsAddressProviderAdapter`, `parseGooglePlaceDetailsToAddressValue` | `src/forms/address/googleMapsJsAddressProvider.ts` | Google Maps Places adapter + details parsing. |
| `AddressProviderAdapter`, `AddressProviderStatus`, `AddressPrediction`, `AddressDetails`, `AddressSearchOptions`, `AddressDetailsOptions` | `src/forms/address/addressProviderTypes.ts` | Provider adapter type contract. |

### Exported from `@solvera/pace-core/hooks`

| Symbol | Source file | Role |
| --- | --- | --- |
| `useAddressFieldSessionToken` | `src/hooks/useAddressFieldSessionToken.ts` | Session-token lifecycle helper for lookup sessions (create/rotate/reset). |

### Key tests (minimum rebuild parity)

| Area | Location |
| --- | --- |
| Field registry and unsupported fallback | `src/forms/fieldRegistry.test.tsx` |
| Address field behaviour + validation UX | `src/forms/address/AddressField.test.tsx` |
| Google adapter mapping + failure paths | `src/forms/address/googleMapsJsAddressProvider.test.ts` |
| Session-token lifecycle | `src/hooks/useAddressFieldSessionToken.test.tsx` |

### Build/export governance notes

- Barrel exports are owned by:
  - `src/forms/index.ts` (`@solvera/pace-core/forms`)
  - `src/hooks/index.ts` (`@solvera/pace-core/hooks`)
- If adding/removing public symbols, update export governance artifacts by running:
  - `npm run build -w @solvera/pace-core`
  - `npm run docs:exports-index`
  - `npm run export:check-governance`

## Visual specification

- **Component layout:** `AddressField` composes pace-core `Label`, `Input`, `Alert`, and listbox-style suggestion list using semantic elements (`ul`/`li` or `menu`/`option` patterns consistent with Select contract where applicable). Layout uses **grid** for the address field group per Standard 07.
- **Search-first reveal contract (provider-backed mode):**
  - When address search is enabled, render only the top `Search address` control initially.
  - Keep structured manual fields (`line1`, `line2`, `locality`, `region`, `postalCode`, `countryCode`) hidden until a manual fallback condition is met.
  - Reveal structured manual fields when lookup returns zero predictions for a query that satisfies `minQueryLength` and is no longer loading.
  - Preserve existing fallback/manual reveal paths: degraded provider state, nested/group validation error display requirements, and explicit post-selection edit action.
  - After prediction selection, default back to summary/collapsed view (manual fields hidden) until user chooses to edit details.
- **Globals:** Cite [7-visual-standards.md](../standards/7-visual-standards.md) Part A and Part C; do not add inline typography utility classes on semantic text elements.
- **Deltas:** This slice intentionally adds address UX beyond CR06 baseline forms; CR06 remains the base form shell.
- **Validation UX (nested vs group):**
  - Structured sub-fields aligned with `AddressValue` / `addressValueSchema` participate in validation display: `line1`, `line2`, `locality`, `region`, `postalCode`, `countryCode`, and optional `placeId`, `formattedAddress` when present in the schema.
  - For any sub-field that has a validation error from react-hook-form / Zod (nested `FieldErrors`): set **`aria-invalid`** on the corresponding `Input`, and show the error message **inline** next to that control (e.g. immediately below the input in the same `Label` group). Do not rely on a single group banner for nested-only failures.
  - **Group destructive alert** (`AlertTitle` **Validation**, destructive variant): show **only** when the address value has a **root-level** validation message on the object field **and** there are **no** errors on known nested sub-fields surfaced inline. If both a root message and nested sub-field errors exist, **do not** show the group alert (inline sub-field messages take precedence; avoids duplicate generic banners such as resolver-level parent messages alongside specific field errors).
  - **Degraded lookup** alert (`Address lookup unavailable`, default variant) is separate and unchanged: it reflects provider/search failure, not field schema validation.

## Verification

- **pace-core:** Unit and integration tests cover registry composition, unsupported fallback, AddressField manual mode, mock provider success path, and provider failure degradation.
- **Consuming apps:** Import from `@solvera/pace-core/forms`; wire `useZodForm` + registry; optionally pass Google adapter after loading Maps script.
- **Rebuild verification (contract parity):**
  - Confirm `@solvera/pace-core/forms` exports all symbols listed in **Package implementation map**.
  - Confirm `@solvera/pace-core/hooks` exports `useAddressFieldSessionToken`.
  - Confirm `AddressField` nested-vs-root validation alert behaviour matches this document.

## Testing requirements

- Unit tests: schema composition; unsupported field behavior; address value parsing; session token lifecycle; debounce/minimum query behavior.
- Integration tests: `AddressField` with mock `AddressProviderAdapter` (success, failure, degraded manual).
- Search-first visibility tests:
  - Search-enabled initial state shows only `Search address`; structured fields are hidden.
  - Zero predictions after a query at/above `minQueryLength` reveals structured manual fields.
  - Below-threshold queries and in-flight loading states do not reveal structured fields.
  - Prediction selection keeps summary/collapsed mode and exposes explicit edit affordance to reopen structured fields.
- **Validation UX regression (pace-core, `zodResolver` + structured address schema):**
  - Nested failure (e.g. invalid `locality`): message appears inline at the locality control; that input has **`aria-invalid`**.
  - Nested-only failures: **no** destructive group **Validation** alert (no duplicate top banner when errors are only on nested paths).
  - Root-only / group-level failure on the address object (e.g. object-level refine with no nested field messages): destructive **Validation** alert shows the root message.
- Coverage expectations per Standard 08.

Traceability: consumer-facing request `CORE-address-field-validation-ux-request` (pace-portal2 docs) describes the same acceptance behaviour; pace-core remains the single implementation source.

## Do not

- Do not embed Google script loading inside core UI in a way that forces all consumers to load Maps.
- Do not require provider availability for successful address entry (manual path must always work).
- Do not persist raw provider payloads beyond transient form state.
- Do not add app-specific domain rules (portal tables, medical taxonomies) to this slice.
- Do not move `useAddressFieldSessionToken` into the forms export surface; keep it in hooks to preserve subpath ownership.

## References

- [CR21-workflow-forms-runtime.md](./CR21-workflow-forms-runtime.md)
- [CR06-forms-and-feedback.md](./CR06-forms-and-feedback.md)
- [CR16-event-scoped-crud-scaffold.md](./CR16-event-scoped-crud-scaffold.md)
- [CR18-composite-resilience-utilities.md](./CR18-composite-resilience-utilities.md)
- [7-visual-standards.md](../standards/7-visual-standards.md)
- [docs/XX00-template-requirements.md](../../../docs/XX00-template-requirements.md)

---

## Prompt to use with Cursor

Implement the feature described in this document. Follow the standards and guardrails provided. Read **Package implementation map (rebuild reference)** for expected files and public symbols. Add or update tests and verification as specified in **Testing requirements** and **Verification**. If public exports change, run `npm run build -w @solvera/pace-core` before repo-wide validate so `dist/` and source exports stay aligned. Then run `npm run validate` and fix issues until it passes.

---

**Checklist before running Cursor:** [CR00-core-project-brief.md](./CR00-core-project-brief.md) · [CR00-core-architecture.md](./CR00-core-architecture.md) · Cursor rules · ESLint config · this requirements doc.
