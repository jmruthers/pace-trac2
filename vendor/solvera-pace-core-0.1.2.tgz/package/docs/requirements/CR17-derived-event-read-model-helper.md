# CR17 – Derived event read-model helper

## Overview

- Purpose: define a shared helper contract for resolving `selectedEvent` and related event-row hydration/fallback precedence so services, theming, and stats hooks use one consistent read model.
- Scope: package-level read-model contracts and helper utilities. No schema creation and no domain-specific event business logic.
- Dependencies: CR02-foundation-types-utils-styles (types/utilities), CR03-auth-and-context (selected context sources), CR10-services-and-providers (service integration), CR15-dynamic-theming (theme source precedence).
- Standards: 02 Architecture, 04 API and tech stack, 06 Code quality, 08 Testing and documentation.

## Acceptance criteria

- [x] Define a helper contract that resolves a canonical selected-event read model from available context sources.
- [x] Document deterministic precedence for event resolution (explicit selection source before fallback source).
- [x] Support null-safe behavior when no event is available; consumers must receive an explicit no-selection state.
- [x] Expose a shape-normalization contract for event rows so consumers can read common fields without each feature re-deriving mappings.
- [x] Include optional source metadata (for diagnostics/testing) indicating which source produced the resolved event.
- [x] Keep this helper domain-neutral; no event-type-specific business rules or calculations.

## API / Contract

- Public exports from `packages/core/src/events/` or `packages/core/src/utils/events/`:
  - `deriveSelectedEvent(...)`
  - `normalizeEventReadModel(...)`
  - `getEventResolutionMetadata(...)` (or equivalent)
- Expected contract-level types (names may vary if equivalent):
  - `EventResolutionInput`: candidate event sources (selectedEvent, event list, route params, persisted selection, optional fallback callbacks, `allowListFallback`, `allowPersistedRestore`)
  - `ResolvedEventResult`: `{ selectedEvent: EventReadModel | null; source: 'selected' | 'list' | 'route' | 'persisted' | 'none'; warnings?: string[] }`
  - `EventReadModel`: normalized event shape for cross-slice use (id/code/name/date fields and optional palette/theme payload when present)
- Precedence contract:
  1. explicit selected event in context, only when present in the current normalized event list
  2. valid route/persisted target match in current event list (persisted skipped when `allowPersistedRestore: false`)
  3. deterministic fallback selection from available list (skipped when `allowListFallback: false`)
  4. null result (`source: 'none'`) when no valid event exists
  5. when list is empty/transitional, unresolved selected/persisted values must not be emitted as active selected event

- Canonical event identity contract:
  - For RPC/read rows that include both synthetic row `id` and business `event_id`, the canonical event identity MUST be `event_id`.
  - Consumers must not persist or resolve selected event from transport/synthetic row IDs.

## Visual specification

Not applicable (non-UI contract slice).

## Verification

- pace-core: verify services consume `deriveSelectedEvent` rather than duplicating fallback logic.
- pace-core: verify dynamic theming and stats hooks consume normalized event shape from this slice.
- Consuming apps: verify context changes (event switch, cleared selection, stale persisted selection) produce deterministic resolved results.

Implemented verification:
- `EventService` now uses `deriveSelectedEvent(...)` and `normalizeEventReadModel(...)` for persisted/auto selection and row hydration.
- `EventService` now enforces canonical event identity from `event_id` when ingesting `data_user_events_get` rows.
- `useContextTheme` now normalizes selected event data before palette extraction and uses the shared read model path.
- `useResolvedScope` now derives event scope from the shared event context path (`useOptionalEvents`) rather than local ad hoc event resolution.

## Testing requirements

- Unit tests for precedence ordering and null-safe outcomes across all source combinations.
- Unit tests for normalization from varied event row shapes to `EventReadModel`.
- Integration tests for usage in at least two consumers (e.g. service hook + theming hook) to prevent divergent behavior.

Implemented tests:
- Unit: `packages/core/src/events/deriveSelectedEvent.test.ts`
- Unit: `packages/core/src/events/normalizeEventReadModel.test.ts`
- Consumer integration: `packages/core/src/providers/EventServiceProvider.integration.test.tsx`
- Consumer integration: `packages/core/src/theming/theming.integration.test.tsx`
- Additional consumer coverage: `packages/core/src/hooks/useContextTheme.test.tsx`, `packages/core/src/services/EventService.test.ts`, `packages/core/src/rbac/hooks/useResolvedScope.test.tsx`

Validation:
- `npm run validate` (workspace root) passes with all checks green (type-check, lint, build, tests, demo audit, package audit).

## Do not

- Do not introduce event-domain business rules (cost/risk formulas, itinerary rules, app-specific statuses).
- Do not require new database columns/tables in this slice.
- Do not duplicate resolution precedence definitions in downstream requirements; consume this contract.

## References

- [CR10-services-and-providers.md](./CR10-services-and-providers.md)
- [CR13-organisation-stats-hooks.md](./CR13-organisation-stats-hooks.md)
- [CR15-dynamic-theming.md](./CR15-dynamic-theming.md)
- [2-architecture-standards.md](../../../packages/core/docs/standards/2-architecture-standards.md)
- [4-api-tech-stack-standards.md](../../../packages/core/docs/standards/4-api-tech-stack-standards.md)

---

## Prompt to use with Cursor

Implement the feature described in this document. Follow the standards and guardrails provided. Add or update tests and verification flows as specified in Testing requirements and Verification. Run validate and fix any issues until it passes.

