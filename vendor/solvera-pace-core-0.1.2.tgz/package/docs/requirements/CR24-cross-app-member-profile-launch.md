# CR24 - Cross-app member-profile launch

## Overview

- Purpose and scope: define the shared `pace-core2` contract for building and launching cross-app member-profile handoffs, starting with TEAM -> Portal delegated member-profile entry. Scope is shared config, URL-building helpers, launch behaviour, and minimal verification guidance. Scope is **not** Portal page implementation, delegated authorisation, or app-specific RBAC policy.
- External prerequisites: Portal routes (`/profile/view/:memberId`, `/profile/edit/:memberId`), delegated access/RPC/RLS behaviour, and the consuming app's permission decisions remain outside this slice and must already exist in the consuming app/domain docs.
- Dependencies: [CR03-auth-and-context.md](./CR03-auth-and-context.md), [CR04-rbac.md](./CR04-rbac.md), [CR05c-layout-and-shell.md](./CR05c-layout-and-shell.md), [CR10-services-and-providers.md](./CR10-services-and-providers.md).
- Standards: 02 Architecture, 03 Security and RBAC, 04 API and tech stack, 05 pace-core compliance, 06 Code quality, 08 Testing and documentation.

## Problem

PACE apps already share delegated member-profile routes in Portal, but the launch contract is currently being re-specified in consuming app docs instead of being owned once in `pace-core2`. That creates avoidable drift in:

- route selection (`view` vs `edit`)
- target identifier rules (`memberId`, not `personId`)
- new-tab/no-return-url behaviour
- environment/config handling for Portal origin
- stale local URL assembly helpers copied per app

This slice centralises the **launch contract**, not the downstream Portal implementation.

## Target contract

### Supported launch modes

- `view` -> `{PORTAL_ORIGIN}/profile/view/{memberId}`
- `edit` -> `{PORTAL_ORIGIN}/profile/edit/{memberId}`

Rules:

- `memberId` is always the route identifier. Do not accept `personId` or organisation id as path substitutes.
- Launch opens a **new tab/window** by default.
- No `returnUrl` is appended by default for this contract.
- Query params are opt-in and must be explicitly documented by the consumer; the shared helper does not invent app-specific params.

### Shared config

- `PORTAL_ORIGIN` (name may vary in the consuming app's env wiring) is a required consumer-supplied origin/config value.
- The shared helper accepts a normalised config object rather than reading env directly from package code.
- Consumers remain responsible for validating that config exists before rendering a CTA.

### Shared helper surface

Public surface for this slice is owned by a dedicated subpath: **`@solvera/pace-core/member-profile-launch`**.

Required helpers:

- `buildMemberProfileLaunchUrl({ portalOrigin, mode, memberId })`
- `launchMemberProfile({ portalOrigin, mode, memberId, target? })`
- `isMemberProfileLaunchMode(value)` or equivalent narrow type guard

Optional helper/component:

- `MemberProfileLaunchButton` or thin hook wrapper if more than one app needs consistent button semantics and target handling.

### Non-ownership

This slice does **not** own:

- whether the user is authorised to use the target route
- how Portal resolves organisation context from `memberId`
- delegated proxy-session persistence inside Portal
- consuming-app RBAC logic for deciding when to show a CTA

Those remain consuming-app and Portal responsibilities. The shared helper only makes the launch contract consistent.

## Acceptance criteria

- [x] `pace-core2` exposes a typed helper that builds the canonical Portal member-profile URL for `view` and `edit`.
- [x] The helper rejects unsupported launch modes and invalid/empty `memberId` input.
- [x] Launch behaviour defaults to a new tab/window and does not append `returnUrl`.
- [x] The helper does not hardcode environment variable names or read app env directly.
- [x] The contract is documented as `memberId`-only; no parallel `personId` path is supported.
- [x] Demo or test coverage verifies both URL modes and the default launch target behaviour.
- [x] The CR24 API is exported through `@solvera/pace-core/member-profile-launch` and documented in its export map.
- [x] `packages/core/package.json` must contain and maintain a concrete `./member-profile-launch` subpath export; deep internal imports are not part of the contract.

## API / Contract

- Types:
  - `MemberProfileLaunchMode = 'view' | 'edit'`
  - `BuildMemberProfileLaunchUrlParams`
  - `LaunchMemberProfileParams`
- Behaviour:
  - `buildMemberProfileLaunchUrl(...)` returns a fully qualified URL string
  - `launchMemberProfile(...)` delegates to `window.open` or an injected opener
  - consumers can inject an opener for testability

### Authoritative contract notes

- `buildMemberProfileLaunchUrl` input:
  - `portalOrigin: string` (required, absolute origin like `https://portal.example.com`)
  - `mode: MemberProfileLaunchMode`
  - `memberId: string`
- URL shape is strict:
  - `view` -> `{portalOrigin}/profile/view/{memberId}`
  - `edit` -> `{portalOrigin}/profile/edit/{memberId}`
- Validation:
  - `memberId` must be non-empty after trim.
  - `mode` must be exactly `'view' | 'edit'`.
  - `portalOrigin` must be non-empty after trim.
  - helper should fail fast with a deterministic error message for invalid input.
- `launchMemberProfile`:
  - default target is `_blank`.
  - accepts injected opener for tests/non-browser contexts:
    - `open?: (url: string, target: string) => Window | null | unknown`
  - does not append `returnUrl` or other query params by default.
- Consumers may wrap this helper to add app-specific query params, but those params are outside CR24 and must be documented by the consumer.
- Export governance:
  - `packages/core/package.json` must expose `./member-profile-launch` pointing to compiled JS and d.ts outputs.
  - CR24 symbols must not require root-export fallback from `@solvera/pace-core`.

## Package implementation map (rebuild reference)

Use this section to recreate or audit CR24 without relying on chat history. Paths are relative to `packages/core/`.

### Exported from `@solvera/pace-core/member-profile-launch`

| Symbol | Source file | Role |
| --- | --- | --- |
| `buildMemberProfileLaunchUrl` | `src/member-profile-launch/index.ts` (or split module under `src/member-profile-launch/`) | Canonical URL builder for Portal member-profile handoff (`view` / `edit`). |
| `launchMemberProfile` | `src/member-profile-launch/index.ts` (or split module under `src/member-profile-launch/`) | Launch wrapper over URL builder + opener (`window.open` by default). |
| `isMemberProfileLaunchMode` | `src/member-profile-launch/index.ts` (or split module under `src/member-profile-launch/`) | Narrow type guard for launch mode validation. |
| `MemberProfileLaunchMode`, `BuildMemberProfileLaunchUrlParams`, `LaunchMemberProfileParams` | `src/member-profile-launch/index.ts` (or `types.ts`) | Typed launch contract. |

### Barrel/export ownership

| File | Responsibility |
| --- | --- |
| `src/member-profile-launch/index.ts` | Barrel for CR24 helper and types. |
| `packages/core/package.json` | Add and maintain `./member-profile-launch` subpath export. |
| `src/index.ts` | Do not mirror CR24 symbols on root export unless governance explicitly allows it. |

### Key tests (minimum parity)

| Area | Location |
| --- | --- |
| URL generation and validation | `src/member-profile-launch/index.test.ts` (or equivalent) |
| Launch target/opener behavior | `src/member-profile-launch/index.test.ts` (or equivalent) |

## Verification

- Unit tests for URL generation:
  - `view` mode
  - `edit` mode
  - invalid mode rejection
  - invalid `memberId` rejection
- Unit tests for launch behaviour:
  - default `_blank` target
  - injected opener support
- Consumer follow-through:
  - TEAM docs should depend on this slice rather than specifying app-local URL builders
- Export follow-through:
  - `@solvera/pace-core/member-profile-launch` imports for CR24 helpers compile in consuming apps without root-export fallback.
  - `packages/core/package.json` includes the `./member-profile-launch` export key and points at built artifacts.
  - Generated export documentation/governance checks include the CR24 subpath and do not rely on deep imports.

## Do not

- Do not add Portal-specific RBAC checks to the shared helper.
- Do not read app env directly from package code.
- Do not extend this into a generic cross-app routing framework.
- Do not absorb the TEAM directory picker-return contract into this slice without a second real consumer.
- Do not co-locate CR24 in `@solvera/pace-core/location`; this slice owns a separate `@solvera/pace-core/member-profile-launch` surface.

---

## Prompt to use with Cursor

Implement the feature described in this document. Follow the standards and guardrails provided. Read **Package implementation map (rebuild reference)** for expected files and exports. Add or update tests and verification as specified in **Verification**. If public exports change, run `npm run build -w @solvera/pace-core` before repo-wide validate so `dist/` stays aligned. Then run `npm run validate` and fix issues until it passes.
