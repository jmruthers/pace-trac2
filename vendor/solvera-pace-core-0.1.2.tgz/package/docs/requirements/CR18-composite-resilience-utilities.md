# CR18 – Composite resilience utilities

## Overview

- Purpose: define shared utilities for composing multi-source loading/error/partial-success states so feature slices can present resilient behavior without duplicating fallback orchestration.
- Scope: package-level utility contracts for resilience composition only. No feature-specific data fetching or domain aggregation logic.
- Dependencies: CR02-foundation-types-utils-styles (ApiResult/logging helpers), CR12-supabase-react-query-error-handling (source-specific error normalization).
- Standards: 02 Architecture, 06 Code quality, 09 Operations, 08 Testing and documentation.

## Acceptance criteria

- [x] Provide contract utilities to compose multiple source states into a single resilient state model.
- [x] Support partial-success semantics where at least one source succeeds while others fail.
- [x] Provide fallback contract helpers that allow callers to specify primary and fallback sources without embedding domain rules.
- [x] Expose deterministic status outputs (loading, partial, success, error) and a normalized error collection shape.
- [x] Keep source-agnostic contracts: utilities accept generic source descriptors/results and do not reference Supabase-specific shapes directly.
- [x] Include guidance for integration with CR12 error normalization when sources are Supabase/React Query based.

## API / Contract

- Public exports from `packages/core/src/resilience/` (or equivalent):
  - `composeResilientState(...)`
  - `resolveWithFallback(...)`
  - `collectSourceErrors(...)`
- Expected contract-level types (names may vary if equivalent):
  - `CompositeSourceResult<T>`: `{ key: string; data?: T; isLoading: boolean; error?: unknown }`
  - `CompositeResilienceState<T>`: `{ status: 'loading' | 'partial' | 'success' | 'error'; data: T | null; partialData?: Partial<T>; errors: ResilienceError[] }`
  - `ResilienceError`: normalized key/message/code fields for source-level failures
- `resolveWithFallback` contract should accept ordered sources and stop at first successful resolution, while preserving diagnostics for skipped/failed sources.

## Visual specification

Not applicable (non-UI contract slice).

## Verification

- pace-core: verify at least one feature composes multiple source states using this slice instead of custom local combiners.
- pace-core: verify CR12-aligned source errors can be normalized and surfaced through composite outputs.
- Consuming apps: verify fallback behavior and partial-success rendering logic remain stable when one upstream source is unavailable.

Implemented verification:
- Added `packages/core/src/resilience/` with `composeResilientState(...)`, `resolveWithFallback(...)`, and `collectSourceErrors(...)`.
- Refactored `usePublicEvent` to use `resolveWithFallback` for ordered code/id resolution and resilience composition utilities for deterministic outcome handling.
- CR12 alignment boundary is documented in `usePublicEvent`: source-specific normalization remains in CR12; this slice composes already-normalized outcomes.

## Testing requirements

- Unit tests for status resolution transitions (`loading`/`partial`/`success`/`error`).
- Unit tests for fallback ordering and first-success behavior.
- Unit tests for source-error collection and normalization outputs.
- Integration test with a consumer hook demonstrating partial-success and fallback behavior.

Implemented tests:
- Unit: `packages/core/src/resilience/composeResilientState.test.ts`
- Unit: `packages/core/src/resilience/resolveWithFallback.test.ts`
- Unit: `packages/core/src/resilience/collectSourceErrors.test.ts`
- Consumer hook integration coverage: `packages/core/src/hooks/usePublicEvent.test.tsx` (fallback order, partial-success, and all-source-failure surfaced error behavior).

Validation:
- `npm run validate` passes after implementation updates.

Expanded adoption (post-CR18 opportunities rollout):
- `OrganisationServiceProvider` now publishes keyed source outcomes, resilience status, and normalized resilience errors for organisation refresh flows.
- `useUnifiedAuth` now composes organisation/event source outcomes into a unified resilience view while preserving existing fields.
- Stats hooks (`useOrganisationStats`, `useAllOrganisationStats`, `useSystemStats`) now expose resilience metadata (`resilienceStatus`, `resilienceErrors`, `sourceOutcomes`) with partial-success semantics where appropriate.
- RBAC multi-check hooks (`useResourcePermissions`, `useMultiplePermissions`) now expose keyed resilience diagnostics alongside existing permission booleans.
- Public file resolution (`usePublicFileDisplay`) now uses ordered fallback resolution with composed resilience outputs.
- `PublicPageLayout` now supports non-fatal partial-state rendering through resilience props.
- Attachment access resolution now supports explicit opt-in signed->public fallback while remaining strict by default.
- Root export ergonomics updated: `CollectSourceErrorsOptions` and `ComposeResilientStateOptions` are available from the root package entry.

Hardening pass coverage (finalization):
- `useResolvedScope` now exposes `resilienceStatus`, `resilienceErrors`, and keyed `sourceOutcomes` across auth/organisation/events/app-context resolution.
- `ContextSelector` now consumes unified auth resilience metadata to keep selector UX available during partial failures while rendering fatal-state retry affordances only for full errors.
- `usePublicEvent` contract tests now assert stable keyed `sourceOutcomes` and explicit `partial`/`error` resilience semantics for fallback paths.
- `PublicPageLayout` coverage now locks non-fatal partial alert behavior and confirms loading/error precedence remains unchanged.
- Resilience utility branch tests now cover `partialData` merge behavior, custom `isSuccess` fallback semantics, and `mapError` null fallback normalization.
- Additive ergonomics updates: provider context hooks are available from the curated consumer surface where explicitly allowlisted.
- Demo adoption: `OrganisationStatsShowcasePage` now surfaces section-level resilience status/error messaging consistently across organisation/all-org/system sections.

## Do not

- Do not implement domain aggregation rules in this slice.
- Do not hardcode transport/client dependencies (Supabase, REST, GraphQL) into core utility contracts.
- Do not redefine source-specific retry/error policy already owned by CR12.
- Do not duplicate resilience contract types across unrelated entrypoints; `CompositeStatus` and `ResilienceError` are owned by the resilience contract surface.

## References

- [CR09-public-pages.md](./CR09-public-pages.md)
- [CR12-supabase-react-query-error-handling.md](./CR12-supabase-react-query-error-handling.md)
- [CR10-services-and-providers.md](./CR10-services-and-providers.md)
- [9-operations-standards.md](../../../packages/core/docs/standards/9-operations-standards.md)

---

## Prompt to use with Cursor

Implement the feature described in this document. Follow the standards and guardrails provided. Add or update tests and verification flows as specified in Testing requirements and Verification. Run validate and fix any issues until it passes.

