# R07b – DataTable: Server-side, filtering, import, edit, hierarchical

*R07b of 2. Builds on [R07a-datatable.md](./R07a-datatable.md). This slice adds server-side pagination, filtering UI, toolbar/search, row actions, import modal, inline edit and create/delete modals, grouping/aggregation, and hierarchical rows. Implement after R07a.*

## Overview

- **Purpose:** Extend the DataTable from R07a with server-side data loading, column filtering, full toolbar (search, column visibility), RBAC-driven row actions, CSV import modal, inline editing and create/delete flows, grouping with aggregation, and hierarchical (parent/child) rows.
- **Scope:** Package extensions to DataTable, types, hooks, and UI (toolbar, filter row, modals); demo updates to showcase at least server-side or filtering, and optionally import or row actions.
- **Dependencies:** R07a (DataTable core), 02-foundation, 05a-primitives, 05b-dialog-select-tabs (modals), 04-rbac, 06-forms (for edit/create form fields if inline edit uses forms).
- **Standards:** 05 pace-core compliance, 02 Architecture, 03 Security & RBAC, 07 Visual.

## Source layout

Extends the `data-table/` feature folder from CR07a. Toolbar, filter row, table body, pagination footer, and modals are separate modules under `packages/core/src/components/data-table/`; `DataTable.tsx` remains a thin orchestrator delegating to `useDataTableController` and layout submodules.

## In scope for this slice

- **Server-side pagination:** `ServerSideConfig<TData>` with `fetchData(params) => Promise<ServerSideResponse<TData>>`; `ServerSideParams` (pageIndex, pageSize, sorting, columnFilters, globalFilter, grouping); `ServerSideResponse` (data, totalCount, pageCount, hasNextPage, hasPreviousPage). DataTable accepts `serverSide?: ServerSideConfig`; when set, pagination/sort/filter drive fetchData and display server-returned data and totalCount.
- **Feature flags:** `features?: DataTableFeatureConfig` — optional booleans: search, pagination, sorting, filtering, import, export, selection, creation, editing, deletion, deleteSelected, grouping, columnVisibility, columnReordering, hierarchical. DataTable uses these to show/hide toolbar controls and row actions (in combination with RBAC).
- **Column filtering UI:** Column definitions support `enableColumnFilter?: boolean`, `filterType?: 'text' | 'select' | 'number' | 'date'`, `filterSelectOptions?` for select filters. The **filter row is hidden by default**; a toolbar control labelled **Filters** (with filter icon) toggles its visibility (`aria-label` **Show filters** / **Hide filters** for assistive tech). Filter state is in useDataTableState (columnFilters) or passed to server in ServerSideParams.
- **Toolbar:** Single row: **left (float-left)** — search input (global filter), then **row count** (total, or "x / y" when filters/search are applied); **right (fixed order; visibility toggled by features/RBAC)** — Filters → Group by → Expand/Collapse all → Columns (visibility/reorder) → Import → Export → Delete selected → Create (last). Toolbar and row actions use **Lucide icons** (Search, Download, Upload, Plus, SquarePen, Trash2); sortable headers show ArrowUp/ArrowDown when sorted. Column visibility and reorder: when `features.columnVisibility` / `features.columnReordering` are enabled, the user can show/hide columns and reorder columns via a **Columns dropdown** (native popover anchored to the toolbar button, with checkboxes and up/down). **Grouping:** user can optionally group rows by a field of their choice via a "Group by" dropdown listing columns with `enableGrouping`.
- **Row actions:** `actions?: DataTableAction<TData>[]` — each action has label, icon?, onClick(row), variant?, disabled?, hidden? (e.g. from RBAC). DataTable renders action buttons per row; visibility respects useCan/useResourcePermissions or equivalent. Optional built-in Edit/Delete that call onEditRow/onDeleteRow.
- **Import modal:** `onImport?: (data: TData[]) => ImportHandlerResult`, `importModalConfig?: ImportModalConfig` (title?, description?, etc.). ImportModal: file upload, CSV parse, column mapping (from table columns), preview, chunked call to onImport. `ImportHandlerResult` = void | Promise<void> | ImportSummary | Promise<ImportSummary>. `ImportSummary`: { successCount, totalCount, failedCount, failedRows? }. Toolbar shows Import when onImport and RBAC allow; modal shows success/error summary. `onImportModalClose?` callback after close (e.g. refetch).
- **Inline editing / create / delete:** `onEditRow?: (row, data) => void`, `onCreateRow?: (data) => void`, `onCreateClick?: () => void`, `onDeleteRow?: (row) => void`, `onDeleteSelected?: (selectedRows) => void`. Column defs: `editable?`, `fieldType?`, `fieldOptions?` for edit mode. DataTable supports row edit mode (inline or modal), create modal/dialog (when `onCreateRow` is provided), external create handler (when `onCreateClick` is provided — toolbar Create calls it instead of opening the built-in modal), single-row delete confirmation, bulk delete confirmation (when selection and deleteSelected enabled). Toast on success/error (or delegate to app).
- **Selection and bulk delete:** `selection?: Record<string, boolean>`, `onRowSelectionChange?`, `onDeleteSelected?`. Row checkboxes when `features.selection` (auto-enabled when `onDeleteSelected` is provided unless `selection: false`). Toolbar **Delete selected** appears when one or more rows are selected, `onDeleteSelected` is provided, and `features.deleteSelected !== false`; consuming apps gate the handler by permission (pace-core does not require `canDelete` for bulk delete). Bulk delete confirmation dialog runs before calling `onDeleteSelected`.
- **Grouping and aggregation:** Column defs: `enableGrouping?: boolean`; optional `aggregate?`, `aggregateFn?`, `aggregateCell?`. DataTable supports group-by column(s); aggregation helpers (sum, avg, count, min, max) in utils; footer or group footer with aggregate values. `aggregates?: AggregateConfig[]` on DataTableProps; AggregateConfig: { field, function: 'sum'|'avg'|'count'|'min'|'max', label }.
- **Hierarchical rows:** `hierarchical?: HierarchicalConfig` — enabled, defaultExpanded?, onExpandedChange?, indentSize?. Rows extend `HierarchicalDataRow` (isParent, parentId?, id). DataTable renders expand/collapse; child rows indented; sorting respects hierarchy (or flat with parentId). Optional expand-all / collapse-all in toolbar.

## Out of scope for this slice

- Virtual scrolling and performance config (chunking, search index) — can be a later slice or doc if needed.

---

## Acceptance criteria

- [x] Server-side: DataTable accepts serverSide config; fetchData receives ServerSideParams; displayed data and totalCount from ServerSideResponse; pagination/sort/filter trigger fetchData (debounced where specified).
- [x] Feature flags: DataTable accepts features (search, pagination, sorting, filtering, import, export, selection, creation, editing, deletion, deleteSelected, grouping, columnVisibility, columnReordering, hierarchical); toolbar and row behaviour respect flags and RBAC.
- [x] Filtering: Column defs support enableColumnFilter, filterType, filterSelectOptions; filter row is hidden by default and shown via toolbar toggle; filter state applied to client data or sent in ServerSideParams.
- [x] Toolbar: Single row — search (left), row count (total or "x / y" when filtered), then Export/Import/Create/Columns/Group by/etc. on the right; Lucide icons for actions and sort indicators; column visibility and reorder via Columns dropdown when features enable them.
- [x] Row actions: actions prop and/or built-in Edit/Delete; visibility per action (hidden, disabled, RBAC); onClick(row) invoked.
- [x] Import modal: File picker, CSV parse, column mapping from table columns, preview, chunked onImport; ImportSummary shown on success; onImportModalClose called on close.
- [x] Edit/Create/Delete: onEditRow, onCreateRow, onDeleteRow, onDeleteSelected; inline or modal edit; create modal; delete confirmation (single and bulk); column editable, fieldType, fieldOptions for edit form.
- [x] Selection: Row selection state; onRowSelectionChange; bulk delete with confirmation when `onDeleteSelected` is provided (and not opted out via `deleteSelected: false`).
- [x] Grouping/aggregation: Group by column(s); aggregation utils (sum, avg, count, min, max); footer or group footer with aggregate values.
- [x] Hierarchical: hierarchical config; expand/collapse; parent/child rows with indent; optional expand-all/collapse-all.
- [x] Demo: At least one of: server-side DataTable, or client DataTable with filtering + toolbar; optionally import, row actions, or edit flow. Step-by-step verifiable.

---

## API / Contract (extensions beyond R07a)

### DataTableProps (R07b additions)

- `serverSide?: ServerSideConfig<TData>` — fetchData(params) => Promise<ServerSideResponse<TData>>; enableServerSorting?, enableServerFiltering?, enableServerSearch?, enableServerPagination?, debounceMs?, cacheMs?.
- `features?: DataTableFeatureConfig` — Optional overrides; see **Feature flags and defaults** below. Consuming apps opt out by passing `features={{ search: false }}` etc.
- `onEditRow?: (row: TData, data: Partial<TData>) => void`, `onDeleteRow?: (row: TData) => void`, `onCreateRow?: (data: Partial<TData>) => void`, `onCreateClick?: () => void`, `onDeleteSelected?: (selectedRows: Record<string, boolean>) => void`.
- `onImport?: (data: TData[]) => ImportHandlerResult`, `importModalConfig?: ImportModalConfig`, `onImportModalClose?: () => void` — called when the import modal is closed (e.g. to refetch).
- `onRowSelectionChange?: (selection: Record<string, boolean>) => void`, `selection?: Record<string, boolean>`.
- `aggregates?: AggregateConfig[]` — { field, function: 'sum'|'avg'|'count'|'min'|'max', label }.
- `hierarchical?: HierarchicalConfig` — enabled, defaultExpanded?, onExpandedChange?, indentSize?, etc.
- `actions?: DataTableAction<TData>[]` — label, icon?, onClick(row), variant?, disabled?, hidden?, visible?, loading?, showForParent?, showForChild?.
- `loadingSpinnerLabel?: string` — optional label for the table body loading row (default `'Loading table'`).
- `columnVisibility?: ColumnVisibilityState`, `onColumnVisibilityChange?: (visibility: ColumnVisibilityState) => void` — optional controlled column visibility (id → boolean).
- `columnOrder?: ColumnOrderState`, `onColumnOrderChange?: (order: ColumnOrderState) => void` — optional controlled column order (array of column ids).

### Feature flags and defaults

DataTable uses an **opt-out** model: most features are **on by default**. The consuming app overrides only when it wants to disable a feature (e.g. `features={{ search: false }}`).

**DataTableFeatureConfig defaults:**


| Feature          | Default   | Meaning                                                        | Notes                                                                                                             |
| ---------------- | --------- | -------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------- |
| search           | **true**  | Toolbar search input (global filter)                           | Opt out: `features={{ search: false }}`.                                                                          |
| pagination       | **true**  | Page size selector, prev/next, page jump                       |                                                                                                                   |
| sorting          | **true**  | Sortable column headers                                        |                                                                                                                   |
| filtering        | **true**  | Filter row toggle + column filters                             | Filter row is hidden by default; user can show it. Filter inputs only apply to columns with `enableColumnFilter`. |
| export           | **true**  | Export CSV button                                              | Still gated by RBAC.                                                                                              |
| import           | **true**  | Import button when `onImport` is provided                      | No button if app does not pass `onImport`.                                                                        |
| selection        | **false** | Checkbox column for row selection                              | **Opt-in only**, or auto-enabled when `onDeleteSelected` is provided (unless `selection: false`). Set `features={{ selection: true }}` explicitly when needed without bulk delete. |
| creation         | **true**  | Create button when `onCreateRow` or `onCreateClick` is provided | No button if app does not pass either handler. When `onCreateClick` is set, toolbar Create calls it instead of opening the built-in create modal. |
| editing          | **true**  | Edit row action when `onEditRow` is provided                   |                                                                                                                   |
| deletion         | **true**  | Delete row action when `onDeleteRow` is provided               |                                                                                                                   |
| deleteSelected   | **true**  | “Delete selected” when `onDeleteSelected` is provided          | Opt out with `deleteSelected: false`. Auto-enables `selection` when handler is provided (unless `selection: false`). Visibility is not gated by `canDelete`; apps gate via conditional handler. |
| grouping         | **true**  | “Group by” dropdown when columns have `enableGrouping`         | Dropdown only shown when at least one column has `enableGrouping`.                                                |
| columnVisibility | **true**  | Control to show/hide columns                                   |                                                                                                                   |
| columnReordering | **true**  | Ability to reorder columns                                     |                                                                                                                   |
| hierarchical     | **true**  | Expand-all / collapse-all when `hierarchical` config is passed | Toolbar controls only when `hierarchical?.enabled` is true.                                                       |


**Summary:** All flags default to **true** except **selection**, which defaults to **false**. Implementation MUST use these defaults in the package so that omitting `features` gives the opt-out behaviour above.

### ServerSideConfig / ServerSideParams / ServerSideResponse

- **ServerSideParams:** pageIndex, pageSize, sorting (SortingState), columnFilters (ColumnFiltersState), globalFilter (string), grouping (GroupingState).
- **ServerSideResponse<TData>:** data: TData[], totalCount: number, pageIndex, pageSize, pageCount, hasNextPage, hasPreviousPage.
- **ServerSideConfig<TData>:** fetchData(params) => Promise<ServerSideResponse<TData>>; enableServerSorting?, enableServerFiltering?, enableServerSearch?, enableServerPagination?; debounceMs?, cacheMs?.

### Import

- **ImportHandlerResult:** void | Promise<void> | ImportSummary | Promise<ImportSummary>.
- **ImportSummary:** { successCount: number, totalCount: number, failedCount: number, failedRows?: Array<{ row: number, reason: string }> }.
- **ImportModalConfig:** title?, description?, uploadAreaText?, chunkSize?, etc. (customise modal copy).
- **ImportModal mapping labels:** Column mapping rows and preview table headers MUST display each column’s `header` string (fallback to the import key only when header is absent). Mapped row object keys use `id ?? accessorKey` (unchanged from table column identity).
- **ImportModal auto-match:** On CSV parse, initial column mapping SHOULD match file headers against the import key, `accessorKey`, `id`, and `header` (trimmed, case-insensitive).
- **Importable columns:** `importable?: boolean` on `DataTableColumn` — when `false`, the column is excluded from import mapping (default: included).

### Column (R07b additions)

- **DataTableColumn:** enableColumnFilter?, filterType?, filterSelectOptions?; editable?, fieldType?, fieldOptions?; enableGrouping?, aggregate?, aggregateFn?, aggregateCell?; searchable?; importable?. For `fieldType: 'select'`, `fieldOptions.options` MUST be an array of `{ value: string, label: string }`; the create/edit form UI displays the **label** for the current value and submits the **value**.

### HierarchicalConfig

- enabled: boolean; defaultExpanded?: boolean | string[]; onExpandedChange?: (expandedIds: string[]) => void; indentSize?: number; parentRowClassName?, childRowClassName?.

### DataTableAction<TData>

- label: string; icon?: ComponentType; onClick: (row: TData) => void; variant?; disabled?: boolean | (row: TData) => boolean; hidden?: boolean | (row: TData) => boolean; visible?: boolean | (row: TData) => boolean; loading?: boolean | (row: TData) => boolean (when true, action is disabled and shows an inline spinner in the actions cell); testId?; showForParent?, showForChild? (hierarchical).

---

## Behaviour

- **Table-centric markup contract:** DataTable should emit table-related markup (`caption`, `thead`, `tbody`, `tfoot`, rows/cells) and heading markup for the title, while using pace-core Button/Checkbox/Input/Select controls for interactions.
- **Table body markup contract:** `DataTableBody` owns the single `<TableBody>` wrapper for data rows; `DataTableLayout` MUST NOT wrap `DataTableBody` in an additional `<TableBody>` (avoids nested tbody and ensures frame classes apply to rows).
- **Caption title contract:** Render one copy of `title` only; it must be an `h4` and must be the first element in `TableCaption`.
- **Caption toolbar contract:** Search, row count, and table actions are rendered in `TableCaption` after the title heading, not in a separate `<header>` element.
- **Caption wrapper minimisation:** In the standard table render path, `TableCaption` direct children should be only the title heading (`h4`) and the toolbar `nav` (when shown); remove extra caption-level wrapper nodes used only for layout.
- **Caption display contract:** `TableCaption` must retain native caption display behavior; do not apply grid display classes directly to the `<caption>` element.
- **Caption padding contract:** DataTable `TableCaption` uses `px-4` horizontal padding so caption content aligns with `th`/`td` inset (including pagination footer cells). Do not apply `p-0` or remove horizontal padding on caption.
- **Caption surface contract:** `TableCaption` uses the same layer body background as `<tbody>` (per CR05a); DataTable caption toolbar sits on that surface, not thead/tfoot band shading.
- **Caption frame contract:** When present, `TableCaption` is the top frame edge: full top border box (`border-t border-l border-r border-b`, layer token) and top corner radius (`rounded-t-*`) per CR05a; table carries no outer border when `<tfoot>` is present.
- **Pagination footer frame contract:** Pagination last `<tfoot>` row cells use the CR05a decentralized bottom frame (`border-l`/`border-r`/`border-b`, `rounded-b-*`, and header/footer band background on the same cell) so the pagination band bottom corners mirror the caption top corners when both are present.
- **Toolbar control order contract:** Enabled toolbar controls MUST render in this order: **left** — search, row count; **right** — filters toggle, group by, expand/collapse all, columns, import, export, delete selected, create. Disabled or hidden controls are omitted without shifting the relative order of remaining controls.
- **Table surface contract:** DataTable MUST NOT wrap Table in Card; surface framing comes from Table `layer`.
- **Border contract:** no vertical interior cell borders; horizontal dividers and outer frame follow the CR05a Table frame model (`border-separate border-spacing-0`, caption top border box, edge-cell side borders, cell-level row borders, flat thead when caption present).
- **Toolbar nav wrapper contract:** The caption toolbar `nav` is the layout wrapper for search, row count, and action controls. Do not add extra grouping wrappers around search controls or around filter/grouping action clusters solely for layout.
- **Toolbar nav flow contract:** Caption toolbar `nav` is a normal flow container (not grid/flex) with right text alignment so controls align to the right edge.
- **Toolbar left anchors contract:** In caption toolbar `nav`, the search wrapper `label` and row-count `span` must include `float-left` so they stay pinned to the top-left while action buttons/select controls remain right-aligned and naturally flow around them.
- **Toolbar nav wrapping contract:** Toolbar controls render as inline/inline-block level elements so they naturally wrap to additional lines when the caption nav becomes narrow.
- **Toolbar nav vertical alignment contract:** Inline-flow children inside caption toolbar `nav` must use consistent vertical alignment (`align-middle`) so search, row count, buttons, and grouping controls align on the same visual row height.
- **Search icon placement:** In the caption toolbar, show the search icon inside the search input at the right edge (not as a separate leading icon element).
- **Toolbar and footer layout recipes:** Caption controls use inline flow wrapping in the toolbar nav; footer controls use direct Tailwind grid recipes (`auto 1fr auto` for footer controls, and `auto auto` for action clusters) in component class strings, not `core.css` alias utilities.
- **Column groups contract:** DataTable should render a `colgroup` with column type grouping metadata (`data-col-type`) for select, data, and actions columns. Select and actions columns should remain content-fit/narrow; data columns should be the expandable group.
- **Actions column alignment contract:** Actions column header (`th`) and body cells (`td`) use `text-right`; do not wrap row action buttons in an extra layout-only wrapper element inside the actions `td`.
- **Row count:** To the right of the search box, the table MUST show total row count (e.g. "42 rows"); when search or column filters are applied (client-side), it MUST show "x / y" (filtered count / total count). Server-side may show only total if the API does not provide a filtered count.
- **Filter row:** The filter row MUST be **hidden by default** and shown/hidden via a toolbar **Filters** button (visible label **Filters**; `aria-label` **Show filters** / **Hide filters**). It is only rendered when the user has toggled it on and at least one column has `enableColumnFilter`.
- **Icons:** Toolbar actions and row actions MUST use Lucide icons (Search, Download, Upload, Plus, SquarePen, Trash2); sortable column headers MUST show ArrowUp/ArrowDown (or equivalent) when sorted. Icon-only buttons MUST have `aria-label`.
- **Column visibility and reorder:** When `features.columnVisibility` is true, a **Columns** toolbar control MUST open a **dropdown panel** (native `popover="auto"` anchored to the trigger, not a modal `Dialog`) allowing the user to show/hide columns. When `features.columnReordering` is true, the user MUST be able to reorder columns (up/down in the same panel). Visibility and order MAY be controlled via `columnVisibility` / `onColumnVisibilityChange` and `columnOrder` / `onColumnOrderChange`.
- **Columns dropdown visual specification:** Trigger is an outline `Button` labelled **Columns** with `popovertarget` / `popovertargetaction="toggle"`, `aria-expanded`, and `aria-controls` pointing at the panel id. Panel uses the same native Popover + CSS anchor positioning family as Select (`top-anchor-bottom`, `position-try`, `max-h-[50vh]`, joined trigger/content radii via `listboxTriggerJoinClasses` / `listboxContentJoinClasses`). Panel content: a `ul` of rows only (no in-panel heading; the trigger label identifies the control). Each row uses a full-width grid: optional visibility `Checkbox`, column header label (`1fr`), optional up/down reorder `Button`s right-aligned in the trailing column. Changes apply immediately; **no Done footer** — dismiss via light dismiss or Escape. Panel MUST NOT block the table behind a scrim.
- **Grouping:** When `features.grouping` is true and at least one column has `enableGrouping`, the user MUST be able to optionally group rows by a field of their choice via a "Group by" dropdown. The trigger MUST show the selected column **header** (for example `Type`), not the internal column id/accessor key (for example `supplierTypeLabel`).
- **Pagination footer structure:** Pagination controls are rendered inside table `tfoot` (not a separate external `<footer>`). `tfoot` MUST render one pagination `tr` with one `td` that always spans all rendered table columns (computed from current column structure; if needed, use a safe minimum of `1` to keep valid table markup). Inside that `td`, render a single `nav` wrapper (`aria-label="Pagination"`) with grid columns `auto 1fr auto auto auto auto` and no inter-column gap so the layout is: (1) inline `label` with plaintext "Rows per page" and page-size `Select`; (2) inline page status `span` with "Page", current-page `Select`, and "of {totalPages}"; (3-6) four inline icon buttons for first, previous, next, and last page using Lucide `ChevronsLeft`, `ChevronLeft`, `ChevronRight`, and `ChevronsRight`.
- **Default page size contract:** When `initialPageSize` is not provided, DataTable defaults page size to the largest configured option in `PAGE_SIZE_OPTIONS`.
- **Section wrapper restriction:** Do not use `<section>` wrappers in DataTable markup for toolbar, pagination, or row action layout; apply grid layout classes directly on `caption`, `tfoot` rows/cells, or inline containers.
- **Feature flags:** DataTable MUST use the **opt-out** defaults defined in **Feature flags and defaults** above. Most features are on by default; only **selection** is off by default (opt-in). Consuming apps MAY pass `features` to turn individual features off (or, for selection, on).
- When serverSide is set, DataTable MUST NOT slice data client-side for pagination; MUST call fetchData with current params and display returned data and totalCount; MUST support server-side sort/filter/search if enabled. Feature flags MUST control visibility of toolbar and row actions; RBAC MUST further restrict which actions are shown. Import modal MUST call onImport with parsed/mapped data and display ImportSummary when returned. Edit/Create/Delete flows MUST call the provided handlers; bulk delete MUST show confirmation before onDeleteSelected. Grouping MUST allow group-by column(s) and display aggregate values per group/footer. Hierarchical MUST render expand/collapse and indent child rows.
- **Create/Edit form select fields:** For columns with `fieldType: 'select'` and `fieldOptions.options` (array of `{ value, label }`), the Create row and Edit row modals MUST display the **label** of the selected option to the user (e.g. organisation name), while storing and submitting only the **value** (e.g. ID). The select trigger MUST show the label, not the raw value.
- **Empty data with creation:** When there is no data (client-side: `data.length === 0`; server-side: response received and `displayData.length === 0`) **and** `features.creation === true` **and** (`onCreateRow` or `onCreateClick` is provided), DataTable MUST **not** render only the empty-state block. It MUST render the toolbar (including the Create button) and the table structure: column headers plus a table body with a single empty row (e.g. one cell with `colSpan` spanning all columns) that displays the empty state message (e.g. `emptyState.title`, `emptyState.description`) when provided, or a generic message such as "No rows" / "No data to display." Users MUST be able to see the Create button and the table shell so they can add the first row.
- Aggregation features in this slice are table-presentation aggregations. Shared business/domain calculators and cross-surface print/export composition are deferred and remain outside this slice.

---

## Demo app requirements

- At least one DataTable that uses either server-side config or client-side with filtering + full toolbar (search, export, optionally import). Optionally: row actions (Edit/Delete), import flow, create modal, or hierarchical data. Step-by-step: user can search/filter, change page (if server-side), trigger import or row action, and see correct behaviour and toasts/summaries.

---

## Verification

- **Server/client mode correctness:** Verify server-side mode sends correct params and consumes server response shape, while client mode preserves R07a behaviour.
- **Extended feature contract:** Verify filtering toggle, toolbar actions, row actions, import, selection, grouping, and hierarchical controls obey feature flags + RBAC.
- **Data entry flows:** Verify create/edit/delete and bulk delete confirmations invoke handlers correctly and preserve table state expectations.

---

## Testing requirements

- Unit tests: ServerSideConfig usage (fetchData called with correct params); feature flags and RBAC for toolbar/actions; aggregation utils; hierarchical state helpers. Integration tests: DataTable with serverSide (load, paginate, sort); filter row updates data or params; import modal (parse, map, onImport); row actions fire; edit/create/delete flows. Coverage per Standard 08.

---

## Do not

- Do not remove or break R07a behaviour (client-side sort, pagination, export). Do not add virtual scrolling or performance config in this slice unless specified. Do not copy old implementation; implement from this spec and standards.

---

## References

- [R07a-datatable.md](./R07a-datatable.md), [2-architecture-standards.md](../../packages/core/docs/standards/2-architecture-standards.md), [3-security-rbac-standards.md](../../packages/core/docs/standards/3-security-rbac-standards.md), [7-visual-standards.md](../../packages/core/docs/standards/7-visual-standards.md), implementation-guides/data-tables.

**Server-side usage:** `serverSide={{ fetchData: async (params) => ({ data: await api.fetch(params), totalCount: await api.count(params), ... }) }}`.

**Import:** `onImport={async (data) => { await save(data); return { successCount: data.length, totalCount: data.length, failedCount: 0 }; }}` `importModalConfig={{ title: 'Import users' }}`.

---

## Prompt to use with Cursor

Implement the feature described in this document. Assume R07a is already implemented (DataTable core, useDataTableState, export). Add server-side pagination, feature flags, filtering UI, toolbar, row actions, import modal, edit/create/delete flows, selection and bulk delete, grouping/aggregation, and hierarchical rows as specified. Follow the standards and guardrails. Add or update tests and demo. Run validate and fix any issues until it passes.