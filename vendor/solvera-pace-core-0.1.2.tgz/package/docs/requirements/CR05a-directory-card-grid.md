# CR05a-directory-card-grid – Directory card grid

*Layout primitives for equal-height browse/launcher/KPI card grids across pace-suite apps.*

## Overview

- **Purpose:** Single-sourced layout for directory-style card grids so side-by-side cards share row height and grids do not use list markup.
- **Scope:** Package export + demo example.
- **Dependencies:** [CR05a-primitives.md](./CR05a-primitives.md) (`Card fill`), [CR29-event-tile.md](./CR29-event-tile.md) (parallel contract for event tiles).
- **Standards:** 05 pace-core compliance, 07 Visual.

## Acceptance criteria

- [x] `CardGrid` and `CardGridItem` exported from `@solvera/pace-core/components`.
- [x] `Card fill` prop implemented per CR05a directory card grid subsection.
- [x] Demo styles showcase renders a directory card grid with uneven body copy and at least one navigational item.
- [x] Integration tests cover `Card fill` and `CardGrid` / `CardGridItem`.
- [x] ESLint `no-directory-card-list-grid` aligns with this requirement.

## API / Contract

**Export:** `packages/core/src/components/advanced-ui/CardGrid.tsx`

### CardGrid props

- `children: ReactNode`
- `className?: string`
- `columns?: 1 | 2 | 3 | { md?: 2 | 3; lg?: 2 | 3 | 4 }` — default responsive `grid-cols-1 md:grid-cols-2 lg:grid-cols-3`
- `heading?: ReactNode`
- `headingId?: string` — when `heading` is a string, used as `h2` `id`

### CardGridItem props

- `children: ReactNode` — SHOULD be `<Card fill>…</Card>`
- `href?: string` — when set, wraps children in `<a className="contents no-underline" href={href}>`
- `className?: string` — merged onto the link when `href` is set (layout-only)

## Visual specification

- **CardGrid root:** `<section className="grid gap-4 …">`.
- **Heading:** Optional `<h2 className="col-span-full">` when `heading` is provided.
- **CardGridItem with href:** Link uses `contents` so the child `Card` is the effective grid participant; card surface receives grid stretch.
- **Equal height:** Grid children use `Card fill` so variable description length does not change visible card height within a row.

## Behaviour

- Presentation-only — no routing library inside `CardGridItem`; pass `href` at call site.
- When `href` is omitted, `CardGridItem` renders children only (fragment semantics via direct children in grid).

## Do not

- Do not use `<ul>` / `<ol>` as the CardGrid container.
- Do not fetch data inside these layout components.

## References

- [CR05a-primitives.md](./CR05a-primitives.md) — Card `fill` recipes
- [CR29-event-tile.md](./CR29-event-tile.md) — EventTile directory grid parity
- [7-visual-standards.md](../standards/7-visual-standards.md) — Part B directory card grids

---

## Prompt to use with Cursor

Implement the feature described in this document. Follow the standards and guardrails provided. Add or update tests and demo as specified. Run validate and fix any issues until it passes.
