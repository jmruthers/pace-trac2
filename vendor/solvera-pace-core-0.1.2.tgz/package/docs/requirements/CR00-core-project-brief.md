# Project brief: pace-core

## Filename convention

This document follows:

`**CR00-core-project-brief.md**`


| Segment             | Meaning                                   |
| ------------------- | ----------------------------------------- |
| `**CR**`            | Core requirement series.                  |
| `**00**`            | Foundation slot shared with architecture. |
| `**core**`          | Product slug.                             |
| `**project-brief**` | Document type.                            |


---

This document describes the high-level goals and objectives for pace-core. It is the main reference for what the project is and what it aims to achieve. For setup (workspace or install pace-core, `npm run setup`, env and MCP), see [NEW-PROJECT-SETUP.md](../../NEW-PROJECT-SETUP.md).

---

## What is pace-core?

pace-core is the shared foundation for the pace-suite: a single NPM package (`@solvera/pace-core`) that provides everything consuming apps need to build consistent, secure, standards-compliant products.

The package delivers:

- Design system - shared types, utilities, and styles (Tailwind v4, design tokens main/sec/acc, `core.css`). Typography, spacing, and colour are defined here so apps stay visually and technically aligned.
- Page chrome and cards - in-page breadcrumb, page header, empty state, entity hero ([CR27](./CR27-page-chrome.md)); delegated-editing and section banners ([CR28](./CR28-delegated-editing-banner.md)); reusable event card ([CR29](./CR29-event-card.md)).
- Auth and context - Supabase-backed auth, organisation and event context, session restoration, protected routes, and inactivity handling.
- RBAC and secure data access - permission engine, secure Supabase client boundary, hooks and guards, route/page permission contracts.
- Shared service and resilience contracts - services/providers, read-model helper, resilience composition, location/timezone adapter interfaces.
- Workflow-typed forms and field registry - metadata-driven field registry ([CR20](./CR20-form-registry-and-address-field.md)), workflow-typed public forms runtime and submission contracts ([CR21](./CR21-workflow-forms-runtime.md)); consuming apps supply orchestration and persistence adapters.
- Shared reporting foundations - explore-based join topology, field-selection validation, and report-builder primitives ([CR22](./CR22-shared-reporting-foundations.md)); database field metadata and templates remain outside pure UI scope where noted.
- Shared communications and cross-app launch contracts - shared communications platform primitives ([CR23](./CR23-comms-platform.md)), shared member-profile handoff/launcher contracts for app-to-app delegation ([CR24](./CR24-cross-app-member-profile-launch.md)), and a shared itinerary derivation helper for cross-app participant/planner itinerary parity ([CR26](./CR26-shared-itinerary-derivation-helper.md)).
- Quality system - standards (00-09), Cursor rules, ESLint config, and audit tooling installed into consuming apps through `npm run setup`.

The repo also contains a demo app at the root that consumes the package via workspace. The demo exists to validate package behaviour and compliance; it is not a separate published product.

### Initial scope and decisions

- pace-core is the authoritative source for reusable platform contracts and shared implementation patterns used by pace-suite apps.
- The package and demo consume an existing Supabase project. This repo does not own schema migrations, RLS policy authoring, or database function design changes.
- Requirement slices CR02–CR29 define the implementation and verification backlog for package contracts and demo wiring (including CR20–CR26 for shared forms platform, reporting, communications, cross-app launch contracts, and shared itinerary derivation; CR27–CR29 for prototype-gap page chrome, banners, and EventCard).

---

## Goals and non-goals

Goals:

- Be the single, authoritative foundation for pace-suite design system, components, auth, RBAC, services, and quality tooling.
- Keep the codebase standards-first and auditable, with Cursor, ESLint, and audit aligned to documented standards.
- Publish and maintain `@solvera/pace-core` so consuming apps can install and align quickly via `npm run setup`.
- Keep the demo app reliable as a verification surface for package behaviour and requirement slices.

Non-goals:

- Recreating or preserving undocumented legacy quirks from older codebases.
- Adding exports or behaviour outside agreed requirement slices and standards.
- Owning schema/migration lifecycle in this repo.

---

## Tech stack

- Runtime: Node LTS; package manager: npm.
- Language: TypeScript (strict).
- UI: React 19, React DOM 19.
- Build: Vite 7.
- Styling: Tailwind CSS v4 (CSS-first with `@import 'tailwindcss';` and `@theme` tokens).
- Testing: Vitest, React Testing Library, userEvent.
- Backend/auth: Supabase (existing project; no migrations in this repo).
- Monorepo/consumption: npm workspaces with publishable package under `packages/core` and a root demo consuming via `workspace:*`.

---

## Repo structure

- `packages/core` - publishable package `@solvera/pace-core` (components, hooks, providers, rbac, services, types, utils, theming, styles, scripts, standards/docs).
- `src` (repo root demo app) - demo routes/pages that validate package capabilities.
- `docs` - setup docs, changelog, architecture/requirements docs.
- No database migrations in this repo unless schema ownership explicitly changes.

---

## Quality gates

- Validate - `npm run validate` is the definition of done (typecheck, lint, build, tests, audits).
- Standards - standards 00-09 are canonical; tools enforce, not redefine.
- No silencing - fix root causes instead of suppressing lint/audit findings.

---

## Out of scope

- Schema and migrations - this repo does not create/alter Supabase schema, RLS policies, or DB functions.
- App-specific feature ownership - consuming apps own their domain-specific features and UI composition beyond shared contracts.

---

## Related documents

- [CR00-core-architecture.md](./CR00-core-architecture.md) - bounded-context architecture and requirement mapping.
- [CR02-foundation-types-utils-styles.md](./CR02-foundation-types-utils-styles.md) - foundation contracts (types, utils, style system).
- [CR03-auth-and-context.md](./CR03-auth-and-context.md) - auth/session/organisation context contracts.
- [CR04-rbac.md](./CR04-rbac.md) - RBAC engine, secure client boundary, permission guards.
- [CR05a-primitives.md](./CR05a-primitives.md), [CR05a-directory-card-grid.md](./CR05a-directory-card-grid.md), [CR05b-dialog-select-tabs.md](./CR05b-dialog-select-tabs.md), [CR05c-layout-and-shell.md](./CR05c-layout-and-shell.md) - UI primitives, directory card grid layout, overlays, and app shell.
- [CR06-forms-and-feedback.md](./CR06-forms-and-feedback.md) - forms, login page, and feedback patterns.
- [CR07a-datatable.md](./CR07a-datatable.md), [CR07b-datatable.md](./CR07b-datatable.md), [CR07c-datatable.md](./CR07c-datatable.md) - DataTable baseline, advanced features, and prototype-parity column/props extensions.
- [CR08-advanced-ui.md](./CR08-advanced-ui.md), [CR09-public-pages.md](./CR09-public-pages.md) - advanced/public UI surfaces.
- [CR10-services-and-providers.md](./CR10-services-and-providers.md) through [CR19-location-timezone-adapter-interfaces.md](./CR19-location-timezone-adapter-interfaces.md) - service, resilience, theming, CRUD, and adapter contracts.
- [CR20-form-registry-and-address-field.md](./CR20-form-registry-and-address-field.md) - dynamic field registry and AddressField adapters.
- [CR21-workflow-forms-runtime.md](./CR21-workflow-forms-runtime.md) - workflow-typed forms runtime and submission contracts (canonical forms platform architecture).
- [CR22-shared-reporting-foundations.md](./CR22-shared-reporting-foundations.md) - shared reporting explores, planners, and builder primitives (canonical reporting architecture).
- [CR23-comms-platform.md](./CR23-comms-platform.md) - shared communications platform contracts and composer primitives.
- [CR24-cross-app-member-profile-launch.md](./CR24-cross-app-member-profile-launch.md) - shared cross-app member-profile launch and URL-construction contract.
- [CR26-shared-itinerary-derivation-helper.md](./CR26-shared-itinerary-derivation-helper.md) - shared pure itinerary derivation contract for day-entry expansion, timezone precedence, participant scoping, and in-day ordering.
- [CR27-page-chrome.md](./CR27-page-chrome.md) - in-page breadcrumb, page header, empty state, and entity hero band.
- [CR28-delegated-editing-banner.md](./CR28-delegated-editing-banner.md) - proxy/delegated-editing banner and section callout banner.
- [CR29-event-card.md](./CR29-event-card.md) - reusable event card for directory and dashboard grids.
