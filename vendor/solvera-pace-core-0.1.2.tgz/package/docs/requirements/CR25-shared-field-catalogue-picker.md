# CR25 - Shared field-catalogue picker for workflow authoring

## Overview

- Purpose and scope: define the shared `pace-core2` contract for selecting workflow authoring `field_key` values from the canonical field catalogue, replacing app-local free-text key entry where a catalogue-backed picker is required.
- This slice owns the shared picker API surface, data-loading hook contract, and export ownership for consuming apps.
- External prerequisites: the read contract `data_core_field_list_core_form()` (or approved successor) and its RLS/auth behavior are owned outside this repo.
- Dependencies: [CR12-supabase-react-query-error-handling.md](./CR12-supabase-react-query-error-handling.md), [CR21-workflow-forms-runtime.md](./CR21-workflow-forms-runtime.md).
- Standards: 02 Architecture, 03 Security and RBAC, 04 API and tech stack, 05 pace-core compliance, 06 Code quality, 07 Visual, 08 Testing and documentation.

## Problem

Consuming apps currently rely on free-text `field_key` entry in authoring flows, which creates avoidable key typos, weak discoverability, and duplicate app-local picker implementations. TEAM rollout item `pc-1` requires one shared field-catalogue picker contract bound to the canonical form-field catalogue read path.

## Target contract

### Shared ownership

- The canonical picker surface is exported from `@solvera/pace-core/forms`.
- The picker must be reusable by any consuming app that authors workflow forms.
- CR21 consumes this slice for workflow authoring composition and must not redefine picker transport contracts.

### Data contract

- Picker options are sourced from the approved form catalogue read contract:
  - primary source: `data_core_field_list_core_form()`
  - fallback/source substitution: allowed only through an injected adapter contract.
- Picker rows must include at minimum:
  - `field_key` (stable option value),
  - display label (human-readable),
  - optional grouping metadata (domain/category),
  - optional helper metadata used for UI hints (for example supported field type).

### API surface

- Required exports from `@solvera/pace-core/forms`:
  - `WorkflowFieldCataloguePicker` (component),
  - `useWorkflowFieldCatalogue` (data hook),
  - `WorkflowFieldCatalogueOption` type,
  - component and hook props/output types.
- Required behavior:
  - controlled value API (`value`, `onValueChange`),
  - loading and empty states,
  - optional search/filter support for large catalogues,
  - graceful error surface without throwing in render paths.

### Non-ownership

- This slice does not own catalogue table migrations or seed data policy.
- This slice does not own workflow-type-specific field validation rules beyond selectable catalogue entries.

## Acceptance criteria

- [x] `pace-core2` defines and documents a shared picker contract bound to the canonical form-field catalogue read path.
- [x] Public exports for picker component, hook, and types are defined under `@solvera/pace-core/forms`.
- [x] The contract supports transport injection so consuming apps can use secure clients/adapters without package-level env coupling.
- [x] The picker contract is reusable across consuming apps and does not depend on TEAM-only route or page semantics.
- [x] CR21 references this slice as the field-catalogue picker authority.

## API / Contract

- `WorkflowFieldCatalogueOption`:
  - `fieldKey: string`
  - `label: string`
  - `group?: string`
  - `fieldType?: string`
- `useWorkflowFieldCatalogue`:
  - returns `{ options, isLoading, error, refresh }`
  - supports injected loader/adapter for non-default transport
- `WorkflowFieldCataloguePicker`:
  - accepts `value`, `onValueChange`, `options`, `isLoading`, `errorMessage?`, and optional `disabled`
  - may accept optional `onOptionSelect` (full catalogue row when the author selects an option, for syncing `fieldType` and labels in authoring) and optional `searchPlacement` (`popover` \| `none`) for in-popover filter vs no filter; legacy `enableSearch` may map to `searchPlacement` (see CR21 contract notes)
  - renders options using pace-core form primitives and accessible select semantics

## Verification

- Unit tests:
  - option mapping from catalogue row contract to picker options,
  - controlled-value behavior,
  - empty/error/loading state rendering.
- Integration tests:
  - `WorkflowFormFieldEditor` composition path using the shared picker contract.
- Export verification:
  - all CR25 symbols import from `@solvera/pace-core/forms` without deep paths.

## Do not

- Do not keep free-text `field_key` entry as the only authoring path once the shared picker contract is implemented.
- Do not hardcode TEAM-only labels or route logic into picker contracts.
- Do not query raw DB metadata tables directly from consuming app UI when an approved read contract exists.

## References

- [CR12-supabase-react-query-error-handling.md](./CR12-supabase-react-query-error-handling.md)
- [CR21-workflow-forms-runtime.md](./CR21-workflow-forms-runtime.md)
- [docs/requirements/team/rollout-summary-TEAM-2026-05-04.md](../../../../docs/requirements/team/rollout-summary-TEAM-2026-05-04.md)

---

## Prompt to use with Cursor

Implement the feature described in this document. Follow the standards and guardrails provided. Add or update tests and verification as specified in **Verification**. If public exports change, run `npm run build -w @solvera/pace-core` before repo-wide validate so `dist/` stays aligned. Then run `npm run validate` and fix issues until it passes.
