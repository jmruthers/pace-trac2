# CR16 – Event-scoped CRUD scaffold and attachment lifecycle primitives

## Overview

- Purpose: define a reusable, secure scaffold for event-scoped CRUD operations and attachment lifecycle orchestration so consuming apps can implement feature-specific entities without duplicating RBAC/secure-client boilerplate.
- Scope: package contracts (hooks, adapters, utility types) and demo verification surfaces. This slice defines contract boundaries, not domain-specific entity schemas.
- Dependencies: CR04-rbac (secure client and permission checks), CR10-services-and-providers (service composition), CR12-supabase-react-query-error-handling (error normalization), CR17-derived-event-read-model-helper (selected event context), CR18-composite-resilience-utilities (fallback/loading composition).
- Standards: 03 Security and RBAC, 04 API and tech stack, 05 pace-core compliance, 08 Testing and documentation.

## Acceptance criteria

- [x] Provide an event-scoped CRUD hook scaffold contract that requires explicit scope input (`organisationId`, `eventId`, `appId` where relevant) and a permission gate before mutation.
- [x] Define create/read/update/delete operation contracts with consistent `ApiResult`-style outcomes and clear loading/error state semantics.
- [x] Require all data and mutation operations to use the pace-core secure client boundary from CR04; raw base clients are not allowed in scaffold operations.
- [x] Support optimistic-update and invalidation extension points without enforcing a single cache strategy.
- [x] Define attachment lifecycle primitives that cover metadata record lifecycle plus storage operations (upload, access, delete) under the same secure boundary.
- [x] Attachment contracts expose adapter interfaces for app-specific table/entity mappings (entity id field, relation field, metadata projections) without forcing one schema.
- [x] Contracts remain opt-in and composable; apps can use CRUD scaffold only, attachment primitives only, or both together.

## API / Contract

- Public exports from `packages/core/src/crud/` (or equivalent): `useEventScopedCrud`, adapter types, shared operation result types, and attachment lifecycle helpers.
- Required contract-level shapes (names may vary if equivalent):
  - `EventScopeInput`: `{ organisationId?: string | null; eventId?: string | null; appId?: string | null }`
  - `CrudPermissionConfig`: permission identifiers for read/create/update/delete checks
  - `CrudOperationResult<T>`: result payload and operation status (`data`, `error`, `isLoading`, mutation helpers)
  - `AttachmentLifecycleAdapter`: mapping contract for entity table, attachment metadata table, key fields, and optional transform hooks
- Attachment primitives contract (names may vary if equivalent):
  - `createAttachmentReference`
  - `uploadAttachmentContent`
  - `resolveAttachmentAccess` (signed/public URL policy by adapter configuration)
  - `deleteAttachment` (storage and metadata cleanup sequencing)
  - `replaceAttachmentWithRollback` (replacement semantics: upload to a distinct storage path, update metadata; on metadata update failure remove only the new object and preserve the prior link; on success optionally remove the prior storage object per explicit policy)
- Canonical attachment storage key contract (when adapter does not override `getStoragePath`): `organisationId/eventId/relationTable/relationId/objectId-fileName` where `objectId` is unique per upload attempt.
- Hooks/utilities should accept explicit extension callbacks for:
  - optimistic state update
  - post-success invalidation
  - custom error mapping
- Contract only: implementation details (query library wiring, concrete table names, storage bucket names) are app configuration concerns unless provided via adapter defaults.
- Attachment lifecycle defaults and R08 upload flow MUST share one canonical path-builder strategy for org/event segregation; domain adapters may override key generation only when they have an explicit documented exception.

## Visual specification

Not applicable (non-UI contract slice).

## Verification

- [x] pace-core: add or update a demo flow showing one event-scoped CRUD entity using scaffolded read/mutate operations under secure client context.
- [x] pace-core: add or update a demo flow showing attachment lifecycle with adapter mapping (create metadata, upload content, read access URL, delete).
- [x] Consuming apps: verify permission denial blocks mutation while allowing permitted operations in the same scope.
- [x] Consuming apps: verify attachment delete cleans both metadata reference and storage object according to adapter policy.
- [x] pace-core: unit tests verify `replaceAttachmentWithRollback` preserves the existing linked file when the new upload succeeds but metadata update fails, and does not remove the prior object until the new path is committed (unless an explicit cleanup policy applies after success).

## Testing requirements

- [x] Unit tests for scope validation, permission precondition handling, and operation result normalization.
- [x] Unit tests for attachment lifecycle sequencing and adapter mapping behavior.
- [x] Integration tests for secure-client-only enforcement and mutation success/error paths under scoped context.
- [x] Coverage follows Standard 08 with emphasis on security boundaries and lifecycle consistency.
- [x] Unit tests for `replaceAttachmentWithRollback`: successful replace with optional old-object cleanup; metadata update failure rolls back new storage only and leaves prior path intact; upload failure does not mutate metadata.

## Do not

- Do not encode app-specific domain rules, formulas, or entity schemas in this slice.
- Do not bypass CR04 secure client contracts for any CRUD or attachment operation.
- Do not require one storage vendor implementation in core contracts; keep provider-specific details outside this slice.
- Do not copy implementation from prior app code; implement from this contract.

## References

- [CR04-rbac.md](./CR04-rbac.md)
- [CR10-services-and-providers.md](./CR10-services-and-providers.md)
- [CR12-supabase-react-query-error-handling.md](./CR12-supabase-react-query-error-handling.md)
- [CR17-derived-event-read-model-helper.md](./CR17-derived-event-read-model-helper.md)
- [CR18-composite-resilience-utilities.md](./CR18-composite-resilience-utilities.md)
- [3-security-rbac-standards.md](../../../packages/core/docs/standards/3-security-rbac-standards.md)
- [4-api-tech-stack-standards.md](../../../packages/core/docs/standards/4-api-tech-stack-standards.md)

---

## Prompt to use with Cursor

Implement the feature described in this document. Follow the standards and guardrails provided. Add or update tests and verification flows as specified in Testing requirements and Verification. Run validate and fix any issues until it passes.

