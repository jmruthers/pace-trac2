# Foundation: types, utils, styles

*Enrichment complete (reverse-engineering pass): API/Contract signatures, Behaviour MUSTs, Demo step-by-step, References with inline examples.*

## Overview

- **Purpose:** Core types, shared utilities, and design-system styles that all other package code and the demo app depend on.
- **Scope:** Package only (demo consumes via package). No auth or RBAC yet.
- **Dependencies:** None (first feature slice after repo shell).
- **Standards:** 01 Project structure, 04 API & tech stack, 06 Code quality, 07 Visual.

## Acceptance criteria

- [x] Core types exported: ApiResult, ApiError, base auth/event/organisation types, shared guards.
- [x] ApiResult helpers exported: createSuccessResult, createErrorResult, normalizeToApiError for consistent API/RPC error handling.
- [x] Utils: `cn`, Logger (createLogger, LogLevel), formatDate/Time/DateTime/Currency/Number/Percent/FileSize/CompactNumber, timezone helpers (formatInTimeZone, getUserTimeZone, toZonedTime, fromZonedTime), validation schemas (email, name, phone, url, password, etc.) and sanitize* where applicable.
- [x] Styles: `core.css` with Tailwind v4 `@theme`, design tokens (main, sec, acc 50–950), base and typography from pace-core; no bracket arbitrary values.
- [x] Exports wired in package (types, utils, styles/core.css).
- [x] Standard 07: Visual — Part A (`app.css` / consumption) and package `core.css` tokens only; no feature component markup in this slice (downstream component recipes live in each feature requirement **Visual specification**, e.g. CR05a, CR06).
- [x] Consumer export governance baseline is owned here: generated export index, stability metadata (`stable`/`advanced`/`internal`), and CI validation for duplicate/export-boundary regressions.
- [x] Repository authority baseline is owned here: package-canonical docs/templates paths are the authored source (`packages/core/docs/standards`, `packages/core/templates`) and setup/validation tooling enforces this authority.

## API / Contract

- **Types:** Export from `packages/core/src/types/` (e.g. index) — ApiResult, ApiError, Organisation, OrganisationMembership, UserProfile, createSuccessResult, createErrorResult, normalizeToApiError, and any shared guards/types used by auth and RBAC later.
- **Utils:** Export from `packages/core/src/utils/` — `cn`, Logger, formatting, timezone, validation schemas and sanitization helpers.
- **Styles:** `packages/core/src/styles/core.css` — `@import 'tailwindcss';`, `@theme` with --color-main-*, --color-sec-*, --color-acc-* (50–950), base and typography rules. Exported as package subpath `./styles/core.css`.
- **Export governance:** generated index at `packages/core/docs/reference/consumer-exports-index.md`, governance config at `packages/core/scripts/export-governance.config.json`, and CI guardrails in `packages/core/scripts/check-export-governance.cjs`.
- **Repository authority:** standards/templates authored under package-canonical paths; validation rejects reintroduction of duplicate root authority trees.
- File paths: `src/types/`, `src/utils/`, `src/styles/core.css`.

### Concrete signatures and shapes

**ApiResult and ApiError:**
```ts
type ApiError = { code: string; message: string; details?: object };
type ApiResult<T> = { ok: true; data: T } | { ok: false; error: ApiError };
function ok<T>(data: T): ApiResult<T>;
function err(error: ApiError): ApiResult<never>;
function isOk<T>(result: ApiResult<T>): result is { ok: true; data: T };
function isErr<T>(result: ApiResult<T>): result is { ok: false; error: ApiError };
function createSuccessResult<T>(data: T): ApiResult<T>;
function createErrorResult(code: string, message: string, details?: object): ApiResult<never>;
function normalizeToApiError(error: unknown, defaultCode?: string, defaultMessage?: string): ApiError;
```

**Branded types (and helpers):** `UserId`, `OrganisationId`, `EventId`, `AppId`, `PageId` (string brands). Creators: `createUserId(id)`, `createOrganisationId(id)`, etc. Type guards: `isUserId(value)`, `isOrganisationId(value)`, etc. Assertions: `assertUserId(id)`, `assertOrganisationId(id)`, `assertEventId(id)`, etc.

**Core auth/organisation types (key fields):** `User`: id, email?, created_at, updated_at, user_metadata?, app_metadata?. `Session`: access_token, refresh_token?, expires_in, expires_at, token_type, user. `Organisation`: id, name, display_name, description?, subscription_tier, settings, is_active, created_at, updated_at. `OrganisationMembership`: id, user_id, organisation_id, role ('org_admin'|'leader'|'member'|'supporter'), status, granted_at, created_at, updated_at. `UserProfile`: id, email, full_name?, created_at, updated_at. `OrganisationContextType`: composed of OrganisationContextState (selectedOrganisation, organisations, userMemberships, isLoading, error, hasValidOrganisationContext, isContextReady) and OrganisationContextMethods (setSelectedOrganisation, switchOrganisation, getUserRole, refreshOrganisations, ensureOrganisationContext, getPrimaryOrganisation, isOrganisationSecure).

**Guards:** `isUser(obj): obj is User`, `isSession(obj): obj is Session`, `isAuthErrorCode(code): code is AuthErrorCode`.

**Validation (Zod schemas):** emailSchema, nameSchema, phoneSchema, urlSchema, dateSchema, passwordSchema, securePasswordSchema, loginSchema, registrationSchema, secureLoginSchema, passwordResetSchema, changePasswordSchema, userProfileSchema, contactFormSchema. Inferred types: LoginFormValues, RegistrationFormValues, ChangePasswordFormValues, UserProfileFormValues. Sanitization: sanitizeUserInput, sanitizeFormData, sanitizeHtml (from utils/validation/sanitization).

**Utils:** `cn(...inputs: ClassValue[]): string`. Logger: `LogLevel` enum (DEBUG, INFO, WARN, ERROR); `LoggerConfig`: level, includeTimestamp, includeComponent, prefix?; `createLogger(component: string)`: returns logger with debug, info, warn, error(component, message, ...args). Formatting: `formatDate(date: Date|string|number): string`, `formatTime(date): string`, `formatDateTime(date): string`, `formatCurrency(value, currencyCode?, locale?): string`, `formatNumber(value, options?, locale?): string`, `formatPercent(value, locale?, options?): string`, `formatCompactNumber(value, locale?): string`, `formatFileSize(bytes): string`. Timezone: `formatInTimeZone(date, timeZone, formatStr): string`, `getUserTimeZone(): string`, `toZonedTime(date: Date, timezone: string): Date`, `fromZonedTime(localDate: Date, timezone: string): Date`.

**core.css:** MUST include `@import 'tailwindcss';` and `@theme { ... }` with at least --font-sans, --font-heading, and layout/size vars. Consuming apps extend colour palettes (--color-main-*, --color-sec-*, --color-acc-* 50–950) in their app.css via @theme; core.css MUST NOT use bracket arbitrary values for design tokens.

## Behaviour

- ApiResult MUST be implemented as a discriminated union `{ ok: true; data: T } | { ok: false; error: ApiError }`; ApiError shape MUST include at least `code` and `message`.
- normalizeToApiError MUST NOT throw; it MUST return a safe ApiError shape for any input (handles objects with code/message, Error instances, or unknown; uses defaultCode/defaultMessage when needed).
- formatDate, formatTime, and formatDateTime MUST use en-GB locale and 24-hour time where applicable.
- core.css MUST NOT use bracket arbitrary values for design tokens; all design tokens MUST be defined via @theme.
- Consuming app MUST extend colour palettes (main, sec, acc 50–950) via @theme in app.css; app.css MUST import package core.css.
- Timezone utilities in this slice (`formatInTimeZone`, `getUserTimeZone`, `toZonedTime`, `fromZonedTime`) are foundational helpers only. Provider-agnostic location/timezone adapter contracts and cache interfaces are defined in `CR19-location-timezone-adapter-interfaces.md`.

## Demo app requirements

- Demo app has `app.css` with `@import 'tailwindcss';`, `@source` for package, `@import '@solvera/pace-core/styles/core.css';`, and theme palettes (main, sec, acc). App-level backgrounds should use the template `pace-background` class on `body` when a shared page background utility is needed. A single placeholder page that renders one pace-core–styled element is enough to verify styles.
- **Step-by-step:** User opens app → single placeholder page renders → one pace-core–styled element (e.g. heading or card) is visible → app.css imports package core.css and defines main/sec/acc palettes (and optional `pace-background` helper).

## Verification

- **Package:** Confirm exported types, ApiResult helpers, and utility functions are available from package entry points and match the contract signatures.
- **Styling foundation:** Confirm `core.css` uses Tailwind v4 CSS-first setup and design tokens with `main/sec/acc` palettes only.
- **Consumer wiring:** Confirm demo `app.css` imports package `core.css` and renders at least one token-driven element.
- **Export governance baseline:** Confirm `npm run docs:exports-index` and `npm run export:check-governance` pass.
- **Repository authority baseline:** Confirm setup/validate scripts and references resolve package-canonical docs/templates paths.

## Testing requirements

- Unit tests for utils (formatDate, formatCurrency, cn, timezone helpers, validation) — ≥90% coverage where applicable. Types: no runtime tests; contract covered by consumers.

## Do not

- Do not add auth or RBAC types beyond what is needed for shared shapes (e.g. Organisation, session placeholder types).
- Do not copy old implementation; implement from this spec and the standards.

## References

- [7-visual-standards.md](../../../packages/core/docs/standards/7-visual-standards.md), [4-api-tech-stack-standards.md](../../../packages/core/docs/standards/4-api-tech-stack-standards.md). Existing api-reference and implementation-guides for types/utils/styles (reference only).
- [CR19-location-timezone-adapter-interfaces.md](./CR19-location-timezone-adapter-interfaces.md)
- Export governance and canonical standards migration concerns are absorbed into this requirement from superseded governance-only slices.
- **Inline — ApiResult:** Use `ok(data)` / `err({ code, message })` and narrow with `isOk(result)` / `isErr(result)` before accessing `data` or `error`.
- **Inline — app.css minimal structure:** `@import 'tailwindcss';` then `@source` directives for package, then `@import '@solvera/pace-core/styles/core.css';`, then `@theme { }` defining --color-main-*, --color-sec-*, --color-acc-* (50–950) so pace-core components render correctly.

---

## Prompt to use with Cursor

Implement the feature described in this document. Follow the standards and guardrails provided. Add or update tests and demo as specified in "Testing requirements" and "Demo app requirements". Run validate and fix any issues until it passes.
