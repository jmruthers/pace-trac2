# CR05d – Footer support and privacy

*Depends on [CR05c – Layout and shell](./CR05c-layout-and-shell.md). Defines platform-owned Support and Privacy modals in PaceFooter and the app-support-request Edge function contract.*

## Overview

- **Purpose:** Let any pace app user (signed in or anonymous) contact support from the shell footer and read the privacy policy without forking footer UI.
- **Scope:** pace-core `PaceFooter`, Support/Privacy dialogs, client helper, privacy markdown content, and shared Supabase Edge function `app-support-request`.
- **Dependencies:** CR05c, CR06 (Dialog, Toast, Form patterns), CR14-style `functions.invoke` boundary, PUMP gateway config (Resend).
- **Standards:** 03 Security & RBAC, 04 API & Tech Stack, 07 Visual.

## Acceptance criteria

- [ ] PaceFooter renders copyright left and Support + Privacy link actions right (responsive grid).
- [ ] Support dialog collects subject + message; anonymous users also provide name + email.
- [ ] Submit invokes `app-support-request` and delivers email to `help@solvera.au` with Reply-To set to the submitter.
- [ ] Privacy dialog renders repo markdown as semantic HTML (no raw HTML injection).
- [ ] Server ignores client-supplied identity when JWT is present; anonymous path requires validated name + email.
- [ ] Rate limits applied per IP (anonymous) and per user id (authenticated).
- [ ] Support dialog shows Subject and Message labels above full-width controls; Message textarea matches Subject input width.
- [ ] Support dialog displays a read-only preview of client-known diagnostic context included with the request; server-only fields (timestamp, user id, client IP) are disclosed via note text.

## Support dialog

| Field | Rule |
|-------|------|
| `subject` | Required, max 200 characters |
| `message` | Required, max 5000 characters |
| `name` | Required when not authenticated; max 200 |
| `email` | Required when not authenticated; validated email |

- Primary action label: **Submit** (non-persistence).
- Success: close dialog and show success feedback (`Toast` preferred when `ToastProvider` is present).
- Failure: destructive `Alert` with normalized error message.
- Authenticated users: hide name/email fields; identity from auth context / JWT on server.

### Visual specification

- **Form layout:** `DialogBody` uses `grid gap-4`. Each field uses `Label` wrapping its control (CR06). Subject and Message labels MUST appear above their controls; both controls are full width (`w-full` on `Input` / `Textarea`).
- **Diagnostics preview:** After all editable fields and before `DialogFooter`, render a `<section>` with heading **Information included with your request**, short explanatory copy, and a compact `<dl>` listing client-known values that will be emailed: name, email, app, page URL, user agent, and optional organisation / event / app / session ids when present. Each row shows label and value on one line (`grid-cols-[auto_1fr]`). Omit optional id rows when unset. End with a note that timestamp and network address are added when the message is sent. No typography utility classes on semantic text elements (Standard 07).

## Client diagnostics (untrusted hints)

Client MAY send: `page_url`, `user_agent`, `app_name` / `source_app`, `organisation_id`, `event_id`, `app_id`, `session_id`. Server MUST NOT trust client `name` / `email` when JWT is present. Server enriches from auth and request metadata (`x-forwarded-for` / `cf-connecting-ip` when available).

## Privacy dialog

- Scrollable `DialogBody`.
- Content source: `packages/core/content/privacy-policy.md` (generated to `privacy-policy.generated.ts` at build).
- Renderer supports `##` / `###` headings, paragraphs, and `-` list items only; outputs `h2`, `h3`, `p`, `ul`, `li`.

## Edge function: `app-support-request`

- Invoke via `functions.invoke` (same boundary as `record-login`).
- Accepts anonymous and authenticated callers.
- Sends to **`help@solvera.au`**; **Reply-To** = submitter email.
- Uses active Resend gateway config (`loadActiveGatewayConfig` / `sendResendAttempt`), not PUMP bulk composer or `sendSystemNotification`.
- From address: `APP_SUPPORT_FROM_EMAIL` env var (default documented in deploy notes).
- Returns `ApiResult<{ submitted: true }>`.
- Rate limits: anonymous — 3 requests / minute / IP; authenticated — 10 requests / minute / user id.

## Exports

From `@solvera/pace-core/components`: `SupportDialog`, `PrivacyPolicyDialog`, updated `PaceFooter`.

From `@solvera/pace-core/support`: `submitSupportRequest`, `APP_SUPPORT_REQUEST_FUNCTION_NAME`, `supportFormSchema`, `formatSupportDiagnosticsPreview`, `collectSupportDiagnostics`, types.

## Testing

- Integration tests: PaceFooter layout and dialog open; SupportDialog validation (anon vs auth); PrivacyPolicyDialog heading render.
- Unit tests: `submitSupportRequest` payload; `appSupportRequestService` validation and email assembly; `formatSupportDiagnosticsPreview`; markdown renderer.

## Do not

- Do not add consumer props to override footer links or modal content.
- Do not expose Resend API key to the client.
- Do not add a full markdown dependency for privacy rendering.

## References

- [CR05c – Layout and shell](./CR05c-layout-and-shell.md)
- [3-security-rbac-standards.md](../standards/3-security-rbac-standards.md)
- [4-api-tech-stack-standards.md](../standards/4-api-tech-stack-standards.md)
