# Services and providers

*Enrichment complete (reverse-engineering pass): API/Contract signatures, Behaviour MUSTs, Demo step-by-step, References with inline examples.*

## Overview

- **Purpose:** EventService, OrganisationService, InactivityService, session restoration (SessionRestorationLoader, useSessionRestoration) so the demo and apps can use service-based data and session handling where needed.
- **Scope:** Package + demo (optional for minimal demo; required for full parity).
- **Dependencies:** 02-foundation, 03-auth-and-context, 04-rbac (secure client). Uses existing DB; no schema creation.
- **Standards:** 02 Architecture (services as abstractions), 05 pace-core compliance, 04 API & tech stack.

## Candidate integration scope (TRAC2 pace-core2)

- Candidate 1 (event-scoped CRUD scaffold): this slice defines service/provider composition boundaries that consume CRUD scaffolding contracts from R16.
- Candidate 2 (attachment lifecycle primitives): service contracts may delegate attachment lifecycle orchestration to R16 while preserving service-level abstractions in this slice.
- Candidate 4 (derived event read-model helper): shared event hydration/selection precedence is defined in R17 and consumed by service hooks in this slice.
- Candidate 5 (composite resilience utilities): multi-source fallback patterns are defined in R18 and can be applied by service composition where appropriate.

## Acceptance criteria

- [x] EventService (IEventService interface, implementation); OrganisationService (IOrganisationService or equivalent); InactivityService.
- [x] Providers: EventServiceProvider, OrganisationServiceProvider, InactivityServiceProvider (or combined with auth where applicable).
- [x] Session restoration: SessionRestorationLoader component, useSessionRestoration hook (or equivalent).
- [x] Hooks: useEventService, useOrganisationService, useInactivityService, useSessionRestoration; useEvents, useOptionalEvents, useOrganisations if they wrap these services.
- [x] Public surface is interface-first: consumer entrypoints prioritise service interfaces/contracts and provider/hook consumption; low-level construction helpers are internal unless explicitly required by a consumer workflow.

## API / Contract

- **Exports:** From `packages/core/src/services/`, `src/providers/`, `src/hooks/` — service interfaces and implementations; providers; hooks. Contract only.
- **Export boundary:** direct implementation-class exports and factory-only composition helpers are optional and should be withheld from consumer entrypoints unless they are part of an explicit consumer contract.

### Concrete signatures and shapes

**IEventService / EventService:** getEvents(): Event[], getSelectedEvent(): Event | null, isLoading(): boolean, getError(): Error | null, setSelectedEvent(event), refreshEvents(): Promise<void>, loadPersistedEvent(events), restorePersistedEvent(), persistEventSelection(eventId), autoSelectNextEvent(events), initialize(), cleanup(). All data access via secure client; return types as ApiResult where applicable for async operations.

**IOrganisationService / OrganisationService:** getOrganisations(), getSelectedOrganisation(), getUserMemberships(), isLoading(), getError(), hasValidOrganisationContext(), isContextReady(), switchOrganisation(orgId), getUserRole(orgId?), validateOrganisationAccess(orgId), refreshOrganisations(), ensureOrganisationContext(), getPrimaryOrganisation(), isOrganisationSecure(), buildOrganisationHierarchy(orgs), initialize(), cleanup().

**InactivityService (IInactivityService):** start(), reset(), getRemainingMs? (or equivalent time remaining), subscribe? (or state exposed via provider); getShowInactivityWarning(), getInactivityTimeRemaining(), isIdle(), getTimeRemaining(), resetActivity(), startTracking(), stopTracking(), handleStaySignedIn(), handleSignOutNow().

**SessionRestorationLoader:** (component) shows loading until session is restored or times out; props: message?, className?. **useSessionRestoration():** extends SessionRestorationState (isRestoring, restorationError) with hasTimedOut, timeoutMs.

**Hooks:** useEventService(), useOrganisationService(), useInactivityService(), useSessionRestoration() — return service instance or state; useEvents(), useOptionalEvents() — return events, selectedEvent, setSelectedEvent, refreshEvents, isLoading, error (from EventService).

**EventServiceProvider props:** `autoSelectEvent?: boolean` (default `true`) — when `false`, EventService does not fall back to the first event in the list after refresh. `restorePersistedSelection?: boolean` (default `true`) — when `false`, persisted localStorage selection is not restored on init/refresh. Operator apps with an org-events landing that requires explicit first pick (e.g. GEAR) pass **`autoSelectEvent={false}` only**; leave `restorePersistedSelection` at default so a full page refresh restores the last user-selected event.

## Behaviour

- Services MUST use secure Supabase client (useSecureSupabase or equivalent) for all data access. SessionRestorationLoader MUST be used in app shell if session restoration is enabled (per UnifiedAuthProvider). Selected event (and optionally organisation) may carry palette data for dynamic theming; see R15-dynamic-theming.
- EventService selection state MUST be list-valid: `selectedEvent` may only resolve to an event present in the current fetched event list, otherwise it resolves to `null` (or deterministic list fallback when available). Stale persisted IDs must not become active selection during empty/transitional lists and must be reconciled once the list is available.
- For event RPC rows with both synthetic `id` and business `event_id`, service-layer identity MUST resolve from `event_id` for selection, persistence, and RBAC scope propagation.
- Service contracts in this slice are service-layer abstractions, not canonical derived event read models. Shared read-model hydration and precedence contracts are defined in `R17-derived-event-read-model-helper.md`. Event-scoped CRUD scaffolding contracts are defined in `R16-event-scoped-crud-scaffold.md`.
- SessionRestorationLoader and service-provider initialization are shell-level concerns. Same-layout internal route transitions MUST NOT remount shell providers or replay initial loader flow unless a true app bootstrap occurs.
- **EventServiceProvider bootstrap:** While mounted, `EventServiceProvider` MUST always publish a non-null context value. `useEvents()` and `useEventServiceContext()` MUST throw only when invoked outside `EventServiceProvider`, not during organisation or event-service bootstrap.
- While organisation context is loading (`OrganisationServiceProvider.isLoading === true`), event context MUST expose `isLoading: true`, `events: []`, `selectedEvent: null`, and `service: null`.
- When organisation context is settled with no selected organisation, event context MUST expose `isLoading: false`, `events: []`, `selectedEvent: null`, and `service: null`.
- When `EventService` is active, context `service` MUST be non-null and event list/selection state MUST mirror the service.

## Demo app requirements

- Demo wires at least one service provider (e.g. OrganisationServiceProvider already in 03; EventServiceProvider if events are used). SessionRestorationLoader in app shell if session restoration is in scope. InactivityServiceProvider with InactivityWarningModal from 08.
- **Step-by-step:** Demo wires OrganisationServiceProvider (and optionally EventServiceProvider). If session restoration is in scope, SessionRestorationLoader is in shell; on reload, user sees loader then either signed-in state or login. InactivityServiceProvider with InactivityWarningModal (from 08) triggers after idle.

## Verification

- **Service contracts:** Verify Event/Organisation/Inactivity services expose and honour the documented interfaces.
- **Provider wiring:** Verify corresponding providers and hooks are available and compose correctly in app wiring.
- **Session behaviour:** Verify session restoration loader and inactivity tracking behaviour function as documented when enabled.
- **Navigation continuity:** Verify same-layout internal navigation does not retrigger shell-level service initialization or restoration loader flashes.

## Testing requirements

- Unit tests for services (mocked client); integration tests for providers and session restoration behaviour. Coverage per Standard 08.

## Do not

- Do not create new tables or RPCs; use existing schema. Do not copy old implementation.

## References

- [2-architecture-standards.md](../../packages/core/docs/standards/2-architecture-standards.md), [4-api-tech-stack-standards.md](../../packages/core/docs/standards/4-api-tech-stack-standards.md). packages/core/docs/architecture/services.md (reference only).
- [R16-event-scoped-crud-scaffold.md](./R16-event-scoped-crud-scaffold.md), [R17-derived-event-read-model-helper.md](./R17-derived-event-read-model-helper.md)
- **Inline — service interface:** e.g. IEventService.getEvents(): Event[]; IOrganisationService.getOrganisations(): Organisation[]; services return in-memory state; async methods return Promise<void> or Promise<ApiResult<...>> as per implementation.

---

## Prompt to use with Cursor

Implement the feature described in this document. Follow the standards and guardrails provided. Add or update tests and demo as specified. Run validate and fix any issues until it passes.
