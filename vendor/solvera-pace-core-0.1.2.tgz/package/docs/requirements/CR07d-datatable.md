# CR07d – DataTable: Row expansion and export-only columns

*CR07d of 4. Builds on [CR07a-datatable.md](./CR07a-datatable.md), [CR07b-datatable.md](./CR07b-datatable.md), and [CR07c-datatable.md](./CR07c-datatable.md). Adds full-width expandable detail rows and export-only column definitions. No breaking changes.*

## Overview

- **Purpose:** Allow consuming apps to show compact data rows with optional full-width detail panels below (e.g. catalogue event plan fields) without widening the table or duplicating rows in `data`.
- **Scope:** `rowExpansion` config, `exportOnly` column flag, controller/body/toolbar updates, tests and demo.
- **Dependencies:** CR07a, CR07b, CR07c.
- **Standards:** 05 pace-core compliance, 07 Visual.

## In scope for this slice

### E1 — `rowExpansion` (full-width detail row)

- **Type:** `rowExpansion?: RowExpansionConfig<TData>` on `DataTableProps`.

```ts
export interface RowExpansionConfig<TData> {
  enabled: boolean;
  renderExpandedRow: (row: TData) => ReactNode;
  canExpand?: (row: TData) => boolean;
  defaultExpanded?: boolean | string[];
  onExpandedChange?: (expandedIds: string[]) => void;
  /** When provided with `onExpandedRowIdsChange`, expansion is controlled by the parent (e.g. row actions outside the expand column). */
  expandedRowIds?: string[];
  onExpandedRowIdsChange?: (expandedIds: string[]) => void;
  expandedRowClassName?: string;
  /** When `false`, omit the dedicated expand column; expansion still works via controlled `expandedRowIds` or toolbar expand-all. Default `true`. */
  showExpandColumn?: boolean;
}
```

- **Behaviour:**
  - When `enabled` and `showExpandColumn !== false`, DataTable renders a dedicated expand column (`+` / `−` button) per data row.
  - When a row is expanded and `canExpand(row) !== false`, a **detail row** renders immediately below the data row: one `<TableCell colSpan={totalCols}>` containing `renderExpandedRow(row)`.
  - Detail rows are **render-only** — never appended to `data`, `displayData`, export, import payloads, pagination counts, or selection.
  - Detail rows: no checkbox, no row actions, no `onRowActivate`.
  - Reuses `expanded` state from `useDataTableState` (same as hierarchical).
  - Toolbar **Expand all** / **Collapse all** when `rowExpansion.enabled` (same controls as hierarchical).
  - `defaultExpanded` and `onExpandedChange` behave like `HierarchicalConfig`.
  - **Controlled expansion:** when `expandedRowIds` and `onExpandedRowIdsChange` are both set, the expand column (when shown), expand-all, and collapse-all sync to that state so consuming apps can toggle rows from row actions (e.g. catalogue **View event sourcing** with `showExpandColumn: false`).

- **Mutual exclusion (v1):** `rowExpansion.enabled` and `hierarchical.enabled` MUST NOT both be true. Implementation throws in development/tests when both are set.

### E2 — `column.exportOnly`

- **Type:** `exportOnly?: boolean` on `DataTableColumn` (default `false`).
- **Behaviour:** When `true`, column participates in **export** and **import mapping** but is excluded from table header, body, filter row, and column visibility/reorder menu.
- **Value resolution:** `accessorFn` / `accessorKey` still used for export and import as today.

### E3 — `column.exportable`

- **Type:** `exportable?: boolean` on `DataTableColumn` (default `true`).
- **Behaviour:** When `false`, column renders in the grid but is **omitted from CSV export**. Import mapping unchanged unless the column is also `exportOnly`.
- **Use case:** Formatted display columns (e.g. stacked **Price** in the grid) paired with raw `exportOnly` fields for import round-trip.

## Out of scope

- Replacing hierarchical parent/child rows (orthogonal feature).
- Server-side row expansion (detail content is client-rendered only).
- Virtual scrolling.

## Acceptance criteria

- [ ] `rowExpansion` renders expand column and full-width detail row with correct `colSpan`.
- [ ] Expanding rows does not change pagination count or export row count.
- [ ] Selection and select-all ignore detail rows.
- [ ] `canExpand` hides expand control when false.
- [ ] `onRowActivate` does not fire from detail row clicks.
- [ ] Expand-all / collapse-all works with `rowExpansion`.
- [ ] `rowExpansion` and `hierarchical` cannot both be enabled.
- [ ] `exportOnly` columns export/import but do not render in the grid.
- [ ] `exportable: false` columns render in the grid but are omitted from CSV export.
- [ ] Unit and integration tests cover each addition.
- [ ] `npm run validate` passes.

## Guardrails

- Do not break CR07a–CR07c behaviour.
- Requirements-first: this document precedes implementation.

## Related

- [CR07a-datatable.md](./CR07a-datatable.md), [CR07b-datatable.md](./CR07b-datatable.md), [CR07c-datatable.md](./CR07c-datatable.md)
