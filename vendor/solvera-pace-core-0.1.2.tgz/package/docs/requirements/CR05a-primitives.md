# CR05a – Primitives

*Slice 1 of 3: base UI components and table primitives. Implement before 05b (Dialog, Select, Tabs) and 05c (Layout and shell).*

## Overview

- **Purpose:** Base UI components and table primitives so the demo and later slices can build screens consistently. No Dialog, Select, Tabs, or app layout in this slice.
- **Scope:** Package + demo (single showcase page with primitives only).
- **Dependencies:** 02-foundation-types-utils-styles. Optional: 04-rbac if any component needs permission hints.
- **Standards:** 05 pace-core compliance, 06 Code quality, 07 Visual, 02 Architecture.

## Acceptance criteria

- [x] Button; Card (CardHeader, CardTitle, CardDescription, CardContent, CardFooter); Input, InputGroup; Label; Textarea; Alert, AlertTitle, AlertDescription; Avatar; Badge; DateBadge; Checkbox; Switch; Progress.
- [x] **Progress variants:** `Progress` supports `variant?: 'bar' | 'ring'` (default `'bar'`). Ring variant shows circular indicator with centred numeric label (0–100); same `role="progressbar"` / `aria-valuenow` contract as bar.
- [x] Table primitives: Table, TableHeader, TableBody, TableCaption, TableCell, TableFooter, TableHead, TableRow.
- [x] All use design tokens (main/sec/acc); semantic HTML where applicable; no inline styles; exports from package components barrel.
- [x] Demo has a styles/showcase page (or equivalent) that renders Button variants, Card, Input, Label, Textarea, Alert, and a simple Table.
- [x] **Card `link` prop:** optional `link?: string | null` (default `null`); when set, whole-card navigation via `onClick` on `<article>`, hover elevation affordance, keyboard `role="link"`; internal routes use React Router when available; tests cover navigation and decorative descendant behaviour.

## API / Contract

- **Exports:** From `packages/core/src/components/` — Button; Card and subcomponents; Input, InputGroup; Label; Textarea; Alert, AlertTitle, AlertDescription; Avatar; Badge; DateBadge; Checkbox; Switch; Progress; Table, TableHeader, TableBody, TableRow, TableHead, TableCell, TableCaption, TableFooter. Public props and composition as per package barrel.

### Minimal prop contracts

**Button:** variant?, size?, **block?** (default `false`), disabled?, onClick?, children, **aria-label?** (required when size is `icon`). Variant-only primitive — **no `className` prop**; use variants/sizes/`block` or a layout wrapper at the call site. Variant: **default**, outline, destructive, secondary, ghost, link. Size: **icon**, small, medium (default), large. When `block` is `true`, the button spans the full width of its container (`w-full`, `m-0`) and lays out non-icon children in `grid-cols-[1fr_auto]` (label + trailing content). **Badge:** `variant?: BadgeVariant`, `children`; variant-only primitive — **no `className` prop**. `BadgeVariant` is a flat 27-variant union using `{style}-{tone}-{shade}` names where style = `solid | outline | soft`, tone = `main | sec | acc`, shade = `muted | normal | strong`. Default variant is `solid-main-muted`. **DateBadge:** `m: string`, `d: string`; display-only month/day element — **no `className` prop**; positioning is applied by parent layouts (for example absolute overlay in EventCard header). **Card:** CardHeader, CardTitle, CardDescription, CardContent, CardFooter (composition); `fill?: boolean` (default `false`); `layer?: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9` (default `0`; layers 3–9 reserved — runtime error if used); `link?: string | null` (default `null` — URL with optional query string; when non-null, whole-card navigation). `className` remains allowed on `Card` for layout overrides at call sites (unlike Button). **Input:** value, onChange, type, disabled, placeholder (usage SHOULD provide helpful hint text for users). **Avatar:** `name: string` (required; used for `img` alt text and fallback initials source), `imgsrc?: string | null` (image source string), `className?: string`. **Progress:** `value?: number`, `max?: number` (default 100), `variant?: 'bar' | 'ring'` (default `'bar'`), `size?: 'small' | 'medium'` (ring only; default `'medium'`), `className?: string`. Bar uses native `<progress>`. Ring uses stacked border rings with Tailwind conic mask utilities (`mask-conic-from-{pct}%` / `mask-conic-to-{pct}%`) plus centred percentage label (no inline `style` prop). **Table:** Table, TableHeader, TableBody, TableRow, TableHead, TableCell, TableCaption, TableFooter (composition).

## Visual specification

Global tokens, size groups, and elevation: [7-visual-standards.md](../../../packages/core/docs/standards/7-visual-standards.md) Part C. **Class recipes for this slice:**

### Button (primitive)

- **Base (all variants):** Layout: `inline-grid`, `place-items-center`, `m-1`. Shared: `whitespace-nowrap`, `rounded-xl`, `focus-visible:outline-none`, `focus-visible:ring-1`, `focus-visible:ring-ring`, `disabled:pointer-events-none`, `disabled:opacity-50`, `print:shadow-none`. Typography inherits from context (no fixed `text-sm` unless an exception is documented in this doc). **Medium row-control radius:** Button, Input, and Textarea default radius use `rounded-xl` (documented exception from medium size group `rounded-md`).
- **Sizes:** `icon` | `small` | `medium` (default) | `large` — use these **words** in APIs, not `sm`/`md`/`lg`. Heights: **small** `h-8`, **medium** `h-9`, **large** `h-10`; **icon** `size-8`. Padding: small `px-3`, medium `px-4`, large `px-8`. All sizes: `rounded-xl`.
- **Block layout:** `block?: boolean` (default `false`). When `true`: width `w-full`, margin `m-0`, and for non-icon sizes `grid-cols-[1fr_auto] items-center justify-items-stretch text-left` so label + trailing content (e.g. Badge count) align in filter sidebars ([CR31](./CR31-filter-sidebar.md)).
- **Variants:** **default** — `bg-main-800 text-main-50 shadow hover:bg-acc-400`. **destructive** — `bg-acc-600 text-acc-50 shadow-sm hover:bg-acc-400`. **outline** — `border border-main-300 bg-background shadow-sm hover:bg-acc-400`. **secondary** — `bg-sec-100 text-sec-900 shadow-sm hover:bg-acc-400`. **ghost** — `hover:bg-acc-400`. **link** — `text-main-700 underline-offset-4 hover:underline drop-shadow-lg drop-shadow-transparent hover:drop-shadow-acc-400`.
- **Accessibility:** `aria-label` required when `size="icon"`.

### Card (primitive)

- **Layout:** Card and subcomponents use **grid** or normal flow only; **no flex**.
- **Structure:** `Card` (`article`): `CardHeader` (`header`), `CardTitle`, `CardDescription`, `CardContent`, `CardFooter` (`footer`). Actions live in `CardFooter` (no separate CardActions).
- **CardTitle:** Always `<h3>`; no `as` prop.
- **CardContent:** Renders as `<section>` (header/footer semantics).
- **Card slot layout classes:** When a Card slot (`CardHeader`, `CardContent`, `CardFooter`) is the intended layout container, apply layout classes directly to that slot.
- **No single-child layout wrappers in Card slots:** Do not add a single wrapper element (`section`/`div`/`article`/`main`/`header`/`footer`) inside a Card slot only to carry layout classes. Move those classes to the Card slot itself.
- **Card persistence actions:** In persistence/edit flows, `CardFooter` is the canonical action host. The primary submit action label is exactly `Save` and renders in the footer's bottom-right action area.
- **Card persistence action order:** For save flows, order actions right-to-left as `Save`, `Cancel`, then alternate actions.
- **Card action label exceptions:** Use intent-specific primary labels for non-persistence actions (for example `Delete`, `Approve`, `Publish`, `Send`) instead of forcing `Save`.
- **Borders:** Only the parent **Card** carries hover elevation affordance when `link` is set. **CardHeader** and **CardFooter** MUST NOT use `border-b` / `border-t`.
- **`link` prop (optional navigation):** `link?: string | null` (default `null`). When non-null and non-empty:
  - Root remains `<article>` (not `<a>` / `Link` wrapper).
  - `onClick` navigates to `link`. **Internal** URLs (no URL scheme such as `http:`, `https:`, `mailto:`, `tel:`) use React Router `navigate(link)` when `useInRouterContext()`; otherwise `window.location.assign(link)` as fallback. **External** URLs (has scheme) open via `window.open(link, '_blank', 'noopener,noreferrer')` per [5-pace-core-compliance-standards.md](../../../packages/core/docs/standards/5-pace-core-compliance-standards.md) § Internal Route And Link Navigation.
  - Keyboard: `role="link"`, `tabIndex={0}`, Enter/Space triggers navigation; `focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring`.
  - `cursor-pointer` when linked.
  - Descendant `a`, `button`, and `[role="button"]` are **decorative** when `link` is set — root applies `[&_a]:pointer-events-none [&_button]:pointer-events-none [&_[role=button]]:pointer-events-none` (no per-child runtime logic).
  - **Constraint:** do not rely on nested footer buttons or inline links when `link` is set; they will not receive clicks.
  - **Limitation:** no native middle-click / “open in new tab” for the card surface (trade-off of `article` + `onClick` vs anchor).
- **Layer prop:** `layer` controls root surface, border, and radius only; slot padding and structure are unchanged across layers. Default `layer={0}`.
- **Panel surface token:** Layer 0 uses explicit `bg-main-100 text-main-950`. Layers 1+ use explicit `bg-*` / `text-main-950` per layer recipe below.
- **Slot surface inheritance:** `CardHeader`, `CardContent`, and `CardFooter` MUST NOT set `bg-*` utilities by default. Surface colour is owned by parent `Card` only.
- **Slot class recipes:** `CardHeader` — `grid gap-1 p-4`; `CardContent` — `p-4`; `CardFooter` — `p-4`.
- **Dialog parity:** Same rule as Dialog internal slots — padding/layout on the slot; no slot-level background.
- **Base root classes (all layers):** `overflow-hidden text-main-950` plus layer surface recipe (below). No hover elevation on static (non-linked) cards.
- **Linked root classes (`link` set):** add `cursor-pointer hover:border-border hover:shadow-lg transition-[box-shadow,border-color] focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring [&_a]:pointer-events-none [&_button]:pointer-events-none [&_[role=button]]:pointer-events-none`.
- **Layer 0 (default):** Large size group radius (`rounded-2xl`); resting `border border-main-300`, no shadow; root recipe `overflow-hidden rounded-2xl border border-main-300 bg-main-100 text-main-950`.
- **Layer 1:** `rounded-xl`; `bg-main-50`; resting `border border-transparent` (no visible border); root recipe `overflow-hidden rounded-xl border border-transparent bg-main-50 text-main-950`.
- **Layer 2:** `rounded-lg`; `bg-sec-100`; resting `border border-main-300`; root recipe `overflow-hidden rounded-lg border border-main-300 bg-sec-100 text-main-950`.
- **Layers 3–9:** Reserved for future nested surfaces (stepped radius / alternating palettes). Using layers 3–9 MUST throw at runtime until specified in this document.

#### Directory card grid (Card `fill`)

- **Container:** Multi-column browse, launcher, and KPI directory grids use `<section className="grid …">`. Do not use `<ul>` or `<ol>` as the grid container (row lists such as attention queues may still use `ul` with explicit `ps-0`).
- **`fill` prop:** `fill?: boolean` (default `false`). When `true`, the Card root MUST apply `h-full w-full grid` and a row template so tiles in the same grid row share equal height:
  - `grid-rows-[auto_1fr]` when only header and body slots are present (no `CardFooter` among direct children).
  - `grid-rows-[auto_1fr_auto]` when `CardFooter` is present among direct children.
- **`CardContent` in fill mode:** The content slot participates in the `1fr` row (`min-h-0` on the slot).
- **Navigational cards:** Prefer [CR05a-directory-card-grid](./CR05a-directory-card-grid.md) (`CardGrid` + `CardGridItem`), or wrap `<Card fill>` in a link with `className="contents no-underline"` so the card surface is the effective grid participant.
- **Parity:** [CR29 EventTile](./CR29-event-tile.md) uses the same directory-grid height contract for event-specific presentation.

**AttentionItem (CR30):** Reuses layer-0 border/radius on `<li>` without row fill; tone `<h2>` carries tone `bg-*-200`. Composes `CardHeader` / `CardContent` / `CardFooter` slot components on an `<li>` root in a horizontal slot grid (`grid-cols-[auto_1fr_auto]`). Does not wrap the `Card` primitive; linked-row affordance uses the same `cardLinkedClasses` recipe as Card.

### Other primitives (this slice)

Input, Label, Textarea, Alert, Avatar, Badge, Checkbox, Switch, Progress, Table family: **design tokens only**; align to [7-visual-standards.md](../../../packages/core/docs/standards/7-visual-standards.md) Part C — global size groups and elevation. Document any new stable class lists in **this Visual specification** until a narrower requirement owns them.

### Progress (primitive)

- **Bar variant (default):** `h-2 w-full overflow-hidden rounded-full bg-sec-200`; native `<progress>` element.
- **Ring variant layout:** Root `inline-grid grid-cols-1 grid-rows-1 place-items-center`. Track ring, fill ring, and label each use `col-start-1 row-start-1` (shared grid cell; source-order stacking; no `z-index`, no absolute positioning).
- **Ring variant sizes:** **medium** — `size-11` (44px); **small** — `size-8` (32px).
- **Ring track:** `size-full rounded-full border-4 border-sec-200`, `aria-hidden="true"`.
- **Ring fill:** `size-full rounded-full border-4 border-main-600`, plus `mask-conic-from-{pct}% mask-conic-to-{pct}%` (Tailwind [conic mask dial pattern](https://tailwindcss.com/docs/mask-image#adding-a-conic-mask)); `aria-hidden="true"`. Mask classes MUST be literal utilities (0–100 lookup) — no inline `style` prop.
- **Ring label:** Plain centred text in shared cell; `aria-hidden` on label (value exposed via `aria-valuenow` on root). No typography utility classes on label.
- **Accessibility:** Both variants expose `role="progressbar"`, `aria-valuemin={0}`. **Bar variant:** `aria-valuenow` and `aria-valuemax` use the raw `value` and `max` props. **Ring variant:** `aria-valuenow` and `aria-valuemax` are normalized to a 0–100 percentage scale (rounded from `value / max`); the centred label shows the same percentage.

**AlertTitle exception:** `AlertTitle` applies variant tone classes on the `<h3>` (`text-main-600` / `text-acc-600`) so alert severity is visible when the title is read in isolation. This is an approved exception to the global “no typography/color utilities on semantic headings” rule for this slice only.

### Badge (primitive)

- **Variant system:** Badge exposes 27 flat variants: `solid-main-muted`, `solid-main-normal`, `solid-main-strong`, `solid-sec-muted`, `solid-sec-normal`, `solid-sec-strong`, `solid-acc-muted`, `solid-acc-normal`, `solid-acc-strong`, `outline-main-muted`, `outline-main-normal`, `outline-main-strong`, `outline-sec-muted`, `outline-sec-normal`, `outline-sec-strong`, `outline-acc-muted`, `outline-acc-normal`, `outline-acc-strong`, `soft-main-muted`, `soft-main-normal`, `soft-main-strong`, `soft-sec-muted`, `soft-sec-normal`, `soft-sec-strong`, `soft-acc-muted`, `soft-acc-normal`, `soft-acc-strong`.
- **Base class strategy:** Variant classes are resolved in component logic via explicit class maps (no data-attribute variant styling hooks).
- **Root layout:** Badge is inline text-level content and should render without grid layout helpers (no `inline-grid` / `place-items-center` requirement). Root uses `inline-block w-fit max-w-full` so badges shrink-wrap their label in table cells and toolbars (no full-width stretch).
- **Solid mapping:** Uses filled token surfaces and tone-aligned text. Tone+shade mappings:
  - Shared spacing: `px-3 py-1 mr-1`
  - `*-muted`: `bg-[tone]-200 text-[tone]-600`
  - `*-normal`: `bg-[tone]-500 text-[tone]-50`
  - `*-strong`: `bg-[tone]-700 text-[tone]-50`
- **Outline mapping:** Uses outline token + lighter surface + stronger text. Tone+shade mappings:
  - Shared spacing: `px-3 py-1 mr-1`
  - `*-muted`: `outline-[tone]-400 bg-[tone]-100 text-[tone]-600`
  - `*-normal`: `outline-[tone]-700 bg-[tone]-200 text-[tone]-700`
  - `*-strong`: `outline-[tone]-800 bg-[tone]-400 text-[tone]-900`
- **Soft mapping:** Uses compact soft style plus token-based shadow color utilities:
  - Shared spacing and shadow room: `px-2 py-0 ml-1 mr-2 my-1`
  - `*-muted`: `bg-[tone]-200 text-[tone]-600 shadow-badge-soft shadow-[tone]-200`
  - `*-normal`: `bg-[tone]-500 text-[tone]-50 shadow-badge-soft shadow-[tone]-500`
  - `*-strong`: `bg-[tone]-700 text-[tone]-50 shadow-badge-soft shadow-[tone]-700`
- **Soft shadow utility constraint:** Do not introduce new custom badge shadow utility classes in `core.css`. Only existing `shadow-badge-soft` and `shadow-badge-soft-xl` are permitted for Badge soft variants.
- **Soft shadow merge contract:** `cn()` in `packages/core/src/utils/cn.ts` must preserve coexisting `shadow-badge-soft` + `shadow-[tone]-*` classes via a dedicated tailwind-merge `badge-shadow` class group (separate from the default `shadow` group).
- **Horizontal badge spacing rule:** Use `mr-1` as the default inter-badge horizontal spacing to keep a single spacing unit between sequential badges. Do not use `mx-1` as the component default because adjacent badge margins would stack and visually double the intended inter-badge gap.
- **Rendered-class hygiene:** Each Badge variant MUST emit a single spacing model in final rendered markup. Do not emit duplicate/conflicting padding or margin utilities for one badge instance.

### DateBadge (primitive)

- **Purpose:** Display-only compact month/day date widget for tiles, lists, and other layouts.
- **Props:** `m: string` (month abbrev), `d: string` (day numeral); **no `className` prop** — parents own positioning and surrounding layout.
- **Root:** `<span>` with `grid min-w-12 place-items-center rounded-md border border-main-200 bg-main-50 px-2.5 py-1.5 text-center shadow-sm`.
- **Month line (`m`):** `text-[10px] font-semibold uppercase tracking-widest text-main-800` (approved small-size typography exception).
- **Day line (`d`):** `text-xl font-semibold leading-none tracking-tight text-main-900` (approved small-size typography exception).
- **Accessibility:** Display-only; not interactive. Parent layouts SHOULD expose the full date in visible copy or accessible name when `DateBadge` is decorative context only.

### Other primitive notes (this slice)

- **Alert semantic element:** `Alert` renders as `<aside>` (not `<section>`), with role defaulting to `alert`.
- **Alert variants:** Alert surfaces use shade-100 backgrounds and palette-aligned border/title colours:
  - `default`: `bg-main-100`, border `border-main-600`, title `text-main-600`.
  - `destructive`: `bg-acc-100`, border `border-acc-600`, title `text-acc-600`.
- **Alert radius:** Alert uses Large size group radius (`rounded-2xl`).
- **Alert variant implementation:** Do not use `group-data-[variant=...]` classes or `data-variant` attributes to drive variant styling; resolve variant classes in component logic instead.
- **Input width default:** Input defaults to `w-full` and keeps a `className` prop for explicit instance-level width overrides.
- **Input size parity:** Input default control height is `h-9` (medium) to match Button medium size for side-by-side control alignment.
- **Input margin parity:** Input default outer margin is `m-1` to match Button spacing when controls are placed side-by-side in shared toolbars and caption action rows.
- **Input border/surface parity:** Input default border and surface in medium controls use `border-main-300`, `bg-background`, and `shadow-sm` so side-by-side rows match Button outline treatment.
- **Input radius:** Input default radius uses `rounded-xl` (matches Button medium).
- **Input placeholder guidance:** Input usage should provide concise, context-specific placeholder hints (for example `Enter email address`), while labels remain the primary field descriptor.
- **Textarea border token:** Textarea default border color uses semantic `border-border` (mapped from `--color-border`).
- **Textarea radius:** Textarea default radius uses `rounded-xl` (matches Button medium).

### Table (primitive)

- **`layer` prop:** `layer?: 0 | 1 | 2` (default `0`; layers 3–9 reserved — runtime error if used) — same semantics as Card.
- **Root `<table>` frame (per layer):** static Card-aligned frame (no hover elevation); uses **`border-separate border-spacing-0`**, not `border-collapse`:
  - **With `<caption>` and/or `<tfoot>`:** table carries **no outer border** (`border-separate border-spacing-0 w-full text-main-950` only); outer frame is decentralized to caption and edge/corner cells (below).
  - **Without caption, no `<tfoot>`:** layer 0 `rounded-2xl border border-main-300 overflow-hidden`; layer 1 `rounded-xl border border-transparent overflow-hidden`; layer 2 `rounded-lg border border-main-300 overflow-hidden`.
- **Decentralized outer frame (when caption and/or tfoot present):**
  - **Top:** `<caption>` when present — full top border box and `rounded-t-*` (see caption default below); when caption is absent, first `<thead>` row corner cells own top outer border and `rounded-t-*`.
  - **Sides:** **`border-l` on first column cell**, **`border-r` on last column cell** of every row in thead/tbody/tfoot (including filter rows, aggregate rows, and colspan rows).
  - **Bottom:** last `<tfoot>` row corner cell(s) when `<tfoot>` present; else last `<tbody>` row corner cell(s). Bottom corner radius MUST be on those cells (not on `<tfoot>` alone) so backgrounds curve under `border-separate`.
  - **Horizontal dividers:** cell-level `border-b border-main-300` on `TableHead` / `TableCell`; omit `border-b` on last footer row cells where the bottom outer frame owns that seam.
- **Corner radius ownership:** top corners on `<caption>` when present, else on first `<thead>` row corner cells; bottom corners on last `<tfoot>` row corner cells when present, else on last `<tbody>` row corner cells. When caption is present, `thead` MUST NOT have top radius or a redundant section divider (caption `border-b` is the sole caption→thead seam).
- **Colspan footer row:** when the last `<tfoot>` row is a single spanning cell (e.g. DataTable pagination), that cell owns `border-l`, `border-r`, `border-b`, and `rounded-b-*`.
- **`<tfoot>` / `<thead>` sections (decentralized frame):** band backgrounds live on **`th`/`td`** in thead/tfoot so corner radius and background paint on the same cell; section wrappers keep structure only (no band bg on `<thead>`/`<tfoot>`).
- **`<tbody>` section (decentralized frame):** carries `resolveLayerBodyClasses(layer)` (`bg-main-100` at layer 0) on the `<tbody>` element; body **side borders** remain on first/last column **`td`** cells per row.
- **Header/footer band:** `TableHead` cells in `<thead>` and `TableCell`/`TableHead` cells in `<tfoot>` use one shade darker than the tbody section for the active layer:
  - Layer 0 body `bg-main-100` → thead/tfoot **cells** `bg-main-200`
  - Layer 1 body `bg-main-50` → thead/tfoot **cells** `bg-main-100`
  - Layer 2 body `bg-sec-100` → thead/tfoot **cells** `bg-sec-200`
- **Border grid:** no vertical borders between interior cells; horizontal dividers on **`th`/`td`** (`border-b border-main-300`), not on `<tr>`; layer border token `border-main-300` for layers 0/2, transparent for layer 1.
- **Cell padding:** `TableHead` / `TableCell` retain `px-4 py-2` and horizontal row separator `border-b border-main-300`.
- **Row separators:** horizontal `border-b border-main-300` on each `TableHead` / `TableCell`; last footer row cells omit redundant `border-b` where bottom outer frame owns that seam; `TableFooter` MUST NOT add a redundant top border when the last body row already has `border-b`.
- **Caption default:** `TableCaption` uses `px-4 py-2`, `resolveLayerBodyClasses(layer)`, full top frame (`border-t border-l border-r border-b border-main-300`, layer-aware), top corner radius (`rounded-t-*` per layer) — same background as `<tbody>`, not thead/tfoot band shading. DataTable must not zero out horizontal caption padding.

- **Label/form structure:** Prefer nested control association (`<Label>Text<Input ... /></Label>`) over separate sibling label/control pairs.
- **Button width default:** Button primitives size to content by default (no implicit `w-full`).

### Avatar (primitive)

- **Purpose:** Avatar displays a visual representation of an entity (person, event, product, and similar entities).
- **Rendering contract:** Avatar renders a single `<figure>` root that is the consistent circular container (`size-10` default), with optional `className` override support (for example `size-8`).
- **Layered structure:** Avatar always renders a `<figcaption>` with computed initials in front of the figure background. The image layer is rendered above the caption only when a valid image is available.
- **Image handling:** If `imgsrc` is missing, null, or fails to load, the image layer is not shown and the always-present `figcaption` initials are visible.
- **Error handling:** Use image `onError` handling to treat broken image URLs the same as missing images.
- **Name accessibility/metadata:** The full `name` must remain available in the DOM for accessibility and metadata/hover behavior; when image is shown, `img alt={name}` is required.
- **Fallback initials method:**
  - `name` with 1 to 3 words: use the first letter from each word, uppercased.
  - `name` with more than 3 words: ignore words that are not capitalised.
  - If more than 3 capitalised words remain: use initials from the first capitalised word and the last two capitalised words.
  - Examples: `John -> J`, `John Smith -> JS`, `John Smith Williams -> JSW`, `Hector Marίa GONZALEZ LÓPEZ -> HGL`, `Hector de la cross LÓPEZ -> HL`, `Heinz Big Red Tomato Sauce -> HTS`.
- **Styling contract:** Avatar uses circular treatment (`rounded-full`), default `bg-secondary`, default `text-background`, and accepts `className` for instance-specific extension or overrides.

## Behaviour

- All components MUST use design tokens (main/sec/acc) only; MUST use semantic HTML where applicable; MUST NOT use inline styles. Exports MUST be from package components barrel. Button and Card MUST match **this Visual specification** and Part C.
- Badge MUST implement the 27-variant taxonomy and class mappings defined in this Visual specification.
- DateBadge MUST match the month/day visual recipe in this document and remain display-only (no interactive semantics).

## Demo app requirements

- **Step-by-step:** User opens Styles Showcase (or equivalent) → sees Button variants (default, outline, destructive, etc.) → sees Card with header/title/content → sees Input and Label → sees Alert → sees a simple Table with header and rows. Page may be minimal (no app shell yet; route only).

## Verification

- **Component surface:** Verify all listed primitive components and table primitives are exported from the package barrel.
- **Visual contract:** Verify Button and Card match this document’s class/semantic recipe and Standard 07 token usage.
- **Badge contract:** Verify Badge supports the full 27-variant union and that soft variants use only `shadow-badge-soft` or `shadow-badge-soft-xl` plus tone shadow utilities (no new custom badge shadow utility classes).
- **Avatar contract:** Verify Avatar uses `name` and `imgsrc` props, renders `<figure><img /><figcaption /></figure>`, and applies fallback initials using the specified algorithm.
- **Showcase check:** Verify demo showcase renders the required primitive examples without relying on components from later slices.

## Testing requirements

- Unit or integration tests for Button, Card, Input, Alert, Avatar; accessibility and keyboard behaviour where applicable. Coverage per Standard 08.
- Card tests should cover static cards (no hover elevation classes), linked cards (`role="link"`, hover classes), internal navigation (React Router), external navigation (`window.open`), decorative descendant interactives, and keyboard Enter navigation.
- Avatar tests should include prop contract checks (`name`, `imgsrc`), markup checks (`figure`, `img`, `figcaption`), and initials examples listed in this requirement.
- DateBadge tests should cover month/day rendering and display-only non-interactive markup.

## Do not

- Do not add Dialog, Select, Tabs, Header, Footer, PaceAppLayout, ErrorBoundary, or LoadingSpinner in this slice (those are 05b and 05c). Do not add Form, DataTable, Toast, or file upload. Do not copy old implementation; implement from this spec.

## References

- [7-visual-standards.md](../../../packages/core/docs/standards/7-visual-standards.md), [5-pace-core-compliance-standards.md](../../../packages/core/docs/standards/5-pace-core-compliance-standards.md), [2-architecture-standards.md](../../../packages/core/docs/standards/2-architecture-standards.md).

---

## Prompt to use with Cursor

Implement the feature described in this document. Follow the standards and guardrails provided. Add or update tests and demo as specified. Run validate and fix any issues until it passes.