# CR29 – Event card

*Reusable event card for dashboard grids, events directories, and operator pickers.*

## Overview

- **Purpose:** Single-sourced event card presentation used across portal, base, team, and trac.
- **Scope:** Package export + demo example.
- **Dependencies:** [CR05a-primitives.md](./CR05a-primitives.md) (Card, CardHeader, CardContent, CardFooter, DateBadge); [CR17-derived-event-read-model-helper.md](./CR17-derived-event-read-model-helper.md) (`normalizeEventCardFields`).
- **Standards:** 05 pace-core compliance, 07 Visual, [1-project-structure — pace-core UI component names](../standards/1-project-structure-standards.md#pace-core-ui-component-names).

## Acceptance criteria

- [x] `EventCard` exported from `@solvera/pace-core/components`.
- [x] Structured API: `event: EventCardFields` (core_events display fields), plus media/link props and optional app footer slot.
- [x] **Card composition:** `EventCard` renders as a styled `Card` instance with fixed slot layout (not a separate polymorphic root).
- [x] `link` prop inherits Card navigation and hover affordance per CR05a.
- [x] Header `DateBadge` derived internally from `event.event_date`.
- [x] Body markup (event name, date, location only) owned by pace-core — apps do not pass `meta` slots.
- [x] Footer is an optional app-owned slot — pace-core renders `CardFooter` only when `footer` ReactNode is provided; no built-in footer content.
- [x] Presentation-only — no event data fetching.
- [x] Demo or UI showcase renders EventCard with live event data (four latest by event_date), resolved logos when available, and empty/loading states.

## API / Contract

**Export:** `packages/core/src/components/advanced-ui/EventCard.tsx`

**Also exported:** `EventCardFields`, `EventCardProps` from `@solvera/pace-core/components`; `normalizeEventCardFields` from `@solvera/pace-core/events`; `formatEventCardMetaDate`, `toEventDateBadgeProps`, `toEventDateIso`, `deriveEventInitials` from `@solvera/pace-core/utils`.

### EventCardFields

Canonical display fields from `core_events` (normalised by `normalizeEventCardFields`):

- `event_name: string`
- `event_date: string | null`
- `event_venue: string | null` — event location
- `event_code: string | null` — used for default header glyph initials only; not shown in body

`normalizeEventCardFields(input)` accepts RPC rows, `EventStub`, or `EventReadModel` shapes and reads DB aliases (`event_name` / `name`, `event_date` / `date`, `event_venue` / `venue`, `event_code` / `code`).

### EventCard props

- `event: EventCardFields` — required; drives title, body lines, header date badge, and default glyph initials
- `link?: string | null` (default `null`) — passed to `Card`; whole-card navigation per [CR05a Card `link`](./CR05a-primitives.md)
- `image?: string` — resolved logo/image URL for cover (takes precedence over `fileReference`)
- `fileReference?: FileReference | null` — optional; when set and `image` absent, header uses `FileDisplay` `variant="inline"` as cover
- `supabase?: SupabaseClientLike | null` — for `FileDisplay` URL resolution when using `fileReference`
- `bucket?: string` — storage bucket override for `FileDisplay`
- `imageGlyph?: ReactNode` — optional override for fallback glyph when no cover image
- `imageTag?: ReactNode` — corner tag (e.g. Badge)
- `footer?: ReactNode` — optional app-owned footer content; pace-core renders unstyled `CardFooter` wrapper only
- `className?: string` — on `Card` root

### Card body markup (fixed inside EventCard)

Always renders exactly three body lines — event name, date, location — and nothing else:

```tsx
<CardContent>
  <h6>{event_name}</h6>
  <p className="bullet-calendar text-sec-800">
    {event_date ? <time dateTime={iso}>21 Jun 2026</time> : '—'}
  </p>
  <p className="bullet-map-pin text-sec-800">{event_venue ?? '—'}</p>
</CardContent>
```

- Body date: `formatEventCardMetaDate` — en-GB `d MMM yyyy` (e.g. `21 Jun 2026`) via pace-core utils; wrapped in `<time dateTime={iso}>` when parseable; em-dash `—` when missing
- Body location: `event_venue`; em-dash `—` when null
- Header date badge: `toEventDateBadgeProps(event.event_date)` → `DateBadge`
- **`expected_participants` and other core_events fields are out of scope** for EventCard body

### Card footer slot

When `footer` is provided:

```tsx
<CardFooter>{footer}</CardFooter>
```

Consuming apps own all footer markup (status, CTAs, badges, etc.). pace-core does not interpret footer props or render application/operator patterns.

### Card inheritance

`EventCard` is a `Card` with standard content and styles. When `link` is set:

- Hover elevation and keyboard `role="link"` inherit from Card (CR05a).
- Descendant `a`, `button`, and `[role="button"]` in footer are **decorative** — do not rely on footer CTAs receiving clicks on linked cards.
- No native middle-click / open-in-new-tab for the card surface (Card `link` limitation).

Internal vs external URL routing: per CR05a Card `link` and Standard 05 — not duplicated here.

### App usage

Consuming apps pass `normalizeEventCardFields(eventRow)` plus optional `footer`, `link`, and resolved `image`. Logo URL resolution and footer content remain app concerns; pace-core owns card body markup and formatting. Example: demo **`ShowcaseEventCard`** maps `EventStub`, variant index, and logo hook into `EventCard` props and supplies demo footer JSX.

## Visual specification

`EventCard` composes Card layer 0 with slot class recipes below. Global Card tokens: [7-visual-standards.md](../../../packages/core/docs/standards/7-visual-standards.md) Part C; linked hover inherits Card affordance. `DateBadge` visual recipe: CR05a.

- **Card root:** `bg-main-50 text-card-foreground` via `className` on `Card` (body tone override on layer 0).
- **Linked hover:** inherits Card linked classes from CR05a — no EventCard-specific translate or border overrides.
- **CardHeader (media):** `p-0 relative aspect-video overflow-hidden rounded-t-2xl`; gradient `bg-gradient-to-br from-sec-300/55 via-main-200 to-main-100` when no cover; `bg-main-100` when cover present; subtle overlay `bg-main-900/5` when no cover; centered glyph when blank.
- **Cover image:** when `image` is set, layered cover: decorative backdrop duplicate plus foreground cover (see **Cover backdrop**); foreground `absolute inset-0 block size-full object-cover z-[1]`; decorative `alt=""` on foreground.
- **Cover backdrop:** when `image` is set only — decorative duplicate `<img>` behind foreground with same `src`; `aria-hidden="true"`; `alt=""`; centered in `CardHeader` with `absolute left-1/2 top-1/2 z-0 size-full -translate-x-1/2 -translate-y-1/2 scale-[3] object-cover blur-3xl pointer-events-none`; header `overflow-hidden` contains the wash.
- **Date overlay:** when `event.event_date` parses, wrap derived `DateBadge` in `span` with `absolute left-3 top-3 z-10` on `CardHeader`.
- **imageTag:** absolute `right-3 top-3 z-10`.
- **Default glyph:** initials from `deriveEventInitials(event_code, event_name)` when no cover; `output` with `text-5xl font-semibold tracking-tight text-main-900/15`.
- **CardContent:** always three lines — `<h6>` event name; date `<p className="bullet-calendar text-sec-800">`; location `<p className="bullet-map-pin text-sec-800">`. Bullet utilities are defined in `core.css` (`@utility bullet-*` with Lucide mask SVGs in `@theme` as `--bullet-mask-calendar` / `--bullet-mask-map-pin`; icon `0.5lh` height, `0.75lh` padding-left, colour via `currentColor` on `::before`). When `footer` is provided, add `border-b border-main-200` on `CardContent` (not `CardFooter` — CR05a border rule).
- **CardFooter:** default `CardFooter` padding only (`p-4` from CR05a); no pace-core footer layout recipe — app content defines layout inside the slot.

## Behaviour

- Linked cards MUST be keyboard accessible via Card `link` contract (`role="link"`, Enter/Space).
- Image `alt=""` when decorative; meaningful title via `event.event_name` in `<h6>`.
- `FileDisplay` in header: `variant="inline"`, cover-positioned; `label` from file metadata when available.

## Do not

- Do not use polymorphic `<a>` / `<button>` roots — always compose `Card`.
- Do not embed routing beyond Card `link` — navigation rules live in CR05a / Standard 05.
- Do not fetch events or applications inside the component.
- Do not pass `meta`, `title`, `dateBadge`, or `foot` ReactNode slots — use `event` and optional `footer`.
- Do not render `expected_participants` or other core_events fields in the card body.
- Do not implement structured footer modes (participant/operator) inside pace-core — apps supply footer JSX.

## Breaking changes

1. `EventTile` renamed to **`EventCard`**; `EventTileMetaRow` removed.
2. `dateChip` prop renamed to internal derivation from `event.event_date`.
3. `href` / `onClick` / `as` removed — use `link`.
4. Linked cards: footer CTAs decorative (inherited from Card).
5. **`imageLabel` removed** — no header overlay for event code.
6. **Structured API (breaking):** `title`, `dateBadge`, `meta`, `foot`, and **`EventCardMetaRow`** removed — use `event: EventCardFields` and optional `footer` ReactNode.
7. **`EventCardFooter` / `EventCardApplicationStatus` removed** — footer is app-owned `ReactNode`; **`expected_participants` removed** from `EventCardFields` and body markup.

## References

- [CR05a-primitives.md](./CR05a-primitives.md) (Card `link`, slots, DateBadge)
- [CR17-derived-event-read-model-helper.md](./CR17-derived-event-read-model-helper.md)
- Prototype: `pace-prototype/apps/_shared/tiles.jsx`

---

## Prompt to use with Cursor

Implement the feature described in this document. Follow the standards and guardrails provided. Add or update tests and demo as specified. Run validate and fix any issues until it passes.
