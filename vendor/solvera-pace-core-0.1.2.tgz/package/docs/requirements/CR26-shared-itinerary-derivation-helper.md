# CR26 – Shared itinerary derivation helper

## Overview

- Purpose: define a shared pure `pace-core2` helper contract for itinerary derivation so consuming apps render the same participant and planner-facing itinerary structure without re-implementing day grouping, timezone precedence, or in-day ordering.
- Scope: package-level types and pure helper utilities for itinerary derivation only. Scope is not data fetching, RLS, TRAC page guards, Portal route ownership, map rendering, or app-specific copy.
- External prerequisites: consuming apps remain responsible for acquiring the underlying itinerary resources and assignments through their own Supabase/RPC paths and RLS assumptions. This slice does not widen access and does not bypass app or database security boundaries.
- Dependencies: [CR02-foundation-types-utils-styles.md](./CR02-foundation-types-utils-styles.md), [CR17-derived-event-read-model-helper.md](./CR17-derived-event-read-model-helper.md), [CR19-location-timezone-adapter-interfaces.md](./CR19-location-timezone-adapter-interfaces.md).
- Standards: 02 Architecture, 04 API and tech stack, 05 pace-core compliance, 06 Code quality, 08 Testing and documentation.

## Problem

TRAC is the authority for itinerary business rules, but multiple consumers now need the same executable derivation logic:

- TRAC `/itinerary`
- TRAC composites such as dashboard date-range summaries and master plan itinerary sections
- Portal `/:eventSlug/itinerary`

If each app re-implements day-entry expansion, timezone precedence, participant scoping, and in-day ordering locally, the suite will drift even when the written requirement docs match.

This slice centralises the shared pure derivation contract. It does not change which app owns the route, the read path, or the business authority.

## Target contract

### Shared ownership boundary

- **TRAC docs remain the business/source authority** for itinerary rules and participant visibility semantics.
- **pace-core2 owns the reusable executable helper contract** implementing those shared pure rules.
- Consuming apps own:
  - data fetching and adapter wiring
  - RLS/page guards/RBAC
  - route ownership and page composition
  - app-specific labels, empty-state copy, and visual treatment

### Supported itinerary inputs

The helper must support the three logistics resource types already used by TRAC:

- transport
- activity
- accommodation

Inputs must be normalized enough for shared derivation but remain package-neutral. The helper must accept:

- resource type
- stable resource id
- event default timezone (optional but supported)
- resource snapshot timezone fields and timestamp fields relevant to that resource type
- optional assignment rows or participant ids when the consumer wants participant-only scoping

### Shared derivation rules

The helper contract must support the documented v1 rules already approved in TRAC:

- **Participant-only assignment filter** when the consumer requests participant scope
- **Day-entry expansion**
  - transport renders on departure local day and arrival local day when different
  - activity renders on start local day and finish local day when different
  - accommodation renders on every occupied local day from check-in through check-out inclusive
  - each resource renders at most once per local day
- **Timezone precedence**
  - transport departure-day: departure snapshot timezone -> event default timezone -> UTC
  - transport arrival-day: arrival snapshot timezone -> departure snapshot timezone -> event default timezone -> UTC
  - activity start-day: start snapshot timezone -> event default timezone -> UTC
  - activity finish-day: finish snapshot timezone -> start snapshot timezone -> event default timezone -> UTC
  - accommodation occupied days: accommodation snapshot timezone -> event default timezone -> UTC
- **In-day ordering**
  - transport departure-day by `departure_time`
  - transport arrival-day by `arrival_time` when rendered on a different day
  - activity start-day by `start_time`
  - activity finish-day by `finish_time` when rendered on a different day
  - accommodation check-in day by `check_in_time`
  - accommodation check-out day by `check_out_time` when rendered on a different day
  - accommodation intermediate days sort after timestamped entries for the day
  - final tie-break is resource type, then stable id

### Non-ownership

This slice does **not** own:

- database schema, RLS, or Option A rollout work
- map route/leg generation
- planner CRUD or assignment mutation
- TRAC-specific or Portal-specific route/page guards
- event-specific copy such as “Your transport”

## Acceptance criteria

- [x] `pace-core2` exposes a shared pure helper contract for itinerary derivation rather than requiring consuming apps to re-implement the rules locally.
- [x] The contract supports normalized itinerary inputs for transport, activity, and accommodation and produces deterministic derived day entries.
- [x] The helper supports participant-only filtering when assignment rows and a participant/application identity are supplied, without widening access beyond the provided input set.
- [x] The helper implements the approved timezone precedence rules for all three resource types.
- [x] The helper implements the approved in-day ordering and final tie-break rules.
- [x] The helper can also return shared derived metadata needed by multiple consumers, including visible date range or grouped day buckets.
- [x] The contract is app-neutral: no TRAC route ownership, Portal route ownership, or app-specific copy is embedded in the package helper.

## API / Contract

- Public exports from `packages/core/src/itinerary/` with dedicated subpath **`@solvera/pace-core/itinerary`**:
  - `deriveItineraryDayEntries(...)`
  - `compareItineraryEntries(...)`
  - `validateItineraryInputs(...)`
  - optional convenience helpers: `groupItineraryEntriesByDay(...)`, `getItineraryVisibleDateRange(...)`, `filterItineraryForParticipant(...)`
- Expected contract-level types (names may vary if equivalent):
  - `ItineraryResourceType = 'transport' | 'activity' | 'accommodation'`
  - `ItineraryScope = { mode: 'all' } | { mode: 'participant'; participantApplicationId: string }`
  - `BaseItineraryResourceInput`
  - `TransportItineraryInput`
  - `ActivityItineraryInput`
  - `AccommodationItineraryInput`
  - `ItineraryAssignmentInput`
  - `DerivedItineraryDayEntry`
  - `ItineraryDayGroup`
  - `ItineraryVisibleDateRange`
- Contract rules:
  - The helper must operate on already-fetched input data only.
  - Participant filtering must be narrowing only: it may remove entries from the provided input set but must never imply access to data the consumer did not supply.
  - Derived entries must carry enough metadata for consumers to render list-first timelines consistently without re-deriving day keys or sort keys.
  - `DerivedItineraryDayEntry` must include:
    - stable day key
    - resource type
    - resource id
    - entry kind/source marker (departure, arrival, start, finish, occupied, etc.)
    - local date
    - sort key metadata
    - optional timestamp used for primary ordering
    - optional timezone metadata useful for diagnostics/tests
  - The helper must not require a specific app-side data-fetching hook or service provider.

### Authoritative contract notes

- **Pure-contract requirement:** every exported helper is deterministic and side-effect free; no I/O, no global caches, no date/timezone adapter lookups inside helpers.
- **Validation strategy (hybrid):**
  - `validateItineraryInputs(...)` returns structured validation issues and is the recommended preflight in consuming apps.
  - core derivation helpers may throw deterministic errors when called with invalid data that violates contract assumptions after preflight.
- **Date/time representation:**
  - Inputs use ISO strings for timestamps and optional timezone identifiers.
  - Day keys are normalized as `YYYY-MM-DD` in the resolved local timezone for each derived entry.
- **Comparator contract:** `compareItineraryEntries(a, b)` must implement the approved in-day ordering and final tie-break (`resourceType`, then stable `resourceId`) so consumers do not re-sort with app-local logic.
- **Participant scope contract (primary use case):** CR26 primarily serves single-participant itinerary wrappers. Participant scoping should be first-class in the main derive contract (either via scope parameter or prefiltered input), and any `filterItineraryForParticipant` helper remains optional narrowing sugar.
- **Error handling:** invalid input shape (e.g. missing required timestamps for a resource type) should fail fast via deterministic exceptions or typed validation errors; behavior must be documented and test-covered.

## Package implementation map (rebuild reference)

Use this section to recreate or audit CR26 without relying on chat history. Paths are relative to `packages/core/`.

### Exported from `@solvera/pace-core/itinerary`

| Symbol | Source file | Role |
| --- | --- | --- |
| `deriveItineraryDayEntries` | `src/itinerary/deriveItineraryDayEntries.ts` | Main derivation engine from normalized resources + scope. |
| `validateItineraryInputs` | `src/itinerary/validateItineraryInputs.ts` | Structured preflight validation for helper input contracts. |
| `compareItineraryEntries` | `src/itinerary/compareItineraryEntries.ts` | Canonical sort comparator implementing CR26 ordering rules. |
| `groupItineraryEntriesByDay` *(optional convenience)* | `src/itinerary/groupItineraryEntriesByDay.ts` | Optional grouping helper for day buckets. |
| `getItineraryVisibleDateRange` *(optional convenience)* | `src/itinerary/getItineraryVisibleDateRange.ts` | Optional visible min/max day helper. |
| `filterItineraryForParticipant` *(optional convenience)* | `src/itinerary/filterItineraryForParticipant.ts` | Optional narrowing helper when participant scope is not passed directly to derive. |
| `Itinerary*` types | `src/itinerary/types.ts` | Shared contract types for inputs, scope, derived entries, groups, and ranges. |

### Barrel/export ownership

| File | Responsibility |
| --- | --- |
| `src/itinerary/index.ts` | Itinerary subpath barrel. |
| `packages/core/package.json` | Add and maintain `./itinerary` export subpath. |
| `src/index.ts` | Do not mirror itinerary helpers on root export unless governance explicitly requires it. |

### Key tests (minimum rebuild parity)

| Area | Location |
| --- | --- |
| Input validation contract | `src/itinerary/validateItineraryInputs.test.ts` |
| Derivation expansion + timezone precedence | `src/itinerary/deriveItineraryDayEntries.test.ts` |
| Comparator ordering and tie-breaks | `src/itinerary/compareItineraryEntries.test.ts` |
| Grouping and visible range *(if convenience helpers exported)* | `src/itinerary/grouping-and-range.test.ts` |
| Participant filter *(if convenience helper exported)* | `src/itinerary/filterItineraryForParticipant.test.ts` |
| End-to-end fixture parity | `src/itinerary/itineraryFixtures.integration.test.ts` |

### Build/export governance notes

- Subpath export ownership:
  - `packages/core/package.json` (`./itinerary`)
  - `src/itinerary/index.ts`
- If adding/removing public itinerary symbols, run:
  - `npm run build -w @solvera/pace-core`
  - `npm run docs:exports-index`
  - `npm run export:check-governance`

## Visual specification

Not applicable (non-UI contract slice).

## Verification

- pace-core: verify at least one demo or fixture-driven verification surface can derive itinerary outputs from mixed transport, activity, and accommodation inputs without app-specific code paths.
- Consuming apps: verify TRAC and Portal can both depend on the shared helper while retaining their own route/page ownership.
- Consuming apps: verify identical fixture inputs produce identical day grouping, visible date range, and ordering regardless of which app calls the helper.
- Export verification: `@solvera/pace-core/itinerary` imports compile in consuming apps without root-export fallback.

## Testing requirements

- Unit tests for participant-only filtering behavior, including no-assignment and mixed-assignment cases.
- Unit tests for day-entry expansion:
  - same-day and multi-day transport
  - same-day and multi-day activity
  - same-day and multi-day accommodation
- Unit tests for timezone precedence fallback chains across all resource types.
- Unit tests for in-day ordering and final tie-break behavior.
- Unit tests for visible date range derivation from generated day entries.
- Integration-style fixture tests proving the same canonical input set yields the same derived output across multiple consumer call patterns.

## Do not

- Do not encode TRAC page guards, Portal route ownership, or app-specific labels in the shared helper.
- Do not move RLS or RPC logic into pace-core for this slice.
- Do not require map support or planner-specific concepts in the helper contract.
- Do not let consuming app docs redefine the day-entry, timezone, or ordering rules once this shared helper contract exists; they should reference and consume it.
- Do not place CR26 helpers under `@solvera/pace-core/location`; keep a dedicated `@solvera/pace-core/itinerary` subpath.

## References

- [CR00-core-project-brief.md](./CR00-core-project-brief.md)
- [CR00-core-architecture.md](./CR00-core-architecture.md)
- [CR02-foundation-types-utils-styles.md](./CR02-foundation-types-utils-styles.md)
- [CR17-derived-event-read-model-helper.md](./CR17-derived-event-read-model-helper.md)
- [CR19-location-timezone-adapter-interfaces.md](./CR19-location-timezone-adapter-interfaces.md)
- `docs/requirements/trac/trac-architecture.md`
- `docs/requirements/trac/TR05-itinerary-requirements.md`
- `docs/requirements/trac/trac-feature-list.md`
- `docs/requirements/trac/trac-user-stories.md`
- `docs/requirements/trac/trac-project-brief.md`

---

## Prompt to use with Cursor

Implement the feature described in this document. Follow the standards and guardrails provided. Read **Package implementation map (rebuild reference)** for expected files and exports. Add or update tests and verification flows as specified in **Testing requirements** and **Verification**. If public exports change, run `npm run build -w @solvera/pace-core` before repo-wide validate so `dist/` stays aligned. Then run `npm run validate` and fix any issues until it passes.
