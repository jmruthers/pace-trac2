# Auth and context

*Enrichment complete (reverse-engineering pass): API/Contract signatures, Behaviour MUSTs, Demo step-by-step, References with inline examples.*

## Overview

- **Purpose:** Authentication (Supabase session), organisation context, and route protection so the demo and RBAC can assume a signed-in user and organisation scope.
- **Scope:** Package (providers, hooks, components) + demo app (wiring and protected routes).
- **Dependencies:** 02-foundation-types-utils-styles. Uses existing database (organisations, auth.users); no schema creation.
- **Standards:** 03 Security & RBAC, 05 pace-core compliance, 07 Visual.

## Acceptance criteria

- [x] UnifiedAuthProvider: accepts supabaseClient, appName (and any required props); provides session, user, loading, sign-in/sign-out; integrates with Supabase auth.
- [x] OrganisationServiceProvider: provides current organisation, membership, switchOrganisation (or equivalent); reads from existing organisations (and related) tables via secure client. When user is super admin, organisations list MUST include all organisations from core_organisations (not only membership-based); super admin sees full org list from useOrganisations() for lists, pickers, dropdowns, URL resolution.
- [x] ProtectedRoute component: wraps children; redirects unauthenticated users to login; does not implement a global auth gate that wraps the whole tree and redirects on !isAuthenticated (per Standard 05).
- [x] Hooks: useUnifiedAuth, useOrganisations (or equivalent), useSessionTracking if specified.
- [x] Demo: login page (PaceLoginPage), app shell with ProtectedRoute; user can sign in and see organisation context.

## API / Contract

- **Providers:** UnifiedAuthProvider, OrganisationServiceProvider — from `packages/core/src/providers/`.
- **Components:** ProtectedRoute, PaceLoginPage (if in scope) — from `packages/core/src/components/`.
- **Hooks:** useUnifiedAuth — from `packages/core/src/providers/UnifiedAuthProvider`; useOrganisations — from `packages/core/src/hooks/useOrganisations`.
- **Types:** AuthSessionData, UserProfile, OrganisationContextType, OrganisationMembership (from foundation or here). Contract only; no implementation detail.

### Concrete signatures and shapes

**UnifiedAuthProviderProps:** children, supabaseClient, appName, persistState?, enablePersistence?, requireOrganisationContext?, idleTimeoutMs, warnBeforeMs, onIdleLogout(reason: 'inactivity'), renderInactivityWarning?({ timeRemaining, onStaySignedIn, onSignOutNow }), dangerouslyDisableInactivity?.

**OrganisationServiceProviderProps:** children, supabaseClient, user (User | null), session (Session | null).

**useUnifiedAuth(): UnifiedAuthContextType** — Main surface: user, session, isAuthenticated, signIn, signOut, signUp, resetPassword, updatePassword, refreshSession, selectedOrganisation, selectedOrganisationId, organisations, userMemberships, switchOrganisation, getUserRole, hasValidOrganisationContext, isContextReady, refreshOrganisations, ensureOrganisationContext, getPrimaryOrganisation, events, selectedEvent, selectedEventId, setSelectedEvent, refreshEvents, isLoading, authLoading, organisationLoading, eventLoading, supabase, appName, sessionRestoration, showInactivityWarning, inactivityTimeRemaining, resetActivity, handleStaySignedIn, handleSignOutNow, etc.

**useOrganisations(): OrganisationContextType** — selectedOrganisation, organisations, userMemberships, switchOrganisation, getUserRole, isContextReady, refreshOrganisations, setSelectedOrganisation, validateOrganisationAccess, ensureOrganisationContext, isOrganisationSecure, getPrimaryOrganisation, isLoading, error, hasValidOrganisationContext. When user is super admin, organisations MUST be the full list from core_organisations (via secure client), not only "organisations the user is a member of"; org loading for super admins MUST NOT hang indefinitely.

**ProtectedRoute props:** loginPath? (default `/login`), requireEvent?, noEventsFallback?, loadingFallback?; renders children via React Router Outlet when authenticated; optional children are the nested route elements.

## Behaviour

- When user is super admin, useOrganisations() (or the data source behind OrganisationServiceProvider) MUST return all organisations from core_organisations (via secure client), not only membership-based list; ensure org loading for super admins does not hang indefinitely.
- ProtectedRoute MUST redirect unauthenticated users to loginPath (default `/login`) via React Router Navigate replace; MUST NOT implement a global auth gate that wraps the whole app and redirects on !isAuthenticated (per Standard 05).
- Session restoration MUST be honoured before redirect (e.g. show loading until restoration completes or times out).
- UnifiedAuthProvider MUST be the outermost auth provider; OrganisationServiceProvider MUST be a child of UnifiedAuthProvider. setupRBAC MUST be called after Supabase client is available (e.g. in main.tsx before render).
- Apps using UnifiedAuthProvider MUST configure inactivity logout (idleTimeoutMs, warnBeforeMs, onIdleLogout, and renderInactivityWarning with e.g. InactivityWarningModal from CR08).
- pace-core components that accept an app identifier (UnifiedAuthProvider, PaceLoginPage, PaceAppLayout, etc.) take `appName`. Consuming apps MUST declare and use the app name as specified in Standard 5 (pace-core compliance); see that standard for declaration location and global usage.
- For authenticated event-configuration logo uploads that use canonical `FileUpload`, consuming apps MUST provide resolved `organisation_id`, `event_id`, `app_id`, and a non-empty `pageContext` so pace-core can execute `app_file_reference_create` with explicit scope instead of direct metadata table inserts.
- Same-layout route transitions MUST NOT reinitialize auth/context providers or repeat initial session-restoration flow once the shell is active. Internal client-side navigation should preserve session and organisation/event context state unless an explicit sign-out or context switch occurs.

## Demo app requirements

- Demo has a login route and protected routes. User can sign in, see organisation context (e.g. selector or current org name), and navigate to a protected page. Sign-out works.
- **Step-by-step:** User visits protected route while unauthenticated → redirected to `/login`. User signs in on PaceLoginPage → redirected to onSuccessRedirectPath (e.g. `/`). User sees organisation context (selector or current org name). User can sign out and is redirected to login.

### Login page layout and markup

- **Visual and DOM:** MUST match [CR06 – Forms and feedback](./CR06-forms-and-feedback.md) **Visual specification** — Login page (PaceLoginPage) (grid, page background via consuming app e.g. `pace-background` on `body`, Card regions per [Standard 07](../../../packages/core/docs/standards/7-visual-standards.md#modal-dialog-panel-sizing), typography exceptions for login header, default copy patterns).
- **Accessibility:** The `main` landmark MUST have an appropriate `aria-label` (e.g. "Login" or "[App Name] Login Page").
- **Behaviour:** Email + password, submit via pace-core auth, redirect on success, show error in-form (Alert destructive per standard).

**References:** Standard 07 Visual (Part C globals), CR06 Visual specification, 05 pace-core compliance.

## Verification

- **Routing flow:** Verify unauthenticated users are redirected to `/login` and authenticated users can access protected routes via `ProtectedRoute`.
- **Context flow:** Verify `useOrganisations()` resolves context correctly, including super-admin all-organisations behaviour.
- **Provider order:** Verify app wiring uses `UnifiedAuthProvider` and nested `OrganisationServiceProvider` as required.
- **Navigation/session continuity:** Verify same-layout client-side route changes do not trigger provider remount cycles or session-restoration regressions.

## Testing requirements

- Unit/integration tests for auth and organisation context behaviour; coverage per Standard 08. ProtectedRoute: redirect when unauthenticated, render children when authenticated.
- **UnifiedAuthProvider (critical path, 100% enforced):** integration tests cover session restoration (success, error, timeout, session without user), sign-in/sign-out and auth RPC helpers (`signUp`, `resetPassword`, `updatePassword`, `refreshSession`, unavailable-auth client), `onAuthStateChange` subscription, and context hook guards (`useUnifiedAuthContext`, `useOptionalUnifiedAuthContext`).
- **Inactivity logout:** when all four props are configured (`idleTimeoutMs`, `warnBeforeMs`, `onIdleLogout`, `renderInactivityWarning`), tests assert idle warning then `onIdleLogout('inactivity')` and sign-out; `handleStaySignedIn` and `handleSignOutNow`; user activity (`mousemove` / listeners) and `resetActivity` reset the idle clock; countdown decreases in `renderInactivityWarning`; disabled via `dangerouslyDisableInactivity` or incomplete prop set (stub slice, no interval); no session → inactivity inert.

## Do not

- Do not create or migrate database schema; use existing Supabase schema and data.
- Do not implement a global auth gate that redirects to login on !isAuthenticated for the whole tree (per pace-core compliance standard).

## References

- [5-pace-core-compliance-standards.md](../../../packages/core/docs/standards/5-pace-core-compliance-standards.md) (auth routing, provider order), [3-security-rbac-standards.md](../../../packages/core/docs/standards/3-security-rbac-standards.md). Implementation-guides/authentication (reference only).
- **Inline — app name:** Per Standard 5: declare `APP_NAME` in `src/App.tsx`; in main.tsx import it and pass to setupRBAC and UnifiedAuthProvider.
- **Inline — provider nesting:** In main.tsx: `import { APP_NAME } from './App';` then `setupRBAC(supabaseClient, { appName: APP_NAME, getAppId: ... });` (with canonical uppercase `APP_NAME`) and wrap app with `<UnifiedAuthProvider supabaseClient={client} appName={APP_NAME} idleTimeoutMs={...} warnBeforeMs={...} onIdleLogout={...}>` then `<OrganisationServiceProvider supabaseClient={client} user={user} session={session}>` then routes; use `<Route element={<ProtectedRoute />}>` (or `<ProtectedRoute loginPath="/login" />`) with nested routes inside.
- **Inline — ProtectedRoute usage:** `<Route element={<ProtectedRoute loginPath="/login" />}><Route path="/dashboard" element={<DashboardPage />} /></Route>`; unauthenticated visits to `/dashboard` redirect to `/login`.

---

## Prompt to use with Cursor

Implement the feature described in this document. Follow the standards and guardrails provided. Add or update tests and demo as specified. Run validate and fix any issues until it passes.
