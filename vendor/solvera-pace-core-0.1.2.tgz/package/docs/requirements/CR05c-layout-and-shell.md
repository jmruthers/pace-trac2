# CR05c – Layout and shell

*Slice 3 of 3: app layout, navigation, and error/loading. Depends on 05a and 05b. Completes primitives-and-layout. This requirement is the single source of truth for shell functionality and visual recipe (merged from CR17).*

## Overview

- **Purpose:** App shell (Header, Footer, navigation, PaceAppLayout) and error/loading so the demo and other features have a consistent layout and recovery UI.
- **Scope:** Package + demo (app shell wrapping routes; nav to showcase and other pages).
- **Dependencies:** 02-foundation-types-utils-styles, 04-rbac (if layout uses guards), 05a-primitives, 05b-dialog-select-tabs. Optional: 03-auth for layout that shows user/org.
- **Standards:** 05 pace-core compliance, 06 Code quality, 07 Visual, 02 Architecture.

## Acceptance criteria

- [x] PaceHeader, PaceFooter, NavigationMenu, UserMenu; PaceAppLayout with navItems, logo, optional context selector and permission config.
- [x] ErrorBoundary; LoadingSpinner.
- [x] All use design tokens (main/sec/acc); semantic HTML where applicable; no inline styles; exports from package components barrel.
- [x] Demo app uses PaceAppLayout as the main layout; nav items link to Styles Showcase (and any other existing routes); user can navigate and see Header, nav menu, Footer.
- [x] PaceAppLayout is the fixed shell entrypoint for consuming apps; header regions are composed by pace-core and are not consumer-injected.
- [x] PaceAppLayout composes PaceHeader + PaceMain + PaceFooter, with route content rendered through PaceMain inside the shell `<main>` container.
- [x] Internal same-layout navigation is client-side and preserves shared shell regions; only routed PaceMain child content updates.
- [x] Header nav renders direct children in this order (left to right): app switcher, app icon link, primary navigation region, context switcher, user menu trigger.
- [x] Primary navigation uses inline link pills at `lg` and above and a compact Select menu below `lg`; consuming apps pass up to **five** primary `navItems` (extras are ignored by the shell).
- [x] Header is fully responsive with shell-specific breakpoint behavior:
  - app switcher visible at `xs` and above (hidden below `xs`).
  - app icon switches from favicon to wide wordmark at `lg` and above.
  - primary navigation shows inline link pills at `lg` and above; below `lg` the compact Select trigger shows only the `Menu` icon below `sm` (no visible label and no visible chevron) and uses standard Select trigger presentation (plain label + default chevron) from `sm` and above.
  - user menu trigger shows only an Avatar instance below `md` (no visible label and no visible chevron); at `md` and above it shows the user display name with Select trigger chevron, and the avatar is hidden.
  - nav and user menu trigger buttons keep SelectTrigger no-wrap label content and trigger-chevron alignment behavior at larger breakpoints where a Select trigger is used (compact primary nav below `lg`, user menu).
  - context switcher and user menu use `lg:w-fit` and fixed width at `xl` where configured (`xl:w-72`).
- [x] Header has bottom border and uses `gap-0` strategy with margin-based spacing between visible regions (so hidden regions do not leave phantom gaps).
- [x] **`appSwitcherItems` passthrough** — `PaceAppLayout` / `PaceHeader` accept optional `appSwitcherItems?: AppSwitcherItem[]` and pass them to `AppSwitcher` so consuming apps can supply RBAC-filtered app lists (default remains bundled icon set when omitted).
- [x] **Minimal / navigation-free layout mode** — `layoutVariant?: 'default' | 'minimal'` (default `'default'`). When `'minimal'`: hide app switcher, navigation menu, and context selector; show app logo link and user menu only. Consuming apps use this for profile-wizard and similar focused flows. Equivalent explicit flags (`showAppSwitcher={false}`, `navItems=[]`, `showContextSelector={false}`) are also supported.
- [x] **`UserMenu` extra actions** — `PaceAppLayout` accepts optional `extraMenuActions?: UserMenuExtraAction[]` (`{ id, label, onSelect }[]`) rendered between the profile block and standard account actions (change password, sign out). Supports prototype “Run profile setup wizard” and similar app-specific entries.

## API / Contract

- **Exports:** From `packages/core/src/components/shell/` — PaceHeader, PaceFooter, PaceMain, NavigationMenu, UserMenu, PaceAppLayout, `usePaceMain`, ErrorBoundary, LoadingSpinner. Public props as per package barrel (`PaceHeader` / `PaceFooter` only; no `Header` / `Footer` aliases).

### Minimal prop contracts

**PaceAppLayout:** appName (required), navItems?: NavigationItem[] (max **5** primary items rendered), logoHref?, showContextSelector?, showOrganisations?, showEvents?, **onOrganisationSelect?**, **onEventSelect?**, **layoutVariant?: 'default' | 'minimal'**, **showAppSwitcher?: boolean** (default true; ignored when `layoutVariant='minimal'`), **appSwitcherItems?: AppSwitcherItem[]**, userFullName (required), userEmail (required), userAvatarSrc?, onUserMenuSignOut (required), onUserMenuChangePassword (required), **extraMenuActions?: UserMenuExtraAction[]**, permissionConfig?, enforcePermissions?, permissionFallback?, **routeAccessDenied?**, etc. Contract is intentionally fixed so layout and look and feel stay consistent; consuming apps use PaceAppLayout as provided and cannot inject custom header-region nodes or replace the default UserMenu region. `appName` is also used to resolve shell logo assets (`/logos/{appSlug}-logo-wide.svg` and `/logos/{appSlug}-favicon.svg` via `appPublicLogoPath`) when available. **NavigationItem:** { id: string, label: string, href?: string, icon?: string, children?: NavigationItem[], permissions?, roles?, accessLevel?, meta?, pageId? }. **AppSwitcherItem:** { id: string, label: string, href: string } (re-exported from AppSwitcher). **UserMenuExtraAction:** { id: string, label: string, onSelect: () => void }. Internal app-route `href` values MUST be handled through client-side router navigation so shared shell regions persist across route changes. **usePaceMain:** page-level hook for shell-routed page files to declare shell `<main>` metadata (`className`, `ariaLabel`, `printTitle`, `printPageOrientation`) rendered by PaceMain. **ErrorBoundary; LoadingSpinner.**

**Distinction — PaceHeader vs PageHeader (CR27):** `PaceHeader` is the fixed **app shell** chrome (logo, nav, user menu). **`PageHeader`** (CR27) is **in-page** chrome (breadcrumb + title + actions) rendered inside route content below the shell. They MUST NOT be conflated.

**NavigationMenu:** Hybrid primary navigation for the shell. At `lg` and above, renders up to five inline `Link` pills in a `<nav aria-label="Primary">` region with longest-prefix active matching. Below `lg`, renders a compact Select trigger (Menu icon below `sm`, active label + chevron at `sm+`) listing the same items. Per-item RBAC: when `permissions` is set, `NavigationGuard` hides denied items and MUST forward the item's `pageId` (or the page name parsed from a `:page.*` permission) to the RBAC check as `p_page_id`, matching `PagePermissionGuard` / `usePageCan`; when `pageId` is set without `permissions`, gate with `read` permission for that page using the same `pageId` forwarding. Deep-link routes MUST NOT appear in primary `navItems`. **PaceFooter:** No consumer props; pace-core dictates the copyright text and styling. PaceFooter ALWAYS renders the default copyright line (see Behaviour); consuming apps cannot change it. **ErrorBoundary; LoadingSpinner.**

## Visual specification

Global rules: [7-visual-standards.md](../../../packages/core/docs/standards/7-visual-standards.md) Part C. **App shell (PaceHeader, PaceFooter, PaceMain):**

- **PaceHeader structure:** full-width `<header role="banner">` with a single centered `<nav aria-label="Application header">` constrained by `--app-width`. Use direct Tailwind utilities in component code (for example `max-w-(--app-width)` with `grid-cols-[auto_auto_1fr_auto_auto]` on the header nav). The `<nav>` direct children are the five shell controls in this order: app switcher, app icon link, primary navigation region (`NavigationMenu`), context selector, user menu trigger. Do not add extra region wrapper elements around these controls.
- **Header region ownership:** PaceHeader is the composition owner for shell regions (AppSwitcher, NavigationMenu, optional ContextSelector, UserMenu) including their responsive class recipes. PaceAppLayout passes high-level shell data/flags only and must not pass pre-rendered region nodes with class overrides into PaceHeader.
- **Header spacing model:** nav container uses `gap-0`; horizontal spacing is applied on visible direct children so hidden controls do not leave phantom gaps.
- **Header responsive behavior:**
  - App switcher visible at `sm` and above.
  - App icon control is always present: below `lg` use `public/logos/{appSlug}-favicon.svg`; at `lg` and above use `public/logos/{appSlug}-logo-wide.svg` (`appSlug` = lowercased `appName`).
  - Primary navigation (`NavigationMenu`) renders inline link pills at `lg` and above inside `<nav aria-label="Primary">` with `ul` / `li` structure. Active item uses `bg-main-700 text-main-50`; inactive uses `text-main-800 hover:bg-main-100`. Below `lg`, compact Select trigger: icon-only below `sm`, active label + chevron at `sm+`, `lg:hidden` on the trigger.
  - User menu trigger renders avatar-only below `md` (no visible text and no visible chevron). At `md` and above, render user display name text and default Select chevron, matching context selector trigger behavior, and do not show the avatar.
  - For nav and user triggers, preserve SelectTrigger grid-column trigger layout (`content | chevron`) and no-wrap trigger label content so chevrons remain at the right edge of the trigger (for example trigger grid template utility `grid-cols-[1fr_auto]`).
  - Navigation menu, context selector, and user menu shrink-to-fit at `lg`, and use fixed/specified widths at `xl` and above for context selector and user menu.
- **Header styling:** no background utility on `<header>`; no border on `<header>`. Shell header chrome is visually flat and inherits the page background.
- **NavigationMenu:** hybrid inline + compact Select as specified above; caps visible primary items at five; longest matching `href` prefix wins for active state among sibling items.
- **App switcher:** Select-based image-first trigger using bundled app-switcher icon and app list icons from `packages/core/src/assets/app-icons`; trigger does not include app name text; dropdown can be wider than trigger and must avoid horizontal scrolling.
- **App icon:** control links to app default landing page (`logoHref` route) and switches from favicon below `lg` to wide wordmark at `lg+` using consuming app `appName`.
- **UserMenu:** Select-based trigger/dropdown. Trigger content is avatar-only below `md` (no visible text, no visible chevron) and user display name + default chevron at `md` and above, matching context selector. The user menu region keeps explicit right margin spacing in the shell row at all breakpoints where the control is visible. Menu includes full name and email context plus standard options for change password and sign out.
- **UserMenu dropdown anchor alignment:** UserMenu `SelectContent` aligns the dropdown panel to the trigger’s right edge with anchor positioning (`right-anchor-right left-auto`) rather than viewport/offset positioning (`right-0`).
- **Footer:** no consumer props. Background uses `bg-main-100`. Top border uses `border-main-300`. Inner row uses CSS Grid (`grid-cols-1 md:grid-cols-2`) within `max-w-(--app-width) px-4`: copyright **left-aligned** (`<small>`), footer actions **right-aligned** in `<nav aria-label="Footer links">`. Default copyright via `getDefaultFooterCopyright()`. **Support** and **Privacy** use pace-core `Button variant="link"` (not raw `<a>` for in-app modals). Modals are owned by pace-core; consumers must not fork footer modals. Spacing: e.g. `mt-8 py-6`, top border. See [CR05d – Footer support and privacy](./CR05d-footer-support-and-privacy.md).
- **PaceMain content:** wrapper with horizontal/vertical padding and centered content constrained by `--app-width`. PaceMain renders route/page content directly inside the shell `<main>` container (without extra Card/CardContent wrapper elements). Optional soft gradient uses main/sec/acc tokens only.
- **Main landmark ownership:** PaceAppLayout owns the shell page-level `<main>` landmark. Child route pages rendered inside PaceAppLayout must not render an additional `<main>` root; they should use sectioning/content roots (`<section>`, `<article>`, fragments) instead.
- **Page-owned main layout metadata:** Shell-routed page files declare per-page shell `<main>` metadata via `usePaceMain` (including layout classes and print metadata such as `printTitle` / `printPageOrientation`); central route config remains responsible for route wiring, not page-specific main metadata strings.
- **Card slot markup discipline for consuming pages:** When composing content inside Card subcomponents in shell-routed pages, prefer classes on `CardHeader`/`CardContent`/`CardFooter` directly and avoid single-child wrapper elements that exist only for layout classes.
- **UserMenu:** responsive trigger contract: avatar-only below `md`, display name or email at `md` and above; dropdown/panel for sign out and optional change password; optional role badge.

## Behaviour

- All components MUST use design tokens (main/sec/acc) only; MUST use semantic HTML where applicable; MUST NOT use inline styles. PaceAppLayout MUST accept navItems and render navigation; MUST support optional permission config and fallback. Exports MUST be from package components barrel.
- **Navigation:** Primary shell navigation MUST use pace-core `NavigationMenu` via `PaceAppLayout`. Consuming apps MUST pass at most **five** primary `navItems`; additional routes MUST be deep links (not in the header). Header MUST display primary nav links inline at `lg` and above. Consuming apps MUST NOT implement custom shell nav substitutes (no forked `GearHeader`-style inline nav).
- **Navigation transition model:** Internal navigation between routes that share the same layout MUST use client-side router mechanisms and MUST NOT trigger a full document reload. This applies to navigation components, in-page actions/buttons, and programmatic navigation.
- **Shared-shell persistence:** For same-layout route transitions, shared shell components MUST remain mounted and intact, including Header, Footer, session/provider state, and context-derived CSS variables. Only routed content inside PaceMain is expected to update.
- **Hard-navigation exceptions:** Full document navigation is allowed only for explicit hard-navigation cases (for example opening a new tab, external destinations, downloads, or other intentional browser-level navigations).
- **New-tab behaviour:** When an app route is opened in a new tab, full page render is expected. Session continuity and derived theme variables SHOULD resolve seamlessly in the new tab once session/context restoration completes.
- **Footer:** Footer has no consumer props; pace-core dictates copyright text, Support/Privacy actions, and styling. Footer MUST display the default copyright line (e.g. "© Copyright 2022–{current year} all rights reserved, Solvera Solutions Pty Ltd.") and platform Support/Privacy link actions that open pace-core dialogs. Consuming apps cannot change footer content or replace modals. All consuming apps (including the demo) MUST use pace-core’s Footer as provided via PaceAppLayout; they must not substitute a custom footer.
- **Context selector:** When `showContextSelector` is true, Header wires ContextSelector for org/event context selection (see [CR08 – Advanced UI](./CR08-advanced-ui.md)). Optional **`onOrganisationSelect`** and **`onEventSelect`** callbacks on `PaceAppLayout` / `PaceHeader` forward to `ContextSelector` for app-specific navigation side effects. Consuming apps **SHOULD** integrate dynamic theming at the app root per [CR15 – Dynamic theming](./CR15-dynamic-theming.md) (e.g. **`useContextTheme()`**) so switching context updates **`--color-main-*`**, **`--color-sec-*`**, and **`--color-acc-*`** on the document element when the selected entity has palette data.
- **Logo and app switcher:** Header renders app icon and switcher as specified above; app icon links to default page; switcher uses bundled icon set and routed app destinations.
- **Header composition:** Consuming apps MUST NOT provide custom header-region nodes, MUST NOT replace the UserMenu region with a custom component, and MUST NOT substitute a custom Header in place of PaceAppLayout.
- **Header composition boundary:** PaceAppLayout MUST instantiate PaceHeader as a simple shell component instance (analogous to PaceMain/PaceFooter usage) and MUST NOT act as a pass-through layer for per-region rendered props.
- **Main content container:** Consuming apps MUST use PaceAppLayout-provided PaceMain container and MUST NOT replace shell-level layout structure with custom outer page roots.
- **Main landmark discipline:** Shell-routed page components rendered under PaceAppLayout MUST NOT render their own `<main>` element.
- **User menu contract:** Consuming apps MUST wire authenticated identity and actions into PaceAppLayout by always passing `userFullName`, `userEmail`, `onUserMenuSignOut`, and `onUserMenuChangePassword`. User menu actions MUST execute real handlers; no optional/no-op user-menu path is allowed. Optional **`extraMenuActions`** render additional Select items above change-password/sign-out; each action MUST invoke its `onSelect` handler when chosen.
- **Minimal layout:** When `layoutVariant='minimal'`, shell MUST hide app switcher, navigation menu, and context selector while preserving logo link and user menu. Demo MUST include a minimal-layout example route or documented usage in CR11.
- **App switcher passthrough:** When `appSwitcherItems` is provided, AppSwitcher MUST use the supplied list instead of the bundled default; consuming apps remain responsible for RBAC filtering before passing items.
- **Import-not-fork hygiene:** Consuming apps MUST NOT fork `PaceHeader`, `UserMenu`, `AppSwitcher`, `Form`/`FormField`, `Card`, `Dialog`, `FileUpload`/`FileDisplay`, `AddressField`, or `PaceLoginPage`. Import package exports instead of reimplementing prototype `_shared` components locally.
- **Main content container:** Consuming apps MUST use PaceAppLayout-provided PaceMain container and MUST NOT replace shell-level layout structure with custom outer page roots.
- **Main landmark discipline:** Shell-routed page components rendered under PaceAppLayout MUST NOT render their own `<main>` element.

## Demo app requirements

- **Step-by-step:** User opens app → sees PaceAppLayout with Header, nav menu, and Footer. User can navigate to Styles Showcase (and any other routes) from nav. User sees UserMenu (if auth/layout wired). ErrorBoundary and LoadingSpinner are available for use in the app (e.g. wrap routes or async content).
- **Step-by-step:** User opens app → sees PaceAppLayout with Header, nav menu, and Footer. User can navigate to Styles Showcase (and any other routes) from nav. For same-layout routes, only PaceMain content changes while Header/Footer/session/theme context remain intact. User sees UserMenu (if auth/layout wired). ErrorBoundary and LoadingSpinner are available for use in the app (e.g. wrap routes or async content).

**Inline — NavigationItem and PaceAppLayout:** `const navItems: NavigationItem[] = [{ id: 'home', label: 'Home', href: '/', icon: 'Home' }, { id: 'styles', label: 'Styles', href: '/styles-showcase', icon: 'LayoutDashboard' }];` then `<PaceAppLayout appName="My App" navItems={navItems} logoHref="/" userFullName={userDisplayName} userEmail={userEmail} onUserMenuSignOut={handleUserMenuSignOut} onUserMenuChangePassword={handleOpenChangePassword}><Outlet /></PaceAppLayout>` (with React Router Route element).

## Verification

- **Shell structure:** Verify demo app uses `PaceAppLayout` and renders `header > nav` shell structure with direct ordered shell controls (no redundant wrapper regions), hybrid primary navigation, main landmark, and footer from pace-core.
- **Single-main shell check:** Verify shell-routed child pages do not render nested/duplicate `<main>` landmarks under PaceAppLayout.
- **Behaviour parity:** Verify navigation and footer behaviour follow this requirement (no custom shell nav forks, no custom footer replacement).
- **Route transition behaviour:** Verify same-layout navigation uses client-side routing and does not cause full document reloads.
- **Shell persistence:** Verify shared shell regions (Header/Footer/context controls) remain mounted across same-layout route changes.
- **Main content container parity:** Verify main content renders directly within PaceAppLayout shell `<main>` (without extra Card/CardContent wrappers).
- **Trigger coverage:** Verify navigation rules hold for menu navigation, in-page actions/buttons, and programmatic route transitions.
- **New-tab exception:** Verify explicit new-tab navigation performs full render in the new tab and recovers session/context-derived theme state consistently.
- **Responsive shell:** Verify shell visibility and sizing rules at `sm`, `md`, `lg`, and `xl` breakpoints.
- **Minimal layout:** Verify `layoutVariant='minimal'` hides switcher, nav, and context selector; logo and user menu remain.
- **App switcher passthrough:** Verify custom `appSwitcherItems` render in AppSwitcher dropdown.
- **Extra menu actions:** Verify `extraMenuActions` appear in UserMenu and invoke handlers.
- **Recovery UI:** Verify `ErrorBoundary` and `LoadingSpinner` are available and functional in route or async content contexts.

## Testing requirements

- Integration tests for PaceAppLayout (nav rendering, optional guards), ErrorBoundary (catch and display), LoadingSpinner. Coverage per Standard 08.

## Do not

- Do not add Form, DataTable, Toast, or file upload in this slice. Do not copy old implementation; implement from this spec.
- Do not inject custom `headerActions` or `customUserMenu` style overrides into PaceAppLayout.
- Do not import and use `Header` directly in consuming apps.
- Do not implement a floating top-level page root that bypasses PaceAppLayout shell main container.

## References

- [CR05d – Footer support and privacy](./CR05d-footer-support-and-privacy.md)
- [7-visual-standards.md](../../../packages/core/docs/standards/7-visual-standards.md), [5-pace-core-compliance-standards.md](../../../packages/core/docs/standards/5-pace-core-compliance-standards.md), [2-architecture-standards.md](../../../packages/core/docs/standards/2-architecture-standards.md). API reference components (reference only).

---

## Prompt to use with Cursor

Implement the feature described in this document. Follow the standards and guardrails provided. Add or update tests and demo as specified. Run validate and fix any issues until it passes.
