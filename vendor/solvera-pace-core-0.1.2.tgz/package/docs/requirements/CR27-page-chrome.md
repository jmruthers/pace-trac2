# CR27 – Page chrome

*In-page chrome primitives: breadcrumb trail, page header, empty state, and entity hero band. Distinct from CR05c shell (`PaceHeader`) and CR09 public layout.*

## Overview

- **Purpose:** Reusable page-level chrome inside authenticated route content so consuming apps stop ad-hoc `<h1>` + back-button layouts.
- **Scope:** Package exports + demo/styles showcase examples.
- **Dependencies:** [CR05a-primitives.md](./CR05a-primitives.md) (Button, Card, Badge).
- **Standards:** 05 pace-core compliance, 06 Code quality, 07 Visual.

## Acceptance criteria

- [x] `Breadcrumb`, `PageHeader`, `EmptyState`, `EntityHero` exported from `@solvera/pace-core/components`.
- [x] Optional sub-exports `HeroLogo`, `HeroBadge` for EntityHero media slots.
- [x] All use design tokens (main/sec/acc); semantic HTML; no inline styles; no typography utility classes on semantic headings.
- [x] Demo or styles showcase renders each export.

## API / Contract

**Exports:** From `packages/core/src/components/advanced-ui/` — `Breadcrumb`, `PageHeader`, `EmptyState`, `EntityHero`, `HeroLogo`, `HeroBadge`.

### Breadcrumb

- **Props:** `items: { label: string; href?: string }[]` — last item is current page (`aria-current="page"`).
- **Root:** `<nav aria-label="Breadcrumb">`.

### PageHeader

- **Props:** `title: string`, `subtitle?: ReactNode` (plain text or inline links such as `Button variant="link"` inside the subtitle paragraph), `breadcrumbItems?: BreadcrumbItem[]`, `actions?: ReactNode` (hub CTAs, etc.).
- **Root:** `<section>` with breadcrumb (when provided), `<h1>`, optional subtitle, optional actions slot.
- **Note:** This is **not** `PaceHeader` / `PublicPageHeader`.

### EmptyState

- **Props:** `title: string`, `description?: string`, `action?: ReactNode` (typically Button), `compact?: boolean`.
- **Root:** `<section>` centred empty content pattern.

### EntityHero

- **Props:** `media?: ReactNode`, `eyebrow?: string`, `title: ReactNode`, `meta?: EntityHeroMetaRow[]`, `description?: string`, `footer?: ReactNode`, `actions?: ReactNode`.
- **EntityHeroMetaRow:** `{ icon?: ReactNode; text: string; href?: string; external?: boolean }`.
- **Root:** semantic band for event/org summary (hub + application headers).

### HeroLogo / HeroBadge

- **HeroLogo:** `image?: string`, `code?: string`, `alt?: string`, `fileReference?: FileReference | null`, `supabase?: SupabaseClientLike | null`, `bucket?: string`, `className?: string` — event tile / logo slot for `EntityHero` media. Default tile is **192×192px** (`size-48`). When `fileReference` and `supabase` are set, resolves the public logo URL and renders an inline image inside the tile; falls back to `code` initials when resolution fails or the image request errors (404, etc.). Direct `image` URL remains supported for pre-resolved assets. Optional `className` overrides layout on the tile wrapper only.
- **HeroBadge:** `code: string` — organisation badge slot.

## Visual specification

- Follow [7-visual-standards.md](../standards/7-visual-standards.md) Part C medium/large size groups.
- **PageHeader actions:** bottom-aligned or header-row grid; use grid not flex for two-dimensional action placement where needed.
- **EntityHero:** grid layout — media column + body column + optional actions column on large viewports.
- **HeroLogo (EntityHero media):** default **192×192px** square tile (`size-48`); bordered, `rounded-md`, initials fallback when no image.
- **EmptyState:** medium card spacing; optional compact mode reduces vertical padding.

## Behaviour

- Breadcrumb internal links use React Router `Link` when inside router context; otherwise `<a href>`.
- EntityHero meta rows with `href` render as links; `external` adds `target="_blank"` and `rel="noreferrer"`.
- Components are presentation-only — no data fetching or routing decisions.

## Testing requirements

- Integration tests for Breadcrumb, PageHeader, EmptyState, and EntityHero. Coverage per Standard 08.
- **EntityHero integration tests** MUST cover: title and media; eyebrow and description; plain meta rows; internal and external meta links (`target="_blank"` and `rel="noreferrer"` when `external`); meta row icons; footer and actions slots.

## Do not

- Do not conflate with `PaceHeader` (CR05c) or `PublicPageHeader` (CR09).
- Do not add EventCard (CR29), KPI, Toolbar, or FilterChip in this slice.

## References

- Prototype: `pace-prototype/apps/_shared/chrome.jsx`
- [CR05c-layout-and-shell.md](./CR05c-layout-and-shell.md)

---

## Prompt to use with Cursor

Implement the feature described in this document. Follow the standards and guardrails provided. Add or update tests and demo as specified. Run validate and fix any issues until it passes.
