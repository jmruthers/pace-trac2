# RBAC module

*Enrichment complete (reverse-engineering pass): API/Contract signatures, Behaviour MUSTs, Demo step-by-step, References with inline examples.*

## Overview

- **Purpose:** Role-based access control: config, engine, secure Supabase client, hooks (useRBAC, useCan, useResourcePermissions, usePermissionLevel, useSecureSupabase, etc.), guards (PagePermissionGuard, NavigationGuard, AccessDenied), and audit. All permission checks and data access go through this module.
- **Scope:** Package only; demo and other features depend on it.
- **Dependencies:** 03-auth-and-context (organisation and auth). Uses existing RLS and RBAC tables/functions; no schema creation.
- **Standards:** 03 Security & RBAC, 05 pace-core compliance, 04 API & tech stack.

## Candidate integration scope (TRAC2 pace-core2)

- Candidate 1 (event-scoped CRUD scaffold): RBAC defines the secure client and permission preconditions consumed by CR16.
- Candidate 2 (attachment lifecycle primitives): RBAC secure/storage-capable client requirements apply to attachment reads/writes and signed-access flows.
- Candidate 3 (route/page permission mapping helper): this requirement owns the permission-check contract consumed by route/page mapping metadata.
- Candidate 7 (print/export primitives): authorization for print/export actions remains in this module, but print/export composition is deferred until multi-app roadmap evidence is confirmed.

## Acceptance criteria

- [x] RBAC config initialization is consumer-facing through `setupRBAC`; low-level config mutators/getters remain internal implementation details.
- [x] Secure client: createSecureClient / useSecureSupabase; all data access and Edge function invokes via this client; no direct createClient for app queries or Edge invokes. The secure client MUST expose `rpc`, `from`, `auth`, `storage` (when configured), and `functions` (Supabase Edge Functions) so that `secureSupabase.functions.invoke(name, options)` is available and uses the same underlying client/session as `rpc`/`from`. All database and Edge operations (including recordLogin and admin Edge functions such as create-user, reset-password) MUST go through the pace-core–provided secure boundary; apps MUST NOT use the raw base client only for Edge invokes.
- [x] Engine/API: isPermitted, isPermittedCached, getPermissionLevel, getPermissionMap, getRoleContext; page permissions are runtime-composed from DB page names via toPagePermission(pageName, operation). getPermissionLevel(scope) is implemented by calling getRoleContext(scope) and returning result.data.permissionLevel (or 'none' on error); the engine does not call rbac_get_access_level.
- [x] Hooks: useRBAC, useResolvedScope, useResourcePermissions, usePermissions, useCan, usePermissionLevel, useEventAppRole, useMultiplePermissions, useRoleManagement, useSecureSupabase.
- [x] Event-app role grant and revoke: useRoleManagement (or equivalent) exposes grantEventAppRole and revokeEventAppRole; event-app roles (viewer, participant, planner, event_admin) can be granted or revoked via pace-core API matching existing DB contract (rbac_role_grant / rbac_role_revoke with p_role_type: 'event_app', p_context_id: 'event_id:app_id'). Both MUST be exported from the rbac module.
- [x] Guards: PagePermissionGuard, NavigationGuard, AccessDenied component.
- [x] Adapters: withPermissionGuard, withPermissionLevelGuard, withRoleGuard (if in contract); middleware pattern if specified.
- [x] Audit: RBAC audit events/manager behavior exists as implementation detail per standard; no RLS or DB function review in this project.
- [x] Storage-capable client: pace-core provides a supported way for apps to obtain a Supabase client that implements SupabaseClientLike (including `client.storage`) for use with FileUpload, FileDisplay, and other storage operations, consistent with the existing RBAC/RLS model (same org/event context as the secure client). Implement one of: (A) extend useSecureSupabase so the returned client exposes a working `storage` API when configured; (B) a dedicated hook (e.g. useStorageCapableClient or useSupabaseStorageClient) that returns such a client for the current auth/org/event context; (C) a documented contract plus a reference implementation or adapter in pace-core that returns a storage-capable client given the same config/auth as the secure client.

## API / Contract

- **Exports:** From `packages/core/src/rbac/` (or package subpath `./rbac`): consumer-safe engine APIs, hooks, guards, permission constants/types, `setupRBAC`, createSecureClient / fromSupabaseClient / useSecureSupabase, and storage-capable client API (when implemented per acceptance criteria). Contract only.
- **Public boundary rule:** internal RBAC plumbing helpers (for example client setters/getters, app-context resolver internals, audit-manager mutators) are implementation details and MUST NOT be exported to consumer entrypoints.

### Concrete signatures and shapes

**setupRBAC(supabase: SupabaseClient<Database>, config?: Partial<RBACConfig>): void** — Call before app render (e.g. in main.tsx after client creation).

**isPermitted(input: PermissionCheck, appName?: string, precomputedSuperAdmin?: boolean | null): Promise<ApiResult<boolean>>**. **PermissionCheck:** { userId: UUID, scope: Scope, permission: Permission, pageId?: PageId | UUID }. Scope: { organisationId?: UUID, eventId?: string, appId?: UUID }.

**createSecureClient(supabaseUrl, supabaseKey, organisationId, eventId?, appId?, isSuperAdmin?): SecureSupabaseClient**. **fromSupabaseClient(client: SupabaseClient<Database>, organisationId, eventId?, appId?, resolveAppId?, isSuperAdmin?): SecureSupabaseClient**.

**useSecureSupabase(baseClient?: SupabaseClient<Database> | null): SupabaseClient<Database> | null** — Returns scoped secure client for authenticated flows when required RBAC scope is ready. Returns `null` (fail-closed) when authenticated scope is incomplete. In consuming apps, the hook MUST be called without arguments; `baseClient` is reserved for internal/test usage.

**Secure client surface (Edge functions):** The secure client MUST also expose `functions` (Supabase Edge Functions), so that `secureSupabase.functions.invoke(name, options)` is available and uses the same underlying client/session as `rpc`/`from`. All database and Edge operations (including recordLogin and admin Edge functions such as create-user, reset-password) MUST go through the pace-core–provided secure boundary; apps MUST NOT use the raw base client only for Edge invokes.

**Storage-capable client:** When approach (A) is used, useSecureSupabase returns a client that also exposes `storage` (SupabaseClientLike). When approach (B) is used, expose e.g. **useStorageCapableClient()** or **useSupabaseStorageClient()** returning a client implementing SupabaseClientLike (including `client.storage`) for the current auth/org/event context, for use with FileUpload, FileDisplay, and other storage operations. When approach (C) is used, document the contract and provide a reference implementation or adapter that, given the same config/auth as the secure client, returns such a client. Export the chosen API from the rbac package (or documented location).

**Hooks (return shape summary):** useRBAC (permission state and helpers), useCan(permission, scope?) (boolean + loading), usePageCan(pageName, operation, scope?) (typed page permission helper), useResourcePermissions(resource, operations?) (per-permission booleans), usePermissionLevel(scope?) (PermissionLevel), useEventAppRole(scope?) (`{ role: EventAppRole | null; isLoading: boolean }`), usePermissions(scope?) (permission map), useResolvedScope() (resolved scope + loading), useMultiplePermissions, useRoleManagement, useSecureSupabase; plus storage-capable client hook or extended useSecureSupabase when applicable. For page permissions (`*:page.*`), `useCan`/`usePageCan` MUST wait for resolved page scope readiness (`appId` and `organisationId`) before executing RBAC checks; while scope is incomplete they MUST remain loading and MUST NOT return deny from partial scope.

**Event-app role grant:** grantEventAppRole(supabase, params, grantedBy?): Promise<RoleManagementResult>. Types: GrantEventAppRoleParams — { user_id, event_id, app_id, role: 'viewer'|'participant'|'planner'|'event_admin', granted_by? }; RoleManagementResult — { success, error?, message?, roleId? }. Implementation MUST call supabase.rpc('rbac_role_grant', { p_user_id, p_role_type: 'event_app', p_role_name, p_context_id: 'event_id:app_id', p_granted_by }). Return shape from rbac_role_grant: array of one row with success, message, role_id, error_code. Exposed via useRoleManagement and exported from rbac module.

**Event-app role revoke:** revokeEventAppRole(supabase, params, revokedBy?): Promise<RoleManagementResult>. Same pattern as grant but calls supabase.rpc('rbac_role_revoke', { p_user_id, p_role_type: 'event_app', p_role_name, p_context_id: 'event_id:app_id', p_revoked_by }). Return shape from rbac_role_revoke: array of one row with success, message, revoked_count, error_code. Exposed via useRoleManagement and exported from rbac module.

**Required RBAC RPCs (pace DB):** The following RPCs must exist in the pace DB for RBAC and guarded pages to work. Implementation MUST follow [Security & RBAC Standards](../../../packages/core/docs/standards/3-security-rbac-standards.md) (SECURITY DEFINER, SET search_path TO public, schema-qualified references, COMMENT ON FUNCTION) and [API & Tech Stack Standards](../../../packages/core/docs/standards/4-api-tech-stack-standards.md) (RPC contract).

- **rbac_get_role_context** — Used by getRoleContext() and by getPermissionLevel() (which returns this RPC’s permissionLevel). Args: p_organisation_id uuid DEFAULT NULL, p_event_id text DEFAULT NULL, p_app_id uuid DEFAULT NULL (current user from session). Returns: single row with role (text), permissionLevel (text), organisationId (uuid, nullable), eventId (text, nullable). permissionLevel one of: none | viewer | member | leader | admin | super_admin.
- **rbac_permissions_get** — Resolves effective page permission rows for a user. Args: p_user_id uuid, p_organisation_id uuid DEFAULT NULL, p_event_id uuid DEFAULT NULL, p_app_id uuid DEFAULT NULL, p_page_id uuid DEFAULT NULL. **When `p_organisation_id` and `p_app_id` are set and `p_event_id` is null**, the function MUST union the user's active **event-app roles** for that app on any event in the organisation with their organisation roles before matching `rbac_page_permissions`. This allows org landing routes (e.g. app `/events` before event selection) to honour matrix grants for `planner`, `participant`, `viewer`, and `event_admin` without requiring a selected event. When a specific `p_event_id` is supplied, event-scoped role matching continues to apply as before.
- **rbac_check_permission_simplified** — Used by isPermitted() / isPermittedCached(). Args: p_user_id uuid, p_permission text, p_organisation_id uuid DEFAULT NULL, p_event_id uuid DEFAULT NULL, p_app_id uuid DEFAULT NULL, p_page_id text DEFAULT NULL (page name string or app-page row uuid, resolved in `rbac_app_pages`), p_rbac_session_id uuid DEFAULT NULL. Returns: boolean (or row with permitted in legacy shapes). Required for per-permission checks (e.g. read:page.financial-context). **When `p_page_id` and `p_app_id` are both non-null and the page does not resolve to a row in `rbac_app_pages` for that app, the function MUST deny (after recording denial telemetry) and MUST NOT fall through to `org_admin` / `event_admin` implicit allow.** Super Admin bypass remains unconditional. **When `p_page_id` or `p_app_id` is null**, org-level and event-app role shortcuts MAY still grant access for non-page-catalogue checks. Consuming apps MUST register each shell `pageId` in `rbac_app_pages` (and grant via `rbac_page_permissions`) so the permissions matrix and guards behave as operators expect.

**Non-default RPCs:**

- **rbac_get_access_level** — Not used by the engine. Permission level is derived from `rbac_get_role_context.permissionLevel`; pace-core does not call `rbac_get_access_level`.
- **rbac_get_permission_map** — Used by getPermissionMap() / usePermissions(). When missing, the engine returns ok({}). Add to the pace DB only if a product need for a full permission map exists.

**Diagnosing 404s:** If RBAC RPCs return 404, ensure the required RPCs (rbac_get_role_context, rbac_check_permission_simplified) exist in the pace DB (e.g. via pace-core2 or shared migrations).

**Guards:** PagePermissionGuard: pageName, operation ('read'|'create'|'update'|'delete'), children, fallback?, strictMode?, auditLog?, pageId?, scope?, onDenied?, loading?. NavigationGuard: permission (single string permission for nav-item protection). AccessDenied: (message?, etc.). Print/layout metadata (`printTitle`, `printPageOrientation`) is configured through `usePaceMain`, not through PagePermissionGuard.

**Guard modules:** `PagePermissionGuard`, `NavigationGuard`, and `AccessDenied` (PascalCase component names) each export from a dedicated module under `packages/core/src/rbac/` (`PagePermissionGuard.tsx`, `NavigationGuard.tsx`, `AccessDenied.tsx`) per [React component module filenames](../standards/1-project-structure-standards.md#react-component-module-filenames).

**Permission constants/helpers (actual exports):** GLOBAL_PERMISSIONS, ORGANISATION_PERMISSIONS, EVENT_APP_PERMISSIONS, PAGE_DOMAIN_PERMISSIONS (and ALL_PERMISSIONS aggregate), toPagePermission(pageName, operation) for typed page permission composition, and SET_ORGANISATION_CONTEXT_RPC for the platform session-context RPC name. Page permissions are DB-driven at runtime; consuming apps pass **exact** `rbac_app_pages.page_name` strings to guards/hooks. **New** pages: **PascalCase** catalogue keys matching the page file stem (`EventsPage`). **Legacy** lowercase/kebab/PascalCase values (e.g. `reports`, `member-roles`, `CommsLog`) remain valid until migrated — see [Project Structure — Legacy RBAC page names](../standards/1-project-structure-standards.md#legacy-rbac-page-names). Route paths use kebab-case and are **not** derived from `pageName`.

## Behaviour

- All app data access in consuming app feature/page code MUST go through useSecureSupabase; MUST NOT use direct createClient for app queries. `createSecureClient`/`fromSupabaseClient` are advanced constructors for library, adapter, and non-React surfaces.
- Apps that use FileUpload, FileDisplay, or other storage operations MUST obtain the Supabase client via the storage-capable client mechanism defined in this requirement (useSecureSupabase when it exposes storage, or the dedicated hook/adapter). MUST NOT use a raw createClient() for file operations except as the base client passed to the provider.
- For event-scoped file uploads that write metadata rows to `core_file_references` (for example BA01 event logo uploads from the configuration page), pace-core MUST use the `app_file_reference_create` RPC boundary with explicit `organisation_id`, `event_id`, `app_id`, and `pageContext` scope. Consumers SHOULD use canonical `FileUpload` APIs and MUST NOT implement app-side direct table inserts as a workaround.
- Secure client RPC calls MUST be fail-closed for context setup: if `set_organisation_context` is missing or returns an error, the secure client MUST throw and MUST NOT proceed with the target RPC.
- **`set_organisation_context` MUST write both `app.organisation_id` and `app.current_organisation_id` to the same organisation UUID** (transaction-local). `get_current_organisation_context()` reads `app.current_organisation_id` with fallback to `app.organisation_id`. RPCs that resolve org via `get_current_organisation_context()` (for example `app_gear_catalogue_import_rows`) MUST see the organisation the secure client just set; MUST NOT rely on `rbac_organisation_roles` fallback when the user selected a different org in the shell.
- **Advanced session-context override:** Consuming apps MAY call `SET_ORGANISATION_CONTEXT_RPC` on the **base** Supabase client when they must set org/event/app context outside the secure wrapper (for example event-host organisation context for submission writes). This is a documented advanced exception — not a general escape hatch from useSecureSupabase. Import the constant from `@solvera/pace-core/rbac`; do not hard-code the RPC name string.
- For authenticated scoped operations, useSecureSupabase MUST fail closed when `organisationId` is unresolved or when configured `appName` has unresolved `appId`; it MUST NOT return a raw base client for these paths.
- For write paths whose authorization depends on app/org/event context, consuming apps SHOULD use an RPC write boundary that accepts explicit scope parameters and executes permission check plus mutation within one DB transaction.
- Consuming apps MUST NOT call `fromSupabaseClient(...)` in page/feature code and MUST NOT perform raw base-client scoped mutations in those surfaces.
- Use [RBAC Consumer Cutover Checklist](../reference/rbac-consumer-cutover-checklist.md) when migrating apps to strict fail-closed RBAC flow.
- setupRBAC MUST be called before app render (e.g. in main after client creation). The `appName` passed to `setupRBAC` MUST be the same value used by the app for `UnifiedAuthProvider` and login/layout components; see Standard 5 (pace-core compliance) for declaration and usage. PagePermissionGuard MUST render fallback when permission denied and remain focused on access control. Print/layout metadata is declared per-page via `usePaceMain`.
- Resolved app ID MUST come from RBAC scope resolution (`setupRBAC` + `getAppId` when `appName` is configured) and be consumed via `useResolvedScope().appId` or `useRBAC().appId`.
- Page-level route protection MUST use `PagePermissionGuard(pageName, operation)`. Page-level CRUD UI checks SHOULD prefer `useResourcePermissions('<page-name>')` with canonical DB page names. Page keys MUST be **lowercase kebab-case** slugs identical to `rbac_app_pages.page_name` and to the segment after `page.` in permission strings (see Standard 3 — Page key naming). `useCan(permission, scope?)` remains available for non-CRUD/domain actions (for example `approve:page.<slug>`) and explicit programmatic checks.
- Page permissions MUST be evaluated only after scope readiness for route/page checks: `appId` and `organisationId` must be present before RBAC permission RPC evaluation. During scope resolution, guards/hooks must surface loading (or defer rendering) rather than transient deny states.
- **Page catalogue fail-closed:** For checks where `p_page_id` + `p_app_id` are both supplied, `rbac_check_permission_simplified` MUST return false when no matching row exists in `rbac_app_pages` for that app (after denial telemetry). Event Admin and Org Admin MUST NOT receive implicit access in that case. Super Admin bypass is unchanged. For a **catalogued** page, access still requires explicit `rbac_page_permissions` grants for that role (matrix evaluation); Event Admin is not a blanket bypass for registered pages.
- Route and navigation permission metadata should be derived from a single typed mapping source where possible; use `CR18-route-page-permission-mapping-helper.md` for the canonical helper contract to reduce drift between route config and guard config.
- For authenticated shells using `PaceAppLayout`, consuming apps MUST pass `userFullName`, `userEmail`, `onUserMenuSignOut`, and `onUserMenuChangePassword` so the user menu always exposes identity and wired account actions.

### Migration impact (fail-closed context setup)

- Existing apps that relied on silent fallback behavior for `set_organisation_context` will now receive explicit runtime errors on secure RPC calls.
- Before upgrading, verify the `set_organisation_context` RPC exists and is callable with the current auth/session in each environment.
- Keep `setupRBAC` initialization in bootstrap code and pass the same `appName` constant to both `setupRBAC` and `UnifiedAuthProvider`.
- When `appName` is configured, provide `getAppId` in `setupRBAC` and ensure it resolves active app IDs for the authenticated user.
- Treat any new context setup error as a deployment/configuration issue and resolve it before enabling app traffic.

## Demo app requirements

- Demo uses PagePermissionGuard on at least one protected page; uses useResourcePermissions('<page-name>') or useCan for a button or action. User with sufficient role can access; otherwise AccessDenied or equivalent.
- **Step-by-step:** At least one protected page uses PagePermissionGuard (pageName, operation). User with sufficient role sees content; user without sees AccessDenied or fallback. At least one action (e.g. button) uses useCan or useResourcePermissions to show/hide or enable/disable.

## Verification

- **Secure boundary:** Verify data and Edge operations use the pace-core secure client surface (`from`, `rpc`, `functions`, and configured `storage`) rather than raw client usage in feature code.
- **Permission checks:** Verify `PagePermissionGuard` and hook-based checks (`useCan` / `useResourcePermissions`) enforce grant/deny behaviour for scoped permissions.
- **Contract parity:** Verify required RPCs and exported constants/hooks align with this module contract.
- **Manual — `rbac_check_permission_simplified` (post-migrate on a dev DB):** With no `rbac_app_pages` row for a given `page_name` under the target app, call the RPC as **event_admin** (not super_admin) with non-null `p_app_id`, `p_page_id` set to that page slug, org/event scope populated, and a page permission such as `read:page.<slug>` — expect **`false`**. With **`p_page_id` null** and a permission that is intentionally governed by role bypass, elevated roles may still receive **`true`**. Super_admin should still receive **`true`** for any inputs. For a catalogued page with explicit matrix grants, expect grant behaviour unchanged.
- **Manual — org landing + event-app role (FU-018):** User with org role `member` and event-app role `planner` on app GEAR for an event in the org. Matrix grants `planner` read on `DashboardPage`. Call `rbac_check_permission_simplified` with org + GEAR app + `DashboardPage`, **`p_event_id` null** — expect **`true`**. User with only `member` org role and no event-app roles for GEAR — expect **`false`** when matrix does not grant `member` read on that page.

## Testing requirements

- Unit tests for engine/api and hooks; integration tests for guards in colocated files: `AccessDenied.integration.test.tsx`, `PagePermissionGuard.integration.test.tsx`, `NavigationGuard.integration.test.tsx`. Coverage per Standard 08. Critical: permission grant/deny, scope resolution, secure client usage.

## Do not

- Do not create or alter RLS policies or database functions; use existing schema. Do not copy old implementation; implement from this spec and RBAC contract.

## References

- [3-security-rbac-standards.md](../../../packages/core/docs/standards/3-security-rbac-standards.md), [4-api-tech-stack-standards.md](../../../packages/core/docs/standards/4-api-tech-stack-standards.md), [5-pace-core-compliance-standards.md](../../../packages/core/docs/standards/5-pace-core-compliance-standards.md). packages/core/docs/rbac/RBAC_CONTRACT.md and api-reference (reference only). Storage-capable client for file upload/display (pace-admin request); FileUpload/FileDisplay require client with storage (CR08).
- [CR16-event-scoped-crud-scaffold.md](./CR16-event-scoped-crud-scaffold.md)
- **Inline — PermissionCheck:** `{ userId: user.id, scope: { organisationId: selectedOrganisation?.id, eventId, appId }, permission: 'read:users', pageId?: 'page-uuid' }`.
- **Inline — PagePermissionGuard + usePaceMain:** `usePaceMain({ printTitle: 'Dashboard', printPageOrientation: 'portrait' });` and `<PagePermissionGuard pageName="dashboard" operation="read" fallback={<AccessDenied />}><DashboardPage /></PagePermissionGuard>`.

---

## Prompt to use with Cursor

Implement the feature described in this document. Follow the standards and guardrails provided. Add or update tests and demo as specified. Run validate and fix any issues until it passes.
