# pace-core Architecture

## Filename convention

This document follows:

`**CR00-core-architecture.md**`


| Segment            | Meaning                                    |
| ------------------ | ------------------------------------------ |
| `**CR**`           | Core requirement series.                   |
| `**00**`           | Foundation slot shared with project brief. |
| `**core**`         | Product slug.                              |
| `**architecture**` | Document type.                             |


---

pace-core is the shared foundation package for the pace-suite. This architecture defines bounded contexts, public contract boundaries, and how requirement slices CR02–CR26 compose into a coherent package and demo verification model (including shared workflow-typed forms, reporting foundations, and itinerary derivation where applicable).

---

## Design principles

- Contract-first package design: define stable interfaces and behaviour before implementation details.
- Secure-by-default data access: all app data and Edge-function operations run through pace-core secure client boundaries.
- Standards-driven consistency: implementation follows standards 00-09 with no lint/audit silencing.
- Reuse over duplication: consuming apps compose package exports instead of re-implementing platform concerns.
- Clear ownership boundaries: pace-core owns shared contracts and tooling; external schema ownership stays outside this repo.

---

## Table of contents

- [Section 1 Foundation and quality system](#section-1-foundation-and-quality-system)
- [Section 2 Identity context and access control](#section-2-identity-context-and-access-control)
- [Section 3 UI system and shell composition](#section-3-ui-system-and-shell-composition)
- [Section 4 Data interaction and feedback surfaces](#section-4-data-interaction-and-feedback-surfaces)
  - [Shared workflow forms and reporting foundations (CR20–CR22)](#shared-workflow-forms-and-reporting-foundations-cr20cr22)
  - [Shared itinerary derivation foundations (CR26)](#shared-itinerary-derivation-foundations-cr26)
- [Section 5 Public and shared application surfaces](#section-5-public-and-shared-application-surfaces)
- [Section 6 Services read-model and resilience contracts](#section-6-services-read-model-and-resilience-contracts)
- [Section 7 Session analytics theming and platform adapters](#section-7-session-analytics-theming-and-platform-adapters)
- [Section 8 Demo verification and delivery contract](#section-8-demo-verification-and-delivery-contract)

---

## Section 1 Foundation and quality system

### Overview

- Purpose and scope: establish core types, utility contracts, styling tokens, export governance, and authority boundaries.
- Dependencies: none.
- Requirement slices: CR02.
- Standards: 01, 04, 06, 07, 08.

### Acceptance criteria

- Core type contracts and ApiResult helpers are stable and exported.
- Utility contracts (formatting, validation, timezone helpers, logging) are stable and exported.
- Tailwind v4 token foundation (`main`/`sec`/`acc`) is package-canonical.
- Export governance and documentation authority checks are validated.

### API / Contract

- Public exports: `types`, `utils`, `styles/core.css`, consumer export index/governance metadata.
- Public service contracts: ApiResult and utility signatures documented in CR02.
- File paths: `packages/core/src/types/*`, `packages/core/src/utils/*`, `packages/core/src/styles/core.css`.
- **Source layout (components):** `packages/core/src/components/` is organized by feature folders (`primitives/`, `overlays/`, `shell/`, `forms-feedback/`, `auth/`, `advanced-ui/`, `data-table/`, `public-layout/`). Only `index.ts` and feature folders are allowed at the components root. Internal modules (e.g. `overlays/select/internal/ListboxBase.tsx`, `public-layout/DefaultPublicPageError.tsx`) are not re-exported from the public barrel.
- Table ownership: none in this context.

### Verification

- Run package export/governance checks and confirm documented type/function signatures.
- Confirm consuming app CSS wiring imports `@solvera/pace-core/styles/core.css` and token palettes.

### Testing requirements

- Utility unit test coverage for critical formatter/validation/timezone functions.

### Do not

- Do not introduce feature-specific UI or auth/RBAC behaviour in foundation contracts.

### References

- [CR02-foundation-types-utils-styles.md](./CR02-foundation-types-utils-styles.md)

---

## Section 2 Identity context and access control

### Overview

- Purpose and scope: provide authentication/session context, organisation/event context, RBAC checks, secure client boundaries, and guarded route/page behaviour.
- Dependencies: Section 1.
- Requirement slices: CR03, CR04.
- Standards: 03, 04, 05.

### Acceptance criteria

- Auth providers and protected routing are stable and consumable.
- Organisation/event context works for normal and super-admin scopes.
- RBAC engine/hook contracts and secure client boundaries enforce permissioned data access.
- Edge functions and storage operations are available through the same secure boundary.

### API / Contract

- Public exports: `UnifiedAuthProvider`, `OrganisationServiceProvider`, `ProtectedRoute`, `useUnifiedAuth`, `useOrganisations`, RBAC hooks/guards and `setupRBAC`.
- Public service contracts: permission checks, role-management functions, secure client wrapper contract.
- File paths: `packages/core/src/providers/*`, `packages/core/src/rbac/*`, `packages/core/src/hooks/*`.
- Tables/RPC contracts: RBAC RPC set and existing org/auth tables per CR03/CR04.

### Verification

- Verify redirect/session restoration flow, super-admin org list behaviour, and guard grant/deny paths.
- Verify all data/Edge operations flow through secure client APIs.

### Testing requirements

- Integration tests for auth/route protection and RBAC guard/hook behaviour.

### Do not

- Do not bypass secure client boundaries or add global auth gates that violate Standard 05.

### References

- [CR03-auth-and-context.md](./CR03-auth-and-context.md)
- [CR04-rbac.md](./CR04-rbac.md)

---

## Section 3 UI system and shell composition

### Overview

- Purpose and scope: define primitives, overlays, and application shell contracts used by all consuming app pages.
- Dependencies: Sections 1 and 2.
- Requirement slices: CR05a, CR05b, CR05c.
- Standards: 02, 05, 07.

### Acceptance criteria

- Primitive component surfaces are stable and standards-compliant.
- Dialog/select/tabs composition follows documented behavioural and visual recipes.
- Shell contract (`PaceAppLayout`, `PaceHeader`, `PaceMain`, `PaceFooter`) is fixed and reusable.
- Responsive shell interactions and metadata hooks (`usePaceMain`) are implemented.

### API / Contract

- Public exports: primitive components, Dialog/Select/Tabs family, shell components, `usePaceMain`, recovery components.
- File paths: `packages/core/src/components/*`.
- UI contract ownership: semantic markup and token usage per requirement visual specs.

### Verification

- Validate showcase and shell routes render package components only.
- Validate responsive header/menu/user trigger behaviours and single-main-landmark discipline.

### Testing requirements

- Component and integration tests for primitives, overlays, and shell navigation/recovery surfaces.

### Do not

- Do not allow consuming apps to replace shell-controlled regions with custom equivalents.

### References

- [CR05a-primitives.md](./CR05a-primitives.md)
- [CR05b-dialog-select-tabs.md](./CR05b-dialog-select-tabs.md)
- [CR05c-layout-and-shell.md](./CR05c-layout-and-shell.md)

---

## Section 4 Data interaction and feedback surfaces

### Overview

- Purpose and scope: standardize forms, user feedback, and DataTable capabilities from baseline through advanced workflows; extend with **metadata-driven field registry**, **workflow-typed public forms**, and **shared reporting** per CR20–CR22.
- Dependencies: Sections 1 to 3.
- Requirement slices: CR06, CR07a, CR07b, CR20, CR21, CR22.
- Standards: 04, 05, 07, 08.

### Acceptance criteria

- Form infrastructure and feedback patterns are reusable and composable.
- Login and password-change UX contracts are stable.
- DataTable core (sort/pagination/export) and advanced features (server-side, filters, import/edit/grouping/hierarchy) are contract-defined.
- RBAC-aware action visibility and behaviour are enforced where required.

### API / Contract

- Public exports: form hooks/components, toast APIs, DataTable APIs/types/hooks/factory/export helpers.
- File paths: `packages/core/src/components/*`, `packages/core/src/hooks/*`, `packages/core/src/utils/*`.

### Verification

- Verify form validation/submission and toast feedback flows.
- Verify DataTable slice behaviour and feature-flag defaults, including RBAC gating and server/client parity.

### Testing requirements

- Unit and integration coverage for form hooks/components and table state/feature behaviour.

### Do not

- Do not collapse CR07a and CR07b scope boundaries or reintroduce custom non-package form/table implementations.

### References

- [CR06-forms-and-feedback.md](./CR06-forms-and-feedback.md)
- [CR07a-datatable.md](./CR07a-datatable.md)
- [CR07b-datatable.md](./CR07b-datatable.md)
- [CR07c-datatable.md](./CR07c-datatable.md)
- [CR20-form-registry-and-address-field.md](./CR20-form-registry-and-address-field.md)
- [CR21-workflow-forms-runtime.md](./CR21-workflow-forms-runtime.md)
- [CR22-shared-reporting-foundations.md](./CR22-shared-reporting-foundations.md)

### Shared workflow forms and reporting foundations (CR20–CR22)

- **CR20** — Dynamic **field registry** and **`AddressField`** with provider adapters: reusable metadata-driven controls and validation for forms; domain-neutral `field_type` mapping.
- **CR21** — **Workflow-typed forms runtime**: `field_key` semantics, workflow/access-mode contracts, public entrypoint UX (with CR09), pre-submission checks, registration-type selection, and transport-agnostic submission payloads. Aligns with the shared **`core_forms`** platform; domain writes stay in app orchestrators and database RPCs (see CR21 **Forms platform architecture (canonical)**).
- **CR22** — **Shared reporting**: hybrid model — field catalogue and templates in the database, **join topology in TypeScript explores**, query planning and report-builder primitives in the package. Runtime **scope** is always app-supplied at execution time.

### Shared itinerary derivation foundations (CR26)

- **CR26** — **Shared itinerary derivation helper**: pure package-level derivation for participant/planner itinerary outputs across TRAC, Portal, and other consumers. Owns day-entry expansion, participant-only narrowing filter support, timezone precedence, in-day ordering, and derived date-range/day-group metadata. Does **not** own fetching, RLS, app routes, or planner CRUD.

---

## Section 5 Public and shared application surfaces

### Overview

- Purpose and scope: provide advanced app UI primitives (date/time, files, context selector, inactivity warning) and public-page contracts.
- Dependencies: Sections 1 to 4.
- Requirement slices: CR08, CR09.
- Standards: 03, 05, 07.

### Acceptance criteria

- Advanced UI contracts support secure file flows, timezone-aware date/time UX, and context-driven behaviour.
- Public-page providers/layout/hooks allow unauthenticated public content without leaking protected data.
- Context selector and dynamic theme integration points are explicit.

### API / Contract

- Public exports: advanced UI components/hooks, public layout/provider/hooks.
- File paths: `packages/core/src/components/*`, `packages/core/src/hooks/*`.

### Verification

- Verify file upload/display, context switching, and inactivity modal behaviour.
- Verify public route loading without auth redirect and public-data-only boundaries.

### Testing requirements

- Integration tests for advanced components and public-page hooks/layout.

### Do not

- Do not expose protected org/RBAC data through public contracts.

### References

- [CR08-advanced-ui.md](./CR08-advanced-ui.md)
- [CR09-public-pages.md](./CR09-public-pages.md)

---

## Section 6 Services read-model and resilience contracts

### Overview

- Purpose and scope: define service/provider abstractions, event read-model derivation, shared itinerary derivation, and multi-source resilience composition.
- Dependencies: Sections 1, 2, and 5.
- Requirement slices: CR10, CR17, CR18, CR26.
- Standards: 02, 04, 06, 09.

### Acceptance criteria

- Service interfaces/providers expose stable consumer surfaces.
- Shared selected-event derivation and normalization prevents divergent local logic.
- Shared itinerary derivation prevents consumer apps from re-implementing day-entry, timezone, and ordering rules.
- Composite resilience utilities provide deterministic loading/partial/success/error semantics.

### API / Contract

- Public exports: service/provider hooks/interfaces, event read-model helpers, itinerary derivation helpers, resilience utilities.
- File paths: `packages/core/src/services/*`, `packages/core/src/providers/*`, `packages/core/src/events/*`, `packages/core/src/itinerary/*`, `packages/core/src/resilience/*`.

### Verification

- Verify service hooks consume shared read-model helper contracts.
- Verify consuming apps can share itinerary derivation outputs from one package contract.
- Verify multi-source consumers expose resilience metadata consistently.

### Testing requirements

- Unit and integration tests for service contracts, event derivation precedence, itinerary derivation, and resilience composition.

### Do not

- Do not embed app-specific domain formulas or provider-specific policy in these shared contracts.

### References

- [CR10-services-and-providers.md](./CR10-services-and-providers.md)
- [CR17-derived-event-read-model-helper.md](./CR17-derived-event-read-model-helper.md)
- [CR18-composite-resilience-utilities.md](./CR18-composite-resilience-utilities.md)
- [CR26-shared-itinerary-derivation-helper.md](./CR26-shared-itinerary-derivation-helper.md)

---

## Section 7 Session analytics theming and platform adapters

### Overview

- Purpose and scope: define shared contracts for login history recording, dynamic theming, event-scoped CRUD scaffolds, stats hooks, and location/timezone adapter interfaces.
- Dependencies: Sections 1 to 6.
- Requirement slices: CR11, CR12, CR13, CR14, CR15, CR16, CR19.
- Standards: 03, 04, 07, 08, 09.

### Acceptance criteria

- Demo route map remains aligned with requirement slices and guard/layout contracts.
- Supabase/React Query error policy is normalized and reusable.
- Organisation/system stats, login history, and dynamic theming contracts are stable.
- Event-scoped CRUD and attachment lifecycle contracts stay secure and adapter-driven.
- Location/timezone interfaces remain provider-agnostic and cache-contract driven.

### API / Contract

- Public exports: error utilities, stats hooks, login history helper/hook, theming runtime/hooks, CRUD scaffold contracts, location/timezone adapters.
- File paths: `packages/core/src/utils/*`, `packages/core/src/hooks/*`, `packages/core/src/theming/*`, `packages/core/src/crud/*`, `packages/core/src/location/*`.

### Verification

- Verify each contract through targeted demo flows and package-level tests.
- Verify integration boundaries (secure client, theme root application, provider-agnostic adapters) remain intact.

### Testing requirements

- Unit and integration tests per requirement slices with emphasis on contract stability and secure boundaries.

### Do not

- Do not move schema ownership, vendor implementation details, or app-specific business logic into pace-core contracts.

### References

- [CR11-demo-pages.md](./CR11-demo-pages.md)
- [CR12-supabase-react-query-error-handling.md](./CR12-supabase-react-query-error-handling.md)
- [CR13-organisation-stats-hooks.md](./CR13-organisation-stats-hooks.md)
- [CR14-login-history.md](./CR14-login-history.md)
- [CR15-dynamic-theming.md](./CR15-dynamic-theming.md)
- [CR16-event-scoped-crud-scaffold.md](./CR16-event-scoped-crud-scaffold.md)
- [CR19-location-timezone-adapter-interfaces.md](./CR19-location-timezone-adapter-interfaces.md)

---

## Section 8 Demo verification and delivery contract

### Overview

- Purpose and scope: define how the root demo app verifies package capabilities and keeps route/permission/layout parity.
- Dependencies: all architecture sections.
- Requirement slices: CR11 plus all referenced slices.
- Standards: 01, 05, 08.

### Acceptance criteria

- Demo route coverage maps to requirement slices and is navigable via package shell.
- Protected/public route boundaries remain correct.
- `npm run validate` is consistently passing with package and demo checks.

### API / Contract

- Public exports: not applicable; this is a consumer verification surface.
- Paths: root `src/App.tsx`, `src/pages/*`, demo wiring docs.

### Verification

- Run manual route walkthrough plus full validate pipeline.

### Testing requirements

- Keep smoke coverage where useful; rely on package-level tests for component/contract correctness.

### Do not

- Do not duplicate package components or bypass package layout/guard contracts in demo code.

### References

- [CR11-demo-pages.md](./CR11-demo-pages.md)

---

## Prompt to use with Cursor

Implement the feature described in this document. Follow standards and guardrails. Add or update tests and verification flows as specified in each referenced requirement slice. Run validate and fix issues until it passes.
