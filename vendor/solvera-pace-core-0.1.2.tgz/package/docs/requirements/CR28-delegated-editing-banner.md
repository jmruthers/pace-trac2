# CR28 – Delegated editing and section banners

*Presentation-only banner composites for proxy/delegated editing mode and multi-link section callouts (profile gate, status bands).*

## Overview

- **Purpose:** Shared banner UX for delegated editing (proxy mode) and rich section callouts with optional actions/links.
- **Scope:** Package exports + demo example.
- **Dependencies:** [CR05a-primitives.md](./CR05a-primitives.md) (Alert, Badge, Button).
- **Standards:** 05 pace-core compliance, 07 Visual.

## Acceptance criteria

- [x] `ProxyModeBanner` (alias acceptable: `DelegatedEditingBanner`) exported.
- [x] `SectionBanner` exported.
- [x] Presentation-only — no session storage, RPC validation, or org context switching.
- [x] Demo or styles showcase renders both components.

## API / Contract

**Exports:** From `packages/core/src/components/advanced-ui/` (ProxyModeBanner, SectionBanner)

### ProxyModeBanner

- **Props:** `targetDisplayName: string`, `onExit: () => void`, `description?: string`, `className?: string`.
- **Root:** `<output role="status">` or `<section role="status">` with target name, optional description, exit Button.
- **Non-scope:** session persistence, permission checks (apps own via hooks).

### SectionBanner

- **Props:** `variant?: 'default' | 'destructive'` (maps to Alert tones), `title?: string`, `description?: ReactNode`, `status?: string` (optional Badge label), `actions?: ReactNode`, `className?: string`.
- **Root:** `<section role="status">` (or `role="alert"` when destructive).
- **Use case:** Profile gate on event hub with deep links in `actions` slot; richer than plain Alert for multi-link callouts.

## Visual specification

- Compose Alert/Badge/Button primitives; main/sec/acc tokens only.
- Full-width band within page content column; medium size group.

## Behaviour

- `onExit` on ProxyModeBanner MUST be wired by consuming app (clears proxy session).
- SectionBanner `actions` slot is opaque ReactNode — apps supply links/buttons.

## Do not

- Do not implement proxy session logic in pace-core.
- Do not fetch profile completeness — apps pass copy and links.

## References

- Prototype: proxy banner in MembershipsPages; SectionBanner in `_shared/feedback.jsx`

---

## Prompt to use with Cursor

Implement the feature described in this document. Follow the standards and guardrails provided. Add or update tests and demo as specified. Run validate and fix any issues until it passes.
