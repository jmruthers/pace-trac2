# R15 – Dynamic theming (event/org colours from DB)

*Load colour/palette data from the database for the selected event (and optionally organisation) and apply it so the UI is themed via CSS variables; clear or revert to app defaults when no selection or on change.*

## Overview

- **Purpose:** Load colour/palette data from the database for the selected event (and optionally organisation) and apply it so the UI is themed (CSS variables `--color-main-*`, `--color-sec-*`, `--color-acc-*`) in the style of the selected event/org; clear or revert to app defaults when no selection or on change.
- **Scope:** Package + demo (demo shows theme change when switching event/org).
- **Dependencies:** R02 (foundation styles/tokens), R03 (auth/context), R10 (EventService / OrganisationService or equivalent so "selected event/org" is defined). No new DB schema: assume palette is stored in existing event/org data (e.g. `event_colours`, or org theme fields) per existing schema.
- **Standards:** 07 Visual (design tokens, no arbitrary values), 04 API & tech stack.

## Candidate integration scope (TRAC2 pace-core2)

- Candidate 4 (derived event read-model helper): event/org palette lookup should consume the shared selected-event hydration and fallback contract in R17 rather than redefining precedence locally.
- Candidate 6 (location cache + timezone adapters): no location provider logic is added here; theming remains independent of provider-specific geocoding/timezone infrastructure.

## Acceptance criteria

- [x] Palette data for the selected event (and optionally organisation) is loaded from the database (via existing RPC/client and data shapes).
- [x] When the selected event (or org, if in scope) has palette data, the app applies it so that CSS variables (`--color-main-*`, `--color-sec-*`, `--color-acc-*`) are updated and the UI reflects the theme.
- [x] When selection changes, the applied theme updates (new palette applied or cleared to app defaults).
- [x] When there is no selected event/org or no palette data, the UI uses app default theme (no stale theme from a previous selection).
- [x] Contract: package exports a theming runtime (e.g. `applyPalette`, `clearPalette`) and hooks (`useTheme`, `useContextTheme`) so consuming apps can achieve the above without reimplementing logic; demo uses **`useContextTheme()`** at app root so that switching event/org in the context selector updates the visible theme.

## API / Contract

- **Exports:** From package (e.g. `theming` and hooks): `applyPalette(paletteData)`, `clearPalette()`, and optionally `generateSSRThemeCSS`, `isDynamicThemingActive`, `getCurrentThemeData`; hooks `useTheme(palette)` (theme-agnostic, for event or organisation) and `useContextTheme()` (derives palette from selected event/org and calls `useTheme`); helpers `getPaletteFromEvent(event)`, `getPaletteFromOrganisation(organisation)`. Types: `PaletteData`, `PaletteShades` (see data contract below).
- **Palette data structure (runtime):** Matches the design tokens at the base of `@theme static` in app.css: `main`, `sec`, `acc`, each with **required** `raw` and shades `50`, `100`, `200`, … `950`. Values are OKLCH strings (e.g. `oklch(0.7 0.057 252.02)`). `PaletteData`: `{ main: PaletteShades, sec: PaletteShades, acc: PaletteShades }`. See `packages/core/src/theming/types.ts` for TypeScript types.
- **Stored JSON (database / legacy):** `core_events.event_colours` (and equivalent writers) may store a **legacy** object with top-level keys **`ev-main`**, **`ev-sec`**, **`ev-acc`**, each mapping shade keys (`raw`, `50`–`950`) to **OKLCH components** `{ L, C, H }` (numbers). **`getPaletteFromEvent`** and **`getPaletteFromOrganisation`** normalise that shape to **`PaletteData`** by emitting `oklch(L C H)` strings. New data **MAY** use canonical `PaletteData` JSON (`main` / `sec` / `acc` with string values) instead; both shapes are accepted.
- **Where palette comes from:** Event: `event.event_colours` or `event.palette` or `event.theme` (EventStub); EventService `select('*')` includes columns present on the row. Organisation: `organisation.settings?.theme` or `settings?.palette`. Use `getPaletteFromEvent` / `getPaletteFromOrganisation` to read, validate, and normalise; they return `PaletteData | null`.
- **Context selection:** [R08 – ContextSelector](./R08-advanced-ui.md) updates **`selectedEvent`** / **`selectedOrganisation`** in auth context. **`useContextTheme()`** reads those values, resolves palette (event first, then organisation), and calls **`useTheme`**, which applies or clears CSS variables on **`document.documentElement`**. Consuming apps MUST mount **`useContextTheme()`** at shell level when using ContextSelector (see [R05c](./R05c-layout-and-shell.md)).
- **Runtime:** `applyPalette` sets global CSS custom properties (same names as `@theme static`) on the document root; no style tags or inline style blocks. `clearPalette` removes those properties so app default applies.
- **Hooks:** `useTheme(palette)` — pass `PaletteData | null`; applies or clears; clears on unmount. `useContextTheme()` — no args; uses auth context, derives palette (event first, then org), calls `useTheme`; use in app shell so ContextSelector-driven selection updates theme.

## Behaviour

- Applying a palette MUST update the document's CSS custom properties so that pace-core components using design tokens (main/sec/acc) reflect the new colours.
- Clearing MUST restore app default theme (e.g. values from app.css `@theme` or equivalent).
- Theme application MUST be tied to selected event/org so that changing selection (e.g. via ContextSelector) updates or clears theme as specified above. **`useContextTheme()`** is the supported integration between ContextSelector-driven selection and this behaviour.
- This slice owns palette extraction/application behavior. Generic event read-model hydration and precedence contracts are defined in `R17-derived-event-read-model-helper.md`; theming should consume that contract rather than redefining event-hydration semantics.
- Internal same-layout route transitions MUST NOT clear and reapply palette variables solely due to navigation. Theme changes should occur only when selected context or palette source data changes, or when a full app bootstrap/new-tab load occurs.

## Demo app requirements

- Demo has event (and optionally org) context and a way to switch (e.g. ContextSelector). When the user switches to an event/org that has palette data, the UI theme (colours) updates; when switching to none or one without palette, theme clears or stays default.
- **Step-by-step:** User switches event (or org) → visible theme (e.g. header, buttons, tokens) changes to match selected entity. User clears selection or selects entity without colours → theme reverts to app default.

## Verification

- **Runtime:** With a selected entity that has palette data, confirm `applyPalette` updates `--color-main-*`, `--color-sec-*`, and `--color-acc-*` variables on the document root.
- **Selection changes:** Switch between entities with different palettes and verify theme updates immediately and clears on no-selection/no-palette states.
- **Cleanup:** Navigate away/unmount theme hook and verify `clearPalette()` restores app defaults (no stale overrides).
- **Route-transition stability:** Verify same-layout client-side navigation preserves current dynamic palette without transient clear/reapply flicker.

## Testing requirements

- Unit tests for theming runtime (`applyPalette`, `clearPalette`), palette extraction (`getPaletteFromEvent` / `getPaletteFromOrganisation`, including legacy `ev-*` + L/C/H JSON), and for **`useTheme`** / **`useContextTheme`** (apply on selection, clear when no selection / on cleanup). Integration test: theme updates when selected event/org changes (e.g. in demo or test app shell). Coverage per Standard 08.

## Do not

- Do not define new database schema in this requirement; use existing event/org and palette fields. Do not require bracket arbitrary values for colours; use design tokens only.

## References

- [7-visual-standards.md](../../packages/core/docs/standards/7-visual-standards.md) (§ Dynamic theming). R03 (auth/context), [R08](./R08-advanced-ui.md) (ContextSelector), [R05c](./R05c-layout-and-shell.md) (shell + context selector), R10 (EventService, OrganisationService).
- [R17-derived-event-read-model-helper.md](./R17-derived-event-read-model-helper.md)

---

## Prompt to use with Cursor

Implement the feature described in this document. Follow the standards and guardrails provided. Add or update tests and demo as specified in "Testing requirements" and "Demo app requirements". Run validate and fix any issues until it passes.

---

**Checklist before running Cursor:** intro doc + guardrails doc + [Standards overview](../../packages/core/docs/standards/0-standards-overview.md) (four-layer: standards, cursor rules, ESLint, audit) + Cursor rules + ESLint config + this requirements doc.
