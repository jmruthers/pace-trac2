# Public pages

*Enrichment complete (reverse-engineering pass): API/Contract signatures, Behaviour MUSTs, Demo step-by-step, References with inline examples.*

## Overview

- **Purpose:** Public (unauthenticated) layout and providers, and public hooks (usePublicEvent, usePublicFileDisplay, usePublicEventLogo, usePublicRouteParams, usePublicPageContext, useIsPublicPage) so apps can serve public-facing pages (e.g. event landing, public file view) without requiring sign-in.
- **Scope:** Package + demo (at least one public route that uses the layout and one public hook).
- **Dependencies:** 02-foundation, 05-primitives-and-layout; optional 03-auth (PublicPageProvider may use limited client). Uses existing DB for public event/file data.
- **Standards:** 03 Security & RBAC (no leaking of protected data), 05 pace-core compliance, 07 Visual.

## Candidate integration scope (TRAC2 pace-core2)

- Candidate 5 (composite resilience utilities): this slice can compose public data sources with shared resilience helpers from R18 where needed.
- Candidate 6 (location cache + timezone adapters): public-page location/timezone integrations should use provider-agnostic adapter interfaces from R19.
- Candidate 7 (print/export primitives): public print/export composition remains deferred until multi-app demand is confirmed.

## Acceptance criteria

- [x] PublicPageLayout, PublicPageHeader, PublicPageFooter; PublicPageProvider (wraps public routes, provides public context).
- [x] Hooks: usePublicEvent, usePublicFileDisplay, usePublicEventLogo, usePublicRouteParams, usePublicPageContext, useIsPublicPage; cache/clear helpers if in contract.
- [x] Public routes do not require authentication; data access for public content only (e.g. public event info, public files); no organisation-scoped or permission-protected data exposed.

## API / Contract

- **Exports:** From `packages/core/src/components/public-layout/` (PublicPageLayout, PublicPageHeader, PublicPageFooter, PublicPageProvider) and hooks (usePublicEvent, usePublicFileDisplay, usePublicEventLogo, usePublicRouteParams, usePublicPageContext, useIsPublicPage). Contract only.

### Concrete signatures and shapes

**PublicPageProvider:** children, appName? (and any client/config props for public Supabase). **PublicPageLayout:** children, eventCode, event?, isLoading?, error?, `resilienceStatus?`, `resilienceErrors?` (composite resilience per [CR18](./CR18-composite-resilience-utilities.md)), refetch?, header?, footer? (customHeader/customFooter), showValidationErrors?, ErrorFallback?, loadingMessage?, printPageOrientation?. **PublicPageHeader / PublicPageFooter:** (event?, etc. as per layout).

**usePublicEvent(eventCode | id):** returns event data for public display (event, isLoading, error, refetch; cache helpers: clearPublicEventCache, getPublicEventCacheStats). **usePublicFileDisplay(fileId | ref):** returns url or display info for public files; clearPublicFileDisplayCache, getPublicFileDisplayCacheStats. **usePublicEventLogo:** event logo URL/info. **useEventLogoReference(eventId):** authenticated apps — resolves public `FileReference` via `core_events.logo_id` (counterpart to `usePublicEventLogo`). **usePublicRouteParams():** eventCode (and route params); usePublicEventCode, generatePublicRoutePath, extractEventCodeFromPath. **usePublicPageContext():** public page context (supabase, appName, environment, etc.). **useIsPublicPage():** boolean.

## Behaviour

- Public routes MUST NOT require authentication. Data fetched on public routes MUST be limited to public content only (e.g. public event info, public files); MUST NOT expose organisation-scoped or permission-protected data.
- Public hook caches in this slice are public-page specific and must not be treated as generic resilience or location/timezone adapter caches. Generic composite resilience contracts are defined in `R18-composite-resilience-utilities.md`; provider-agnostic location/timezone adapter interfaces are defined in `R19-location-timezone-adapter-interfaces.md`.
- Internal navigation between routes that share `PublicPageLayout` MUST use client-side routing and MUST NOT trigger full document reloads.
- During same-layout public-route transitions, shared public layout shell regions MUST remain mounted and intact; only routed content inside the layout content area should update.
- Full document navigation is reserved for explicit hard-navigation cases such as opening a new tab, external destinations, or downloads.
- PublicPageLayout row sizing recipe (`auto 1fr auto`) MUST be implemented via direct Tailwind utilities in the component (for example `grid-rows-[auto_1fr_auto]`), not via custom `core.css` utility aliases.

## Demo app requirements

- Demo has a public route (e.g. /public/event/:id or /public/file/:id) that uses PublicPageLayout and at least one of the public hooks to show event or file content without sign-in.
- **Step-by-step:** User visits public route (e.g. /events/:eventCode/public-showcase) without signing in → sees PublicPageLayout with header/footer → content from usePublicEvent or usePublicFileDisplay renders (event name, logo, or file). No auth redirect.

## Verification

- **Access model:** Verify public routes load without authentication and do not redirect to login.
- **Data boundary:** Verify public hooks only expose intended public data (no org-scoped or protected RBAC data leakage).
- **Layout contract:** Verify public pages are wrapped in `PublicPageProvider` and `PublicPageLayout` with expected header/footer behaviour.
- **Navigation behaviour:** Verify public route-to-route transitions within the same layout do not trigger full document reload and preserve shared layout shell regions.

## Testing requirements

- Unit tests for public hooks; integration test for public layout and one public flow. Coverage per Standard 08.
- **PublicPageLayout integration tests** MUST cover: happy-path content with default header/footer; explicit loading UI and custom `loadingMessage`; default error UI with retry; custom `ErrorFallback`; partial resilience alert with children still visible; loading-over-error and error-over-partial precedence; custom header/footer slots; layout `data-*` attributes on `<main>`.

## Do not

- Do not expose organisation or RBAC-protected data on public routes. Do not copy old implementation.

## References

- [3-security-rbac-standards.md](../../packages/core/docs/standards/3-security-rbac-standards.md), [5-pace-core-compliance-standards.md](../../packages/core/docs/standards/5-pace-core-compliance-standards.md). implementation-guides/public-pages (reference only).
- [R18-composite-resilience-utilities.md](./R18-composite-resilience-utilities.md), [R19-location-timezone-adapter-interfaces.md](./R19-location-timezone-adapter-interfaces.md)
- **Inline — public route:** Wrap public routes with `<PublicPageProvider>`. Page: `const { eventCode } = usePublicRouteParams(); const { event, isLoading, error, refetch } = usePublicEvent(eventCode); return <PublicPageLayout eventCode={eventCode} event={event} isLoading={isLoading} error={error} refetch={refetch}>{content}</PublicPageLayout>`. **Inline — usePublicEvent:** `usePublicEvent(eventCode)` returns { event, isLoading, error, refetch }.

---

## Prompt to use with Cursor

Implement the feature described in this document. Follow the standards and guardrails provided. Add or update tests and demo as specified. Run validate and fix any issues until it passes.
