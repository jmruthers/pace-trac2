# CR13 – Organisation and system stats hooks

*Backlog. Core stats only; same DB for all pace apps.*

## Overview

- **Purpose:** Shared organisation overview data (event counts, user counts, users by role) so pace apps share the same data shape and query strategy and only customise the UI (cards, links). Core stats only; app-specific aggregates (e.g. cake_delivery) remain in consuming apps.
- **Scope:** Package hooks (and types); core stats from core_organisations, core_events, rbac_user_profiles (or equivalent). Same DB for all pace apps; pace-admin does not need cake_delivery for this slice.
- **Dependencies:** CR03-auth-and-context, CR04-rbac (useSecureSupabase, useOrganisations).
- **Standards:** 04 API & tech stack, 03 Security & RBAC (secure client for all data).

## Candidate integration scope (TRAC2 pace-core2)

- Candidate 4 (derived event read-model helper): this slice consumes shared event-row hydration/precedence semantics from CR17.
- Candidate 8 (domain calculators): shared calculator extraction remains deferred; this slice keeps only stats derivations directly tied to organisation/system counts.

## Acceptance criteria

- [x] Types: OrganisationStats (id, name, display_name?, eventCount, activeEvents, upcomingEvents, userCount, usersByRole, userStats e.g. org_admin, leader, member, supporter, total, unitCount, awaitingApproval).
- [x] useOrganisationStats(organisationId) returns stats for one org via secure client.
- [x] Optionally useAllOrganisationStats() for super-admin style (all orgs).
- [x] Optionally useSystemStats() for system-wide totals (total orgs, events, users).
- [x] Schema assumptions documented (core_organisations, core_events, rbac_*, etc. as "requires schema X").

## API / Contract

- **Exports:** From `packages/core/src/hooks/` (or providers): useOrganisationStats(organisationId), optionally useAllOrganisationStats(), useSystemStats(). Types from `packages/core/src/types/` or hooks module: OrganisationStats, and any related shapes.
- **OrganisationStats:** id, name, display_name?, eventCount, activeEvents, upcomingEvents, userCount, usersByRole, userStats (org_admin, leader, member, supporter, total), unitCount, awaitingApproval.
- **useOrganisationStats(organisationId: string | null):** { data: OrganisationStats | null, isLoading, error, refetch }.
- **useAllOrganisationStats():** { data: OrganisationStats[] | null, isLoading, error, refetch } (super-admin).
- **useSystemStats():** { totalOrgs, totalEvents, totalUsers, isLoading, error, refetch } (or equivalent shape).
- All data access via useSecureSupabase (or equivalent).

## Behaviour

- All queries MUST use secure Supabase client. Document which tables/views are assumed (core_organisations, core_events, rbac_user_profiles or equivalent).
- This slice owns organisation/system stats hooks and role/event count derivations only. Generic event-row hydration/read-model precedence contracts are defined in `CR17-derived-event-read-model-helper.md`.

## Required schema

All data access is via the secure Supabase client (`useSecureSupabase()`); RLS applies. No migrations or schema changes are created by this feature. Required tables and columns:

- **core_organisations:** `id`, `name`, `display_name` (optional). Same as used by OrganisationServiceProvider. Used for organisation list and names.
- **core_events:** Table used in code. Columns include `event_id` (primary key), `organisation_id`, `event_date`, `event_days` (used to derive active = event in progress, upcoming = event_date in future). Used for event counts per organisation (total, active, upcoming) and system-wide total events. **Consuming apps that query events directly MUST use table `core_events`** (not `events`) **and columns `event_id`, `event_name`, `event_code`, `event_date`, `event_venue`, `organisation_id`** (not `id`, `name`, `code`, `date`, `venue`). pace-core exports `CORE_EVENTS_TABLE` and `CORE_EVENTS_LIST_COLUMNS` for this.
- **rbac_organisation_roles:** `organisation_id`, `user_id`, `role` (values: `org_admin`, `leader`, `member`, `supporter`), `status`, `revoked_at`. Used for users-by-role breakdown and active-role detection. Also used by OrganisationServiceProvider for memberships.
- **rbac_user_profiles:** `id`, `organisation_id`. Unioned with `rbac_organisation_roles.user_id` for per-org `userCount` (matches admin user list semantics). `awaitingApproval` counts org-linked users without an active organisation role for that org.
- **cake_unit:** `unit_id`, `organisation_id`. Used for per-org `unitCount`.

## Demo app requirements

- Optional: demo page or dashboard that shows organisation stats for selected org (or all orgs for super admin). Step-by-step: user selects org (or is super admin) → sees event counts, user counts, users by role.

## Verification

- **Package:** Call `useOrganisationStats(organisationId)` and verify returned shape includes event/user counts and role breakdown per this contract.
- **Super-admin flow:** Verify `useAllOrganisationStats()` (when implemented) returns multiple organisations and `useSystemStats()` returns overall totals.
- **Security boundary:** Confirm all reads occur through `useSecureSupabase()` and no raw client is used for stats queries.

## Testing requirements

- Unit tests for hooks with mocked secure client; integration tests if demo exercises the hooks. Coverage per Standard 08.

## Do not

- Do not create or alter database schema; use existing tables. Do not include app-specific aggregates (e.g. cake_delivery) in this slice; apps extend locally if needed.

## References

- [3-security-rbac-standards.md](../../../packages/core/docs/standards/3-security-rbac-standards.md), [4-api-tech-stack-standards.md](../../../packages/core/docs/standards/4-api-tech-stack-standards.md). pace-admin useUnifiedStats as reference for data shape only.
- [CR17-derived-event-read-model-helper.md](./CR17-derived-event-read-model-helper.md)

---

## Prompt to use with Cursor

Implement the feature described in this document. Follow the standards and guardrails provided. Add or update tests and demo as specified. Run validate and fix any issues until it passes.
