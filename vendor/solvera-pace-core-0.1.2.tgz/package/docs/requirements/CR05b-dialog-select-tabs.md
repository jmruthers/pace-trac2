# CR05b – Dialog, Select, Tabs

*Slice 2 of 3: overlay and choice components. Depends on 05a (primitives). Implement before 05c (Layout and shell).*

## Overview

- **Purpose:** Dialog, Select, and Tabs so the demo and other features can use overlays and tabbed/select UIs. No app layout in this slice.
- **Scope:** Package + demo (add Dialog, Select, Tabs to the styles showcase page).
- **Dependencies:** 02-foundation-types-utils-styles, 05a-primitives.
- **Standards:** 05 pace-core compliance, 06 Code quality, 07 Visual, 02 Architecture.

## Acceptance criteria

- [x] Dialog: DialogPortal, DialogTrigger, DialogClose, DialogContent, DialogHeader, DialogBody, DialogFooter, DialogTitle, DialogDescription. Full composition pattern.
- [x] ConfirmationDialog and ConfirmationDialogWithInput (and optional useConfirmationInput); confirm/cancel flows; type-to-confirm variant.
- [x] Select: SelectGroup, SelectValue, SelectTrigger, SelectContent, SelectLabel, SelectItem, SelectSeparator.
- [x] MultiSelect: options-driven multi-value listbox with clear-all affordance and trigger selection summary.
- [x] Tabs: TabsList, TabsTrigger, TabsContent.
- [x] All use design tokens (main/sec/acc); semantic HTML where applicable; no inline styles; exports from package components barrel.
- [x] Demo showcase page includes: open Dialog from trigger, close via Escape or close button; Select with options; Tabs that switch content.

## API / Contract

- **Exports:** From `packages/core/src/components/overlays/` — Dialog and subcomponents (`overlays/dialog/`: DialogPortal, DialogTrigger, DialogClose, DialogContent, DialogHeader, DialogBody, DialogFooter, DialogTitle, DialogDescription); ConfirmationDialog, ConfirmationDialogWithInput; Select and subcomponents (`overlays/select/`: SelectTrigger, SelectContent, SelectItem, SelectValue, SelectGroup, SelectLabel, SelectSeparator); MultiSelect and types (`MultiSelect`, `MultiSelectProps`, `MultiSelectOption`); Tabs (`overlays/Tabs.tsx`: TabsList, TabsTrigger, TabsContent). Optional hook useConfirmationInput from `packages/core/src/hooks/` or components.

### Minimal prop contracts

**Dialog:** DialogTrigger, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose (composition). **ConfirmationDialog:** open, onOpenChange, title, description, confirmLabel?, cancelLabel?, variant?: 'default'|'destructive', onConfirm, isPending?, icon?; uses pace-core Dialog, Button. **ConfirmationDialogWithInput:** same as ConfirmationDialog plus confirmationText (required string user must type), inputPlaceholder?, warningMessage?; confirm disabled until input matches confirmationText; useConfirmationInput(open, confirmationText) to reset on close. **useConfirmationInput(open, confirmationText):** returns input value and reset behaviour; resets when dialog closes. **Select:** SelectTrigger (`disabled?: boolean` passed to the native trigger button), SelectContent, SelectItem, SelectValue, SelectGroup, SelectLabel, SelectSeparator (composition). `SelectContent` renders a `<menu role="listbox">` anchored to `SelectTrigger`, and option rows keep option semantics. **MultiSelect:** options-driven primitive with `options: Array<{ value: string; label: string; disabled?: boolean }>` plus `value?: string[]`, `defaultValue?: string[]`, `onValueChange?: (values: string[]) => void`, `placeholder?`, `disabled?`, `clearable?`, `positionMode?: 'auto' | 'absolute' | 'fixed'`; content uses `<menu role="listbox" aria-multiselectable="true">` and option rows use `role="option"` + `aria-selected`. MultiSelect trigger summary contract: empty -> placeholder, one/two selections -> comma-delimited labels, three-or-more -> `"N selected"`. Select and MultiSelect positioning uses native browser Popover API + CSS Anchor Positioning with `position-try`. Both support `positionMode?: 'auto' | 'absolute' | 'fixed'` where `auto` selects `fixed` for open-dialog context and `absolute` otherwise. **Browser baseline:** this Select/MultiSelect contract targets modern browsers that support Popover/Anchor positioning/`position-try`; legacy fallback behaviour is out of scope for this requirement, and runtime should not carry fallback display/position branches for unsupported browsers. **Tabs:** TabsList, TabsTrigger, TabsContent (composition).

## Visual specification

Global tokens, size groups, and elevation: [7-visual-standards.md](../../../packages/core/docs/standards/7-visual-standards.md) Part C.

- **DialogTrigger composition:** `DialogTrigger` composes pace-core `<Button>` (variant/default trigger styling). Do not duplicate Button class strings in DialogTrigger or other overlay triggers.
- **Dialog panel elevation:** DialogContent is a layout panel and uses the global high-elevation panel style (`shadow-lg`) **at rest** (always visible).
- **Dialog panel surface parity:** DialogContent shares Card layer-0 surface (`bg-main-100 text-main-950`) and Large size group radius (`rounded-2xl`).
- **Dialog panel border:** DialogContent uses always-on `border border-border` (mapped from `--color-border`) at rest. Dialog does **not** use Card hover-only outline elevation — modals require a visible boundary without hover.
- **Dialog internal border rule:** Only DialogContent carries a border. `DialogHeader`, `DialogBody`, and `DialogFooter` must not render section divider borders (`border-b` / `border-t`).
- **Dialog panel sizing:** DialogContent defaults to auto-grow sizing (`w-fit`) capped to viewport width (`max-w-[90vw]`). DialogContent must retain `max-h-[90vh]` and `overflow-auto` so content remains reachable in smaller viewports.
- **Dialog centering utility recipe:** DialogContent should use transform-free viewport centering utilities (`fixed inset-0 m-auto h-fit w-fit`) as the default class recipe.
- **Dialog default position:** DialogContent must lean on native `<dialog>` modal placement via `showModal()` for centered placement; avoid transform-based centering recipes (`left-1/2`, `top-1/2`, `-translate-x-1/2`, `-translate-y-1/2`) unless a later requirement explicitly documents an exception.
- **Dialog layering rule:** In modal mode (`showModal()`), do not rely on `z-*` classes for primary layering behaviour; native top-layer modal behaviour is the default layering contract.
- **Dialog native root element:** DialogContent renders native `<dialog>` as the modal root element (not `<section role="dialog">`).
- **Dialog backdrop:** Dialog backdrop is provided by native `<dialog>::backdrop`; do not render a sibling backdrop `<div>` element.
- **Dialog/select compatibility:** Dialog positioning strategy must remain compatible with Select popover anchor alignment when Select components are rendered inside Dialog content.
- **Dialog actions:** Primary/secondary actions are rendered in `DialogFooter`; layout classes are applied to `DialogFooter` itself (no additional wrapper elements only for grid/alignment).
- **Dialog persistence actions:** In persistence/edit flows, `DialogFooter` is the canonical action host. The primary submit action label is exactly `Save` and renders in the footer's bottom-right action area.
- **Dialog persistence action order:** For save flows, order actions right-to-left as `Save`, `Cancel`, then alternate actions.
- **Dialog action label exceptions:** Use intent-specific labels for non-persistence actions (for example `Delete`, `Approve`, `Publish`, `Send`).
- **Markup minimisation:** Do not add nested wrappers around `DialogHeader`/`DialogBody`/`DialogFooter` solely to apply spacing or grid classes.
- **Card/Dialog slot parity rule:** For any demo markup that uses Card or Dialog slot subcomponents (`CardHeader`/`CardContent`/`CardFooter`, `DialogHeader`/`DialogBody`/`DialogFooter`), apply layout classes directly on the slot subcomponent and avoid a single child wrapper used only for layout.
- **Select empty-state hint:** Every select usage should provide explicit contextual hint copy for the unselected state via `SelectValue placeholder="..."` (for example `Select organisation`, `Choose status`), instead of relying on generic fallback text.
- **Select elevation parity:** Select trigger and Select content use the same drop-shadow level as default Button surfaces for visual parity in shared rows and toolbars.
- **Select trigger radius:** SelectTrigger default closed radius uses `rounded-xl` (matches Button medium).
- **Select content radius:** SelectContent uses matching outer corners on the outer edge (`rounded-b-xl` when opening below; `rounded-t-xl` when opening above).
- **Select trigger/content connection:** When open, SelectTrigger and SelectContent visually connect with zero gap (`mt-0`). Placement-aware join:
  - **Below (default):** trigger removes bottom radius while open (`rounded-b-none`); content has zero top radius (`rounded-t-none`), no top border at seam (`border-t-0`), outer bottom stays `rounded-b-xl`.
  - **Above (`--pace-select-open-up`):** trigger removes top radius while open (`rounded-t-none`); content has zero bottom radius (`rounded-b-none`), no bottom border at seam (`border-b-0`), outer top stays `rounded-t-xl`.
- **Select trigger border/surface parity:** SelectTrigger default border and surface in medium controls use `border-main-300`, `bg-background`, and `shadow-sm` to match Button outline treatment in shared rows.
- **Select content border token:** SelectContent default border uses semantic `border-border` (mapped from `--color-border`).
- **Select trigger size parity:** SelectTrigger default control height is `h-9` (medium) to match Button medium size and Input default height for side-by-side control alignment.
- **Select trigger margin parity:** SelectTrigger default outer margin is `m-1` to match Button spacing and Input default spacing in shared action rows (for example DataTable caption controls).
- **Select text token:** SelectTrigger text and options list item text use semantic `text-foreground`.
- **Select chevron token:** SelectTrigger chevron icon color uses semantic `text-foreground`.
- **Select dropdown density:** SelectContent list container has no extra top/bottom padding; dropdown items use compact row spacing by default (`p-1` pattern, no row margins).
- **Select options list horizontal inset:** SelectContent root `<menu>` applies `px-1` so effective horizontal inset from panel border to option content resolves to two Tailwind spacing units when combined with item-level compact padding.
- **Select chevron affordance:** SelectTrigger shows a default right-edge chevron icon; the icon can be disabled by an explicit trigger prop when a consumer needs a custom trailing affordance.
- **Select max dropdown height:** SelectContent defaults to max height equal to 50% viewport height.
- **Select content positioning classes:** SelectContent uses Tailwind anchor utilities (`top-anchor-bottom`, `left-anchor-left`, `w-anchor`) and named `position-try` fallback chain (`--pace-select-open-up`, `--pace-select-open-right`, `--pace-select-open-left`). Maximum inline size is declared directly in the component implementation via `maxInlineSize: 'min(90vw, max-content)'` on the Select content element.
- **Select explicit anchor pairing:** Each Select instance derives a unique CSS anchor token from internal ids and applies explicit trigger/content anchor linkage (`anchor-name` on trigger and `position-anchor` on content) so anchored placement remains stable across contexts including Dialog.
- **Select context-aware positioning:** `SelectContent` defaults to `positionMode="auto"` and recomputes positioning when opened: use `fixed` inside `dialog[open]` and `absolute` otherwise. Consumers can override with explicit `positionMode="fixed"` or `positionMode="absolute"` for edge cases.
- **Select no-flash context resolution:** In `positionMode="auto"`, Select must determine dialog context before first visible open frame so dropdown positioning does not flash from `absolute` to `fixed` on first activation inside Dialog.
- **MultiSelect visual parity:** MultiSelect trigger/content use the same border, surface, elevation, radius, placement-aware join, and anchor-positioning recipes as Select by default.
- **MultiSelect clear affordance:** When `clearable` and selected values are present, MultiSelect trigger provides a clear-all affordance that resets selected values without opening the listbox.
- **Select instance right-edge alignment override:** For edge-anchored shell controls (for example UserMenu at the right side of the header), `SelectContent` may override horizontal alignment with anchor utilities `right-anchor-right left-auto` to align dropdown and trigger right edges while retaining anchor-positioned placement.
- **Select native popover positioning:** SelectContent placement is browser-managed via Popover API + CSS Anchor Positioning; default placement is below the trigger with automatic alternate placement through `position-try`.
- **Select instance linking:** Each Select instance must maintain a unique trigger/content link pair (trigger `popovertarget` to content id). This linkage is internal to the component implementation; consuming pages should not pass custom ids/keys solely for trigger-to-menu anchoring.
- **Select structure update:** SelectContent options container uses `<menu>` as the list parent while preserving listbox/option accessibility roles.
- **TabsList:** `grid grid-flow-col auto-cols-max gap-1`; no list underline or border.
- **TabsTrigger pill parity:** matches NavigationMenu inline pills ([CR05c](./CR05c-layout-and-shell.md) primary nav recipe).
  - Base shell (all states): `rounded-full px-3 py-2`.
  - **Selected:** `bg-main-700 text-main-50`.
  - **Not selected:** `text-main-800`; **hover:** `hover:bg-main-100` (muted pill).
  - **Inactive at rest:** bare text only (no background).
- **Tabs layout stability:** trigger padding and radius MUST NOT change between states; background and text colour only — no layout shift when switching tabs.
- **Tabs count badge:** unchanged; optional `count` prop keeps existing compact badge beside label.

## Behaviour

- All components MUST use design tokens (main/sec/acc) only; MUST use semantic HTML where applicable; MUST NOT use inline styles. Dialog MUST support closing via Escape and close button. Dialog MUST use native modal lifecycle (`showModal()` / `close()`) and handle native dialog cancel/close events to keep component open state synchronized. Select and MultiSelect MUST use native Popover + CSS Anchor Positioning + `position-try` for options panel placement. Selection components should keep JavaScript logic limited to state sync/accessibility/selection and avoid runtime fallback display or positioning branches. Exports MUST be from package components barrel.
- **Shared listbox keyboard model (Select + MultiSelect):** listbox navigation MUST support **ArrowDown**, **ArrowUp**, **Home**, and **End** to move active option focus; option activation MUST support **Enter** and **Space**. **Escape** closes listbox and returns focus to trigger. **Tab** closes listbox and allows normal focus progression.
- **Select close-on-selection:** Choosing any option (pointer or keyboard) MUST close the dropdown immediately, commit the value, and return focus to the trigger without reopen flicker. Re-selecting the **already selected** option MUST still close the dropdown and MUST still invoke `onValueChange` with that value. Dismissal via native popover **light dismiss** (outside click where the platform provides it) MUST remain correct; internal `open` state MUST stay synchronized with the popover `toggle` / `hidePopover` lifecycle.
- **MultiSelect selection behavior:** Choosing an option toggles selected state and keeps the dropdown open for continued selection. Closing via Escape/Tab/light dismiss commits current selected values and returns focus behavior consistent with the keyboard model. Clear-all affordance commits an empty selection.
- **Tabs layout stability:** tab switching MUST NOT alter trigger box metrics (no border-width or padding changes on selection).

Traceability: consumer request `CORE-select-autoclose-request` (pace-portal2 docs) describes the same baseline Select behaviour; pace-core remains the implementation source of truth.

## Demo app requirements

- **Step-by-step:** On the Styles Showcase page (from 05a): User clicks a trigger → Dialog opens → User closes Dialog via Escape or close button. User opens a ConfirmationDialog (and optionally ConfirmationDialogWithInput with type-to-confirm) → can confirm or cancel. User sees Select with options and can choose an option. User sees Tabs and can switch between TabsTrigger items; TabsContent updates accordingly.

## Verification

- **Dialog behaviour:** Verify open/close composition works, including Escape and close-button dismissal, and verify native dialog contract (`<dialog>` root + native backdrop behaviour).
- **Choice controls:** Verify Select option selection and Tabs content switching function as specified.
- **Select overlay platform:** Verify Select uses native popover + anchor positioning contract with `position-try` alternate placement and `<menu role="listbox">` container semantics.
- **MultiSelect overlay platform:** Verify MultiSelect uses the same native popover + anchor positioning contract and applies `<menu role="listbox" aria-multiselectable="true">` semantics.
- **Select inside Dialog:** Verify Select trigger/content alignment remains correct when Select is rendered inside Dialog content. Use manual browser verification for placement geometry in addition to automated contract assertions.
- **Select upward join:** When `position-try` flips to open above the trigger, verify trigger top corners square (`rounded-t-none`), content bottom corners square (`rounded-b-none`), and outer top radius (`rounded-t-xl`). Use manual browser verification near viewport bottom edge in addition to automated below-placement join assertions.
- **Select first-open stability:** Verify no first-open positioning flicker when opening Select inside Dialog (no interim `absolute` placement before dialog-context `fixed` placement).
- **Select auto-close:** Verify option click, **Enter**, and **Space** close the listbox; verify re-selecting the current value closes; verify listbox/trigger ARIA relationships unchanged.
- **Shared keyboard navigation:** Verify ArrowUp/ArrowDown/Home/End navigation for both Select and MultiSelect.
- **MultiSelect behavior:** Verify option toggle does not close listbox, clear-all resets selections, and trigger summary text follows placeholder / labels / `N selected` contract.
- **Package exports:** Verify Dialog, ConfirmationDialog variants, Select, Tabs, and optional hook exports are available from documented paths.
- **Package exports:** Verify Dialog, ConfirmationDialog variants, Select, MultiSelect, Tabs, and optional hook exports are available from documented paths.

## Testing requirements

- Integration tests for Dialog (open/close, Escape, native `<dialog>` element contract, native close/cancel state sync), Select (open/select/Escape with `<menu role="listbox">` semantics and anchor/popover contract), MultiSelect (open/toggle/clear with `<menu role="listbox" aria-multiselectable="true">` semantics), Tabs (switch); accessibility and keyboard behaviour. Coverage per Standard 08.
- **Selection regression (pace-core):** integration tests MUST cover shared keyboard navigation (**ArrowUp**, **ArrowDown**, **Home**, **End**) and activation (**Enter**, **Space**) for Select and MultiSelect.
- **Select regression (pace-core):** integration tests MUST cover close-after-select for **pointer** and keyboard, **re-select same value** still closes, and **focus returns to the trigger** after selection; retain existing semantics coverage.
- **MultiSelect regression (pace-core):** integration tests MUST cover toggle-without-close for pointer and keyboard, clear-all behavior, trigger summary rendering rules, and Escape/Tab close behavior with focus handling.
- Full **outside-click** / light-dismiss behaviour remains subject to browser Popover implementation; supplement with manual cross-browser checks where automated environment cannot assert native dismiss.

## Do not

- Do not add Header, Footer, PaceAppLayout, ErrorBoundary, or LoadingSpinner in this slice (those are 05c). Do not add Form, DataTable, Toast, or file upload. Do not copy old implementation; implement from this spec.

## References

- [7-visual-standards.md](../../../packages/core/docs/standards/7-visual-standards.md), [5-pace-core-compliance-standards.md](../../../packages/core/docs/standards/5-pace-core-compliance-standards.md), [2-architecture-standards.md](../../../packages/core/docs/standards/2-architecture-standards.md).

---

## Prompt to use with Cursor

Implement the feature described in this document. Follow the standards and guardrails provided. Add or update tests and demo as specified. Run validate and fix any issues until it passes.