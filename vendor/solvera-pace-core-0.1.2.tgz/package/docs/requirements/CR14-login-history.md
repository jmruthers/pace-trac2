# CR14 – Login history (contract and recording mastered by pace-core)

*Backlog. Recording mastered by pace-core for consistency; all pace apps use one shared Supabase project.*

## Design intent (requirements summary)

- **Record when a user logs in** and **which orgs and events they accessed** in that session.
- **Avoid duplicative data:** store at most **one login record per session** (one row per `session_id`).
- **Per session:** record **each org** the user accessed **at most once**, and **each event** at most once (sets only; no counts or repeated entries).
- **First record per session:** the first record for a session MUST include an `organisation_id` (apps SHOULD send it when the user is in an org context); if the client omits it, the backend MAY use a sentinel value so the table’s NOT NULL constraint is satisfied.

These constraints are enforced by: (1) a unique constraint on `session_id` so upsert yields one row per session, and (2) backend merge of `organisation_id` / `event_id` into `organisation_ids_seen` / `event_ids_seen` arrays without duplicates.

## Overview

- **Purpose:** Login history recording and read contract so all pace apps behave consistently. Login history stores **one record per session**; recording is idempotent per session (repeated calls with the same `session_id` result in a single row). The backend stores the **set of orgs/events viewed** per session (distinct only; no counts). Recording is **mastered by pace-core** (contract + recording path); all pace apps connect to the one shared Supabase project. Optional read hook for apps that display login history.
- **Scope:** Package: contract (table/schema, how to invoke recording), recording path (client helper or Edge function contract owned by pace-core), optional useLoginHistory hook. No UI in pace-core; apps implement Login history page (e.g. DataTable, search, date filter).
- **Dependencies:** CR03-auth-and-context, CR04-rbac (useSecureSupabase for read path).
- **Standards:** 03 Security & RBAC, 04 API & tech stack, 09 Operations.

## Acceptance criteria

- [x] Contract documented: table/schema for login records (e.g. user_id, organisation_id for first record or sentinel, event_id?, app_id?, timestamp, session_id?, user_agent?, ip?; one row per session; org/event ids stored as sets per session). How to invoke recording (Edge function name, payload).
- [x] pace-core owns the recording path: client helper or Edge function contract + invoker that all apps call so recording is consistent (implementation in pace-core or shared Supabase project that pace-core defines).
- [x] Optional useLoginHistory(filters?) hook that queries the login records table via useSecureSupabase; access pattern documented (e.g. super admin can read all).
- [x] Read path: RLS or access pattern for "super admin can read all" documented.

## API / Contract

- **Contract (documented):** Login record columns: user_id, organisation_id (required for first record per session, or backend uses sentinel), event_id?, app_id?, timestamp, session_id?, user_agent?, ip? (or equivalent). Recording: Edge function name (e.g. record-login), payload shape. pace-core exports a client helper (e.g. recordLogin(supabase, payload)) or documents the Edge function invocation so all apps use the same contract.
- **useLoginHistory(filters?):** optional hook returning { data: LoginRecord[], isLoading, error, refetch }. Filters may include user_id, organisation_id, date range, etc. Access: super admin can read all; others per RLS.
- **Recording:** pace-core provides recordLogin(...) or equivalent so apps do not implement their own; implementation may be Edge function in shared Supabase project or client-side call that pace-core defines.

## Schema and contract (source of truth)

- **Recording:** The backing table (e.g. `rbac_user_login_history`) stores **one row per session**; `session_id` is the deduplication key. The **record-login Edge function** MUST use upsert semantics: when a row with the given `session_id` already exists, UPDATE it (e.g. refresh `login_timestamp`, `user_agent`, `ip_address`) and **merge** incoming `organisation_id` / `event_id` into the row's sets (see below); otherwise INSERT. No duplicate rows per `session_id`. The shared Supabase project MUST enforce a **UNIQUE constraint on `session_id`** so upsert is well-defined. Table columns (logical): `id`, `user_id`, `email` (server-populated from auth, not from payload), `organisation_id`, `event_id`, `app_id`, `login_timestamp` (or `timestamp`), `session_id`, `user_agent`, `ip_address` (or `ip`), and `organisation_ids_seen` (array), `event_ids_seen` (array). **Orgs/events seen:** The backend MUST maintain `organisation_ids_seen` (e.g. uuid[]) and `event_ids_seen` (e.g. text[]) with default `'{}'`. On INSERT, if `organisation_id`/`event_id` are provided, add them to these arrays. On UPDATE (existing session_id), merge incoming `organisation_id` into `organisation_ids_seen` only if not already present; same for `event_id` and `event_ids_seen`. This records which orgs/events the user viewed in that session (sets only; no duplicate entries). Apps MAY call `recordLogin` when the user enters an org/event context (same `session_id`); backend merges into these sets. Edge function name: `record-login`. Apps MUST use pace-core's `recordLogin(supabase, payload)`; do not invoke the Edge function directly. **The client passed to `recordLogin(supabase, payload)` MUST be the secure client** (from useSecureSupabase or the same provider/auth as the secure client). The secure client MUST support `functions.invoke` so that recording does not require the raw base client; see CR04 for the requirement that the secure client exposes `functions`. Payload (RecordLoginPayload): `user_id` (required), `session_id` (strongly recommended and MUST be supplied for one-record-per-session behaviour; apps SHOULD pass from auth session, e.g. Supabase auth session), `organisation_id` (SHOULD be sent for the first record when the user is in an org context; if omitted, backend MAY use a sentinel), `event_id`, `app_id`, `timestamp` (ISO, optional), `user_agent`, `ip` (all optional). Repeated calls with the same `session_id` are allowed and MUST result in a single row (backend upsert and merge). The helper calls `supabase.functions.invoke('record-login', { body: payload })`. The shared Supabase project implements the Edge function and writes to the login history table. pace-core does not create or migrate schema. **First record and organisation_id:** The first record for a session MUST have an `organisation_id` (table column is NOT NULL). Apps SHOULD send `organisation_id` when establishing the session if the user is already in an org context; if the client omits it, the backend MUST use a sentinel value (e.g. a well-known “no org” UUID).
- **Read path:** Table `rbac_user_login_history`. Each returned row represents **one session**. Columns include `login_timestamp`, `ip_address` (table uses these names; pace-core maps to `LoginRecord` as `timestamp`, `ip` so the public API stays consistent). Rows MAY include `organisation_ids_seen` and `event_ids_seen`; pace-core exposes these on `LoginRecord` when present. Hook: `useLoginHistory(filters?)` returns `{ data: LoginRecord[] | null; isLoading; error; refetch }`. Filters: optional `user_id`, `organisation_id`, `dateFrom`, `dateTo` (inclusive; date filters apply to `login_timestamp`). Access: read path MUST use secure Supabase client (`useSecureSupabase()`). RLS: super admin can read all; others per RLS (e.g. own user or org-scoped). pace-core does not define RLS.

### Usage

**Recording:** (1) Call **once** when the session is established (e.g. after login or first app load with auth) with `user_id`, `session_id` from auth (e.g. `auth.session?.id`), `app_id`, `user_agent`, and `organisation_id` when the user is already in an org context (otherwise the backend may use a sentinel). Optionally include `event_id`. (2) Optionally call again when the user enters an org or event context, with the **same** `session_id` and current `organisation_id` / `event_id`; the backend merges these into the session row's "seen" sets. Do not block UX on failure; log and continue.

**Reading:** Use `useLoginHistory({ organisation_id, dateFrom, dateTo })`; render `data` (LoginRecord[]) or handle `isLoading` / `error`. Full Login history page UI (DataTable, search, date filter) is implemented in consuming apps (e.g. pace-admin).

### Instructions for consuming apps (e.g. pace-admin)

- Read the active Supabase auth session and pass the real `session_id` from auth state (do not generate a replacement id).
- Call `recordLogin` once when the session is established (initial sign-in or restored authenticated load).
- Pass `app_id`, `user_id`, and available client metadata (`user_agent`, optional IP metadata as supported by backend contract).
- Optionally call `recordLogin` again when organisation/event context becomes available, using the same `session_id`, so backend merges seen org/event sets.
- Do not block user navigation on recording failures; log and continue.

## Verification

- **Recording path:** Start a session, call `recordLogin(...)` with a `session_id`, then call again with the same `session_id` and different org/event context; verify only one row exists for that session and seen-org/seen-event sets are merged without duplicates.
- **First record rule:** Verify first-record behaviour satisfies the `organisation_id` requirement (explicit org id or backend sentinel fallback).
- **Read path:** Verify `useLoginHistory(filters?)` returns mapped records (`timestamp`, `ip`) from `rbac_user_login_history` and respects secure-client access boundaries.

## Behaviour

- Recording MUST be invoked via pace-core-defined path so format and table are consistent across all apps. Recording MUST be possible using only the pace-core secure client (no separate base client only for Edge invokes). Read path MUST use secure client; access pattern (e.g. super admin reads all) documented.

### One record per session; org/event at most once per session

- Backend MUST enforce at most **one row per session** (upsert by `session_id`). Apps SHOULD pass `session_id` (from auth session). Repeated calls with the same `session_id` MUST result in a single row.
- **First record:** the first record for a session MUST include an `organisation_id` (apps send it when in org context; if omitted, the backend MUST use a sentinel so the table’s NOT NULL constraint is satisfied).
- For org/event access: the backend MUST record **each organisation** and **each event** the user accessed **at most once per session**. When `organisation_id` or `event_id` are sent, the backend merges them into the row's `organisation_ids_seen` / `event_ids_seen` sets (no duplicate entries in those arrays).

## Demo app requirements

- Optional: demo or docs show how to call recordLogin and how to use useLoginHistory. Full "Login history" page (DataTable, search, date filter) can remain in consuming apps (e.g. pace-admin).

## Testing requirements

- Unit tests for recordLogin helper (or contract tests); unit tests for useLoginHistory with mocked client. Coverage per Standard 08.

## Migration (shared Supabase project)

The shared Supabase project that hosts the Edge function and table MUST enforce one row per session (UNIQUE on `session_id`), implement the `record-login` Edge function with upsert semantics, and MAY add `organisation_ids_seen` / `event_ids_seen` and merge incoming org/event into those sets on update. pace-core does not create or migrate schema.

### Supabase cleanup checklist (one-off operational guidance)

- Remove historical duplicates for the same `session_id`.
- Enforce uniqueness on `session_id` (UNIQUE constraint or unique index).
- Ensure optional context-tracking columns exist for merged session context (`organisation_ids_seen`, `event_ids_seen`).
- Keep Edge-function writes as upsert keyed by `session_id`.
- On update path, merge incoming `organisation_id`/`event_id` into seen arrays without duplicates.
- Ensure auth-derived email/user identity fields are server-sourced rather than trusting client payload.

## Do not

- Do not leave recording implementation to each app; pace-core masters the recording path. Do not add app-specific columns to the contract without updating this doc.

## References

- [3-security-rbac-standards.md](../../../packages/core/docs/standards/3-security-rbac-standards.md), [4-api-tech-stack-standards.md](../../../packages/core/docs/standards/4-api-tech-stack-standards.md), [9-operations-standards.md](../../../packages/core/docs/standards/9-operations-standards.md). CR04 (secure client and functions.invoke). pace-admin record-login Edge function and UserLoginHistory page as reference for behaviour only.

---

## Prompt to use with Cursor

Implement the feature described in this document. Follow the standards and guardrails provided. Add or update tests as specified. Run validate and fix any issues until it passes.
