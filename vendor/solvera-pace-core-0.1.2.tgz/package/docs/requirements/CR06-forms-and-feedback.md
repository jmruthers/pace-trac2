# Forms and feedback

*Enrichment complete. Single slice: form infra, toast, PasswordChangeForm, PaceLoginPage (with embedded login form). Achievable in one prompt.*

## Overview

- **Purpose:** Form components (Form, FormField), form hooks (useZodForm, useFormDialog), Toast, PasswordChangeForm, and PaceLoginPage (including login UI) so the demo and apps can collect input and show feedback.
- **Scope:** Package + demo (login page, at least one form with validation + toast).
- **Dependencies:** 02-foundation-types-utils-styles, 03-auth-and-context (for PaceLoginPage), 05a-primitives, 05b-dialog-select-tabs (for Dialog in form modals if needed), 05c-layout-and-shell optional for nav. Mutation feedback helpers depend on CR12 (Supabase and React Query error handling) when implemented.
- **Standards:** 05 pace-core compliance, 07 Visual, 04 API & tech stack (react-hook-form + Zod).

## Acceptance criteria

- [x] Form, FormField; useZodForm, useFormDialog; Toast (ToastProvider, Toaster, Toast, ToastTitle, ToastDescription, ToastClose, ToastAction), useToast.
- [x] Mutation feedback helpers: HandleMutationError(error, context, toast?), ShowSuccessMessage(message, toast); available for use in forms and mutations (depend on CR12 when implemented).
- [x] PaceLoginPage (email/password login UI, submit, error display, loading state; appName, onSuccessRedirectPath, requireAppAccess).
- [x] PasswordChangeForm (new password, confirm password only; no current password field).
- [x] All use pace-core primitives and design tokens; no plain `<form>` or direct react-hook-form for form UI (per Standard 05).
- [x] PaceLoginPage login-route behaviour: clears active dynamic theme on mount; when `requireAppAccess` is true, checks app access after sign-in and either navigates or shows access error; shows checking-permissions state while access check is in progress; displays non-benign auth/access errors below the form.

## API / Contract

- **Exports:** From `packages/core/src/components/` and `packages/core/src/hooks/` — Form, FormField, PasswordChangeForm, PaceLoginPage; Toast* components; useToast, useZodForm, useFormDialog. From utils or forms/feedback: HandleMutationError(error, context, toast?) — delegates to Supabase error handler (CR12); ShowSuccessMessage(message, toast) — toast({ title: message, variant: 'success' }).

### Concrete signatures and shapes

**Form:** `FormProps<T>`: schema?: z.ZodType<T>, defaultValues?, onSubmit, onError?, mode?: 'onSubmit'|'onChange'|'onBlur'|'onTouched'|'all', children: ReactNode | (methods: UseFormReturn<T>) => ReactNode, className?. Form wraps react-hook-form with Zod resolver and FormProvider; use with FormField (control from context). **FormField:** Composes with Label and Input/Select; uses Controller and control from Form context. Label SHOULD wrap its rendered control directly.

**useZodForm:** `useZodForm<T>({ schema, defaultValues?, mode?: 'onSubmit'|'onBlur'|'onChange'|'onTouched'|'all' })` — returns full react-hook-form `useForm` result (control, handleSubmit, formState, reset, etc.) with zodResolver(schema).

**useFormDialog:** `useFormDialog<T>(options?: { onOpenChange?, resetOnClose?: boolean })` — returns { isOpen, formData: T | null, openDialog(data?: T | null), closeDialog(), handleOpenChange(open: boolean) }. No setFormData or resetForm; pass data into openDialog(data); when resetOnClose is true (default), formData is cleared on close.

**Toast:** ToastProvider wraps app; Toaster renders toasts. **toast(props)** / **useToast():** useToast() returns { toasts, toast(props), dismiss(toastId?) }. toast(props): title?, description?, variant?: 'default'|'destructive'|'success', onClose?, action?. Toasts auto-dismiss after 5s by default (configurable per toast via duration).

**PaceLoginPage props:** appName (required), onSuccessRedirectPath? (default `/`), requireAppAccess? (default false), checkAppAccess?. MUST be used inside UnifiedAuthProvider and React Router. PaceLoginPage renders its own login UI and calls signIn from auth; on success navigates to onSuccessRedirectPath. When `requireAppAccess` is true, page performs app-access validation after sign-in before final navigation.

**PasswordChangeForm props:** onSubmit(values: { newPassword, confirmPassword }): Promise<{ error?: { message?: string, code?: string } }> (required), onSuccess?, onCancel?, className?. Values are newPassword and confirmPassword only (no current password). Client-side: MUST enforce min 8 characters and newPassword === confirmPassword before calling onSubmit.

## Visual specification

Global rules: [7-visual-standards.md](../../../packages/core/docs/standards/7-visual-standards.md) Part C (semantic colour roles, elevation). **This slice:**

### Toast

- **Variants:** `default` | `destructive` | `success` — map to semantic roles in Standard 7 Part C (destructive/danger vs success emphasis via tokens). Presentation MUST stay consistent with Part C elevation for floating surfaces.
- **Panel border token:** Default Toast border uses global semantic border token (`border-border`, mapped from `--color-border`); semantic variants may override border colour intentionally.
- **Toast radius:** Toast uses Large size group radius (`rounded-2xl`).
- **Toast elevation:** Toast keeps always-on high elevation (`shadow-lg`) at rest — transient floating surfaces must remain visible without hover.
- **Toast semantic root:** Each toast item renders as native `<output>`.
- **Toast announcement reliability:** Toast output keeps explicit `role="status"` and `aria-live="polite"` for consistent assistive announcement behaviour.
- **Toast layering:** Toast visibility layering uses native Popover API top-layer behaviour instead of z-index stack wrappers.
- **Toast positioning primitive:** Toast placement uses CSS Anchor Positioning relative to a viewport anchor, not a fixed wrapper `<section>` container.
- **Toast viewport offset:** The first rendered toast in the stack is offset `bottom-4 right-4` from the viewport edge.
- **Toast stack gap:** Subsequent toast messages keep a consistent `gap-2` vertical separation in the stack.
- **Timing:** Default auto-dismiss (e.g. 5s) is a **behaviour** contract; styling still follows tokens only.

### Login page (PaceLoginPage)

- **Page wrapper (`main`):** `min-h-screen grid mx-auto w-fit content-center justify-items-center gap-y-8 p-4` (or equivalent horizontal padding on small viewports). **Page background** (e.g. `pace-background` on `body`) is applied by the **consuming app** like other routes — not a package-only gradient class on `main`.
- **Logo:** PaceLoginPage renders one fixed logo image above the form using `appName` only. Asset path for app-provided logo: `public/logos/{appSlug}-logo-square.svg` served as `/logos/{appSlug}-logo-square.svg` (via `appPublicLogoPath(appName, 'logo-square')`; `appSlug` is lowercased `appName`); `alt` text `${appName} logo`; default height `h-48`. **Consuming app** MUST place this file.
- **Embedded login form:** PaceLoginPage owns the login card markup and submit behaviour; no separate exported LoginForm component.
- **Card (form):** Root `Card` width MUST match [Standard 07 — Narrow dialog-scale panels](../../../packages/core/docs/standards/7-visual-standards.md#modal-dialog-panel-sizing) (`w-full max-w-full lg:w-md`), plus `mx-auto` and base Card styles; `bg-main-100 text-main-950` where defined. Do not add rest-state elevation shadow — Card elevation is hover-only per CR05a.
- **Card header:** `p-6 space-y-1`; title and description **centred** (`text-center`). Login title follows `Sign in to {APP_NAME_DISPLAY}` and login display copy MUST use an uppercase app name segment (e.g. `CORE`) while keeping internal app identifier casing unchanged.
- **Card content:** `p-6 pt-0` with `grid gap-4` applied directly on `CardContent`; no extra grouping wrapper elements.
- **Card footer:** `p-6 pt-0` with `grid gap-2 justify-items-center` applied directly on `CardFooter`; primary **Sign in** submit button uses fixed width `w-32` (8rem). Login footer actions are centered for this screen only. Layout: grid or flow only (**no flex**).
- **Persistence form actions:** Outside authentication flows, forms that persist edits use a bottom-right action row in `CardFooter` or `DialogFooter` with primary label exactly `Save`.
- **Persistence action order:** For save forms, order actions right-to-left as `Save`, `Cancel`, then alternate actions.
- **Persistence label exceptions:** Intent-specific non-persistence actions keep their own labels (for example `Delete`, `Approve`, `Publish`, `Send`).
- **Defaults:** Subtitle copy default `"Enter your credentials to continue."` when not overridden; title pattern `Sign in to {appName}` when `appName` set.
- **Field hints:** Login email/password fields should include concise placeholder hints (for example `Enter email address`, `Enter password`) alongside labels.
- **Errors:** Submit errors via **Alert** `variant="destructive"` inside Card content.
- **Required markers:** Required asterisk is a global form pattern, but PaceLoginPage login fields hide markers by default.
- **Form semantics:** Label wraps its related input for login fields; avoid redundant wrappers around label+input pairs.

CR03 auth demo wiring (landmark label, redirect behaviour) remains in [CR03-auth-and-context.md](./CR03-auth-and-context.md).

## Behaviour

- MUST use pace-core Form/FormField and primitives for form UI; MUST NOT use raw `<form>` or direct react-hook-form for rendering inputs. PaceLoginPage login form MUST be wired to auth signIn and MUST redirect to onSuccessRedirectPath on successful sign-in. Form that uses persistence (if implemented) MUST be used inside React Router and UnifiedAuthProvider. Toast MUST support variant and default auto-dismiss (e.g. 5s), render message items as native `<output>`, and use Popover API + Anchor Positioning for layering/placement. PasswordChangeForm MUST validate minimum 8 characters and password match before submit.
- PaceLoginPage MUST clear any active theme override on login route mount so login renders in app default theme.
- PaceLoginPage MUST surface non-benign auth errors and access errors below the login form.
- When `requireAppAccess` is true, PaceLoginPage MUST show a checking-permissions state while access validation runs, then either continue navigation or show access error.
- **Import-not-fork hygiene:** Consuming apps MUST import `Form`, `FormField`, `PaceLoginPage`, and feedback primitives from `@solvera/pace-core` — MUST NOT reimplement prototype `_shared/form.jsx` or local login/form forks. See also CR05c shell hygiene.

## Demo app requirements

- Route `/login` renders PaceLoginPage (appName, onSuccessRedirectPath="/"). At least one other page or modal shows a form built with Form/FormField + useZodForm (or useZodForm + Form/FormField with control); on submit success a toast appears; on validation or submit error, show error message or toast.
- **Step-by-step:** User visits `/login` → sees PaceLoginPage login card → enters valid email/password → submits → redirects to onSuccessRedirectPath. User opens another page/modal with a validated form → fills fields → submits → success toast appears; or triggers validation error → error shown. Optional: user can open a password-change flow (e.g. from user menu) → fills new + confirm password → submits → success or error.

## Verification

- **Form contract:** Verify form UIs are implemented with pace-core `Form`/`FormField` and hooks (`useZodForm`, `useFormDialog`) rather than raw form rendering.
- **Feedback contract:** Verify toast variants and mutation feedback helpers are wired and produce expected success/error messages, and verify toast DOM/behaviour contract (`<output role="status" aria-live="polite">` + native popover/anchor positioning).
- **Auth flow:** Verify PaceLoginPage sign-in, error rendering, and redirect behaviour match the contract.

## Testing requirements

- Unit tests for useZodForm, useFormDialog, useToast. Integration tests for Form/FormField (submit, validation), PasswordChangeForm (validation, submit), Toast (show, dismiss, native `<output>` semantics, popover/anchor contract), PaceLoginPage (login card rendering, submit, error/loading/disabled-submit states, `requireAppAccess`, auth/access error rendering, checking-permissions state). Coverage per Standard 08.

## Do not

- Do not use plain `<form>` or direct react-hook-form for form UI; use pace-core Form/FormField. Do not add AddressField, DateTimeField, or other advanced form controls in this slice. Do not copy old implementation.

## References

- [5-pace-core-compliance-standards.md](../../../packages/core/docs/standards/5-pace-core-compliance-standards.md), [7-visual-standards.md](../../../packages/core/docs/standards/7-visual-standards.md), [4-api-tech-stack-standards.md](../../../packages/core/docs/standards/4-api-tech-stack-standards.md).
- **Inline — useZodForm:** `const { control, handleSubmit, formState: { errors }, reset } = useZodForm({ schema: mySchema, defaultValues: { name: '' } });` then wire Form/FormField with control. **Inline — PaceLoginPage:** Use the single app name constant per Standard 5 (e.g. `appName={APP_NAME}`). Example: `<Route path="/login" element={<PaceLoginPage appName={APP_NAME} onSuccessRedirectPath="/" requireAppAccess={false} />} />`. See Standard 5 (pace-core compliance) for where APP_NAME is declared and how to use it. **Inline — Form:** `<Form schema={mySchema} defaultValues={{ name: '' }} onSubmit={(data) => { ... }}><FormField name="name" label="Name" /><Button type="submit">Save</Button></Form>`.

---

## Prompt to use with Cursor

Implement the feature described in this document. Follow the standards and guardrails provided. Add or update tests and demo as specified. Run validate and fix any issues until it passes.
