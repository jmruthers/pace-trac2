# CR22 – Shared reporting foundations

## Filename convention

This file is **`CR22-shared-reporting-foundations.md`** — pace-core requirement slice **CR22** (see [CR00-core-project-brief.md](./CR00-core-project-brief.md)).

---

## Overview

- Purpose and scope: implement the shared `pace-core2` reporting foundation described in **Reporting architecture (canonical)** below: explore contracts, metadata validation, join-planning/query-planning helpers, report-builder UI primitives, result-table composition, and template config shaping. Scope is package + demo verification only.
- This slice is the shared package dependency that consuming apps rely on for reporting. It is not limited to a single demo explore or a participant-only MVP framing.
- The contract in this slice must support the currently approved explore keys required by active consumers:
  - `team.participant`
  - `base.participant`
  - `base.unit`
  - `base.activity`
  - `base.scan`
- BASE depends on this slice as the shared reporting foundation for all four approved BASE reporting domains. TEAM support remains in scope where already defined, but TEAM’s narrower current surface must not reduce the shared package contract to participant-only behavior.
- External prerequisites: schema additions and data population for `core_field_list` and `core_report_template`, RLS, and production query execution remain outside this repo. This slice must remain adapter-driven so it can integrate with those persisted contracts without owning them. Structural DDL is tracked as **DB-319** in [`DB-change-decisions-p3.md`](../../../../docs/database/decisions/DB-change-decisions-p3.md).
- Dependencies: [CR07a-datatable.md](./CR07a-datatable.md), [CR07b-datatable.md](./CR07b-datatable.md), [CR10-services-and-providers.md](./CR10-services-and-providers.md), [CR12-supabase-react-query-error-handling.md](./CR12-supabase-react-query-error-handling.md), [CR18-composite-resilience-utilities.md](./CR18-composite-resilience-utilities.md), [CR21-workflow-forms-runtime.md](./CR21-workflow-forms-runtime.md) (conceptual alignment on `core_field_list` / field identity).
- Standards: 02 Architecture, 03 Security and RBAC, 04 API and tech stack, 05 pace-core compliance, 06 Code quality, 07 Visual ([7-visual-standards.md](../standards/7-visual-standards.md)), 08 Testing and documentation, 09 Operations.

## Reporting architecture (canonical)

Reporting is a **shared PACE capability**: built on `pace-core2` and consumed by all apps, each with default scoping, domain relevance, and explore configuration. This section supersedes any standalone “ARC” reporting note; **this CR is the source of truth**.

### Architecture decision: hybrid (code + database)

Three options were considered:

- **Code-only** — domains, bases, joins, and field availability all in TypeScript. Fast to iterate but drifts from the database; admin tooling and agents cannot introspect the model.
- **Metadata-only** — everything in DB tables with runtime SQL generation. Flexible but hard to debug, test, and type-check.
- **Hybrid (chosen)** — **what** is reportable lives in the database; **how** tables connect lives in code.

Concretely:

| Concern | Location |
| --- | --- |
| Domain and base definitions | TypeScript config under `packages/core/src/reporting/` — platform-defined, stable. No `core_report_domain` / seed tables required for MVP. |
| Field metadata | `core_field_list` — reporting availability, domain membership, aggregation strategy. |
| Saved templates | `core_report_template` — user-created records that must persist. |
| Join topology | TypeScript **explore** config per app/domain instantiation. |
| Query execution | TypeScript service in `packages/core/src/reporting/` — no Postgres RPC required for MVP query execution. |

### Domain, app instantiation, base table, and scope

- **Domain** — the conceptual subject of a report (e.g. Participant, Activity, Scan).
- **App instantiation** — how that domain is realised in a specific app: same domain can appear in multiple apps with different base tables, scope columns, and join graphs.
- **Base table** — defines **one row** of report output; every other table joins relative to it. Determined by **domain + app context**, not by domain alone.
- **Scope** — runtime filter the app passes before the report runs (e.g. `organisation_id` for TEAM, `event_id` for BASE). **Not** stored in the shared engine or in saved template builder state; always supplied by the consuming app at execution time.

**Row grain stability:** the base table fixes grain. A selected field must be: on the base table; many-to-one from the base (scalar per row); or one-to-many from the base with a declared **aggregate strategy** (`string_agg`, `array_agg`, `count`, etc.). Fields behind one-to-many joins **without** aggregate metadata are not selectable — enforced at field-selection time via explore declarations.

### Domain map (cross-app)

Not all domains are MVP; the **shared package** must still model them when explores are registered.

| Domain | App | Base table | Scope column | Notes |
| --- | --- | --- | --- | --- |
| Participant | TEAM | `core_member` | `organisation_id` | Standing member directory |
| Participant | BASE | `base_application` | `event_id` | Event applicants |
| Participant | CAKE | `base_application` | `event_id` | Catering view |
| Participant | MEDI | `core_member` | `organisation_id` | Medical profile; extra RLS |
| Organisation | TEAM | `core_organisations` | `parent_id` | Sub-orgs in hierarchy (`team_unit` does not exist — use hierarchy only) |
| Unit | BASE | `base_units` | `event_id` | Event-scoped groupings; “who is in each unit” is Participant + filter, not this domain |
| Activity | BASE | `base_activity_booking` | `event_id` | One row per booking |
| Scan | BASE, TRAC | `base_scan_event` | `event_id` | Immutable scan records |
| Itinerary | TRAC | `trac_itinerary_assignment` | `event_id` | Logistics assignments |
| Invoice | MINT | `mint_invoice` | `organisation_id` | Optional `event_id` for views |
| Communication | PUMP | `pump_comms_log` | `organisation_id` | Optional `event_id` |
| Incident | MEDI | `medi_incident` | `event_id` | Table may be deferred |

**Domain summary (status):**

| Domain | Apps | MVP note |
| --- | --- | --- |
| Participant | TEAM, BASE, CAKE, MEDI | MVP focus: TEAM + BASE |
| Organisation | TEAM | Post-MVP |
| Unit | BASE | Post-MVP |
| Activity | BASE | Post-MVP when module ships |
| Scan | BASE, TRAC | Post-MVP when live |
| Others | TRAC, MINT, PUMP, MEDI | Deferred per module |

`per_offering` aggregate capacity views are **not** part of the user-configurable reporting model — use fixed UI data tables in BASE when needed.

### Explore pattern (join topology in code)

**Problem:** storing join paths on each `core_field_list` row breaks down (fields on base table, round-trips, new apps touching every field row). **Fields and joins are different concerns.**

**Solution:** one **explore** per `{app}.{domain}` key declaring:

- Base table and scope column
- Explicit join list: table, `ON` condition, join type, cardinality, optional `requires` (dependency on another join)

`core_field_list` declares **which domain(s)** a field belongs to and **how to aggregate** when needed — **not** how to join.

**Engine steps (conceptual):**

1. App provides explore key, selected field keys, filters, scope value.
2. Load explore config.
3. Determine required tables from selected fields’ `table_name` (or equivalent) in `core_field_list`.
4. Include only joins needed for those tables; skip unused branches.
5. One-to-many joins trigger `GROUP BY` and the field’s `aggregate_strategy`.
6. Apply scope as `WHERE` on the base table’s scope column.
7. Execute via the app’s execution adapter (e.g. service-role client); RLS on underlying tables remains the data boundary.

**Safety:** new fields from a new table are unavailable until that table is added to the explore — **closed by default**.

### Database schema additions (summary)

DDL for `core_field_list` and `core_report_template` is **DB-319** in [`DB-change-decisions-p3.md`](../../../../docs/database/decisions/DB-change-decisions-p3.md). Normative intent:

- **`core_field_list`:** add `report_domains` (text[]), `aggregate_strategy`, `aggregate_config`. No `join_path` column — joins stay in explores. Existing `report_availability` remains the primary gate.
- **`core_report_template`:** add `domain_id`, `app_id`, `sort_config`, `column_config`. Together they identify the explore context; `event_id` / `organisation_id` on the row remain for display/access context, not for substituting runtime scope in the engine.

**No new tables** for domains/bases in MVP.

### Relationship to the forms platform ([CR21](./CR21-workflow-forms-runtime.md))

Both tracks touch **`core_field_list`** conceptually:

- Forms rescope changes **`core_form_fields`** / response storage to **`field_key`** semantics.
- Reporting adds reporting columns to **`core_field_list`** for DB-backed fields.

Non–DB-backed / prompt-only form fields (if added) should remain **invisible** to reporting (`report_availability = false`, `report_domains` null). **Design in parallel; implement in order; converge on a coordinated field-list rebuild** when schema backlog allows.

### App vs shared-engine responsibilities

**Each app:** mount the builder with the correct explore key; pass **scope** at runtime; enforce RBAC for which domains a role may use; load/save templates filtered to app context.

**Shared engine:** validate fields exist and are reportable; validate domain membership; validate each field’s table is reachable via the explore; assemble join graph; apply aggregates; apply scope and filters; execute through an adapter.

### Worked examples (abbreviated)

- **TEAM participant + conditions:** explore `team.participant` from `core_member`, join to `core_person`, `medi_profile`, `medi_condition` (one-to-many → aggregate condition names).
- **BASE participant, same fields:** explore `base.participant` from `base_application`, scope `event_id`, join to member/person/medical chain — different base and scope, similar shape.
- **BASE-only columns** (e.g. `base_application.status`, `base_registration_type.name`): require joins declared only on BASE explores; TEAM users never see them.

### MEDI fields and access control

Expose only **non-sensitive** summary fields in the builder by default. Elevated clinical fields require: RBAC role, RLS allowing read, and engine-side validation against role — confirm against MEDI RLS decisions before enabling in an explore.

### Implementation sequence (cross-team)

1. **Schema foundation** — DB-319 columns (no full field-list data population yet).
2. **Core reporting service** — explores, validation, query planning, types.
3. **Field list rebuild** — after broader schema decisions settle; populate `report_domains` and aggregates; align with forms `field_key` work where applicable.
4. **TEAM integration** — `team.participant`, org scope, CSV export.
5. **BASE integration** — `base.participant` + other registered BASE explores; migrate legacy BASE templates into `core_report_template` with backfilled `domain_id` / `app_id` where required.

### Decisions recorded (summary)

| Topic | Outcome |
| --- | --- |
| Architecture | Hybrid: TS structure + DB field metadata + DB templates |
| Domain/base tables in DB | No for MVP |
| Join topology | TypeScript explores only |
| `join_path` on `core_field_list` | Do not add |
| Query execution RPC | Not required; TS + Supabase client |
| BASE participant base | `base_application` |
| TEAM participant base | `core_member` |
| Participant vs Registration domain | Single Participant domain |
| Forms vs reporting | Design together; converge at field list rebuild |

## Acceptance criteria

- [x] `pace-core2` exposes explicit TypeScript explore contracts for the approved shared explore key set: `team.participant`, `base.participant`, `base.unit`, `base.activity`, and `base.scan`.
- [x] Explore topology is owned in TypeScript only: base table, scope column, join declarations, cardinality, and join dependencies are defined in code rather than persisted as DB join-path metadata.
- [x] Field selection validation enforces the hybrid architecture rules: fields must be reportable in `core_field_list`, belong to the requested domain, and be reachable from the current explore; joins are never inferred from field metadata.
- [x] Query-planning helpers assemble only the joins required for the selected fields, detect one-to-many joins, and require aggregate strategy metadata where row multiplication would otherwise occur.
- [x] Template config helpers shape and validate the `core_report_template` contract (`domain_id`, `app_id`, `sort_config`, `column_config`) without persisting runtime scope.
- [x] Shared template-management contracts expose visibility and ownership metadata (`is_private`, `created_by`, optional `description`) and include explicit delete capability so consuming apps can enforce creator-owned lifecycle controls.
- [x] `ReportBuilder` exposes `visibilityLabels?: { private: string; shared: string }` so non-event consumers can override template visibility wording without forking shared UI.
- [x] `ReportResultsTable` supports app-owned RBAC page mapping via optional table RBAC config (while preserving canonical defaults), so the shared package does not hardcode consumer policy.
- [x] The shared builder/results package surface is explore-agnostic and reusable by consuming apps; it does not contain BASE-local reporting semantics, app-specific RBAC policy, or business rules beyond the shared reporting contract.
- [x] Demo verification covers the registered TEAM participant explore and all four approved BASE explores with realistic fixture metadata/adapters, proving the shared package foundation rather than a single-explore demo.

## API / Contract

- Public exports from `packages/core/src/reporting/` via a dedicated `@solvera/pace-core/reporting` entrypoint:
  - `reportingExplores`
  - `getReportingExplore`
  - `validateReportingSelection`
  - `buildReportingQueryPlan`
  - `serializeReportTemplateConfig`
  - `deserializeReportTemplateConfig`
  - `ReportBuilder` (supports `forwardRef` to `ReportBuilderHandle`)
  - `ReportResultsTable`
  - Types: `ReportingExploreKey`, `ReportingExplore`, `ReportingJoin`, `ReportingFieldMeta`, `ReportingAggregateStrategy`, `ReportingSelection`, `ReportingFilter`, `ReportingFilterOperator`, `ReportingSort`, `ReportingColumnConfig`, `ReportingScopeValue`, `ReportingQueryPlan`, `ReportingExecutionRequest`, `ReportingExecutionResult`, `ReportingMetadataProvider`, `ReportingExecutionAdapter`, `ReportingTemplateRecord`, `ReportingTemplateStore`, `ReportTemplateConfig`, `ReportBuilderProps`, `ReportBuilderHandle`
- Authoritative contract notes:
  - `ReportingExploreKey` must use `{app}.{domain}` format.
  - The shared package must register and support, at minimum, these keys:
    - `team.participant`
    - `base.participant`
    - `base.unit`
    - `base.activity`
    - `base.scan`
  - `ReportingExplore` must declare `label`, `baseTable`, `scopeColumn`, and `joins`. Each `ReportingJoin` must declare `table`, `on`, `type`, `cardinality`, and optional `requires`.
  - `ReportingFieldMeta` must represent the persisted reporting field catalogue contract from `core_field_list`: stable `fieldKey`, source `tableName`, label, `reportAvailability`, `reportDomains`, and optional aggregate metadata (`aggregateStrategy`, `aggregateConfig`). It must not contain join-path ownership.
  - `validateReportingSelection` must return structured validation output for expected user/configuration errors, including unknown explore, unavailable field, domain mismatch, unreachable table, and missing aggregate strategy.
  - `buildReportingQueryPlan` must produce a transport-agnostic plan/request object. It may emit selected tables, join graph, grouping requirements, filters, sorts, and scope clauses, but it must not require runtime SQL-string construction in React components.
  - `ReportingExecutionAdapter` must accept a `ReportingExecutionRequest` and return an `ApiResult`-style `ReportingExecutionResult`; real DB transport and service-role execution remain adapter concerns outside the shared UI layer.
  - `ReportTemplateConfig` stores builder state only: `exploreKey`, selected fields, filters, sorts, and column config. Runtime scope (`event_id`, `organisation_id`, or equivalent) is not persisted in the template contract.
  - `ReportingTemplateRecord` must include ownership/visibility metadata needed by consuming apps: `is_private`, `created_by`, and optional `description`, in addition to id/name/config.
  - `ReportingTemplateStore.saveTemplate` input must accept visibility metadata (`is_private`, optional `description`) and `ReportingTemplateStore` must expose `deleteTemplate(templateId)` alongside list/load/save.
  - `ReportBuilder` and `ReportResultsTable` must remain shared package primitives. Builder template controls must support a visibility selector plus creator-aware gating for edit/delete actions while avoiding BASE-specific reporting logic.
- `ReportingFilterOperator` includes the v1 builder operator set: `eq`, `neq`, `gt`, `gte`, `lt`, `lte`, `like`, `ilike`, `is_null`, `not_null`. The shared `ReportBuilder` UI exposes only this set. Additional operators (`contains`, `starts_with`, `ends_with`, `in`) may remain on the type for persisted templates and adapter translation but are not offered in the builder dropdown.
- `ReportingExecutionData` may include optional `truncated?: boolean` when the execution adapter hits a row cap (for example LIMIT 10000).
- `ReportBuilder` must accept `visibilityLabels?: { private: string; shared: string }`.
  - Default labels are `{ private: 'Private', shared: 'Event-shared' }`.
  - Consumers may pass app-specific wording (for example org-scoped surfaces using "Org-shared template" / "Private template").
- `ReportBuilder` must accept optional layout and host-integration props (all opt-in; defaults preserve existing single-panel behaviour):
  - `visibilityMode?: 'select' | 'checkbox'` — default `'select'`. TEAM and similar consumers use `'checkbox'` for private/shared visibility.
  - `suppressInlineSavedTemplates?: boolean` — default `false`. When `true`, hides the inline Saved templates list while still loading templates for the Load picker and error/retry surfaces.
  - `alwaysShowResults?: boolean` — default `false`. When `true`, keeps the results pane visible before the first Run (empty state via `ReportResultsTable`).
  - `showTemplateFooterCancel?: boolean` — default `true`. When `false`, omits footer Cancel beside Save when editing an active template.
  - `canDeleteTemplates?: boolean` — default `true`. When `false`, hides delete affordances in inline list and footer.
  - `onTemplatesPersisted?: () => void` — optional callback after successful save/delete catalog mutation.
  - `sharedTemplateBadgeLabel?: string` — badge text for non-private templates in the inline list (default `'Event-shared'`).
  - `sortDirectionCompact?: boolean` — default `false`. When `true`, sort chips show `asc` / `desc` instead of prose labels.
- `ReportBuilder` must support `forwardRef<ReportBuilderHandle | null>` for consuming apps that host an external templates surface (for example TEAM Templates `DataTable`). `ReportBuilderHandle` methods:
  - `reloadTemplatesCatalog()` — force-refresh template list.
  - `loadTemplateById(templateId)` — load template into builder state without running.
  - `loadTemplateAndRun(templateId)` — load template then execute with restored config.
  - `openDeleteDialogForActiveTemplate()` — open delete confirmation for the active template.
  - `notifyTemplateDeleted(templateId)` — remove template from catalog and clear active state when it matches.
  - Implementation may use `flushSync` when synchronising imperative host actions with builder state; consumers must not rely on timing outside these methods.
- `ReportBuilder` must support permission-aware template creation UI through `canCreateTemplates?: boolean` while still rendering template list/load affordances when a `templateStore` is provided.
- `ReportBuilder` template lifecycle feedback must expose explicit list-state contracts in shared UI:
  - loading indicator in list area
  - empty list copy
  - inline list error with retry action
  - toast notifications for save/update/delete success and failure
- `ReportBuilder` must support confirmation-first template deletion with configurable confirmation copy via an optional `deleteTemplateConfirmation` prop (title/body/action labels).
- `ReportResultsTable` must accept optional RBAC table config and pass it to the shared DataTable RBAC boundary.
  - Default remains canonical `reports` page mapping when no override is supplied.
  - Consumers may provide app-specific page mapping where required by their `rbac_app_pages` contract.
- File paths:
  - Package contracts, planners, and UI live under `packages/core/src/reporting/`.
  - Export governance must include `packages/core/package.json`, generated exports index, and public API reference updates for the `./reporting` subpath.
  - Demo verification page lives at `src/pages/ReportingShowcasePage.tsx` (or equivalent route file re-exported through `src/pages/index.ts`).

## Package implementation map (rebuild reference)

Use this section to recreate or audit the CR22 surface without relying on chat history. Paths are relative to `packages/core/` unless noted.

### Exported from `@solvera/pace-core/reporting`

| Symbol | Source file | Role |
| --- | --- | --- |
| `reportingExplores`, `getReportingExplore` | `src/reporting/explores.ts` | Registered explore topology (`team.participant`, `base.participant`, `base.unit`, `base.activity`, `base.scan`). |
| `validateReportingSelection` | `src/reporting/validateReportingSelection.ts` | Selection validation (availability/domain/reachability/aggregate requirements). |
| `buildReportingQueryPlan` | `src/reporting/buildReportingQueryPlan.ts` | Transport-agnostic query-plan construction with minimal join inclusion. |
| `serializeReportTemplateConfig`, `deserializeReportTemplateConfig` | `src/reporting/templateConfig.ts` | Template config shaping; rejects persisted runtime scope. |
| `ReportBuilder`, `ReportBuilderHandle` | `src/reporting/ReportBuilder.tsx` | Shared explore/field/filter/sort/template builder primitive; imperative handle for external templates panel. |
| `ReportResultsTable` | `src/reporting/ReportResultsTable.tsx` | Shared results primitive wrapping DataTable composition. |
| Reporting types (`ReportingExploreKey`, `ReportingExecutionRequest`, `ReportingTemplateRecord`, etc.) | `src/reporting/types.ts` | Canonical reporting type contract. |

### Demo app (repo root)

| Artifact | Path | Role |
| --- | --- | --- |
| Reporting showcase page | `src/pages/ReportingShowcasePage.tsx` | Fixture metadata/adapters covering TEAM participant + all four approved BASE explores, template save/load, and results rendering. |

### Key tests (minimum rebuild parity)

| Area | Location |
| --- | --- |
| Explore registration and lookup | `src/reporting/explores.test.ts` |
| Selection validation contract | `src/reporting/validateReportingSelection.test.ts` |
| Query-plan assembly | `src/reporting/buildReportingQueryPlan.test.ts` |
| Template config serde + scope rejection | `src/reporting/templateConfig.test.ts` |
| Builder integration | `src/reporting/ReportBuilder.integration.test.tsx` |
| Results table integration | `src/reporting/ReportResultsTable.integration.test.tsx` |

### Build/export governance notes

- Subpath export ownership:
  - `packages/core/package.json` (`./reporting`)
  - `src/reporting/index.ts`
- If adding/removing public reporting symbols, run:
  - `npm run build -w @solvera/pace-core`
  - `npm run docs:exports-index`
  - `npm run export:check-governance`

## Visual specification

- Use [7-visual-standards.md](../standards/7-visual-standards.md) Part A and Part C for global styling. Reuse CR07a/CR07b DataTable visuals rather than introducing a separate reporting table language.
- Builder layout recipe:
  - Desktop: two-column layout with a configuration rail (`explore`, `fields`, `filters`, `sorts`, `template actions`) and a flexible results pane.
  - Mobile: single-column stack with configuration sections above results.
  - Explore selection must be explicit and shared-package-level; the builder must support switching among the registered explore keys without changing layout contracts.
  - Selected fields render as removable chips/list rows showing label plus source-table secondary text where useful.
  - Validation and execution errors use shared alert components and must point to the relevant config section or field selection.
  - Results pane uses `ReportResultsTable`, which wraps the CR07 DataTable contract for column visibility, sorting, export, and empty/error states.
- Deltas:
  - This slice defines a shared reporting workstation pattern, not a BASE-local reporting UI.
  - Consuming apps own where the builder is mounted, which explores are exposed to a user role, and any app-specific shell framing around the shared reporting components.

## Verification

- **pace-core demo:** add a reporting showcase page with fixture explores and adapters for:
  - `team.participant` using `core_member` as the base
  - `base.participant` using `base_application` as the base
  - `base.unit` using `base_units` as the base
  - `base.activity` using `base_activity_booking` as the base
  - `base.scan` using `base_scan_event` as the base
- Fixture/demo coverage must include at least one realistic example per BASE explore:
  - participant: participant/application-oriented fields
  - unit: unit-oriented fields
  - activity: booking/session/offering-oriented fields
  - scan: scan-event/scan-point-oriented fields
- Across the fixture suite, include at least one one-to-many aggregate example to prove aggregate handling through shared metadata and query planning.
- Concrete verification flow:
  - Open the demo reporting route and switch between the registered explore keys.
  - Select base-table and joined-table fields for each explore, run the mocked report, and verify the planner includes only the required joins.
  - Verify the result table renders through the shared DataTable wrapper and export controls remain available through the shared export primitives.
  - Save a template, reload it, and verify fields/filters/sorts/column config restore while runtime scope remains external to the stored template.
  - Mount `ReportBuilder` with custom `visibilityLabels` and verify both private/shared label text is rendered from props.
  - Confirm all required exports in **Package implementation map** are importable from `@solvera/pace-core/reporting`.

## Consumer adoption checklist (BA15)

- Pass `canCreateTemplates={canCreate}` from the consuming app permission hook to hide template save controls when create access is denied.
- Keep `templateStore` wired even when `canCreateTemplates` is false so list/loading/error/retry/load interactions remain available.
- Rely on shared row-level creator gating (`template.created_by === currentUserId`) for Edit/Delete visibility.
- Use default delete confirmation copy or pass `deleteTemplateConfirmation` to match app-specific wording.
- Depend on shared template lifecycle feedback: toast success/failure, inline list retry on list load failure, and empty/loading list states.

## Testing requirements

- Unit tests:
  - explore lookup and unknown-explore handling across the registered key set
  - `validateReportingSelection` for report availability, domain membership, unreachable tables, and missing aggregate strategy
  - `buildReportingQueryPlan` for minimal join inclusion, join dependency ordering, one-to-many grouping, and runtime scope clause shaping
  - template config serialization/deserialization, including rejection of persisted runtime scope
- Integration tests:
  - `ReportBuilder` with fixture metadata provider and execution adapter
  - `ReportBuilder` template lifecycle coverage for private/shared visibility round-trip and creator-only edit/delete gating
  - `ReportResultsTable` wrapping DataTable with selected columns and sort config
  - demo-like flows covering:
    - `team.participant`
    - `base.participant`
    - `base.unit`
    - `base.activity`
    - `base.scan`
- Coverage expectations per Standard 08:
  - planners/validators target unit-level coverage expectations
  - builder/results composition receives integration coverage for each approved BASE domain plus the TEAM participant explore already in scope

## Do not

- Do not add `join_path` or equivalent DB-owned join topology metadata to `core_field_list`; joins belong to TypeScript explore config only.
- Do not persist runtime scope (`event_id`, `organisation_id`, or equivalent) inside shared template config.
- Do not hardcode app-specific RBAC/business policy or BASE-local reporting logic into the shared package; use app-provided guards and adapters.
- Do not implement SQL-string-building UI logic in React components; planning and transport boundaries must stay separated.
- Do not treat TEAM’s narrower current reporting surface as a reason to reduce the shared package contract below the approved BASE four-domain requirement.
- Do not move reporting contracts into `@solvera/pace-core` root exports; keep the dedicated `@solvera/pace-core/reporting` subpath authoritative.

## References

- [CR07a-datatable.md](./CR07a-datatable.md)
- [CR07b-datatable.md](./CR07b-datatable.md)
- [CR10-services-and-providers.md](./CR10-services-and-providers.md)
- [CR12-supabase-react-query-error-handling.md](./CR12-supabase-react-query-error-handling.md)
- [CR18-composite-resilience-utilities.md](./CR18-composite-resilience-utilities.md)
- [CR21-workflow-forms-runtime.md](./CR21-workflow-forms-runtime.md)
- [7-visual-standards.md](../standards/7-visual-standards.md)
- [`DB-change-decisions-p3.md`](../../../../docs/database/decisions/DB-change-decisions-p3.md) (**DB-319** reporting schema additions)
- BASE alignment authority:
  - `/Users/kusi/Documents/GitHub/pace-base/rebuild/project-brief.md`
  - `/Users/kusi/Documents/GitHub/pace-base/rebuild/architecture.md`
  - `/Users/kusi/Documents/GitHub/pace-base/rebuild/slices/S15-reporting/requirements.md`
- [docs/XX00-template-requirements.md](../../../../docs/XX00-template-requirements.md)

---

## Prompt to use with Cursor

Implement the feature described in this document. Follow the standards and guardrails provided. Read **Package implementation map (rebuild reference)** for expected files and exports. Add or update tests and demo verification as specified in **Testing requirements** and **Verification**. If public reporting exports change, run `npm run build -w @solvera/pace-core` before repo-wide validate so `dist/` stays aligned. Then run `npm run validate` and fix issues until it passes.

---

**Checklist before running Cursor:** [CR00-core-project-brief.md](./CR00-core-project-brief.md) · [CR00-core-architecture.md](./CR00-core-architecture.md) · Cursor rules · ESLint config · this requirements doc.
