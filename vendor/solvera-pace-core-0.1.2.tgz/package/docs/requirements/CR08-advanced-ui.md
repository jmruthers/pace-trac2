# Advanced UI

*Enrichment complete (reverse-engineering pass): API/Contract signatures, Behaviour MUSTs, Demo step-by-step, References with inline examples.*

## Overview

- **Purpose:** Calendar, DatePickerWithTimezone, DateTimeField, FileUpload, FileDisplay, ContextSelector, InactivityWarningModal so the demo and apps can support dates, files, org/context switching, and inactivity handling.
- **Scope:** Package + demo (showcase or integration of each where applicable).
- **Dependencies:** 02-foundation, 05-primitives-and-layout, 03-auth and 04-rbac for ContextSelector and optional permission-aware file access; 06-forms for any form-based pickers.
- **Standards:** 05 pace-core compliance, 07 Visual, 03 Security & RBAC (file access, context).

## Acceptance criteria

- [x] Calendar component; DatePickerWithTimezone; DateTimeField (date + time, timezone-aware).
- [x] FileUpload (upload UI, progress, validation); FileDisplay (display/download); hooks: useFileDisplay, useFileUrlCache, useFileUpload (or equivalent); StorageUtils and storage types/config as per contract.
- [x] ContextSelector (organisation/event context switch); InactivityWarningModal (idle warning, extend session, sign-out).
- [x] Hooks: useInactivityTracker, useSessionRestoration (if in scope); InactivityServiceProvider.
- [x] All use design tokens and semantic markup; file access via secure client where applicable.

## API / Contract

- **Exports:** From `packages/core/src/components/` and `src/hooks/` — Calendar, DatePickerWithTimezone, DateTimeField, FileUpload, FileDisplay, ContextSelector, InactivityWarningModal; related hooks; storage/utils. Contract only.

### Concrete signatures and shapes

**Calendar:** value (date), onSelect?, mode? (single/range), props for range or single.
**DatePickerWithTimezone:** `value`, `onChange`, `timezone?`, `userTimezone?`, `showTimezoneSelector?`.
- Default mode is date-only (`showTimezoneSelector` defaults to `false`).
- On date selection, the component MUST emit a Date normalized to literal UTC midnight for the selected day (`YYYY-MM-DDT00:00:00.000Z`).
- **Calendar panel (popover):** The date grid opens in a **native popover** (`popover="auto"`) with **CSS anchor positioning** and **`position-try` fallback** (same family as Select in CR05b), using **top-layer `fixed`** placement so the panel is **not clipped** by `overflow-hidden` ancestors (for example `Card`). The panel remains in the DOM; visibility follows popover open state. The **trigger** uses a **native `<button>`** styled consistently with outline trigger patterns used elsewhere in advanced UI.

**DateTimeField:** date + time, timezone-aware. Props: `value`, `onChange`, `timezone?`, `showTimezoneLabel?` (default `false`). When `showTimezoneLabel` is true, render a `<small>` caption below the controls showing the resolved timezone (IANA id plus short offset via `formatTimezoneLabel`).

**FileUpload:** Storage props (supabase, bucket, table_name, record_id, organisation_id, event_id, app_id, category, folder?, pageContext?, is_public?); onUploadSuccess?(result: FileUploadResult), onUploadError?, onProgress?, onRemove?(fileReference: FileReference); accept?, maxSize?, multiple?; files?: FileReference[] (controlled completed uploads for the right panel); acceptHint?: string (optional formats footer override); showUploadedFiles?: boolean (default `true`); label?: string (default `"Browse"`); className?, disabled?. `bucket`, `organisation_id`, and `event_id` are required for canonical storage and deterministic display resolution. `folder` and `pageContext` MUST NOT be used as storage-key segments. `pageContext` is optional for generic storage usage but REQUIRED for RBAC-scoped write boundaries such as `app_file_reference_create` (for example event logo uploads). Delete/remove persistence is **parent-owned** via `onRemove`; FileUpload MUST NOT call storage or DB delete APIs directly. **FileDisplay:** fileReference or url, variant?, bucket?; uses secure client when non-public. When `url` is not provided, FileDisplay resolves bucket from explicit `bucket` prop or `fileReference.file_metadata.bucket`; missing bucket is a contract error. The `supabase` prop for both MUST be a client that implements the pace-core **SupabaseClientLike** contract (including `client.storage`). Apps obtain this client from the storage-capable client mechanism defined in R04. StorageUtils (uploadFile) insert row includes only non-null/non-undefined values for optional fields. **useFileUpload:** uploadStates (each row has stable `id`), handleFileSelect, fileInputRef, isUploading, cancelUpload(id), clearUpload(id). **useFileDisplay, useFileUrlCache:** return url or display info for a file reference.

**ContextSelector:** placeholder?, onOrganisationSelect?, onEventSelect?, showOrganisations?, showEvents?, disabled?, compact?, showNoItemsMessage?, showRetryButton?; uses auth/org/event context internally; no explicit selectedId — derives from UnifiedAuthProvider. **Theming:** palette application is **not** inside this component; consuming apps MUST mount **`useContextTheme()`** (or equivalent integration per [R15 – Dynamic theming](./R15-dynamic-theming.md)) at the **app shell root** so that when selection changes, **`--color-main-*`**, **`--color-sec-*`**, and **`--color-acc-*`** on the **document root** update or clear. **Visual presentation:** see **Visual specification** below.

**InactivityWarningModal:** isOpen, timeRemaining (seconds), onStaySignedIn, onSignOutNow; title?, description?, className?. Rendered via UnifiedAuthProvider renderInactivityWarning when configured.

**useInactivityTracker, useSessionRestoration:** useSessionRestoration(): extends SessionRestorationState (isRestoring, restorationError) with hasTimedOut, timeoutMs. InactivityServiceProvider is part of UnifiedAuthProvider; no separate provider required.

**FileReference:** id, table_name, record_id, file_path, file_metadata, organisation_id, app_id, is_public, created_at, updated_at. **FileMetadata:** fileName, fileType, **bucket** (required on create via `uploadFile` / `app_file_reference_create`), fileSize?, width?, height?, category, etc. Legacy rows with an empty `file_metadata.bucket` MAY be backfilled in the database; **useFileDisplay** and **useFileUrlCache** infer `public-files` when `is_public` is true and `files` otherwise until bucket is present. **FileUploadOptions:** bucket, table_name, record_id, organisation_id, event_id, app_id, category, folder?, pageContext?, is_public?, custom_metadata?. Storage key contract is `organisation_id/event_id/table_name/record_id/objectId-fileName` (objectId must be unique). **FileUploadResult:** { file_reference: FileReference, file_url: string, signed_url? }.

## Visual specification

### ContextSelector

- **States:** (1) **Loading** — spinner + message (e.g. `Loading organisations and events…`). (2) **Error** — destructive **Alert**, message(s), **Retry** button. (3) **Empty** — **Alert**, no-items message, **Check Again** button. (4) **Ready** — **Select** trigger with current org/event or placeholder; dropdown renders a single mixed list with no group headers. Organisation rows use a leading building icon and event rows use a leading calendar icon.
- **Ready-state structure:** Render the ready state as the `Select` root directly (no extra semantic wrapper around the selector root when no additional semantics are needed).
- **Icons:** ContextSelector uses leading icons only for ready-state dropdown item rows (organisation/event differentiation). Trigger and non-ready states remain icon-free unless explicitly specified by a later requirement.
- **Select platform inheritance:** ContextSelector ready-state selector inherits the Select requirement contract (native Popover API + CSS Anchor Positioning + `position-try`, with `<menu role="listbox">` options container).
- **Event list order:** When `showEvents` is true, event options MUST appear in **descending** order by event date (most recent first). `EventService` sorts the auth-context event list after `data_user_events_get` normalization so ContextSelector and other consumers share the same order.

### FileUpload

- **Layout:** Root uses a two-column CSS Grid (`grid-cols-1` on narrow viewports; two columns from `md:` breakpoint). When `showUploadedFiles` is `false`, the drop zone spans the full width (single-column embeds such as dialogs).
- **Left — drop zone (Large size group):** `rounded-2xl`, dashed border (`border-dashed border-main-500`), centered grid content with min height for icon, button, and hints. Drag-over uses an explicit class map keyed off component state (not `group-data-[variant=...]`).
- **Drop zone content (top → bottom):** Upload icon (`Upload` from `@solvera/pace-core/icons`, `main-*` emphasis); primary **Browse** button (`Button` default variant; triggers hidden file input); hint line “drop a file here” (`<small>`); formats footer derived from `accept` or `acceptHint` (e.g. `*File supported .png, .jpg & .webp`).
- **Drag-and-drop:** `drop`, `dragover`, and `dragleave` on the drop zone call `handleFileSelect`; keyboard path remains the Browse button.
- **Right — uploaded files panel:** `<h2>Uploaded files</h2>`, vertical `<ul aria-live="polite">`.
- **Completed row** (from controlled `files` prop): leading file-type icon (`Image` for image MIME/extensions; generic fallback otherwise), filename, ghost **Remove** icon button with `Trash2` and `aria-label="Remove {name}"` (icon uses `acc-*` emphasis); calls `onRemove(fileReference)`.
- **In-progress row** (internal hook state): leading icon + filename; thin bar `Progress` + numeric percent in `<output>`; ghost **Cancel** icon button with `X` and `aria-label="Cancel upload of {name}"`; calls `cancelUpload(id)` (UI-only; does not abort storage).
- **Failed validation/upload:** inline `role="alert"` message in the row; parent or user may call `clearUpload(id)` to dismiss.

### DateTimeField

- **Root:** outer `<section>` with `grid gap-1` and `aria-label="Date and time"`.
- **Controls row:** inner `<section>` with `grid grid-cols-[auto_1fr] gap-2 items-center` — `DatePickerWithTimezone` (date-only, no timezone selector) + time `Input` (`type="time"`, `aria-label="Time"`).
- **Timezone caption:** when `showTimezoneLabel` is true, render `<small>` below the controls row showing the resolved timezone (IANA id plus short offset via `formatTimezoneLabel`).

Other components in this slice: align to [7-visual-standards.md](../../packages/core/docs/standards/7-visual-standards.md) Part C unless a future requirement adds a dedicated recipe.
- **Calendar layout utilities:** Keep layout recipes in component className strings (not `core.css` aliases). Calendar header uses a three-column grid utility compatible with `auto 1fr auto` behavior.
- **DatePickerWithTimezone popover:** The calendar panel uses the same **native popover + anchor positioning + `position-try`** pattern as Select (CR05b family): **fixed** top-layer placement so the panel escapes `overflow-hidden`; trigger is a native **outline-styled** button consistent with other advanced pickers.

## Behaviour

- The client passed to FileUpload and FileDisplay MUST implement SupabaseClientLike (including `client.storage`). Apps MUST obtain this client via the storage-capable client mechanism provided by pace-core (R04); MUST NOT pass a client that does not expose `storage`.
- The file reference insert performed by StorageUtils (uploadFile) MUST omit from the insert payload any field whose value is null or undefined, so that consumers whose file reference table does not include optional columns can use a custom table name without receiving 400 from PostgREST.
- File storage key generation MUST use canonical path semantics: `organisation_id/event_id/table_name/record_id/objectId-fileName`. Path structure is for partitioning and operational isolation only; authorization remains RBAC/RLS and signed-URL policy.
- File access for non-public files MUST go through secure client or RBAC-aware hooks. Date/time components MUST respect timezone (user or explicit). InactivityWarningModal MUST call onStaySignedIn to extend and onSignOutNow to sign out (per UnifiedAuthProvider contract). When org/event selection changes, theme MUST update per R15 (dynamic theming).
- DatePickerWithTimezone MUST hide timezone selection UI by default (date-only mode), and only render timezone selection when explicitly enabled via `showTimezoneSelector`.
- DatePickerWithTimezone MUST normalize selected dates to literal UTC midnight before calling `onChange`.
- DatePickerWithTimezone MUST present the **calendar** in a **popover layer** per **Visual specification** (anchor + `position-try`, not in-flow absolute positioning that can be clipped by ancestors).
- ContextSelector MUST match **this Visual specification** (four states, single mixed dropdown list, item-leading context icons).
- When the app exposes **ContextSelector** (e.g. via PaceAppLayout), the consuming app MUST call **`useContextTheme()`** once at shell level (see [R15](./R15-dynamic-theming.md), [R05c](./R05c-layout-and-shell.md)) so org/event palette data from the database is applied as CSS variables on **`document.documentElement`**; otherwise selection changes will not update theme colours.
- Internal same-layout route changes are not context changes by themselves. Theme updates must be driven by org/event selection changes, not by route transitions that retain the same shell context.
- FileUpload MUST match **this Visual specification** (two-column drop zone + uploaded files panel, drag-and-drop, Browse default label, controlled `files` + `onRemove` for completed rows).
- FileUpload progress display reflects whatever `uploadFile` / `onProgress` reports. The Supabase storage client does not expose byte-level upload progress; values typically jump from `0` to `100` unless a future transport adds intermediate callbacks.
- On successful upload, FileUpload calls `onUploadSuccess` and removes the in-flight row from internal `uploadStates`; the right panel source of truth for completed files is the controlled `files` prop.
- DateTimeField time display and date/time combination MUST respect the resolved timezone (`timezone` prop or `getUserTimeZone()`).
- DateTimeField time input MUST display `HH:mm` for the current `value` in that timezone; when `value` is null, internal time state defaults to `00:00` until the user edits.
- DateTimeField `onChange` MUST emit a single `Date` combining the selected calendar day and time input, interpreted in the resolved timezone.
- DateTimeField `onChange` MUST fire when the time input changes, combining with the current `value` date or today's date when `value` is null.
- DateTimeField `onChange` MUST fire when the date picker changes, preserving the current time portion from `value` or internal time state.
- DateTimeField `disabled` MUST disable both the date picker and the time input.

## Demo app requirements

- Demo includes: a date/time picker example; a file upload and display example; context selector (org or event) if applicable; inactivity modal (trigger after idle or via dev control).
- **Step-by-step:** User opens `/calendar-test` (single date/time demo route) → exercises Calendar single and range selection, DatePickerWithTimezone in date-only mode, DatePickerWithTimezone with timezone selector enabled, DateTimeField with time, and DateTimeField with `showTimezoneLabel` and an explicit timezone. User opens file upload example → selects file → sees progress → file appears in list or FileDisplay. User opens context selector → switches organisation or event → UI updates (including theme when event/org has palette data; see R15-dynamic-theming). User idles for configured period (or triggers via dev control) → InactivityWarningModal appears → user can “Stay signed in” or “Sign out now”.

## Verification

- **Component behaviour:** Verify date/time controls, file upload/display flows, context selection, and inactivity modal interactions match the documented contract.
- **Client contract:** Verify FileUpload/FileDisplay receive a `SupabaseClientLike` client with working `storage` and secure access behaviour.
- **ContextSelector visual states:** Verify loading/error/empty/ready states and icon-led item differentiation in ready-state selector UI.

## Testing requirements

- Unit tests for date/time and storage helpers (including `formatTimezoneLabel`); integration tests for FileUpload, FileDisplay, ContextSelector, InactivityWarningModal, and DateTimeField. Coverage per Standard 08.
- **DateTimeField integration tests** MUST cover: render of date and time controls; timezone caption show/hide via `showTimezoneLabel`; time display for a controlled `value` in an explicit timezone; `onChange` when the time input changes (with and without an existing `value`); `disabled` on both controls; placeholder forwarded to the date picker; default `00:00` time when `value` is null.

## Hierarchical searchable selectors (guidance)

This section is **non-normative** compositional guidance for apps that need a **searchable tree** or grouped options (for example medical condition types). There is **no dedicated pace-core component**; compose existing primitives:

- **Query state:** keep a local filter string; debounce remote or in-memory filtering.
- **Grouping:** map flat or nested option data to `SelectGroup` / `SelectLabel` sections from [CR05b-dialog-select-tabs.md](./CR05b-dialog-select-tabs.md), or render a `Dialog` with a search `Input` and a scrollable `menu`/`listbox` region.
- **Keyboard:** reuse Select’s listbox semantics where possible; otherwise document focus order and Escape-to-dismiss on custom overlays.
- **Fallback:** when hierarchy metadata is missing, fall back to a flat searchable list using the same filter string.
- **Domain data:** taxonomy shape, RPCs, and persistence stay in the consuming app; pace-core only supplies primitives and patterns.

## Do not

- Do not create new storage backend; use existing Supabase storage and contract. Do not copy old implementation.

## References

- [7-visual-standards.md](../../packages/core/docs/standards/7-visual-standards.md), [3-security-rbac-standards.md](../../packages/core/docs/standards/3-security-rbac-standards.md). implementation-guides/file-upload-storage, inactivity-tracking (reference only).
- **Inline — FileReference and FileUploadResult:** FileReference has id, table_name, record_id, file_path, file_metadata (including `bucket`), organisation_id, app_id, is_public. FileUploadResult: `{ file_reference: FileReference, file_url: string, signed_url? }`. **ContextSelector:** `<ContextSelector onOrganisationSelect={switchOrganisation} onEventSelect={setSelectedEvent} showOrganisations showEvents />` (uses auth context; no selectedId prop).

---

## Prompt to use with Cursor

Implement the feature described in this document. Follow the standards and guardrails provided. Add or update tests and demo as specified. Run validate and fix any issues until it passes.
