# CR21 – Workflow-typed forms runtime, authoring, and submission contracts

## Filename convention

This file is **`CR21-workflow-forms-runtime.md`** — pace-core requirement slice **CR21** (see [CR00-core-project-brief.md](./CR00-core-project-brief.md)).

---

## Overview

- Purpose and scope: implement the `pace-core2` layer of the **shared forms platform rescope** documented in **Forms platform architecture (canonical)** below: shared workflow-form contracts, field-key-driven rendering/state helpers, conditional visibility utilities, pre-submission check UX, registration-type selection UX, submission payload shaping, and the **shared admin authoring contract** for form list/create/edit/publish flows. Scope is package + demo verification only.
- External prerequisites: database schema changes, RLS, form-definition persistence, registration-type eligibility evaluation, and workflow orchestration (`app_base_application_create(...)` or equivalent) are owned outside this repo and are prerequisites to real integration.
- Dependencies: [CR06-forms-and-feedback.md](./CR06-forms-and-feedback.md), [CR09-public-pages.md](./CR09-public-pages.md), [CR12-supabase-react-query-error-handling.md](./CR12-supabase-react-query-error-handling.md), [CR18-composite-resilience-utilities.md](./CR18-composite-resilience-utilities.md), [CR20-form-registry-and-address-field.md](./CR20-form-registry-and-address-field.md).
- Standards: 02 Architecture, 03 Security and RBAC, 04 API and tech stack, 05 pace-core compliance, 06 Code quality, 07 Visual ([7-visual-standards.md](../standards/7-visual-standards.md)), 08 Testing and documentation, 09 Operations.

## Forms platform architecture (canonical)

This section is the authoritative description of the **shared `core_forms` cluster** rescope and how it composes with pace-core. **DDL, RLS, and migration ordering** are owned by the database track (see [`DB-change-decisions-p3.md`](../../../../docs/database/decisions/DB-change-decisions-p3.md), **DB-301** and related cards). This slice defines **runtime contracts, UX, and invariants** for the package.

### Problem and rescope direction

The legacy `core_forms` cluster was POC-grade: fields mapped to `table_name` / `column_name`, invited unsafe client-write coupling, and lacked workflow typing and app ownership. The rescoped model uses **typed workflows**, **`field_key`** semantics, and **server-side orchestration** for domain side effects. Where the platform had no production data obligation, superseded tables and columns are removed in favour of explicit workflow typing.

### Three layers

- **`pace-core2` (this package)** — form UI primitives, renderers, validation helpers, step/page patterns, conditional visibility utilities, form state hooks, workflow entrypoint UX, and shared admin authoring contracts/components.
- **Shared forms platform (`core_forms` cluster)** — form definitions, workflow typing, field semantic identity, submission payload structure, response capture.
- **App-level workflow orchestrators** — domain side effects (for example BASE application creation, approval chains, consent capture; TEAM org signup / member-request submission, information collection; other app-specific flows).

The shared platform **never** owns domain persistence. It captures responses and hands them to the workflow orchestrator, which owns what happens next.

### MVP boundaries (member-facing forms)

- **Out of MVP:** org lead/EOI and event lead/EOI flows are excluded from the active rebuild wave unless a slice explicitly reintroduces them.
- **Default access mode:** member-facing forms are **`authenticated_member`** unless a slice marks an exception.
- **Current TEAM / Portal contract:** `org_signup` is member-facing and uses **`authenticated_member`** access in the active rebuild wave.
- **Planned public exceptions:** some org signup flows may need a public entrypoint in TEAM; treat as an explicit exception contract, not the default.

### BASE registration (normative)

- For `workflow_type = 'base_registration'`, **`core_forms` is the registration entrypoint**; **`core_forms.slug`** is the public URL identifier.
- **`base_form_registration_type`** binds a form to permitted **`base_registration_type`** rows.
- **One row** in `base_form_registration_type` → **fixed-type** entrypoint (no selection; slug commits the participant to that type).
- **Multiple rows** → **open-selection** entrypoint (participant chooses among eligible types).
- BASE workflow side effects go through **`app_base_application_create(...)`** (or successor RPC) — **never** direct client writes to domain tables.

### TEAM org signup (normative)

- For `workflow_type = 'org_signup'`, **`core_forms` is an organisation-scoped participant entrypoint** used by Portal/TM01 join and transfer flows.
- `core_forms.organisation_id` is required, `event_id` is null, and the current TEAM / Portal contract uses **`access_mode = 'authenticated_member'`**.
- Portal resolves the selected organisation’s **active primary** `org_signup` form as the canonical supplemental-fields entrypoint for member-request submission.
- Org-scoped member-facing render/share routes use **`/forms/:formSlug`** when an explicit org form slug is addressed directly.
- TEAM workflow side effects go through the **member-request workflow/orchestrator boundary** (for example `app_submit_member_request(...)` or successor contract) — **never** direct client writes to `core_member`, `team_member_request`, or related domain tables.

### Superseded database objects

The following are **dropped** as part of the rescope (zero backward-compatibility obligation where agreed):

- **`core_form_context_types`** — replaced by **`workflow_type`** on `core_forms`; remove **`context_id`** from `core_forms`.
- **`core_form_field_config`** — table/column-oriented per-org config; future per-org field configuration, if needed, uses **`field_key`** as the identifier.

### Data model assumptions (normative contracts)

These are the **semantic contracts** the package and consumers rely on; exact DDL lives in migrations / **DB-301**.

**`core_forms`**

- Carries **`workflow_type`** (see allowed values below), optional **`owner_app_id`** (FK → `rbac_apps`), **`access_mode`** (`public` \| `authenticated_member`, default authenticated member), and **`workflow_config`** (jsonb).
- Current shared-runtime scope is split by owner:
  - **Event-owned workflows:** `base_registration`, `activity_booking`, `merch_order`.
  - **TEAM org-scoped workflows:** `org_signup`, `information_collection`, `consent_capture`.
- For current TEAM org-scoped workflows, **`organisation_id`** is the workflow scope key and **`event_id`** is null.
- For `workflow_type = 'org_signup'`, **`organisation_id` is required**, **`event_id` is null**, and the current Portal/TM01 contract assumes **`access_mode = 'authenticated_member'`**.
- **`slug`** is unique per scope: unique per `(event_id, slug)` when event-scoped, and per `(organisation_id, slug)` when org-scoped; partial unique indexes express this.
- Anchor BASE registration forms are identified by **`workflow_type = 'base_registration'`** (at most one active published row per event via partial unique index on `event_id`).
- At most **one** active published org signup form per organisation: partial unique index on `organisation_id` where `workflow_type = 'org_signup'`, `is_active = true`, and `status = 'published'`.
- **`is_active`** is the live availability switch in the shared runtime; do not assume a second publish/archive lifecycle model here.
- Legacy columns removed: **`context_id`**, **`require_*_confirmation`** booleans — replaced by **`workflow_config`** (see below).

**`core_form_fields`**

- **`field_key`** (text, unique per form) replaces **`table_name` / `column_name`**. Presentation columns (`field_label`, `validation_rules`, `display_options`, etc.) remain as today.

**`core_form_responses`**

- **`workflow_subject_type`** / **`workflow_subject_id`** replace polymorphic **`target_table` / `target_record_id`**. The orchestrator sets the subject after creating the domain record (for example `base_application`).

**`core_form_response_values`**

- **`field_key`** replaces denormalised **`table_name` / `column_name`**.

**`base_form_registration_type` (BASE only)**

- Binds a `core_forms` row (`workflow_type = 'base_registration'`) to **`registration_type_id`**, with denormalised **`event_id`** / **`organisation_id`** for RLS, **`sort_order`**, and **`is_required`** (per registration type). Unique `(form_id, registration_type_id)`.

**`base_registration_type` (BASE only)**

- Carries **`pre_submission_checks`** (`jsonb` array of string keys: `member_profile`, `medical_profile`, `additional_contacts`) shown before the anchor form renders for that registration type.

**TEAM org-form audience binding contract**

- Org-form audience restriction is modelled by a **TEAM-owned binding contract analogous to `base_form_registration_type`**, referencing permitted **`core_membership_type`** rows for an organisation-scoped form.
- The shared renderer consumes the resolved audience outcome; it does not own the persistence model for TEAM member-type bindings.

### `workflow_type` values

`base_registration` \| `org_signup` \| `information_collection` \| `activity_booking` \| `merch_order` \| `consent_capture`.

### `field_key` conventions

`field_key` is the stable semantic identifier at render time, response capture, and orchestration mapping.

- Format: `{domain}.{concept}` (examples: `person.first_name`, `application.emergency_contact_name`, `consent.event_terms`).
- **`generic.*`** namespace: workflow-specific prompts that do not map to a named domain column; orchestrator decides handling.

### `workflow_config` (BASE registration example)

Json object on `core_forms`. Recognised keys for `base_registration` include:

- **`return_url`** — post-submit redirect; if omitted, default to the portal event overview pattern.
Other workflow types define their own keys; unknown keys are ignored by orchestrators that do not recognise them.

> **Note (DB-26):** `pre_submission_checks` for BASE registration live on **`base_registration_type.pre_submission_checks`**, not `core_forms.workflow_config`. Legacy keys in `workflow_config` are deprecated.

### Audience, required forms, and completion

- **`base_form_registration_type.is_required`** is the per-registration-type required/optional switch for event forms.
- **Audience** is modelled outside the renderer.
- Event forms use **registration-type bindings**.
- Org forms use **TEAM-owned member-type bindings**.
- Default org-form audience can be **all active membership types** unless the consuming TEAM/Portal contract narrows it.
- When narrowed, org-form audience restriction uses a **BASE-analogous binding contract** that references **`core_membership_type`**.
- **Completion** for checklists is **submission-based** in MVP (submitted vs not); do not assume generic resubmit flows unless a slice adds them.

### Shared admin authoring contract

`pace-core2` owns the **shared admin authoring contract** for managing workflow forms. This is not a second persistence model and it does not replace consuming-app permissions or app-specific workflow policy. It exists so TEAM, BASE, and later apps do not each invent incompatible form-builder shells over the same `core_forms` platform.

The shared authoring contract covers:

- **Form list management framing** — shared table/list patterns for create, edit, preview/share, activate/deactivate, and delete/archive actions where the consuming app allows them.
- **Metadata editing contract** — shared editing model for `name`, `description`, `slug`, `workflow_type`, `access_mode`, `workflow_config`, and `is_active`.
- **Field selection/editing contract** — shared structured editing for form fields keyed by `field_key`, sort order, active state, labels, validation, and display options. The field catalogue itself remains external input.
- **Publish/activation validation contract** — shared fail-closed validation before a form can become active, including duplicate field-key detection, unsupported workflow/access combinations, invalid metadata, and invalid workflow config.
- **Preview/share contract** — shared notion that participant-facing preview/share targets resolve through the canonical route shape for that workflow/scope; the consuming app decides whether preview/share is surfaced.

The shared authoring contract does **not** own:

- direct writes to domain tables outside the forms cluster
- TEAM member-type binding persistence or BASE registration-type binding persistence
- workflow-specific policy copy or product wording
- app-specific RBAC and route ownership

### Shared authoring invariants

- Admin authoring uses the same canonical form model as runtime consumers; there is no separate app-local draft schema.
- `is_active` remains the live availability switch; the shared authoring surface does not invent a second publish/archive status model.
- `is_primary_entrypoint` is only meaningful for workflows that actually support canonical entrypoint behaviour.
- Field definitions stay `field_key`-first; legacy `table_name` / `column_name` authoring is not a supported path.
- The shared authoring surface may consume a field catalogue such as `core_field_list`, but that catalogue and its DB semantics remain outside this slice.

### Entrypoint resolution (BASE / TEAM / portal patterns)

Canonical participant URL shapes:

- `/{eventSlug}/application`
- `/{eventSlug}/{formSlug}`
- `/forms/:formSlug`

**Rules:**

- **`/application`** resolves the single event form with `workflow_type = 'base_registration'`, `is_primary_entrypoint = true`, and matching `event_id`.
- **`/{formSlug}`** resolves by slug within the event scope.
- **`/forms/:formSlug`** is the member-facing route shape for explicit org-scoped form resolution and sharing.
- Portal join/transfer flow resolves the selected organisation’s active primary `org_signup` form with matching `organisation_id`, `is_primary_entrypoint = true`, and `is_active = true`.
- Non-primary org forms can still resolve by explicit slug through **`/forms/:formSlug`**.
- If no active `org_signup` form exists for the organisation, Portal renders a **minimal no-fields submission path** and still submits through the member-request workflow boundary.

Resolution steps (conceptual):

- BASE event routes: resolve event → resolve form → verify **`is_active`** and open window → enforce **`access_mode`** → load **`base_form_registration_type`** bindings → evaluate registration scope and eligibility → handle existing application resume rules → run **`pre_submission_checks`** from `workflow_config` → render fields.
- TEAM Portal join/transfer flow: resolve selected organisation → resolve active primary `org_signup` form if present → enforce **`access_mode`** → apply TEAM-owned member-type audience and eligibility rules → run **`pre_submission_checks`** from `workflow_config` if configured → render fields, or the minimal no-fields path when no form exists.
- Org form route resolution: resolve explicit org form slug from **`/forms/:formSlug`** within org scope → verify **`is_active`** and open window → enforce **`access_mode`** → apply TEAM-owned member-type audience rules when configured → render fields.

### Submission and backend contract (normative)

The participant UI **does not** write domain tables. Submission goes through a **backend boundary** (Edge Function / RPC with appropriate privileges):

1. Re-validate form availability (`is_active`, open window), access mode, and workflow-specific audience/eligibility rules.
2. Capture **pre-submission check** acknowledgements.
3. Insert **`core_form_responses`** and **`core_form_response_values`** keyed by **`field_key`** when the workflow includes form fields.
4. Call the owning workflow orchestrator with the validated workflow context and any created **`p_form_response_id`**.
5. Link the response: set **`workflow_subject_type` / `workflow_subject_id`** to the created domain record when the orchestrator creates one (for example `base_application`, TEAM member request).
6. Return success; client redirects per workflow contract.

Workflow-specific rules:

- **BASE registration:** validate **`registration_type_id`** via **`base_form_registration_type`**, re-check eligibility **server-side** (UI filtering is UX only), call **`app_base_application_create`** (or equivalent), then create **consent** rows if required and anchor them to the application.
- **TEAM org signup / member request:** submit through the org-signup workflow orchestrator / member-request contract, not through client writes. The orchestrator owns member-type validation, duplicate-request/profile checks, `core_member` / `team_member_request` creation, and any downstream member-domain side effects. Supplemental org-signup responses, when present, are captured only through **`core_form_responses`** / **`core_form_response_values`** keyed by **`field_key`**; the shared renderer does not own the downstream effects.

**Invariant:** workflow selection inputs such as BASE `registration_type_id` or TEAM member-type selection are valid only if they pass **server-side** validation in the owning workflow contract; a raw field value cannot bypass the gate.

### Interaction with BASE workflow concepts (summary)

- **Registration scope** (`core_events.registration_scope`) — enforced on load and on submit; not enforced by conditional fields alone.
- **Eligibility** — `base_registration_type_eligibility` evaluated for UX filtering and re-validated on submit.
- **Approval checks** — requirement chains create `base_application_check` rows; the participant form does not encode the chain in visibility rules.
- **Payment** — if cost > 0, payment belongs in the requirement chain with sort order that avoids charging before approval when types can be rejected.
- **Consent** — `consent.*` **field_key** values on the form are read on submit and turned into **`base_consent`** rows as part of the same submission.

### Conditional fields (within-form only)

Configured in **`display_options`**. **Allowed:** show/hide supplementary fields based on answers; optional sections; cosmetic differences by selected registration type on open-selection forms. **Not allowed as primary branching:** conditional fields must **not** determine which registration type, approval chain, consent set, or cost applies — those come from registration type and server rules. Registration type selection for open-selection forms is a **first-class control**, not a conditional trigger.

### `core_field_list` and non–DB-backed fields

**`core_field_list`** is a separate catalogue (merge fields, reporting, etc.) and is **not** part of this slice’s implementation scope. Non–DB-backed / prompt-only fields, if introduced later, remain orchestrator-owned; **`core_field_list`** alignment is a separate rebuild (see [CR22-shared-reporting-foundations.md](./CR22-shared-reporting-foundations.md) for reporting overlap).

### Non-BASE alignment

- **`org_signup`** is a first-class TEAM-owned organisation-scoped workflow type used by Portal/TM01 join and transfer flows; it is **not** a reuse of `information_collection`.
- **`information_collection`** remains the primary generic collection workflow.
- **`activity_booking`** and **`merch_order`** remain **event-owned** in the current shared runtime.
- Current TEAM org-scoped workflows in this contract surface are **`org_signup`**, **`information_collection`**, **`consent_capture`**, and **`generic`**.

## Acceptance criteria

- [x] `pace-core2` exposes typed workflow-form contracts that model `workflow_type` (including `org_signup`), allowed access modes (`public`, `authenticated_member`), open/closed timing, `workflow_config`, `field_key`, and inferred registration-entrypoint binding mode (single binding = fixed type; multiple bindings = participant selection).
- [x] Workflow field rendering composes the existing forms registry (`CR20` dynamic form field registry and AddressField providers) and `useZodForm`, using `field_key` as the authoritative semantic identifier for submission payloads and conditional visibility evaluation (form state uses stable field row `id` as the RHF/Zod key when needed to avoid dotted `field_key` nesting in react-hook-form; payloads remain `field_key`-first via `workflowValuesByFieldKey`).
- [x] Conditional visibility utilities evaluate only against current in-form values and registration selection context; hidden fields are omitted from render output and stripped from the shared submission payload.
- [x] Pre-submission checks are rendered and gated through shared contracts before field rendering/submission; acknowledgement state is captured separately from field values.
- [x] Registration type selection is a first-class shared control for open-selection entrypoints and remains distinct from conditional field logic; the selected registration type is carried explicitly in the submission payload.
- [x] Submission helpers and adapter contracts capture workflow responses using `field_key`/value pairs, acknowledgements, metadata, and optional `registration_type_id`; the package never writes domain tables directly and never assumes a concrete transport/client.
- [x] Demo verification exists for fixed-type and open-selection metadata fixtures, including public entrypoint states (`loading`, `not_found`, `not_yet_open`, `closed`, `auth_required`, `access_denied`, `ready`, `submitted`, `no_eligible_types`) using `PublicPageLayout` (see `src/pages/WorkflowFormsShowcasePage.tsx`; route wired in the demo app).
- [x] `pace-core2` exposes a shared admin authoring contract for form list/create/edit flows so consuming apps can manage workflow forms without inventing app-local builder semantics.
- [x] Shared authoring validation fails closed before activation/publish when metadata, field definitions, or workflow config are invalid.
- [x] Shared authoring contracts keep preview/share route semantics aligned with the canonical workflow route rules in this slice.
- [x] `WorkflowFieldVisibilityEditor` is part of the public `@solvera/pace-core/forms` authoring export surface so consuming apps do not deep-import internal files.
- [x] **Hub-placement contract (standalone components):** `WorkflowRegistrationTypeSelector` and `WorkflowPreSubmissionChecks` MUST work **outside** `WorkflowFormRenderer` so consuming apps can render them on an event hub (or similar orchestration page) before navigating to the anchor form page.
- [x] **Open-selection hub entrypoint:** When `base_form_registration_type` has multiple rows and no application exists yet, consuming apps MAY render `WorkflowRegistrationTypeSelector` on the hub with controlled `selectedRegistrationTypeId` / `onRegistrationTypeChange`; navigation to the anchor form occurs after selection (package does not own routing).
- [x] **Pre-submission checks on hub:** `WorkflowPreSubmissionChecks` MAY render on the hub for draft applications OR inside `WorkflowFormRenderer`; `acknowledgedCheckKeys` is controlled state — consuming apps persist per-draft acknowledgement keys via their own storage/RPC (package does not own persistence).
- [x] **Standalone component tests:** Integration tests cover selector and checks components mounted without `WorkflowFormRenderer` wrapper.

## API / Contract

- Public exports from `packages/core/src/forms/workflow/` via `@solvera/pace-core/forms`:
  - Components: `WorkflowFormRenderer`, `WorkflowPreSubmissionChecks`, `WorkflowRegistrationTypeSelector`
- Authoring components/contracts: `WorkflowFormAuthoringShell`, `WorkflowFormMetadataEditor`, `WorkflowFormFieldEditor`, `WorkflowFieldVisibilityEditor`, `validateWorkflowAuthoringState`, `buildWorkflowPreviewTarget`, `AuthoringIssueAlerts`, `WORKFLOW_TYPE_LABELS`, `workflowTypeDisplayLabel`
  - Visibility / payload: `evaluateWorkflowVisibility`, `filterVisibleWorkflowFields`, `isWorkflowFieldVisible`, `buildWorkflowSubmissionPayload`, `buildWorkflowFormSchema`
  - Helpers: `workflowFieldToFormFieldMeta`, `workflowValuesByFieldKey`, `getWorkflowPreSubmissionCheckKeys`, `resolvePreSubmissionChecks`, `arePreSubmissionChecksSatisfied`
  - Types: `WorkflowType`, `WorkflowAccessMode`, `WorkflowFormStatus`, `WorkflowEntrypointState`, `WorkflowFormDefinition`, `WorkflowFieldDefinition`, `WorkflowRegistrationBinding`, `WorkflowVisibilityRule`, `WorkflowVisibilityCondition`, `WorkflowVisibilityContext`, `WorkflowPreSubmissionCheck`, `WorkflowFormConfig`, `WorkflowSubmissionPayload`, `WorkflowSubmissionAdapter`, `WorkflowSubmissionResult`, `WorkflowSubmissionSuccess`, `ResolvedPreSubmissionCheck`, `WorkflowAuthoringState`, `WorkflowAuthoringValidationResult`, plus component props types where exported
- Authoritative contract notes:
  - `WorkflowType` must cover the architecture-approved values: `'base_registration' | 'org_signup' | 'information_collection' | 'activity_booking' | 'merch_order' | 'consent_capture' | 'generic'`.
  - `WorkflowAccessMode` in current MVP/shared-runtime scope must be exactly `'public' | 'authenticated_member'`.
  - `WorkflowFormDefinition` must include stable identifiers and runtime state required by the renderer: `id`, `slug`, `name`, `description?`, `workflowType`, `accessMode`, `status`, `opensAt?`, `closesAt?`, `workflowConfig`, `fields`, and optional `registrationBindings`.
  - `registrationBindings` are a BASE event-registration concern; TEAM org-form audience and member-type bindings remain consuming-app contracts outside the shared renderer.
  - `WorkflowFieldDefinition` must extend the metadata-driven field model used by `CR20` (dynamic form field registry and AddressField providers) with `fieldKey: string`, `sortOrder: number`, `isActive?: boolean`, and structured `displayOptions` for conditional visibility.
  - `WorkflowRegistrationBinding` must carry the selected semantic identity and participant-facing copy: `registrationTypeId`, `label`, `description?`, `sortOrder`, `isDefault?`, and optional eligibility state/message returned by the consuming app/backend.
  - `WorkflowEntrypointState` must cover page-level gating before submission: `loading`, `not_found`, `not_yet_open`, `closed`, `auth_required`, `access_denied`, `no_eligible_types`, `ready`, `submitted`.
  - `WorkflowSubmissionPayload` must carry `formId`, `workflowType`, optional `registrationTypeId`, `values: Array<{ fieldKey: string; value: unknown }>`, `preSubmissionChecks: string[]`, and optional metadata/context bag for consuming apps.
  - `registrationTypeId` is BASE-specific; TEAM org-signup member-type selection and request metadata remain owned by the consuming workflow contract outside the shared renderer payload.
  - `WorkflowSubmissionAdapter` must be transport-agnostic and return an `ApiResult`-style outcome aligned with CR12/CR18. The adapter owns network/database side effects; pace-core only shapes/validates the payload contract.
  - **Hub orchestration (consuming apps):** pace-core exports selector/check components for hub placement; it does **not** export hub forms lists, withdraw flows, or profile-gate banners (portal composes CR28 `SectionBanner` + app data).
  - **`WorkflowRegistrationTypeSelector` standalone props:** `bindings: WorkflowRegistrationBinding[]`, `selectedRegistrationTypeId?: string | null`, `onChange?: (registrationTypeId: string) => void`, `groupName: string` (required for radio a11y), `disabled?: boolean`. Works when `bindings.length > 1`; fixed-type entrypoints render read-only summary when `bindings.length === 1`.
  - **`WorkflowPreSubmissionChecks` standalone props:** `checks: ResolvedPreSubmissionCheck[]`, `acknowledgedKeys: ReadonlyArray<string>`, `onAcknowledgedKeysChange: (keys: string[]) => void`, `disabled?: boolean`, optional `sectionId`. Submission/gating elsewhere remains app responsibility until checks satisfied.
  - `WorkflowAuthoringState` must model the editable shared authoring surface for a form: metadata, fields, and authoring-time validation state.
- `WorkflowFieldVisibilityEditor` must be exported from `@solvera/pace-core/forms` with its props type so consumers can compose conditional visibility UX without internal-path imports.
  - `WorkflowFormMetadataEditor` may accept `slugReadOnly?: boolean` to lock only slug edits (for example when a consumer enforces immutable published slugs) while leaving other metadata controls at their normal `disabled` behavior.
  - `WorkflowFormAuthoringShell` may accept `slugReadOnly?: boolean` and forward it to `WorkflowFormMetadataEditor`; omitting the prop must preserve existing behavior.
  - `WorkflowFormAuthoringShell` may accept optional `metadataAside?: ReactNode`; when provided, content renders **below** `WorkflowFormMetadataEditor` in a single stacked column (full-width cards with vertical `gap`). Omitting the prop preserves prior behavior (metadata card only).
  - `WorkflowFormAuthoringShell` may accept optional `onSaveValidationAttempted?: () => void`; when Save is clicked while `validateWorkflowAuthoringState` reports errors, the shell records the attempt (shows inline issues) and invokes this callback.
  - `WorkflowFormMetadataEditor` may accept optional `shownAuthoringIssues?: WorkflowAuthoringValidationIssue[]` (normally from the shell after a failed save) to render inline alerts; validator paths with dedicated controls are mapped explicitly, and any other `metadata.*` issues (for example `metadata.opensAt` / `metadata.closesAt` from schedule fields in consumer `middleContent`) render in a **fallback** alert block at the bottom of the metadata card.
  - `WorkflowFormFieldEditor` may accept optional `shownFieldIssues?: WorkflowAuthoringValidationIssue[]` for per-row and sheet-level inline alerts.
  - `WorkflowFieldCataloguePicker` may accept optional `onOptionSelect?: (option: WorkflowFieldCatalogueOption | null) => void` (fires when the author picks a catalogue row, for syncing `fieldType` and labels) and optional `searchPlacement?: 'popover' | 'none'` (filter UI inside the select popover vs no filter). `enableSearch?: boolean` is **deprecated**; `false` maps to `searchPlacement: 'none'`.
  - **Runtime dependency:** field reorder in `WorkflowFormFieldEditor` uses **`@dnd-kit/core`**, **`@dnd-kit/sortable`**, and **`@dnd-kit/utilities`** (declared in `packages/core/package.json`).
  - **Schedule validation:** when both `metadata.opensAt` and `metadata.closesAt` are set, `validateWorkflowAuthoringState` compares **UTC calendar dates** only; **`closesAt` must fall on a strictly later calendar day** than `opensAt` (same calendar day fails even if the close timestamp is later in the day). Invalid ISO strings are errors on the corresponding path.
  - Shared authoring exports must stay transport-agnostic. They shape and validate authoring state, but the consuming app owns persistence and RBAC.
  - Preview/share helpers must return canonical route targets for the workflow/scope, but they must not assume that every consumer exposes preview/share actions.
- Shared field-catalogue picker ownership is defined in [CR25-shared-field-catalogue-picker.md](./CR25-shared-field-catalogue-picker.md). CR21 consumes that contract for authoring surfaces and does not redefine picker transport semantics here.
- File paths:
  - Package contracts and components live under `packages/core/src/forms/workflow/`.
  - Demo verification page lives at `src/pages/WorkflowFormsShowcasePage.tsx` (imported from the demo app route; may be direct-imported to satisfy barrel export governance).

## Visual specification

- Use [7-visual-standards.md](../standards/7-visual-standards.md) Part A and Part C for global spacing, semantic colours, elevation, and size groups. This slice adds only the workflow-entrypoint recipe below.
- Public workflow entrypoints must compose `PublicPageLayout` from CR09. They must not use authenticated app shell chrome.
- Layout recipe:
  - Outer content container: centered column, `w-full`, `max-w-3xl`, generous vertical rhythm (`gap-6` or equivalent Standard 07 spacing group).
  - Intro block: form title, optional participant-facing description, and event/app branding supplied by the surrounding public layout.
  - State banners: use shared alert components for closed/not-yet-open/access/eligibility states; destructive only for hard-stop states, default/info styling for neutral guidance.
  - Registration selection: render open-selection bindings as stacked radio-card rows with title, supporting copy, and right-aligned status/meta content. Fixed-type entrypoints do not show the selector; they may show a read-only summary card instead.
  - Pre-submission checks: render as a grouped card section above the form fields with checkbox rows and concise helper text. Submission CTA remains disabled until required acknowledgements are satisfied.
  - Fields: use the CR20 registry renderers (dynamic form field registry and AddressField providers) in a single-column flow by default; conditional reveal/hide transitions must not reorder unrelated content unpredictably.
- Deltas:
  - This slice extends CR20 by adding workflow-specific entrypoint framing and `field_key` semantics; it does not override CR20 field-level control styling.
  - This slice depends on CR09 for page chrome and state handling rather than introducing a second public-page layout system.
  - Shared admin authoring should reuse the same visual language: structured sectioning, explicit validation states, and no raw JSON-primary workflow editing in normal v1 flows.
  - **`WorkflowFormAuthoringShell` authoring errors:** Consumers must **not** expect authoring error aggregation above the editors on initial load. **`Save` calls `onSave` only after `validateWorkflowAuthoringState` passes**; a click while invalid records the attempt and routes issues **inline** using compact alerts mapped from validator paths (`metadata.*`, `fields`, `fields.N.*`), with leftovers in an **Additional checks** card below the Fields editor. **Invalid authoring alone does not disable `Save`;** concurrency/RBAC `disabled` comes from consuming apps (`isSaving`, permissions).
  - **`WorkflowFormMetadataEditor` (Form metadata card):** `CardContent` uses a responsive two-column grid (`md:grid-cols-2`) for metadata controls so paired fields lay out side by side on medium+ breakpoints; **`Description`** spans both columns (`md:col-span-2`) so the textarea keeps full usable width. **Workflow type** and **Access mode** selects show fixed human-readable option labels while underlying values remain canonical slugs (`WorkflowType`, `WorkflowAccessMode`).
  - **`WorkflowFormFieldEditor` (Fields card):** Fields render as **rows in a single scrollable table** (drag handle column, field key picker, label, required/active, remove). **Reorder** is **drag-and-drop only** (keyboard/pointer sensors via `@dnd-kit`); `sortOrder` is rewritten contiguously on reorder. `WorkflowFieldCataloguePicker` filters inside the select popover (no external search row); the picker occupies one grid column in the row. Catalogue selection syncs `fieldType` (and placeholder labels). `generic.*` keys use a constrained type select; catalogue-backed keys **do not render** a type control. **Display options JSON is not exposed** in this editor (visibility/advanced JSON editing is out of scope for v1 BASE builder UI). The row stack lives in **`CardContent`** with **horizontal scroll** where needed; **do not** wrap the table in a second full **border + rounded** frame inside the outer **`Card`**—use the **`Card`** border as the panel edge and **row separators** (`border-b` on rows or equivalent) instead of a nested boxed table.
## Verification

- **pace-core demo:** add a workflow-forms showcase page with fixture definitions for:
  - fixed registration entrypoint with a hidden registration selector and visible fixed-type summary
  - open-selection entrypoint with at least two bindings, one default, and one ineligible option/message
  - pre-submission checks gating the form
  - conditional field visibility based on another field and on selected registration type
  - payload preview or mock submit adapter result showing `field_key`-based values and acknowledgements
  - authoring-state fixture showing metadata edit, field ordering/edit, validation failure, and preview-target generation
  - visibility editor fixture showing `WorkflowFieldVisibilityEditor` integration through package-level imports only
- Concrete verification flow:
  - Visit the demo workflow forms route while signed out and verify the page still renders through `PublicPageLayout`.
  - Verify both supported access modes: `public` entrypoint renders while signed out; `authenticated_member` entrypoint shows the expected auth-required gate until signed in.
  - Toggle between fixture states (`ready`, `not yet open`, `closed`, `auth required`, `no eligible types`) and verify the correct gate content appears.
  - Complete acknowledgements, choose a registration type on the open-selection fixture, answer fields that trigger conditional visibility, and submit.
  - Verify the resulting payload includes only visible fields, keeps `registrationTypeId` separate, and preserves acknowledgement keys.
  - In the authoring fixture, edit metadata and fields, trigger invalid states, and verify activation/publish remains blocked until validation passes.

**Automated coverage (demo app + pace-core):** entrypoint banners and gating behaviour are covered by `WorkflowFormRenderer` integration tests; the demo’s `authenticated_member` + signed-out mapping is covered by `effectiveWorkflowShowcaseEntrypoint` unit tests in the demo app; the workflow showcase submit + payload preview and visibility-editor fixture rendering are covered by `WorkflowFormsShowcasePage` integration tests; authoring validation and preview-target generation are covered by `validateWorkflowAuthoringState`, `buildWorkflowPreviewTarget`, and `WorkflowFormAuthoringShell` tests. Full matrix of fixture **Select** interactions remains manual (popover behaviour is not asserted in jsdom).

## Traceability status

- CR21 authoring exports are shipped and exported from `@solvera/pace-core/forms` via `packages/core/src/forms/index.ts`.
- `WorkflowFieldVisibilityEditor` and `WorkflowFieldVisibilityEditorProps` are exported from `@solvera/pace-core/forms` via `packages/core/src/forms/index.ts`.
- Workflow taxonomy contract now includes `org_signup` in `WorkflowType`.
- Shared authoring validation and preview-target route resolution are implemented in `validateWorkflowAuthoringState` and `buildWorkflowPreviewTarget`.
- Demo verification now includes authoring fixture state edit/save/preview traces in `src/pages/WorkflowFormsShowcasePage.tsx`.
- BA03 dependency readiness: required CR21 authoring imports are now concrete package exports; coverage is provided by automated tests in `packages/core/src/forms/workflow/` plus showcase integration tests.

## Testing requirements

- Unit tests:
  - `evaluateWorkflowVisibility` for positive/negative conditions, multi-rule evaluation, and registration-type-aware conditions
  - `filterVisibleWorkflowFields` to confirm hidden fields are excluded deterministically
  - `buildWorkflowSubmissionPayload` to confirm `field_key` ordering, omission of hidden/inactive fields, acknowledgement capture, and optional registration type handling
- Integration tests:
  - `WorkflowRegistrationTypeSelector` fixed vs open-selection behavior
  - `WorkflowPreSubmissionChecks` gating of submission
  - `WorkflowFormRenderer` composed with `useZodForm`, registry-backed fields, and conditional visibility changes
  - access-mode gating behavior for `public` and `authenticated_member`
  - Demo/public entrypoint flow rendered inside `PublicPageLayout`
- Coverage expectations per Standard 08:
  - workflow utilities target unit-level coverage expectations
  - shared UI contracts receive integration coverage for critical user paths

## Do not

- Do not implement or simulate direct writes to domain tables such as `base_application`; submission side effects belong to the external workflow orchestrator.
- Do not reintroduce `table_name` / `column_name` semantics anywhere in the pace-core contract surface; `field_key` is the only semantic field identifier in this slice.
- Do not let conditional visibility determine approval chain, cost, consent requirements, or canonical registration type; those are workflow concerns resolved outside the renderer.
- Do not add app-specific routing or login redirect logic into the package; expose adapter props/contracts instead.
- Do not copy legacy BASE registration implementation; implement from this slice and the **Forms platform architecture (canonical)** section above.

## References

- [CR06-forms-and-feedback.md](./CR06-forms-and-feedback.md)
- [CR09-public-pages.md](./CR09-public-pages.md)
- [CR12-supabase-react-query-error-handling.md](./CR12-supabase-react-query-error-handling.md)
- [CR18-composite-resilience-utilities.md](./CR18-composite-resilience-utilities.md)
- [CR20-form-registry-and-address-field.md](./CR20-form-registry-and-address-field.md)
- [CR22-shared-reporting-foundations.md](./CR22-shared-reporting-foundations.md)
- [CR25-shared-field-catalogue-picker.md](./CR25-shared-field-catalogue-picker.md)
- [7-visual-standards.md](../standards/7-visual-standards.md)
- [docs/XX00-template-requirements.md](../../../../docs/XX00-template-requirements.md)
- Database traceability: [`DB-change-decisions-p3.md`](../../../../docs/database/decisions/DB-change-decisions-p3.md) (**DB-301**)

---

## Prompt to use with Cursor

Implement the feature described in this document. Follow the standards and guardrails provided. Add or update tests and demo verification as specified in **Testing requirements** and **Verification**. Run `npm run validate` and fix issues until it passes.

---

**Checklist before running Cursor:** [CR00-core-project-brief.md](./CR00-core-project-brief.md) · [CR00-core-architecture.md](./CR00-core-architecture.md) · Cursor rules · ESLint config · this requirements doc.
