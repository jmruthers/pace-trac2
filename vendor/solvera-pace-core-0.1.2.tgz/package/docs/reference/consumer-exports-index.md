# pace-core consumer export index

Comprehensive index of all public `@solvera/pace-core` exports for consumers.

- Scope: all package API entrypoints in `package.json` `exports` with TypeScript declarations.
- Detail level: signature-level only (function signatures + props/option type surfaces).
- Stability tiers: `stable` (root consumer contract), `advanced` (scoped entrypoints), `internal` (not for consumer use).
- Preferred import path: root for stable APIs, scoped entrypoints for advanced APIs.
- Generated: `2026-06-23T10:31:39.820Z` via `npm run docs:exports-index`.

## Import policy

- Use `@solvera/pace-core` by default for stable APIs.
- Use scoped entrypoints only for advanced APIs.
- Do not depend on exports marked `internal`.

## Known collisions

- `Calendar`: `@solvera/pace-core/components`, `@solvera/pace-core/icons`

Collision-safe import examples:
- `Calendar` component from `@solvera/pace-core/components`: `import { Calendar } from '@solvera/pace-core/components';`
- `Calendar` alternative from `@solvera/pace-core/icons`: `import { Calendar as CalendarAlt } from '@solvera/pace-core/icons';`

## Entry points

- [`@solvera/pace-core`](#solvera-pace-core)
- [`@solvera/pace-core/comms`](#solvera-pace-core-comms)
- [`@solvera/pace-core/components`](#solvera-pace-core-components)
- [`@solvera/pace-core/crud`](#solvera-pace-core-crud)
- [`@solvera/pace-core/events`](#solvera-pace-core-events)
- [`@solvera/pace-core/forms`](#solvera-pace-core-forms)
- [`@solvera/pace-core/hooks`](#solvera-pace-core-hooks)
- [`@solvera/pace-core/icons`](#solvera-pace-core-icons)
- [`@solvera/pace-core/itinerary`](#solvera-pace-core-itinerary)
- [`@solvera/pace-core/location`](#solvera-pace-core-location)
- [`@solvera/pace-core/login-history`](#solvera-pace-core-login-history)
- [`@solvera/pace-core/member-profile-launch`](#solvera-pace-core-member-profile-launch)
- [`@solvera/pace-core/providers`](#solvera-pace-core-providers)
- [`@solvera/pace-core/rbac`](#solvera-pace-core-rbac)
- [`@solvera/pace-core/reporting`](#solvera-pace-core-reporting)
- [`@solvera/pace-core/resilience`](#solvera-pace-core-resilience)
- [`@solvera/pace-core/services`](#solvera-pace-core-services)
- [`@solvera/pace-core/support`](#solvera-pace-core-support)
- [`@solvera/pace-core/theming`](#solvera-pace-core-theming)
- [`@solvera/pace-core/types`](#solvera-pace-core-types)
- [`@solvera/pace-core/utils`](#solvera-pace-core-utils)

## `@solvera/pace-core`

Declaration source: `dist/index.d.ts`

### Runtime exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `setupRBAC` | function | stable | `@solvera/pace-core` | Function for setup rbac. | `setupRBAC(supabaseClient: RBACSupabaseClient, config?: Partial<RBACConfig>): void` |
| `UnifiedAuthProvider` | provider | stable | `@solvera/pace-core` | React context provider for unified auth. | `UnifiedAuthProvider(props: UnifiedAuthProviderProps): JSX.Element` |
| `useUnifiedAuthContext` | hook | stable | `@solvera/pace-core` | React hook for unified auth context. | `useUnifiedAuthContext(): UnifiedAuthContextValue` |

### Type exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `RBACConfig` | type | stable | `@solvera/pace-core` | Type export for rbacconfig. | `interface RBACConfig` |
| `RBACSupabaseClient` | type | stable | `@solvera/pace-core` | Type export for rbacsupabase client. | `interface RBACSupabaseClient` |

## `@solvera/pace-core/comms`

Declaration source: `dist/comms/index.d.ts`

### Runtime exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `buildCommSendRequest` | function | advanced | `@solvera/pace-core/comms` | Function for build comm send request. | `buildCommSendRequest(input: { organisationId: string; recipientPool: RecipientPoolDescriptor; draft: CommDraft; sourceApp: string; sourceContextType?: string; sourceContextId?: string; }): CommSendRequest` |
| `CommComposer` | component | advanced | `@solvera/pace-core/comms` | UI component for comm composer. | `CommComposer({ adapter, organisationId, sourceApp, recipientPool, rbac, draft, onDraftChange, templates, mergeFields, recipientPreview, blockSendOnUnresolvedTokens, blockSendWhenPoolEmpty, lockSenderIdentity, sourceContextType: sourceContextTypeProp, sourceContextId: sourceContextIdProp, onCancel, onSendComplete, onSendError, onScheduleComplete, }: CommComposerProps): JSX.Element` |
| `dispatchBaseNotificationJob` | function | advanced | `@solvera/pace-core/comms` | Function for dispatch base notification job. | `dispatchBaseNotificationJob(runtime: PumpRuntime, job: BaseNotificationDispatchJob): Promise<ApiResult<CommSendResult>>` |
| `dispatchBaseNotificationJobs` | function | advanced | `@solvera/pace-core/comms` | Function for dispatch base notification jobs. | `dispatchBaseNotificationJobs(runtime: PumpRuntime, jobs: BaseNotificationDispatchJob[]): Promise<Array<{ jobId: string; result: ApiResult<CommSendResult>; }>>` |
| `draftForChannel` | function | advanced | `@solvera/pace-core/comms` | Function for draft for channel. | `draftForChannel(draft: CommDraft, channel: CommChannel): CommDraft` |
| `extractMergeTokens` | function | advanced | `@solvera/pace-core/comms` | Function for extract merge tokens. | `extractMergeTokens(content: string): string[]` |
| `getUnresolvedTokens` | function | advanced | `@solvera/pace-core/comms` | Function for get unresolved tokens. | `getUnresolvedTokens(content: string, fields: CommMergeField[]): string[]` |
| `insertMergeToken` | function | advanced | `@solvera/pace-core/comms` | Function for insert merge token. | `insertMergeToken(value: string, token: string, selectionStart: number, selectionEnd?: number): string` |
| `isCustomFilterPool` | function | advanced | `@solvera/pace-core/comms` | Function for is custom filter pool. | `isCustomFilterPool(pool: RecipientPoolDescriptor): pool is Extract<RecipientPoolDescriptor, { type: "custom_filter"; }>` |
| `isEventParticipantsPool` | function | advanced | `@solvera/pace-core/comms` | Function for is event participants pool. | `isEventParticipantsPool(pool: RecipientPoolDescriptor): pool is Extract<RecipientPoolDescriptor, { type: "event_participants"; }>` |
| `isManualPool` | function | advanced | `@solvera/pace-core/comms` | Function for is manual pool. | `isManualPool(pool: RecipientPoolDescriptor): pool is Extract<RecipientPoolDescriptor, { type: "manual"; }>` |
| `isOrgMembersPool` | function | advanced | `@solvera/pace-core/comms` | Function for is org members pool. | `isOrgMembersPool(pool: RecipientPoolDescriptor): pool is Extract<RecipientPoolDescriptor, { type: "org_members"; }>` |
| `MergeFieldToolbar` | component | advanced | `@solvera/pace-core/comms` | UI component for merge field toolbar. | `MergeFieldToolbar({ fields, onInsert, disabled }: MergeFieldToolbarProps): JSX.Element` |
| `MessagePreview` | component | advanced | `@solvera/pace-core/comms` | UI component for message preview. | `MessagePreview({ draft, mergeFields, sampleValues }: MessagePreviewProps): JSX.Element` |
| `poolWarningLabel` | function | advanced | `@solvera/pace-core/comms` | Function for pool warning label. | `poolWarningLabel(warning: CommPoolWarning): string` |
| `RecipientPoolPreview` | component | advanced | `@solvera/pace-core/comms` | UI component for recipient pool preview. | `RecipientPoolPreview({ preview, isLoading, errorMessage }: RecipientPoolPreviewProps): JSX.Element` |
| `resolveMergeTokens` | function | advanced | `@solvera/pace-core/comms` | Function for resolve merge tokens. | `resolveMergeTokens(content: string, values: Record<string, string>): string` |
| `sanitiseCommHtml` | function | advanced | `@solvera/pace-core/comms` | Function for sanitise comm html. | `sanitiseCommHtml(html: string): string` |
| `sendSystemNotification` | function | advanced | `@solvera/pace-core/comms` | Function for send system notification. | `sendSystemNotification(adapter: Pick<CommSendAdapter, "send">, request: SystemNotificationRequest): Promise<ApiResult<CommSendResult>>` |
| `useCommDraft` | hook | advanced | `@solvera/pace-core/comms` | React hook for comm draft. | `useCommDraft(initialDraft: CommDraft): { draft: CommDraft; setDraft: import("react").Dispatch<import("react").SetStateAction<CommDraft>>; updateDraft: (patch: Partial<CommDraft>) => void; setChannel: (channel: CommDraft["channel"]) => void; resetDraft: () => void; commitDraft: (nextDraft?: CommDraft) => void; isDirty: boolean; }` |
| `useCommMergeFields` | hook | advanced | `@solvera/pace-core/comms` | React hook for comm merge fields. | `useCommMergeFields(input: { adapter: CommSendAdapter; organisationId: string; channel: CommDraft["channel"]; recipientPool: RecipientPoolDescriptor; sourceContextType?: string; sourceContextId?: string; }): { mergeFields: CommMergeField[]; isLoading: boolean; error: ApiError \| null; refetch: () => Promise<void>; }` |
| `useCommSendAdapter` | hook | advanced | `@solvera/pace-core/comms` | React hook for comm send adapter. | `useCommSendAdapter(options: UseCommSendAdapterOptions): CommSendAdapter` |
| `useCommTemplates` | hook | advanced | `@solvera/pace-core/comms` | React hook for comm templates. | `useCommTemplates(input: { adapter: CommSendAdapter; organisationId: string; channel: CommDraft["channel"]; }): { templates: CommTemplate[]; isLoading: boolean; error: ApiError \| null; refetch: () => Promise<void>; }` |
| `useResolvedPool` | hook | advanced | `@solvera/pace-core/comms` | React hook for resolved pool. | `useResolvedPool(input: { adapter: CommSendAdapter; recipientPool: RecipientPoolDescriptor; organisationId: string; channel: CommDraft["channel"]; }): { preview: CommRecipientPreview \| null; isLoading: boolean; error: ApiError \| null; refetch: () => Promise<void>; }` |
| `validateCommDraft` | function | advanced | `@solvera/pace-core/comms` | Function for validate comm draft. | `validateCommDraft(draft: CommDraft): CommDraftValidationResult` |

### Type exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `BaseNotificationDispatchJob` | type | advanced | `@solvera/pace-core/comms` | Type export for base notification dispatch job. | `interface BaseNotificationDispatchJob` |
| `CommChannel` | type | advanced | `@solvera/pace-core/comms` | Type export for comm channel. | `type CommChannel` |
| `CommComposerProps` | type | advanced | `@solvera/pace-core/comms` | Props type for comm composer. | `interface CommComposerProps` |
| `CommDraft` | type | advanced | `@solvera/pace-core/comms` | Type export for comm draft. | `interface CommDraft` |
| `CommDraftValidationIssue` | type | advanced | `@solvera/pace-core/comms` | Type export for comm draft validation issue. | `interface CommDraftValidationIssue` |
| `CommDraftValidationResult` | type | advanced | `@solvera/pace-core/comms` | Result type for comm draft validation. | `interface CommDraftValidationResult` |
| `CommMergeContext` | type | advanced | `@solvera/pace-core/comms` | Type export for comm merge context. | `interface CommMergeContext` |
| `CommMergeField` | type | advanced | `@solvera/pace-core/comms` | Type export for comm merge field. | `interface CommMergeField` |
| `CommMergeScope` | type | advanced | `@solvera/pace-core/comms` | Type export for comm merge scope. | `type CommMergeScope` |
| `CommMessageStatus` | type | advanced | `@solvera/pace-core/comms` | Type export for comm message status. | `type CommMessageStatus` |
| `CommPoolWarning` | type | advanced | `@solvera/pace-core/comms` | Type export for comm pool warning. | `interface CommPoolWarning` |
| `CommRbacContext` | type | advanced | `@solvera/pace-core/comms` | Type export for comm rbac context. | `interface CommRbacContext` |
| `CommRecipientPreview` | type | advanced | `@solvera/pace-core/comms` | Type export for comm recipient preview. | `interface CommRecipientPreview` |
| `CommRecipientStatus` | type | advanced | `@solvera/pace-core/comms` | Type export for comm recipient status. | `type CommRecipientStatus` |
| `CommScheduleCompletePayload` | type | advanced | `@solvera/pace-core/comms` | Type export for comm schedule complete payload. | `interface CommScheduleCompletePayload` |
| `CommScheduleRequest` | type | advanced | `@solvera/pace-core/comms` | Type export for comm schedule request. | `interface CommScheduleRequest` |
| `CommScheduleResult` | type | advanced | `@solvera/pace-core/comms` | Result type for comm schedule. | `interface CommScheduleResult` |
| `CommSendAdapter` | type | advanced | `@solvera/pace-core/comms` | Type export for comm send adapter. | `interface CommSendAdapter` |
| `CommSendRequest` | type | advanced | `@solvera/pace-core/comms` | Type export for comm send request. | `interface CommSendRequest` |
| `CommSendResult` | type | advanced | `@solvera/pace-core/comms` | Result type for comm send. | `interface CommSendResult` |
| `CommSendTestRequest` | type | advanced | `@solvera/pace-core/comms` | Type export for comm send test request. | `type CommSendTestRequest` |
| `CommTemplate` | type | advanced | `@solvera/pace-core/comms` | Type export for comm template. | `interface CommTemplate` |
| `CommTokenWarning` | type | advanced | `@solvera/pace-core/comms` | Type export for comm token warning. | `interface CommTokenWarning` |
| `CustomFilterPool` | type | advanced | `@solvera/pace-core/comms` | Type export for custom filter pool. | `interface CustomFilterPool` |
| `EffectivePumpSenderIdentity` | type | advanced | `@solvera/pace-core/comms` | Type export for effective pump sender identity. | `interface EffectivePumpSenderIdentity` |
| `EventParticipantsPool` | type | advanced | `@solvera/pace-core/comms` | Type export for event participants pool. | `interface EventParticipantsPool` |
| `EventParticipantsPoolFilters` | type | advanced | `@solvera/pace-core/comms` | Type export for event participants pool filters. | `interface EventParticipantsPoolFilters` |
| `ManualPool` | type | advanced | `@solvera/pace-core/comms` | Type export for manual pool. | `interface ManualPool` |
| `MergeFieldToolbarProps` | type | advanced | `@solvera/pace-core/comms` | Props type for merge field toolbar. | `interface MergeFieldToolbarProps` |
| `MessagePreviewProps` | type | advanced | `@solvera/pace-core/comms` | Props type for message preview. | `interface MessagePreviewProps` |
| `OrgMembersPool` | type | advanced | `@solvera/pace-core/comms` | Type export for org members pool. | `interface OrgMembersPool` |
| `OrgMembersPoolFilters` | type | advanced | `@solvera/pace-core/comms` | Type export for org members pool filters. | `interface OrgMembersPoolFilters` |
| `RecipientPoolDescriptor` | type | advanced | `@solvera/pace-core/comms` | Type export for recipient pool descriptor. | `type RecipientPoolDescriptor` |
| `RecipientPoolPreviewProps` | type | advanced | `@solvera/pace-core/comms` | Props type for recipient pool preview. | `interface RecipientPoolPreviewProps` |
| `SystemNotificationRecipientDescriptor` | type | advanced | `@solvera/pace-core/comms` | Type export for system notification recipient descriptor. | `type SystemNotificationRecipientDescriptor` |
| `SystemNotificationRequest` | type | advanced | `@solvera/pace-core/comms` | Type export for system notification request. | `interface SystemNotificationRequest` |
| `UseCommSendAdapterOptions` | type | advanced | `@solvera/pace-core/comms` | Options type for use comm send adapter. | `interface UseCommSendAdapterOptions` |

## `@solvera/pace-core/components`

Declaration source: `dist/components/index.d.ts`

### Runtime exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `Alert` | component | advanced | `@solvera/pace-core/components` | UI component for alert. | `Alert({ variant, children, className, role, ...rest }: AlertProps): JSX.Element` |
| `AlertDescription` | component | advanced | `@solvera/pace-core/components` | UI component for alert description. | `AlertDescription({ children, className }: AlertDescriptionProps): JSX.Element` |
| `AlertTitle` | component | advanced | `@solvera/pace-core/components` | UI component for alert title. | `AlertTitle({ children, className }: AlertTitleProps): JSX.Element` |
| `AppSwitcher` | component | advanced | `@solvera/pace-core/components` | UI component for app switcher. | `AppSwitcher(props: AppSwitcherProps): JSX.Element` |
| `AttentionItem` | component | advanced | `@solvera/pace-core/components` | UI component for attention item. | `AttentionItem(props: AttentionItemProps): JSX.Element` |
| `AttentionSection` | component | advanced | `@solvera/pace-core/components` | UI component for attention section. | `AttentionSection({ items, title, emptyTitle, emptyDescription, viewAll, className, }: AttentionSectionProps): JSX.Element` |
| `Avatar` | component | advanced | `@solvera/pace-core/components` | UI component for avatar. | `Avatar({ name, imgsrc, className }: AvatarProps): JSX.Element` |
| `Badge` | component | advanced | `@solvera/pace-core/components` | UI component for badge. | `Badge({ variant, children, ...rest }: BadgeProps): JSX.Element` |
| `Breadcrumb` | component | advanced | `@solvera/pace-core/components` | UI component for breadcrumb. | `Breadcrumb({ items, className }: BreadcrumbProps): JSX.Element` |
| `Button` | component | advanced | `@solvera/pace-core/components` | UI component for button. | `Button(props: ButtonProps & RefAttributes<HTMLButtonElement>): ReactNode` |
| `Calendar` | component | advanced | `@solvera/pace-core/components` | UI component for calendar. | `Calendar({ value, valueEnd, onSelect, mode, defaultMonth, className, weekStartsOn, }: CalendarProps): JSX.Element` |
| `Card` | component | advanced | `@solvera/pace-core/components` | UI component for card. | `Card(props: CardProps): JSX.Element` |
| `CardContent` | component | advanced | `@solvera/pace-core/components` | UI component for card content. | `CardContent({ children, className }: CardContentProps): JSX.Element` |
| `CardDescription` | component | advanced | `@solvera/pace-core/components` | UI component for card description. | `CardDescription({ children, className }: CardDescriptionProps): JSX.Element` |
| `CardFooter` | component | advanced | `@solvera/pace-core/components` | UI component for card footer. | `CardFooter({ children, className }: CardFooterProps): JSX.Element` |
| `CardGrid` | component | advanced | `@solvera/pace-core/components` | UI component for card grid. | `CardGrid({ children, className, columns, heading, headingId, }: CardGridProps): JSX.Element` |
| `CardGridItem` | component | advanced | `@solvera/pace-core/components` | UI component for card grid item. | `CardGridItem({ children, href, className }: CardGridItemProps): JSX.Element` |
| `CardHeader` | component | advanced | `@solvera/pace-core/components` | UI component for card header. | `CardHeader({ children, className }: CardHeaderProps): JSX.Element` |
| `CardTitle` | component | advanced | `@solvera/pace-core/components` | UI component for card title. | `CardTitle({ children, className, id }: CardTitleProps): JSX.Element` |
| `Checkbox` | component | advanced | `@solvera/pace-core/components` | UI component for checkbox. | `Checkbox(props: CheckboxProps & ReactNode` |
| `ConfirmationDialog` | component | advanced | `@solvera/pace-core/components` | UI component for confirmation dialog. | `ConfirmationDialog({ open, onOpenChange, title, description, confirmLabel, cancelLabel, variant, onConfirm, isPending, icon, }: ConfirmationDialogProps): JSX.Element \| null` |
| `ConfirmationDialogWithInput` | component | advanced | `@solvera/pace-core/components` | UI component for confirmation dialog with input. | `ConfirmationDialogWithInput({ open, onOpenChange, title, description, confirmLabel, cancelLabel, variant, confirmationText, inputPlaceholder, warningMessage, inputValue, onInputChange, onConfirm, isPending, icon, }: ConfirmationDialogWithInputProps): JSX.Element \| null` |
| `ContextSelector` | component | advanced | `@solvera/pace-core/components` | UI component for context selector. | `ContextSelector({ placeholder, onOrganisationSelect, onEventSelect, showOrganisations, showEvents, disabled, showNoItemsMessage, showRetryButton, className, }: ContextSelectorProps): JSX.Element` |
| `createActionColumn` | function | advanced | `@solvera/pace-core/components` | Function for create action column. | `createActionColumn<TData extends RowRecord>(options: ActionColumnOptions<TData>): DataTableColumn<TData>` |
| `createBooleanColumn` | function | advanced | `@solvera/pace-core/components` | Function for create boolean column. | `createBooleanColumn<TData extends RowRecord>(options: BooleanColumnOptions<TData>): DataTableColumn<TData>` |
| `createColumnsFromConfig` | function | advanced | `@solvera/pace-core/components` | Function for create columns from config. | `createColumnsFromConfig<TData extends RowRecord>(config: ColumnConfigItem[]): DataTableColumn<TData>[]` |
| `createDateColumn` | function | advanced | `@solvera/pace-core/components` | Function for create date column. | `createDateColumn<TData extends RowRecord>(options: DateColumnOptions<TData>): DataTableColumn<TData>` |
| `createNumberColumn` | function | advanced | `@solvera/pace-core/components` | Function for create number column. | `createNumberColumn<TData extends RowRecord>(options: NumberColumnOptions<TData>): DataTableColumn<TData>` |
| `createTextColumn` | function | advanced | `@solvera/pace-core/components` | Function for create text column. | `createTextColumn<TData extends RowRecord>(options: TextColumnOptions<TData>): DataTableColumn<TData>` |
| `DataTable` | component | advanced | `@solvera/pace-core/components` | UI component for data table. | `DataTable<TData extends Record<string, unknown>>(props: DataTableProps<TData>): JSX.Element` |
| `DateBadge` | component | advanced | `@solvera/pace-core/components` | UI component for date badge. | `DateBadge({ m, d }: DateBadgeProps): JSX.Element` |
| `DatePickerWithTimezone` | component | advanced | `@solvera/pace-core/components` | UI component for date picker with timezone. | `DatePickerWithTimezone({ value, onChange, timezone: controlledTimezone, userTimezone: userTimezoneProp, showTimezoneSelector, placeholder, className, disabled, }: DatePickerWithTimezoneProps): JSX.Element` |
| `DateTimeField` | component | advanced | `@solvera/pace-core/components` | UI component for date time field. | `DateTimeField({ value, onChange, timezone: timezoneProp, showTimezoneLabel, placeholder, className, disabled, }: DateTimeFieldProps): JSX.Element` |
| `DelegatedEditingBanner` | component | advanced | `@solvera/pace-core/components` | UI component for delegated editing banner. | `DelegatedEditingBanner({ targetDisplayName, onExit, description, className, }: ProxyModeBannerProps): JSX.Element` |
| `Dialog` | component | advanced | `@solvera/pace-core/components` | UI component for dialog. | `Dialog({ children, open: controlledOpen, onOpenChange }: DialogProps): JSX.Element` |
| `DialogBody` | component | advanced | `@solvera/pace-core/components` | UI component for dialog body. | `DialogBody({ children, className }: DialogBodyProps): JSX.Element` |
| `DialogClose` | component | advanced | `@solvera/pace-core/components` | UI component for dialog close. | `DialogClose({ children }: DialogCloseProps): JSX.Element` |
| `DialogContent` | component | advanced | `@solvera/pace-core/components` | UI component for dialog content. | `DialogContent({ children, className }: DialogContentProps): JSX.Element \| null` |
| `DialogDescription` | component | advanced | `@solvera/pace-core/components` | UI component for dialog description. | `DialogDescription({ children, className, id }: DialogDescriptionProps & { id?: string; }): JSX.Element` |
| `DialogFooter` | component | advanced | `@solvera/pace-core/components` | UI component for dialog footer. | `DialogFooter({ children, className }: DialogFooterProps): JSX.Element` |
| `DialogHeader` | component | advanced | `@solvera/pace-core/components` | UI component for dialog header. | `DialogHeader({ children, className }: DialogHeaderProps): JSX.Element` |
| `DialogPortal` | component | advanced | `@solvera/pace-core/components` | UI component for dialog portal. | `DialogPortal({ children }: DialogPortalProps): ReactPortal \| null` |
| `DialogTitle` | component | advanced | `@solvera/pace-core/components` | UI component for dialog title. | `DialogTitle({ children, className, id }: DialogTitleProps & { id?: string; }): JSX.Element` |
| `DialogTrigger` | component | advanced | `@solvera/pace-core/components` | UI component for dialog trigger. | `DialogTrigger({ children }: DialogTriggerProps): JSX.Element` |
| `EmptyState` | component | advanced | `@solvera/pace-core/components` | UI component for empty state. | `EmptyState({ title, description, action, compact, className, icon: IconComponent, }: EmptyStateProps): JSX.Element` |
| `EntityHero` | component | advanced | `@solvera/pace-core/components` | UI component for entity hero. | `EntityHero({ media, eyebrow, title, meta, description, footer, actions, className, }: EntityHeroProps): JSX.Element` |
| `ErrorBoundary` | class | advanced | `@solvera/pace-core/components` | Class export for error boundary. | `class ErrorBoundary` |
| `EventCard` | component | advanced | `@solvera/pace-core/components` | UI component for event card. | `EventCard({ event, link, image, fileReference, supabase, bucket, imageGlyph, imageTag, footer, className, }: EventCardProps): JSX.Element` |
| `FileDisplay` | component | advanced | `@solvera/pace-core/components` | UI component for file display. | `FileDisplay({ fileReference, url: urlProp, supabase, bucket, variant, className, label, preferImage, }: FileDisplayProps): JSX.Element \| null` |
| `FileUpload` | component | advanced | `@solvera/pace-core/components` | UI component for file upload. | `FileUpload({ supabase, table_name, record_id, organisation_id, event_id, app_id, category, folder, pageContext, is_public, custom_metadata, onUploadSuccess, onUploadError, onProgress, onRemove, files, accept, acceptHint, maxSize, multiple, bucket, tableName, className, disabled, label, showUploadedFiles, }: FileUploadProps): JSX.Element` |
| `FilterSidebar` | component | advanced | `@solvera/pace-core/components` | UI component for filter sidebar. | `FilterSidebar({ ariaLabel, activeId, onSelect, sections, className, }: FilterSidebarProps): JSX.Element` |
| `FilterSidebarItem` | component | advanced | `@solvera/pace-core/components` | UI component for filter sidebar item. | `FilterSidebarItem({ label, count, countLabel, description, meta, metaBadge, isActive, onClick, }: FilterSidebarItemProps): JSX.Element` |
| `FilterSidebarSection` | component | advanced | `@solvera/pace-core/components` | UI component for filter sidebar section. | `FilterSidebarSection({ title, children }: FilterSidebarSectionProps): JSX.Element` |
| `Form` | component | advanced | `@solvera/pace-core/components` | UI component for form. | `Form<T extends FieldValues>({ schema, defaultValues, onSubmit, onError, mode, children, className, }: FormProps<T>): JSX.Element` |
| `FormField` | component | advanced | `@solvera/pace-core/components` | UI component for form field. | `FormField<T extends FieldValues>({ name, label, required, className, inputClassName, showRequiredMarker, render, type, placeholder, }: FormFieldProps<T>): JSX.Element` |
| `getDefaultFooterCopyright` | function | advanced | `@solvera/pace-core/components` | Function for get default footer copyright. | `getDefaultFooterCopyright(year?: number): string` |
| `HeroBadge` | component | advanced | `@solvera/pace-core/components` | UI component for hero badge. | `HeroBadge({ code, className }: HeroBadgeProps): JSX.Element` |
| `HeroLogo` | component | advanced | `@solvera/pace-core/components` | UI component for hero logo. | `HeroLogo({ image, code, alt, className, fileReference, supabase, bucket, }: HeroLogoProps): JSX.Element` |
| `ImportModal` | component | advanced | `@solvera/pace-core/components` | UI component for import modal. | `ImportModal<TData extends Record<string, unknown>>({ open, onClose, onImport, importModalConfig, columns, onImportModalClose, }: ImportModalProps<TData>): JSX.Element` |
| `InactivityWarningModal` | component | advanced | `@solvera/pace-core/components` | UI component for inactivity warning modal. | `InactivityWarningModal({ isOpen, timeRemaining, onStaySignedIn, onSignOutNow, title, description, className, }: InactivityWarningModalProps): JSX.Element` |
| `Input` | component | advanced | `@solvera/pace-core/components` | UI component for input. | `Input(props: InputProps & ReactNode` |
| `InputGroup` | component | advanced | `@solvera/pace-core/components` | UI component for input group. | `InputGroup({ children, className }: InputGroupProps): JSX.Element` |
| `Label` | component | advanced | `@solvera/pace-core/components` | UI component for label. | `Label({ htmlFor, children, className, ...rest }: LabelProps): JSX.Element` |
| `LoadingSpinner` | component | advanced | `@solvera/pace-core/components` | UI component for loading spinner. | `LoadingSpinner({ className, label, decorative }: LoadingSpinnerProps): JSX.Element` |
| `MultiSelect` | component | advanced | `@solvera/pace-core/components` | UI component for multi select. | `MultiSelect({ value: controlledValue, defaultValue, onValueChange, options, placeholder, disabled, clearable, positionMode, className, }: MultiSelectProps): JSX.Element` |
| `NavigationMenu` | component | advanced | `@solvera/pace-core/components` | UI component for navigation menu. | `NavigationMenu(props: NavigationMenuProps): JSX.Element` |
| `PaceAppLayout` | component | advanced | `@solvera/pace-core/components` | UI component for pace app layout. | `PaceAppLayout({ appName, navItems, logoHref, layoutVariant, showAppSwitcher, appSwitcherItems, showContextSelector, showOrganisations, showEvents, onOrganisationSelect, onEventSelect, userFullName, userEmail, userAvatarSrc, extraMenuActions, onUserMenuSignOut, onUserMenuChangePassword, enforcePermissions, permissionFallback, routeAccessDenied, children, className, }: PaceAppLayoutComponentProps): JSX.Element` |
| `PaceFooter` | component | advanced | `@solvera/pace-core/components` | UI component for pace footer. | `PaceFooter({ className }: PaceFooterProps): JSX.Element` |
| `PaceHeader` | component | advanced | `@solvera/pace-core/components` | UI component for pace header. | `PaceHeader({ logoHref, logoSrc, appName, navItems, layoutVariant, showAppSwitcher, appSwitcherItems, showContextSelector, showOrganisations, showEvents, userFullName, userEmail, userAvatarSrc, extraMenuActions, onUserMenuSignOut, onUserMenuChangePassword, onOrganisationSelect, onEventSelect, }: PaceHeaderProps): JSX.Element` |
| `PaceLoginPage` | component | advanced | `@solvera/pace-core/components` | UI component for pace login page. | `PaceLoginPage({ appName, onSuccessRedirectPath, requireAppAccess, checkAppAccess, }: PaceLoginPageProps): JSX.Element` |
| `PaceMain` | component | advanced | `@solvera/pace-core/components` | UI component for pace main. | `PaceMain({ children, className, enforcePermissions, permissionFallback, routeAccessDenied, }: PaceMainProps): JSX.Element` |
| `PaceMainProvider` | provider | advanced | `@solvera/pace-core/components` | React context provider for pace main. | `PaceMainProvider({ children }: PaceMainProviderProps): JSX.Element` |
| `PageHeader` | component | advanced | `@solvera/pace-core/components` | UI component for page header. | `PageHeader({ title, subtitle, breadcrumbItems, actions, className }: PageHeaderProps): JSX.Element` |
| `parseCsvFile` | function | advanced | `@solvera/pace-core/components` | Function for parse csv file. | `parseCsvFile(file: File): Promise<ParseCsvResult>` |
| `parseCsvToRows` | function | advanced | `@solvera/pace-core/components` | Function for parse csv to rows. | `parseCsvToRows(csvText: string): ParseCsvResult` |
| `PasswordChangeForm` | component | advanced | `@solvera/pace-core/components` | UI component for password change form. | `PasswordChangeForm({ onSubmit, onSuccess, onCancel, className, }: PasswordChangeFormProps): JSX.Element` |
| `PrivacyPolicyDialog` | component | advanced | `@solvera/pace-core/components` | UI component for privacy policy dialog. | `PrivacyPolicyDialog({ open, onOpenChange }: PrivacyPolicyDialogProps): JSX.Element` |
| `Progress` | component | advanced | `@solvera/pace-core/components` | UI component for progress. | `Progress({ value, max, variant, size, className, }: ProgressProps): JSX.Element` |
| `ProtectedRoute` | component | advanced | `@solvera/pace-core/components` | UI component for protected route. | `ProtectedRoute({ loginPath, requireEvent, noEventsFallback, loadingFallback, }: ProtectedRouteProps): JSX.Element` |
| `ProxyModeBanner` | component | advanced | `@solvera/pace-core/components` | UI component for proxy mode banner. | `ProxyModeBanner({ targetDisplayName, onExit, description, className, }: ProxyModeBannerProps): JSX.Element` |
| `PublicPageFooter` | component | advanced | `@solvera/pace-core/components` | UI component for public page footer. | `PublicPageFooter(props: PublicPageFooterProps): JSX.Element` |
| `PublicPageHeader` | component | advanced | `@solvera/pace-core/components` | UI component for public page header. | `PublicPageHeader({ event, appName }: PublicPageHeaderProps): JSX.Element` |
| `PublicPageLayout` | component | advanced | `@solvera/pace-core/components` | UI component for public page layout. | `PublicPageLayout({ children, eventCode, event, isLoading, error, resilienceStatus, resilienceErrors, refetch, header, footer, showValidationErrors, ErrorFallback, loadingMessage, printPageOrientation, }: PublicPageLayoutProps): JSX.Element` |
| `PublicPageProvider` | provider | advanced | `@solvera/pace-core/components` | React context provider for public page. | `PublicPageProvider({ children, appName, supabaseClient, environment, }: PublicPageProviderProps): JSX.Element` |
| `SaveActions` | component | advanced | `@solvera/pace-core/components` | UI component for save actions. | `SaveActions({ className, cancelAction, onCancel, cancelLabel, saveType, onSaveClick, saveDisabled, alternateActions, }: SaveActionsProps): JSX.Element` |
| `SectionBanner` | component | advanced | `@solvera/pace-core/components` | UI component for section banner. | `SectionBanner({ variant, title, description, status, actions, className, }: SectionBannerProps): JSX.Element` |
| `Select` | component | advanced | `@solvera/pace-core/components` | UI component for select. | `Select({ value: controlledValue, defaultValue, onValueChange, positionMode, children, }: SelectProps): JSX.Element` |
| `SelectContent` | component | advanced | `@solvera/pace-core/components` | UI component for select content. | `SelectContent({ children, className }: SelectContentProps): JSX.Element` |
| `SelectGroup` | component | advanced | `@solvera/pace-core/components` | UI component for select group. | `SelectGroup({ children, label, className }: SelectGroupProps): JSX.Element` |
| `SelectItem` | component | advanced | `@solvera/pace-core/components` | UI component for select item. | `SelectItem({ value, children, className }: SelectItemProps): JSX.Element` |
| `SelectLabel` | component | advanced | `@solvera/pace-core/components` | UI component for select label. | `SelectLabel({ children, className }: SelectLabelProps): JSX.Element` |
| `SelectSeparator` | component | advanced | `@solvera/pace-core/components` | UI component for select separator. | `SelectSeparator({ className }: SelectSeparatorProps): JSX.Element` |
| `SelectTrigger` | component | advanced | `@solvera/pace-core/components` | UI component for select trigger. | `SelectTrigger({ children, placeholder, showChevron, className, disabled, }: SelectTriggerProps): JSX.Element` |
| `SelectValue` | component | advanced | `@solvera/pace-core/components` | UI component for select value. | `SelectValue({ placeholder, children }: SelectValueProps): JSX.Element` |
| `SessionRestorationLoader` | component | advanced | `@solvera/pace-core/components` | UI component for session restoration loader. | `SessionRestorationLoader({ children, message, className, }: SessionRestorationLoaderProps): JSX.Element` |
| `SupportDialog` | component | advanced | `@solvera/pace-core/components` | UI component for support dialog. | `SupportDialog({ open, onOpenChange, supabase, auth }: SupportDialogProps): JSX.Element` |
| `Switch` | component | advanced | `@solvera/pace-core/components` | UI component for switch. | `Switch({ checked, onChange, disabled, className, id, "aria-label": ariaLabel, }: SwitchProps): JSX.Element` |
| `Table` | component | advanced | `@solvera/pace-core/components` | UI component for table. | `Table({ children, className, layer }: TableProps): JSX.Element` |
| `TableBody` | component | advanced | `@solvera/pace-core/components` | UI component for table body. | `TableBody({ children, className }: TableBodyProps): JSX.Element` |
| `TableCaption` | component | advanced | `@solvera/pace-core/components` | UI component for table caption. | `TableCaption({ children, className }: TableCaptionProps): JSX.Element` |
| `TableCell` | component | advanced | `@solvera/pace-core/components` | UI component for table cell. | `TableCell({ children, className, colSpan }: TableCellProps): JSX.Element` |
| `TableFooter` | component | advanced | `@solvera/pace-core/components` | UI component for table footer. | `TableFooter({ children, className }: TableFooterProps): JSX.Element` |
| `TableHead` | component | advanced | `@solvera/pace-core/components` | UI component for table head. | `TableHead({ children, className, scope }: TableHeadProps): JSX.Element` |
| `TableHeader` | component | advanced | `@solvera/pace-core/components` | UI component for table header. | `TableHeader({ children, className }: TableHeaderProps): JSX.Element` |
| `TableRow` | component | advanced | `@solvera/pace-core/components` | UI component for table row. | `TableRow({ children, className, ...rest }: TableRowProps): JSX.Element` |
| `Tabs` | component | advanced | `@solvera/pace-core/components` | UI component for tabs. | `Tabs({ value: controlledValue, defaultValue, onValueChange, children, }: TabsProps): JSX.Element` |
| `TabsContent` | component | advanced | `@solvera/pace-core/components` | UI component for tabs content. | `TabsContent({ value, children, className }: TabsContentProps): JSX.Element` |
| `TabsList` | component | advanced | `@solvera/pace-core/components` | UI component for tabs list. | `TabsList({ children, className, "aria-label": ariaLabel }: TabsListProps): JSX.Element` |
| `TabsTrigger` | component | advanced | `@solvera/pace-core/components` | UI component for tabs trigger. | `TabsTrigger({ value, children, className, count }: TabsTriggerProps): JSX.Element` |
| `Textarea` | component | advanced | `@solvera/pace-core/components` | UI component for textarea. | `Textarea(props: TextareaProps & ReactNode` |
| `toast` | function | advanced | `@solvera/pace-core/components` | Function for toast. | `toast(props: ToastPropsOptions): string` |
| `Toast` | component | advanced | `@solvera/pace-core/components` | UI component for toast. | `Toast({ id, title, description, variant, onClose, action, onDismiss, }: ToastComponentProps): JSX.Element` |
| `ToastAction` | component | advanced | `@solvera/pace-core/components` | UI component for toast action. | `ToastAction({ label, onClick, className }: ToastActionComponentProps): JSX.Element` |
| `ToastClose` | component | advanced | `@solvera/pace-core/components` | UI component for toast close. | `ToastClose({ onClick, className, children }: ToastCloseProps): JSX.Element` |
| `ToastDescription` | component | advanced | `@solvera/pace-core/components` | UI component for toast description. | `ToastDescription({ id, children, className }: ToastDescriptionProps): JSX.Element` |
| `Toaster` | component | advanced | `@solvera/pace-core/components` | UI component for toaster. | `Toaster({ toasts, onDismiss }: ToasterProps): ReactPortal \| null` |
| `ToastProvider` | provider | advanced | `@solvera/pace-core/components` | React context provider for toast. | `ToastProvider({ children }: ToastProviderProps): JSX.Element` |
| `ToastTitle` | component | advanced | `@solvera/pace-core/components` | UI component for toast title. | `ToastTitle({ id, children, className }: ToastTitleProps): JSX.Element` |
| `useIsPublicPage` | hook | advanced | `@solvera/pace-core/components` | React hook for is public page. | `useIsPublicPage(): boolean` |
| `usePublicPageContext` | hook | advanced | `@solvera/pace-core/components` | React hook for public page context. | `usePublicPageContext(): PublicPageContextValue \| null` |
| `UserMenu` | component | advanced | `@solvera/pace-core/components` | UI component for user menu. | `UserMenu({ fullName, email, avatarSrc, label, extraActions, onChangePassword, onSignOut, className, }: UserMenuProps): JSX.Element` |

### Type exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `ActionColumnOptions` | type | advanced | `@solvera/pace-core/components` | Options type for action column. | `interface ActionColumnOptions` |
| `AggregateConfig` | type | advanced | `@solvera/pace-core/components` | Type export for aggregate config. | `interface AggregateConfig` |
| `AggregateFnName` | type | advanced | `@solvera/pace-core/components` | Type export for aggregate fn name. | `type AggregateFnName` |
| `AlertDescriptionProps` | type | advanced | `@solvera/pace-core/components` | Props type for alert description. | `interface AlertDescriptionProps` |
| `AlertProps` | type | advanced | `@solvera/pace-core/components` | Props type for alert. | `interface AlertProps` |
| `AlertTitleProps` | type | advanced | `@solvera/pace-core/components` | Props type for alert title. | `interface AlertTitleProps` |
| `AlertVariant` | type | advanced | `@solvera/pace-core/components` | Type export for alert variant. | `type AlertVariant` |
| `AppSwitcherItem` | type | advanced | `@solvera/pace-core/components` | Type export for app switcher item. | `interface AppSwitcherItem` |
| `AppSwitcherProps` | type | advanced | `@solvera/pace-core/components` | Props type for app switcher. | `interface AppSwitcherProps` |
| `AttentionItemProps` | type | advanced | `@solvera/pace-core/components` | Props type for attention item. | `interface AttentionItemProps` |
| `AttentionItemTone` | type | advanced | `@solvera/pace-core/components` | Type export for attention item tone. | `type AttentionItemTone` |
| `AttentionSectionItem` | type | advanced | `@solvera/pace-core/components` | Type export for attention section item. | `interface AttentionSectionItem` |
| `AttentionSectionProps` | type | advanced | `@solvera/pace-core/components` | Props type for attention section. | `interface AttentionSectionProps` |
| `AvatarProps` | type | advanced | `@solvera/pace-core/components` | Props type for avatar. | `interface AvatarProps` |
| `BadgeProps` | type | advanced | `@solvera/pace-core/components` | Props type for badge. | `interface BadgeProps` |
| `BadgeVariant` | type | advanced | `@solvera/pace-core/components` | Type export for badge variant. | `type BadgeVariant` |
| `BooleanColumnOptions` | type | advanced | `@solvera/pace-core/components` | Options type for boolean column. | `interface BooleanColumnOptions` |
| `BreadcrumbItem` | type | advanced | `@solvera/pace-core/components` | Type export for breadcrumb item. | `interface BreadcrumbItem` |
| `BreadcrumbProps` | type | advanced | `@solvera/pace-core/components` | Props type for breadcrumb. | `interface BreadcrumbProps` |
| `ButtonProps` | type | advanced | `@solvera/pace-core/components` | Props type for button. | `type ButtonProps` |
| `ButtonSize` | type | advanced | `@solvera/pace-core/components` | Type export for button size. | `type ButtonSize` |
| `ButtonVariant` | type | advanced | `@solvera/pace-core/components` | Type export for button variant. | `type ButtonVariant` |
| `CalendarProps` | type | advanced | `@solvera/pace-core/components` | Props type for calendar. | `interface CalendarProps` |
| `CardContentProps` | type | advanced | `@solvera/pace-core/components` | Props type for card content. | `interface CardContentProps` |
| `CardDescriptionProps` | type | advanced | `@solvera/pace-core/components` | Props type for card description. | `interface CardDescriptionProps` |
| `CardFooterProps` | type | advanced | `@solvera/pace-core/components` | Props type for card footer. | `interface CardFooterProps` |
| `CardGridColumns` | type | advanced | `@solvera/pace-core/components` | Type export for card grid columns. | `type CardGridColumns` |
| `CardGridItemProps` | type | advanced | `@solvera/pace-core/components` | Props type for card grid item. | `interface CardGridItemProps` |
| `CardGridProps` | type | advanced | `@solvera/pace-core/components` | Props type for card grid. | `interface CardGridProps` |
| `CardHeaderProps` | type | advanced | `@solvera/pace-core/components` | Props type for card header. | `interface CardHeaderProps` |
| `CardLayer` | type | advanced | `@solvera/pace-core/components` | Type export for card layer. | `type CardLayer` |
| `CardProps` | type | advanced | `@solvera/pace-core/components` | Props type for card. | `interface CardProps` |
| `CardTitleProps` | type | advanced | `@solvera/pace-core/components` | Props type for card title. | `interface CardTitleProps` |
| `CheckboxProps` | type | advanced | `@solvera/pace-core/components` | Props type for checkbox. | `interface CheckboxProps` |
| `ColumnConfigItem` | type | advanced | `@solvera/pace-core/components` | Type export for column config item. | `interface ColumnConfigItem` |
| `ColumnFilterState` | type | advanced | `@solvera/pace-core/components` | Type export for column filter state. | `type ColumnFilterState` |
| `ColumnOrderState` | type | advanced | `@solvera/pace-core/components` | Type export for column order state. | `type ColumnOrderState` |
| `ColumnVisibilityState` | type | advanced | `@solvera/pace-core/components` | Type export for column visibility state. | `type ColumnVisibilityState` |
| `ConfirmationDialogProps` | type | advanced | `@solvera/pace-core/components` | Props type for confirmation dialog. | `interface ConfirmationDialogProps` |
| `ConfirmationDialogWithInputProps` | type | advanced | `@solvera/pace-core/components` | Props type for confirmation dialog with input. | `interface ConfirmationDialogWithInputProps` |
| `ContextSelectorProps` | type | advanced | `@solvera/pace-core/components` | Props type for context selector. | `interface ContextSelectorProps` |
| `DataTableAction` | type | advanced | `@solvera/pace-core/components` | Type export for data table action. | `interface DataTableAction` |
| `DataTableColumn` | type | advanced | `@solvera/pace-core/components` | Type export for data table column. | `interface DataTableColumn` |
| `DataTableFeatureConfig` | type | advanced | `@solvera/pace-core/components` | Type export for data table feature config. | `interface DataTableFeatureConfig` |
| `DataTableProps` | type | advanced | `@solvera/pace-core/components` | Props type for data table. | `interface DataTableProps` |
| `DataTableRBACConfig` | type | advanced | `@solvera/pace-core/components` | Type export for data table rbacconfig. | `interface DataTableRBACConfig` |
| `DateBadgeProps` | type | advanced | `@solvera/pace-core/components` | Props type for date badge. | `interface DateBadgeProps` |
| `DateColumnOptions` | type | advanced | `@solvera/pace-core/components` | Options type for date column. | `interface DateColumnOptions` |
| `DatePickerWithTimezoneProps` | type | advanced | `@solvera/pace-core/components` | Props type for date picker with timezone. | `interface DatePickerWithTimezoneProps` |
| `DateTimeFieldProps` | type | advanced | `@solvera/pace-core/components` | Props type for date time field. | `interface DateTimeFieldProps` |
| `DelegatedEditingBannerProps` | type | advanced | `@solvera/pace-core/components` | Props type for delegated editing banner. | `type DelegatedEditingBannerProps` |
| `DialogBodyProps` | type | advanced | `@solvera/pace-core/components` | Props type for dialog body. | `interface DialogBodyProps` |
| `DialogCloseProps` | type | advanced | `@solvera/pace-core/components` | Props type for dialog close. | `interface DialogCloseProps` |
| `DialogContentProps` | type | advanced | `@solvera/pace-core/components` | Props type for dialog content. | `interface DialogContentProps` |
| `DialogDescriptionProps` | type | advanced | `@solvera/pace-core/components` | Props type for dialog description. | `interface DialogDescriptionProps` |
| `DialogFooterProps` | type | advanced | `@solvera/pace-core/components` | Props type for dialog footer. | `interface DialogFooterProps` |
| `DialogHeaderProps` | type | advanced | `@solvera/pace-core/components` | Props type for dialog header. | `interface DialogHeaderProps` |
| `DialogPortalProps` | type | advanced | `@solvera/pace-core/components` | Props type for dialog portal. | `interface DialogPortalProps` |
| `DialogProps` | type | advanced | `@solvera/pace-core/components` | Props type for dialog. | `interface DialogProps` |
| `DialogTitleProps` | type | advanced | `@solvera/pace-core/components` | Props type for dialog title. | `interface DialogTitleProps` |
| `DialogTriggerProps` | type | advanced | `@solvera/pace-core/components` | Props type for dialog trigger. | `interface DialogTriggerProps` |
| `EmptyStateProps` | type | advanced | `@solvera/pace-core/components` | Props type for empty state. | `interface EmptyStateProps` |
| `EntityHeroMetaRow` | type | advanced | `@solvera/pace-core/components` | Type export for entity hero meta row. | `interface EntityHeroMetaRow` |
| `EntityHeroProps` | type | advanced | `@solvera/pace-core/components` | Props type for entity hero. | `interface EntityHeroProps` |
| `ErrorBoundaryProps` | type | advanced | `@solvera/pace-core/components` | Props type for error boundary. | `interface ErrorBoundaryProps` |
| `EventCardFields` | type | advanced | `@solvera/pace-core/components` | Type export for event card fields. | `interface EventCardFields` |
| `EventCardProps` | type | advanced | `@solvera/pace-core/components` | Props type for event card. | `interface EventCardProps` |
| `ExpandedState` | type | advanced | `@solvera/pace-core/components` | Type export for expanded state. | `type ExpandedState` |
| `ExportColumn` | type | advanced | `@solvera/pace-core/components` | Type export for export column. | `interface ExportColumn` |
| `ExportOptions` | type | advanced | `@solvera/pace-core/components` | Options type for export. | `interface ExportOptions` |
| `FileDisplayProps` | type | advanced | `@solvera/pace-core/components` | Props type for file display. | `interface FileDisplayProps` |
| `FileUploadProps` | type | advanced | `@solvera/pace-core/components` | Props type for file upload. | `interface FileUploadProps` |
| `FilterSidebarItemData` | type | advanced | `@solvera/pace-core/components` | Type export for filter sidebar item data. | `interface FilterSidebarItemData` |
| `FilterSidebarItemProps` | type | advanced | `@solvera/pace-core/components` | Props type for filter sidebar item. | `interface FilterSidebarItemProps` |
| `FilterSidebarMetaBadge` | type | advanced | `@solvera/pace-core/components` | Type export for filter sidebar meta badge. | `interface FilterSidebarMetaBadge` |
| `FilterSidebarMetaBadgeVariant` | type | advanced | `@solvera/pace-core/components` | Type export for filter sidebar meta badge variant. | `type FilterSidebarMetaBadgeVariant` |
| `FilterSidebarProps` | type | advanced | `@solvera/pace-core/components` | Props type for filter sidebar. | `interface FilterSidebarProps` |
| `FilterSidebarSectionData` | type | advanced | `@solvera/pace-core/components` | Type export for filter sidebar section data. | `interface FilterSidebarSectionData` |
| `FilterSidebarSectionProps` | type | advanced | `@solvera/pace-core/components` | Props type for filter sidebar section. | `interface FilterSidebarSectionProps` |
| `FormFieldProps` | type | advanced | `@solvera/pace-core/components` | Props type for form field. | `interface FormFieldProps` |
| `FormProps` | type | advanced | `@solvera/pace-core/components` | Props type for form. | `interface FormProps` |
| `GroupingState` | type | advanced | `@solvera/pace-core/components` | Type export for grouping state. | `type GroupingState` |
| `HeroBadgeProps` | type | advanced | `@solvera/pace-core/components` | Props type for hero badge. | `interface HeroBadgeProps` |
| `HeroLogoProps` | type | advanced | `@solvera/pace-core/components` | Props type for hero logo. | `interface HeroLogoProps` |
| `HierarchicalConfig` | type | advanced | `@solvera/pace-core/components` | Type export for hierarchical config. | `interface HierarchicalConfig` |
| `HierarchicalDataRow` | type | advanced | `@solvera/pace-core/components` | Type export for hierarchical data row. | `interface HierarchicalDataRow` |
| `ImportHandlerResult` | type | advanced | `@solvera/pace-core/components` | Result type for import handler. | `type ImportHandlerResult` |
| `ImportModalConfig` | type | advanced | `@solvera/pace-core/components` | Type export for import modal config. | `interface ImportModalConfig` |
| `ImportModalProps` | type | advanced | `@solvera/pace-core/components` | Props type for import modal. | `interface ImportModalProps` |
| `ImportSummary` | type | advanced | `@solvera/pace-core/components` | Type export for import summary. | `interface ImportSummary` |
| `InactivityWarningModalProps` | type | advanced | `@solvera/pace-core/components` | Props type for inactivity warning modal. | `interface InactivityWarningModalProps` |
| `InputGroupProps` | type | advanced | `@solvera/pace-core/components` | Props type for input group. | `interface InputGroupProps` |
| `InputProps` | type | advanced | `@solvera/pace-core/components` | Props type for input. | `interface InputProps` |
| `LabelProps` | type | advanced | `@solvera/pace-core/components` | Props type for label. | `interface LabelProps` |
| `LoadingSpinnerProps` | type | advanced | `@solvera/pace-core/components` | Props type for loading spinner. | `interface LoadingSpinnerProps` |
| `MultiSelectOption` | type | advanced | `@solvera/pace-core/components` | Type export for multi select option. | `interface MultiSelectOption` |
| `MultiSelectProps` | type | advanced | `@solvera/pace-core/components` | Props type for multi select. | `interface MultiSelectProps` |
| `NavigationItem` | type | advanced | `@solvera/pace-core/components` | Type export for navigation item. | `interface NavigationItem` |
| `NavigationMenuProps` | type | advanced | `@solvera/pace-core/components` | Props type for navigation menu. | `interface NavigationMenuProps` |
| `NumberColumnOptions` | type | advanced | `@solvera/pace-core/components` | Options type for number column. | `interface NumberColumnOptions` |
| `PaceAppLayoutComponentProps` | type | advanced | `@solvera/pace-core/components` | Props type for pace app layout component. | `interface PaceAppLayoutComponentProps` |
| `PaceAppLayoutProps` | type | advanced | `@solvera/pace-core/components` | Props type for pace app layout. | `interface PaceAppLayoutProps` |
| `PaceAppLayoutVariant` | type | advanced | `@solvera/pace-core/components` | Type export for pace app layout variant. | `type PaceAppLayoutVariant` |
| `PaceFooterProps` | type | advanced | `@solvera/pace-core/components` | Props type for pace footer. | `interface PaceFooterProps` |
| `PaceHeaderProps` | type | advanced | `@solvera/pace-core/components` | Props type for pace header. | `interface PaceHeaderProps` |
| `PaceLoginPageProps` | type | advanced | `@solvera/pace-core/components` | Props type for pace login page. | `interface PaceLoginPageProps` |
| `PaceMainProps` | type | advanced | `@solvera/pace-core/components` | Props type for pace main. | `interface PaceMainProps` |
| `PaceMainProviderProps` | type | advanced | `@solvera/pace-core/components` | Props type for pace main provider. | `interface PaceMainProviderProps` |
| `PageHeaderProps` | type | advanced | `@solvera/pace-core/components` | Props type for page header. | `interface PageHeaderProps` |
| `ParseCsvResult` | type | advanced | `@solvera/pace-core/components` | Result type for parse csv. | `interface ParseCsvResult` |
| `PasswordChangeFormProps` | type | advanced | `@solvera/pace-core/components` | Props type for password change form. | `interface PasswordChangeFormProps` |
| `PrivacyPolicyDialogProps` | type | advanced | `@solvera/pace-core/components` | Props type for privacy policy dialog. | `interface PrivacyPolicyDialogProps` |
| `ProgressProps` | type | advanced | `@solvera/pace-core/components` | Props type for progress. | `interface ProgressProps` |
| `ProgressSize` | type | advanced | `@solvera/pace-core/components` | Type export for progress size. | `type ProgressSize` |
| `ProgressVariant` | type | advanced | `@solvera/pace-core/components` | Type export for progress variant. | `type ProgressVariant` |
| `ProtectedRouteProps` | type | advanced | `@solvera/pace-core/components` | Props type for protected route. | `interface ProtectedRouteProps` |
| `ProxyModeBannerProps` | type | advanced | `@solvera/pace-core/components` | Props type for proxy mode banner. | `interface ProxyModeBannerProps` |
| `PublicPageFooterProps` | type | advanced | `@solvera/pace-core/components` | Props type for public page footer. | `interface PublicPageFooterProps` |
| `PublicPageHeaderProps` | type | advanced | `@solvera/pace-core/components` | Props type for public page header. | `interface PublicPageHeaderProps` |
| `PublicPageLayoutProps` | type | advanced | `@solvera/pace-core/components` | Props type for public page layout. | `interface PublicPageLayoutProps` |
| `PublicPageProviderProps` | type | advanced | `@solvera/pace-core/components` | Props type for public page provider. | `interface PublicPageProviderProps` |
| `SaveActionsProps` | type | advanced | `@solvera/pace-core/components` | Props type for save actions. | `interface SaveActionsProps` |
| `SectionBannerProps` | type | advanced | `@solvera/pace-core/components` | Props type for section banner. | `interface SectionBannerProps` |
| `SectionBannerVariant` | type | advanced | `@solvera/pace-core/components` | Type export for section banner variant. | `type SectionBannerVariant` |
| `SelectContentProps` | type | advanced | `@solvera/pace-core/components` | Props type for select content. | `interface SelectContentProps` |
| `SelectedRowIds` | type | advanced | `@solvera/pace-core/components` | Type export for selected row ids. | `type SelectedRowIds` |
| `SelectGroupProps` | type | advanced | `@solvera/pace-core/components` | Props type for select group. | `interface SelectGroupProps` |
| `SelectItemProps` | type | advanced | `@solvera/pace-core/components` | Props type for select item. | `interface SelectItemProps` |
| `SelectLabelProps` | type | advanced | `@solvera/pace-core/components` | Props type for select label. | `interface SelectLabelProps` |
| `SelectProps` | type | advanced | `@solvera/pace-core/components` | Props type for select. | `interface SelectProps` |
| `SelectSeparatorProps` | type | advanced | `@solvera/pace-core/components` | Props type for select separator. | `interface SelectSeparatorProps` |
| `SelectTriggerProps` | type | advanced | `@solvera/pace-core/components` | Props type for select trigger. | `interface SelectTriggerProps` |
| `SelectValueProps` | type | advanced | `@solvera/pace-core/components` | Props type for select value. | `interface SelectValueProps` |
| `ServerSideConfig` | type | advanced | `@solvera/pace-core/components` | Type export for server side config. | `interface ServerSideConfig` |
| `ServerSideParams` | type | advanced | `@solvera/pace-core/components` | Type export for server side params. | `interface ServerSideParams` |
| `ServerSideResponse` | type | advanced | `@solvera/pace-core/components` | Type export for server side response. | `interface ServerSideResponse` |
| `SessionRestorationLoaderProps` | type | advanced | `@solvera/pace-core/components` | Props type for session restoration loader. | `interface SessionRestorationLoaderProps` |
| `SimpleColumn` | type | advanced | `@solvera/pace-core/components` | Type export for simple column. | `interface SimpleColumn` |
| `SortingState` | type | advanced | `@solvera/pace-core/components` | Type export for sorting state. | `type SortingState` |
| `SortingStateItem` | type | advanced | `@solvera/pace-core/components` | Type export for sorting state item. | `interface SortingStateItem` |
| `SupportDialogAuthContext` | type | advanced | `@solvera/pace-core/components` | Type export for support dialog auth context. | `interface SupportDialogAuthContext` |
| `SupportDialogProps` | type | advanced | `@solvera/pace-core/components` | Props type for support dialog. | `interface SupportDialogProps` |
| `SwitchProps` | type | advanced | `@solvera/pace-core/components` | Props type for switch. | `interface SwitchProps` |
| `TableBodyProps` | type | advanced | `@solvera/pace-core/components` | Props type for table body. | `interface TableBodyProps` |
| `TableCaptionProps` | type | advanced | `@solvera/pace-core/components` | Props type for table caption. | `interface TableCaptionProps` |
| `TableCellProps` | type | advanced | `@solvera/pace-core/components` | Props type for table cell. | `interface TableCellProps` |
| `TableFooterProps` | type | advanced | `@solvera/pace-core/components` | Props type for table footer. | `interface TableFooterProps` |
| `TableHeaderProps` | type | advanced | `@solvera/pace-core/components` | Props type for table header. | `interface TableHeaderProps` |
| `TableHeadProps` | type | advanced | `@solvera/pace-core/components` | Props type for table head. | `interface TableHeadProps` |
| `TableLayer` | type | advanced | `@solvera/pace-core/components` | Type export for table layer. | `type TableLayer` |
| `TableProps` | type | advanced | `@solvera/pace-core/components` | Props type for table. | `interface TableProps` |
| `TableRowProps` | type | advanced | `@solvera/pace-core/components` | Props type for table row. | `type TableRowProps` |
| `TabsContentProps` | type | advanced | `@solvera/pace-core/components` | Props type for tabs content. | `interface TabsContentProps` |
| `TabsListProps` | type | advanced | `@solvera/pace-core/components` | Props type for tabs list. | `interface TabsListProps` |
| `TabsProps` | type | advanced | `@solvera/pace-core/components` | Props type for tabs. | `interface TabsProps` |
| `TabsTriggerProps` | type | advanced | `@solvera/pace-core/components` | Props type for tabs trigger. | `interface TabsTriggerProps` |
| `TextareaProps` | type | advanced | `@solvera/pace-core/components` | Props type for textarea. | `interface TextareaProps` |
| `TextColumnOptions` | type | advanced | `@solvera/pace-core/components` | Options type for text column. | `type TextColumnOptions` |
| `ToastActionComponentProps` | type | advanced | `@solvera/pace-core/components` | Props type for toast action component. | `interface ToastActionComponentProps` |
| `ToastActionProps` | type | advanced | `@solvera/pace-core/components` | Props type for toast action. | `interface ToastActionProps` |
| `ToastCloseProps` | type | advanced | `@solvera/pace-core/components` | Props type for toast close. | `interface ToastCloseProps` |
| `ToastComponentProps` | type | advanced | `@solvera/pace-core/components` | Props type for toast component. | `interface ToastComponentProps` |
| `ToastDescriptionProps` | type | advanced | `@solvera/pace-core/components` | Props type for toast description. | `interface ToastDescriptionProps` |
| `ToasterProps` | type | advanced | `@solvera/pace-core/components` | Props type for toaster. | `interface ToasterProps` |
| `ToastItem` | type | advanced | `@solvera/pace-core/components` | Type export for toast item. | `interface ToastItem` |
| `ToastPropsOptions` | type | advanced | `@solvera/pace-core/components` | Options type for toast props. | `interface ToastPropsOptions` |
| `ToastProviderProps` | type | advanced | `@solvera/pace-core/components` | Props type for toast provider. | `interface ToastProviderProps` |
| `ToastTitleProps` | type | advanced | `@solvera/pace-core/components` | Props type for toast title. | `interface ToastTitleProps` |
| `ToastVariant` | type | advanced | `@solvera/pace-core/components` | Type export for toast variant. | `type ToastVariant` |
| `UserMenuExtraAction` | type | advanced | `@solvera/pace-core/components` | Type export for user menu extra action. | `interface UserMenuExtraAction` |
| `UserMenuProps` | type | advanced | `@solvera/pace-core/components` | Props type for user menu. | `interface UserMenuProps` |

## `@solvera/pace-core/crud`

Declaration source: `dist/crud/index.d.ts`

### Runtime exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `checkCrudPermissionPrecondition` | function | advanced | `@solvera/pace-core/crud` | Function for check crud permission precondition. | `checkCrudPermissionPrecondition(input: { action: "read" \| "create" \| "update" \| "delete"; permissions?: CrudPermissionConfig; userId: string \| null; scope: Required<EventScopeInput>; }): Promise<ApiResult<void>>` |
| `createAttachmentReference` | function | advanced | `@solvera/pace-core/crud` | Function for create attachment reference. | `createAttachmentReference<TReference>(input: { secureClient: unknown; scope: EventScopeInput; adapter: AttachmentLifecycleAdapter<TReference>; relationId: string; relationTable?: string \| null; filePath?: string; isPublic?: boolean; metadata?: Record<string, unknown>; }): Promise<ApiResult<{ reference: TReference; metadataId: string; filePath: string; }>>` |
| `deleteAttachment` | function | advanced | `@solvera/pace-core/crud` | Function for delete attachment. | `deleteAttachment(input: { secureClient: unknown; adapter: AttachmentLifecycleAdapter<unknown>; metadataId: string; filePath: string; continueOnStorageFailure?: boolean; }): Promise<ApiResult<void>>` |
| `ensureSecureClient` | function | advanced | `@solvera/pace-core/crud` | Function for ensure secure client. | `ensureSecureClient(client: unknown): ApiResult<SecureSupabaseClient>` |
| `isSecureSupabaseClient` | function | advanced | `@solvera/pace-core/crud` | Function for is secure supabase client. | `isSecureSupabaseClient(client: unknown): client is SecureSupabaseClient` |
| `replaceAttachmentWithRollback` | function | advanced | `@solvera/pace-core/crud` | Function for replace attachment with rollback. | `replaceAttachmentWithRollback(input: { secureClient: unknown; scope: EventScopeInput; adapter: AttachmentLifecycleAdapter<unknown>; metadataId: string; relationId: string; relationTable?: string \| null; existingFilePath: string; file: File; metadata?: Record<string, unknown>; cleanupOldStorageObject?: boolean; }): Promise<ApiResult<{ filePath: string; }>>` |
| `resolveAttachmentAccess` | function | advanced | `@solvera/pace-core/crud` | Function for resolve attachment access. | `resolveAttachmentAccess(input: { secureClient: unknown; adapter: AttachmentLifecycleAdapter<unknown>; filePath: string; isPublic: boolean; }): Promise<ApiResult<{ url: string; }>>` |
| `uploadAttachmentContent` | function | advanced | `@solvera/pace-core/crud` | Function for upload attachment content. | `uploadAttachmentContent(input: { secureClient: unknown; scope: EventScopeInput; adapter: AttachmentLifecycleAdapter<unknown>; relationId: string; relationTable?: string \| null; metadataId?: string; file: File; metadata?: Record<string, unknown>; filePath?: string; }): Promise<ApiResult<{ filePath: string; }>>` |
| `useEventScopedCrud` | hook | advanced | `@solvera/pace-core/crud` | React hook for event scoped crud. | `useEventScopedCrud<TRead, TCreateInput = never, TUpdateInput = never, TDeleteInput = never>(options: UseEventScopedCrudOptions<TRead, TCreateInput, TUpdateInput, TDeleteInput>): CrudOperationResult<TRead, TCreateInput, TUpdateInput, TDeleteInput>` |
| `validateEventScopeInput` | function | advanced | `@solvera/pace-core/crud` | Function for validate event scope input. | `validateEventScopeInput(scope: EventScopeInput, options?: ValidateScopeOptions): ApiResult<Required<EventScopeInput>>` |

### Type exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `AttachmentLifecycleAdapter` | type | advanced | `@solvera/pace-core/crud` | Type export for attachment lifecycle adapter. | `interface AttachmentLifecycleAdapter` |
| `CrudErrorMapper` | type | advanced | `@solvera/pace-core/crud` | Type export for crud error mapper. | `type CrudErrorMapper` |
| `CrudMutationExtensions` | type | advanced | `@solvera/pace-core/crud` | Type export for crud mutation extensions. | `interface CrudMutationExtensions` |
| `CrudOperationResult` | type | advanced | `@solvera/pace-core/crud` | Result type for crud operation. | `interface CrudOperationResult` |
| `CrudPermissionConfig` | type | advanced | `@solvera/pace-core/crud` | Type export for crud permission config. | `interface CrudPermissionConfig` |
| `EventScopedCrudContext` | type | advanced | `@solvera/pace-core/crud` | Type export for event scoped crud context. | `interface EventScopedCrudContext` |
| `EventScopeInput` | type | advanced | `@solvera/pace-core/crud` | Type export for event scope input. | `interface EventScopeInput` |
| `UseEventScopedCrudOptions` | type | advanced | `@solvera/pace-core/crud` | Options type for use event scoped crud. | `interface UseEventScopedCrudOptions` |

## `@solvera/pace-core/events`

Declaration source: `dist/events/index.d.ts`

### Runtime exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `buildEventLogoStubReference` | function | advanced | `@solvera/pace-core/events` | Function for build event logo stub reference. | `buildEventLogoStubReference(event: Record<string, unknown> \| null \| undefined): FileReference \| null` |
| `deriveSelectedEvent` | function | advanced | `@solvera/pace-core/events` | Function for derive selected event. | `deriveSelectedEvent(input: EventResolutionInput): ResolvedEventResult` |
| `getEventResolutionMetadata` | function | advanced | `@solvera/pace-core/events` | Function for get event resolution metadata. | `getEventResolutionMetadata(result: ResolvedEventResult): EventResolutionMetadata` |
| `isDirectEventLogoUrl` | function | advanced | `@solvera/pace-core/events` | Function for is direct event logo url. | `isDirectEventLogoUrl(value: string \| undefined): value is string` |
| `normalizeEventCardFields` | function | advanced | `@solvera/pace-core/events` | Function for normalize event card fields. | `normalizeEventCardFields(input: unknown): EventCardFields \| null` |
| `normalizeEventReadModel` | function | advanced | `@solvera/pace-core/events` | Function for normalize event read model. | `normalizeEventReadModel(input: unknown, fallbackOrganisationId?: string \| null): EventReadModel \| null` |
| `readDirectEventLogoUrl` | function | advanced | `@solvera/pace-core/events` | Function for read direct event logo url. | `readDirectEventLogoUrl(event: Record<string, unknown> \| null \| undefined): string \| undefined` |
| `sortEventsByDateDesc` | function | advanced | `@solvera/pace-core/events` | Function for sort events by date desc. | `sortEventsByDateDesc(events: ReadonlyArray<EventStub>): EventStub[]` |

### Type exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `EventCardFields` | type | advanced | `@solvera/pace-core/events` | Type export for event card fields. | `interface EventCardFields` |
| `EventReadModel` | type | advanced | `@solvera/pace-core/events` | Type export for event read model. | `interface EventReadModel` |
| `EventResolutionInput` | type | advanced | `@solvera/pace-core/events` | Type export for event resolution input. | `interface EventResolutionInput` |
| `EventResolutionMetadata` | type | advanced | `@solvera/pace-core/events` | Type export for event resolution metadata. | `interface EventResolutionMetadata` |
| `EventResolutionSource` | type | advanced | `@solvera/pace-core/events` | Type export for event resolution source. | `type EventResolutionSource` |
| `ResolvedEventResult` | type | advanced | `@solvera/pace-core/events` | Result type for resolved event. | `interface ResolvedEventResult` |

## `@solvera/pace-core/forms`

Declaration source: `dist/forms/index.d.ts`

### Runtime exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `AddressField` | component | advanced | `@solvera/pace-core/forms` | UI component for address field. | `AddressField({ meta, control, name, provider: providerProp, showAddressSearch, debounceMs, minQueryLength, componentRestrictions, }: AddressFieldProps): JSX.Element` |
| `arePreSubmissionChecksSatisfied` | function | advanced | `@solvera/pace-core/forms` | Function for are pre submission checks satisfied. | `arePreSubmissionChecksSatisfied(checks: ReadonlyArray<ResolvedPreSubmissionCheck>, acknowledgedKeys: ReadonlyArray<string>): boolean` |
| `AuthoringIssueAlerts` | component | advanced | `@solvera/pace-core/forms` | UI component for authoring issue alerts. | `AuthoringIssueAlerts({ issues, }: { issues: WorkflowAuthoringValidationIssue[]; }): JSX.Element \| null` |
| `buildAddressValueSchema` | function | advanced | `@solvera/pace-core/forms` | Function for build address value schema. | `buildAddressValueSchema(meta: FormFieldMeta): z.ZodTypeAny` |
| `buildWorkflowFormSchema` | function | advanced | `@solvera/pace-core/forms` | Function for build workflow form schema. | `buildWorkflowFormSchema(definition: WorkflowFormDefinition, registry: ReturnType<typeof createFieldRegistry>, getVisibilityContext: (values: Record<string, unknown>) => WorkflowVisibilityContext): z.ZodType<Record<string, unknown>>` |
| `buildWorkflowPreviewTarget` | function | advanced | `@solvera/pace-core/forms` | Function for build workflow preview target. | `buildWorkflowPreviewTarget(state: WorkflowAuthoringState, options?: BuildWorkflowPreviewTargetOptions): WorkflowPreviewTarget` |
| `buildWorkflowSubmissionPayload` | function | advanced | `@solvera/pace-core/forms` | Function for build workflow submission payload. | `buildWorkflowSubmissionPayload(options: BuildWorkflowSubmissionPayloadOptions): WorkflowSubmissionPayload` |
| `closestCenter` | constant | advanced | `@solvera/pace-core/forms` | Constant value for closest center. | `const closestCenter: CollisionDetection` |
| `composeSchemaFromFieldMetadata` | function | advanced | `@solvera/pace-core/forms` | Function for compose schema from field metadata. | `composeSchemaFromFieldMetadata(registry: RegistryWithSchema, fields: FormFieldMeta[], options?: ComposeSchemaOptions): z.ZodObject<Record<string, z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>>, z.core.$strip>` |
| `Controller` | function | advanced | `@solvera/pace-core/forms` | Function for controller. | `Controller<TFieldValues extends FieldValues = FieldValues, TName extends FieldPath<TFieldValues> = FieldPath<TFieldValues>, TTransformedValues = TFieldValues>(props: ControllerProps<TFieldValues, TName, TTransformedValues>): import("react").ReactElement<unknown, string \| import("react").JSXElementConstructor<any>>` |
| `createDefaultFieldRegistryEntries` | function | advanced | `@solvera/pace-core/forms` | Function for create default field registry entries. | `createDefaultFieldRegistryEntries(): FieldRegistryEntry[]` |
| `createFieldRegistry` | function | advanced | `@solvera/pace-core/forms` | Function for create field registry. | `createFieldRegistry(options: CreateFieldRegistryOptions): { get(fieldType: string): FieldRegistryEntry \| undefined; has(fieldType: string): boolean; buildObjectSchema(fields: FormFieldMeta[], opts?: ComposeSchemaOptions): z.ZodObject<{ [x: string]: z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>; }, z.core.$strip>; }` |
| `createGoogleMapsJsAddressProviderAdapter` | function | advanced | `@solvera/pace-core/forms` | Function for create google maps js address provider adapter. | `createGoogleMapsJsAddressProviderAdapter(): AddressProviderAdapter` |
| `createManualAddressProviderAdapter` | function | advanced | `@solvera/pace-core/forms` | Function for create manual address provider adapter. | `createManualAddressProviderAdapter(): AddressProviderAdapter` |
| `CSS` | constant | advanced | `@solvera/pace-core/forms` | Constant value for css. | `const CSS: Readonly<{ Translate: { toString(transform: Transform \| null): string \| undefined; }; Scale: { toString(transform: Transform \| null): strin...` |
| `defaultManualAddressProviderAdapter` | constant | advanced | `@solvera/pace-core/forms` | Constant value for default manual address provider adapter. | `const defaultManualAddressProviderAdapter: AddressProviderAdapter` |
| `defaultWorkflowFieldCatalogueLoader` | function | advanced | `@solvera/pace-core/forms` | Function for default workflow field catalogue loader. | `defaultWorkflowFieldCatalogueLoader({ client, }: WorkflowFieldCatalogueLoaderContext): Promise<WorkflowFieldCatalogueOption[]>` |
| `DndContext` | component | advanced | `@solvera/pace-core/forms` | UI component for dnd context. | `DndContext(props: Props): React.ReactNode` |
| `evaluateWorkflowVisibility` | function | advanced | `@solvera/pace-core/forms` | Function for evaluate workflow visibility. | `evaluateWorkflowVisibility(rule: WorkflowVisibilityRule \| undefined, context: WorkflowVisibilityContext): boolean` |
| `filterVisibleWorkflowFields` | function | advanced | `@solvera/pace-core/forms` | Function for filter visible workflow fields. | `filterVisibleWorkflowFields(fields: WorkflowFieldDefinition[], context: WorkflowVisibilityContext): WorkflowFieldDefinition[]` |
| `FormProvider` | provider | advanced | `@solvera/pace-core/forms` | React context provider for form. | `FormProvider<TFieldValues extends FieldValues, TContext = any, TTransformedValues = TFieldValues>(props: FormProviderProps<TFieldValues, TContext, TTransformedValues>): React.JSX.Element` |
| `getWorkflowPreSubmissionCheckKeys` | function | advanced | `@solvera/pace-core/forms` | Function for get workflow pre submission check keys. | `getWorkflowPreSubmissionCheckKeys(definition: WorkflowFormDefinition): string[]` |
| `isWorkflowFieldVisible` | function | advanced | `@solvera/pace-core/forms` | Function for is workflow field visible. | `isWorkflowFieldVisible(field: WorkflowFieldDefinition, context: WorkflowVisibilityContext): boolean` |
| `KeyboardSensor` | class | advanced | `@solvera/pace-core/forms` | Class export for keyboard sensor. | `class KeyboardSensor` |
| `mapWorkflowFieldCatalogueRowToOption` | function | advanced | `@solvera/pace-core/forms` | Function for map workflow field catalogue row to option. | `mapWorkflowFieldCatalogueRowToOption(row: WorkflowFieldCatalogueRpcRow): WorkflowFieldCatalogueOption` |
| `parseGooglePlaceDetailsToAddressValue` | function | advanced | `@solvera/pace-core/forms` | Function for parse google place details to address value. | `parseGooglePlaceDetailsToAddressValue(details: AddressDetails): AddressValue` |
| `PointerSensor` | class | advanced | `@solvera/pace-core/forms` | Class export for pointer sensor. | `class PointerSensor` |
| `resolveFieldRenderer` | function | advanced | `@solvera/pace-core/forms` | Function for resolve field renderer. | `resolveFieldRenderer(registry: ReturnType<typeof createFieldRegistry>, meta: FormFieldMeta, props: Omit<import("./types.js").FieldRenderProps, "meta">): ReactNode` |
| `resolvePreSubmissionChecks` | function | advanced | `@solvera/pace-core/forms` | Function for resolve pre submission checks. | `resolvePreSubmissionChecks(definition: WorkflowFormDefinition): ResolvedPreSubmissionCheck[]` |
| `SortableContext` | component | advanced | `@solvera/pace-core/forms` | UI component for sortable context. | `SortableContext({ children, id, items: userDefinedItems, strategy, disabled: disabledProp, }: Props): JSX.Element` |
| `sortableKeyboardCoordinates` | constant | advanced | `@solvera/pace-core/forms` | Constant value for sortable keyboard coordinates. | `const sortableKeyboardCoordinates: KeyboardCoordinateGetter` |
| `UnsupportedFieldFallback` | component | advanced | `@solvera/pace-core/forms` | UI component for unsupported field fallback. | `UnsupportedFieldFallback({ fieldId, fieldType }: UnsupportedFieldFallbackProps): JSX.Element` |
| `useFieldArray` | hook | advanced | `@solvera/pace-core/forms` | React hook for field array. | `useFieldArray<TFieldValues extends FieldValues = FieldValues, TFieldArrayName extends FieldArrayPath<TFieldValues> = FieldArrayPath<TFieldValues>, TKeyName extends string = "id", TTransformedValues = TFieldValues>(props: UseFieldArrayProps<TFieldValues, TFieldArrayName, TKeyName, TTransformedValues>): UseFieldArrayReturn<TFieldValues, TFieldArrayName, TKeyName>` |
| `useFormContext` | hook | advanced | `@solvera/pace-core/forms` | React hook for form context. | `useFormContext<TFieldValues extends FieldValues, TContext = any, TTransformedValues = TFieldValues>(): UseFormReturn<TFieldValues, TContext, TTransformedValues>` |
| `useSensor` | hook | advanced | `@solvera/pace-core/forms` | React hook for sensor. | `useSensor<T extends SensorOptions>(sensor: Sensor<T>, options?: T): SensorDescriptor<T>` |
| `useSensors` | hook | advanced | `@solvera/pace-core/forms` | React hook for sensors. | `useSensors(...sensors: (SensorDescriptor<any> \| undefined \| null)[]): SensorDescriptor<SensorOptions>[]` |
| `useSortable` | hook | advanced | `@solvera/pace-core/forms` | React hook for sortable. | `useSortable({ animateLayoutChanges, attributes: userDefinedAttributes, disabled: localDisabled, data: customData, getNewIndex, id, strategy: localStrategy, resizeObserverConfig, transition, }: Arguments): { active: import("@dnd-kit/core").Active \| null; activeIndex: number; attributes: import("@dnd-kit/core").DraggableAttributes; data: SortableData & { [x: string]: any; }; rect: import("react").MutableRefObject<import("@dnd-kit/core").ClientRect \| null>; index: number; newIndex: number; items: import("@dnd-kit/core").UniqueIdentifier[]; isOver: boolean; isSorting: boolean; isDragging: boolean; listeners: import("@dnd-kit/core/dist/hooks/utilities").SyntheticListenerMap \| undefined; node: import("react").MutableRefObject<HTMLElement \| null>; overIndex: number; over: import("@dnd-kit/core").Over \| null; setNodeRef: (node: HTMLElement \| null) => void; setActivatorNodeRef: (element: HTMLElement \| null) => void; setDroppableNodeRef: (element: HTMLElement \| null) => void; setDraggableNodeRef: (element: HTMLElement \| null) => void; transform: import("@dnd-kit/utilities").Transform \| null; transition: string \| undefined; }` |
| `useWorkflowFieldCatalogue` | hook | advanced | `@solvera/pace-core/forms` | React hook for workflow field catalogue. | `useWorkflowFieldCatalogue({ loader, enabled, }?: UseWorkflowFieldCatalogueOptions): UseWorkflowFieldCatalogueResult` |
| `validateWorkflowAuthoringState` | function | advanced | `@solvera/pace-core/forms` | Function for validate workflow authoring state. | `validateWorkflowAuthoringState(state: WorkflowAuthoringState): WorkflowAuthoringValidationResult` |
| `verticalListSortingStrategy` | constant | advanced | `@solvera/pace-core/forms` | Constant value for vertical list sorting strategy. | `const verticalListSortingStrategy: SortingStrategy` |
| `WORKFLOW_TYPE_LABELS` | constant | advanced | `@solvera/pace-core/forms` | Constant value for workflow type labels. | `const WORKFLOW_TYPE_LABELS: Record<WorkflowType, string>` |
| `WorkflowFieldCataloguePicker` | component | advanced | `@solvera/pace-core/forms` | UI component for workflow field catalogue picker. | `WorkflowFieldCataloguePicker({ value, onValueChange, onOptionSelect, options, isLoading, errorMessage, disabled, enableSearch, searchPlacement: searchPlacementProp, }: WorkflowFieldCataloguePickerProps): JSX.Element` |
| `workflowFieldToFormFieldMeta` | function | advanced | `@solvera/pace-core/forms` | Function for workflow field to form field meta. | `workflowFieldToFormFieldMeta(field: WorkflowFieldDefinition): FormFieldMeta` |
| `WorkflowFieldVisibilityEditor` | component | advanced | `@solvera/pace-core/forms` | UI component for workflow field visibility editor. | `WorkflowFieldVisibilityEditor({ field, allFields, registrationTypeOptions, onVisibilityRuleChange, }: WorkflowFieldVisibilityEditorProps): JSX.Element` |
| `WorkflowFormAuthoringShell` | component | advanced | `@solvera/pace-core/forms` | UI component for workflow form authoring shell. | `WorkflowFormAuthoringShell({ state, onStateChange, onSave, onPreviewTarget, heading, subheading, allowedWorkflowTypes, metadataAside, middleContent, eventSlug, disabled, saveLabel, slugReadOnly, fieldCatalogueLoader, onSaveValidationAttempted, }: WorkflowFormAuthoringShellProps): JSX.Element` |
| `WorkflowFormFieldEditor` | component | advanced | `@solvera/pace-core/forms` | UI component for workflow form field editor. | `WorkflowFormFieldEditor({ state, onChange, disabled, fieldCatalogueLoader, shownFieldIssues, }: WorkflowFormFieldEditorProps): JSX.Element` |
| `WorkflowFormMetadataEditor` | component | advanced | `@solvera/pace-core/forms` | UI component for workflow form metadata editor. | `WorkflowFormMetadataEditor({ state, onChange, allowedWorkflowTypes, disabled, slugReadOnly, shownAuthoringIssues, }: WorkflowFormMetadataEditorProps): JSX.Element` |
| `WorkflowFormRenderer` | component | advanced | `@solvera/pace-core/forms` | UI component for workflow form renderer. | `WorkflowFormRenderer({ definition, fieldRegistry: fieldRegistryProp, entrypointState, selectedRegistrationTypeId, onRegistrationTypeChange, acknowledgedCheckKeys, onAcknowledgedCheckKeysChange, onSubmit, metadata, submitLabel, }: WorkflowFormRendererProps): JSX.Element` |
| `WorkflowPreSubmissionChecks` | component | advanced | `@solvera/pace-core/forms` | UI component for workflow pre submission checks. | `WorkflowPreSubmissionChecks({ checks, acknowledgedKeys, onAcknowledgedKeysChange, disabled, sectionId, }: WorkflowPreSubmissionChecksProps): JSX.Element \| null` |
| `WorkflowRegistrationTypeSelector` | component | advanced | `@solvera/pace-core/forms` | UI component for workflow registration type selector. | `WorkflowRegistrationTypeSelector({ bindings, selectedRegistrationTypeId, onChange, groupName, disabled, }: WorkflowRegistrationTypeSelectorProps): JSX.Element \| null` |
| `workflowTypeDisplayLabel` | function | advanced | `@solvera/pace-core/forms` | Function for workflow type display label. | `workflowTypeDisplayLabel(type: WorkflowType): string` |
| `workflowValuesByFieldKey` | function | advanced | `@solvera/pace-core/forms` | Function for workflow values by field key. | `workflowValuesByFieldKey(fields: WorkflowFieldDefinition[], valuesByStableId: Record<string, unknown> \| undefined): Record<string, unknown>` |

### Type exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `AddressDetails` | type | advanced | `@solvera/pace-core/forms` | Type export for address details. | `interface AddressDetails` |
| `AddressDetailsOptions` | type | advanced | `@solvera/pace-core/forms` | Options type for address details. | `interface AddressDetailsOptions` |
| `AddressFieldProps` | type | advanced | `@solvera/pace-core/forms` | Props type for address field. | `interface AddressFieldProps` |
| `AddressPrediction` | type | advanced | `@solvera/pace-core/forms` | Type export for address prediction. | `interface AddressPrediction` |
| `AddressProviderAdapter` | type | advanced | `@solvera/pace-core/forms` | Type export for address provider adapter. | `interface AddressProviderAdapter` |
| `AddressProviderStatus` | type | advanced | `@solvera/pace-core/forms` | Type export for address provider status. | `type AddressProviderStatus` |
| `AddressSearchOptions` | type | advanced | `@solvera/pace-core/forms` | Options type for address search. | `interface AddressSearchOptions` |
| `AddressValue` | type | advanced | `@solvera/pace-core/forms` | Type export for address value. | `type AddressValue` |
| `BuildWorkflowSubmissionPayloadOptions` | type | advanced | `@solvera/pace-core/forms` | Options type for build workflow submission payload. | `interface BuildWorkflowSubmissionPayloadOptions` |
| `ComposeSchemaOptions` | type | advanced | `@solvera/pace-core/forms` | Options type for compose schema. | `interface ComposeSchemaOptions` |
| `DragEndEvent` | type | advanced | `@solvera/pace-core/forms` | Type export for drag end event. | `interface DragEndEvent` |
| `FieldRegistryEntry` | type | advanced | `@solvera/pace-core/forms` | Type export for field registry entry. | `interface FieldRegistryEntry` |
| `FieldRenderProps` | type | advanced | `@solvera/pace-core/forms` | Props type for field render. | `interface FieldRenderProps` |
| `FormFieldMeta` | type | advanced | `@solvera/pace-core/forms` | Type export for form field meta. | `interface FormFieldMeta` |
| `ResolvedPreSubmissionCheck` | type | advanced | `@solvera/pace-core/forms` | Type export for resolved pre submission check. | `interface ResolvedPreSubmissionCheck` |
| `UseFormReturn` | type | advanced | `@solvera/pace-core/forms` | Type export for use form return. | `type UseFormReturn` |
| `UseWorkflowFieldCatalogueOptions` | type | advanced | `@solvera/pace-core/forms` | Options type for use workflow field catalogue. | `interface UseWorkflowFieldCatalogueOptions` |
| `UseWorkflowFieldCatalogueResult` | type | advanced | `@solvera/pace-core/forms` | Result type for use workflow field catalogue. | `interface UseWorkflowFieldCatalogueResult` |
| `WorkflowAccessMode` | type | advanced | `@solvera/pace-core/forms` | Type export for workflow access mode. | `type WorkflowAccessMode` |
| `WorkflowAuthoringMetadata` | type | advanced | `@solvera/pace-core/forms` | Type export for workflow authoring metadata. | `interface WorkflowAuthoringMetadata` |
| `WorkflowAuthoringState` | type | advanced | `@solvera/pace-core/forms` | Type export for workflow authoring state. | `interface WorkflowAuthoringState` |
| `WorkflowAuthoringValidationIssue` | type | advanced | `@solvera/pace-core/forms` | Type export for workflow authoring validation issue. | `interface WorkflowAuthoringValidationIssue` |
| `WorkflowAuthoringValidationResult` | type | advanced | `@solvera/pace-core/forms` | Result type for workflow authoring validation. | `interface WorkflowAuthoringValidationResult` |
| `WorkflowEntrypointState` | type | advanced | `@solvera/pace-core/forms` | Type export for workflow entrypoint state. | `type WorkflowEntrypointState` |
| `WorkflowFieldCatalogueLoader` | type | advanced | `@solvera/pace-core/forms` | Type export for workflow field catalogue loader. | `type WorkflowFieldCatalogueLoader` |
| `WorkflowFieldCatalogueLoaderContext` | type | advanced | `@solvera/pace-core/forms` | Type export for workflow field catalogue loader context. | `interface WorkflowFieldCatalogueLoaderContext` |
| `WorkflowFieldCatalogueOption` | type | advanced | `@solvera/pace-core/forms` | Type export for workflow field catalogue option. | `interface WorkflowFieldCatalogueOption` |
| `WorkflowFieldCataloguePickerProps` | type | advanced | `@solvera/pace-core/forms` | Props type for workflow field catalogue picker. | `interface WorkflowFieldCataloguePickerProps` |
| `WorkflowFieldDefinition` | type | advanced | `@solvera/pace-core/forms` | Type export for workflow field definition. | `interface WorkflowFieldDefinition` |
| `WorkflowFieldVisibilityEditorProps` | type | advanced | `@solvera/pace-core/forms` | Props type for workflow field visibility editor. | `interface WorkflowFieldVisibilityEditorProps` |
| `WorkflowFormAuthoringShellProps` | type | advanced | `@solvera/pace-core/forms` | Props type for workflow form authoring shell. | `interface WorkflowFormAuthoringShellProps` |
| `WorkflowFormConfig` | type | advanced | `@solvera/pace-core/forms` | Type export for workflow form config. | `type WorkflowFormConfig` |
| `WorkflowFormDefinition` | type | advanced | `@solvera/pace-core/forms` | Type export for workflow form definition. | `interface WorkflowFormDefinition` |
| `WorkflowFormFieldEditorProps` | type | advanced | `@solvera/pace-core/forms` | Props type for workflow form field editor. | `interface WorkflowFormFieldEditorProps` |
| `WorkflowFormMetadataEditorProps` | type | advanced | `@solvera/pace-core/forms` | Props type for workflow form metadata editor. | `interface WorkflowFormMetadataEditorProps` |
| `WorkflowFormRendererProps` | type | advanced | `@solvera/pace-core/forms` | Props type for workflow form renderer. | `interface WorkflowFormRendererProps` |
| `WorkflowFormStatus` | type | advanced | `@solvera/pace-core/forms` | Type export for workflow form status. | `type WorkflowFormStatus` |
| `WorkflowPreSubmissionCheck` | type | advanced | `@solvera/pace-core/forms` | Type export for workflow pre submission check. | `type WorkflowPreSubmissionCheck` |
| `WorkflowPreSubmissionChecksProps` | type | advanced | `@solvera/pace-core/forms` | Props type for workflow pre submission checks. | `interface WorkflowPreSubmissionChecksProps` |
| `WorkflowPreviewTarget` | type | advanced | `@solvera/pace-core/forms` | Type export for workflow preview target. | `interface WorkflowPreviewTarget` |
| `WorkflowRegistrationBinding` | type | advanced | `@solvera/pace-core/forms` | Type export for workflow registration binding. | `interface WorkflowRegistrationBinding` |
| `WorkflowRegistrationTypeSelectorProps` | type | advanced | `@solvera/pace-core/forms` | Props type for workflow registration type selector. | `interface WorkflowRegistrationTypeSelectorProps` |
| `WorkflowSubmissionAdapter` | type | advanced | `@solvera/pace-core/forms` | Type export for workflow submission adapter. | `interface WorkflowSubmissionAdapter` |
| `WorkflowSubmissionPayload` | type | advanced | `@solvera/pace-core/forms` | Type export for workflow submission payload. | `interface WorkflowSubmissionPayload` |
| `WorkflowSubmissionResult` | type | advanced | `@solvera/pace-core/forms` | Result type for workflow submission. | `type WorkflowSubmissionResult` |
| `WorkflowSubmissionSuccess` | type | advanced | `@solvera/pace-core/forms` | Type export for workflow submission success. | `interface WorkflowSubmissionSuccess` |
| `WorkflowType` | type | advanced | `@solvera/pace-core/forms` | Type export for workflow type. | `type WorkflowType` |
| `WorkflowVisibilityCondition` | type | advanced | `@solvera/pace-core/forms` | Type export for workflow visibility condition. | `type WorkflowVisibilityCondition` |
| `WorkflowVisibilityContext` | type | advanced | `@solvera/pace-core/forms` | Type export for workflow visibility context. | `interface WorkflowVisibilityContext` |
| `WorkflowVisibilityRule` | type | advanced | `@solvera/pace-core/forms` | Type export for workflow visibility rule. | `type WorkflowVisibilityRule` |

## `@solvera/pace-core/hooks`

Declaration source: `dist/hooks/index.d.ts`

### Runtime exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `clearFileDisplayCache` | function | advanced | `@solvera/pace-core/hooks` | Function for clear file display cache. | `clearFileDisplayCache(fileReferenceId?: string): void` |
| `extractEventCodeFromPath` | function | advanced | `@solvera/pace-core/hooks` | Function for extract event code from path. | `extractEventCodeFromPath(pathname: string, pattern?: RegExp): string \| null` |
| `fetchEventLogoReference` | function | advanced | `@solvera/pace-core/hooks` | Function for fetch event logo reference. | `fetchEventLogoReference(secureSupabase: ReturnType<typeof useSecureSupabase>, eventId: string): Promise<ApiResult<EventLogoReference>>` |
| `generatePublicRoutePath` | function | advanced | `@solvera/pace-core/hooks` | Function for generate public route path. | `generatePublicRoutePath(eventCode: string, basePath?: string): string` |
| `useAddressFieldSessionToken` | hook | advanced | `@solvera/pace-core/hooks` | React hook for address field session token. | `useAddressFieldSessionToken(options?: UseAddressFieldSessionTokenOptions): { getSessionToken: () => object \| null; resetSessionToken: () => void; }` |
| `useAllOrganisationStats` | hook | advanced | `@solvera/pace-core/hooks` | React hook for all organisation stats. | `useAllOrganisationStats(): UseAllOrganisationStatsResult` |
| `useConfirmationInput` | hook | advanced | `@solvera/pace-core/hooks` | React hook for confirmation input. | `useConfirmationInput(open: boolean, _confirmationText: string): UseConfirmationInputReturn` |
| `useContextTheme` | hook | advanced | `@solvera/pace-core/hooks` | React hook for context theme. | `useContextTheme(): void` |
| `useDataTableState` | hook | advanced | `@solvera/pace-core/hooks` | React hook for data table state. | `useDataTableState<TData>(options: UseDataTableStateOptions<TData>): UseDataTableStateReturn<TData>` |
| `useEventLogoReference` | hook | advanced | `@solvera/pace-core/hooks` | React hook for event logo reference. | `useEventLogoReference(eventId: string \| null, scopeKey?: EventLogoScopeKey): import("@tanstack/react-query").UseQueryResult<EventLogoReference, Error>` |
| `useEvents` | hook | advanced | `@solvera/pace-core/hooks` | React hook for events. | `useEvents(): import("../providers/EventServiceProvider.js").EventServiceContextValue` |
| `useEventService` | hook | advanced | `@solvera/pace-core/hooks` | React hook for event service. | `useEventService(): IEventService \| null` |
| `useFileDisplay` | hook | advanced | `@solvera/pace-core/hooks` | React hook for file display. | `useFileDisplay(fileReference: FileReference \| null, options: UseFileDisplayOptions): UseFileDisplayResult` |
| `useFileUpload` | hook | advanced | `@solvera/pace-core/hooks` | React hook for file upload. | `useFileUpload(options: UseFileUploadOptions): UseFileUploadReturn` |
| `useFileUrlCache` | hook | advanced | `@solvera/pace-core/hooks` | React hook for file url cache. | `useFileUrlCache(fileReference: FileReference \| null, options: UseFileDisplayOptions): UseFileDisplayResult` |
| `useFormDialog` | hook | advanced | `@solvera/pace-core/hooks` | React hook for form dialog. | `useFormDialog<T>(options?: UseFormDialogOptions): UseFormDialogReturn<T>` |
| `useInactivityService` | hook | advanced | `@solvera/pace-core/hooks` | React hook for inactivity service. | `useInactivityService(): import("../services/IInactivityService.js").IInactivityService \| null` |
| `useInactivityTracker` | hook | advanced | `@solvera/pace-core/hooks` | React hook for inactivity tracker. | `useInactivityTracker(): { showInactivityWarning: boolean; inactivityTimeRemaining: number; resetActivity: () => void; handleStaySignedIn: () => void; handleSignOutNow: () => void; }` |
| `useLoginHistory` | hook | advanced | `@solvera/pace-core/hooks` | React hook for login history. | `useLoginHistory(filters?: UseLoginHistoryFilters \| null): UseLoginHistoryResult` |
| `useOptionalEvents` | hook | advanced | `@solvera/pace-core/hooks` | React hook for optional events. | `useOptionalEvents(): { events: import("../types/auth.js").EventStub[]; selectedEvent: import("../types/auth.js").EventStub \| null; setSelectedEvent: (event: import("../types/auth.js").EventStub \| null) => void; refreshEvents: () => Promise<void>; isLoading: boolean; error: Error \| null; }` |
| `useOrganisations` | hook | advanced | `@solvera/pace-core/hooks` | React hook for organisations. | `useOrganisations(): OrganisationContextType` |
| `useOrganisationService` | hook | advanced | `@solvera/pace-core/hooks` | React hook for organisation service. | `useOrganisationService(): IOrganisationService \| null` |
| `useOrganisationStats` | hook | advanced | `@solvera/pace-core/hooks` | React hook for organisation stats. | `useOrganisationStats(organisationId: string \| null): UseOrganisationStatsResult` |
| `usePaceMain` | hook | advanced | `@solvera/pace-core/hooks` | React hook for pace main. | `usePaceMain(options: UsePaceMainOptions): void` |
| `usePublicEvent` | hook | advanced | `@solvera/pace-core/hooks` | React hook for public event. | `usePublicEvent(eventCodeOrId: string \| undefined): UsePublicEventResult` |
| `usePublicEventCode` | hook | advanced | `@solvera/pace-core/hooks` | React hook for public event code. | `usePublicEventCode(): string \| undefined` |
| `usePublicEventLogo` | hook | advanced | `@solvera/pace-core/hooks` | React hook for public event logo. | `usePublicEventLogo(eventCode: string \| undefined): { logoUrl: string \| null; isLoading: boolean; error: Error \| null; }` |
| `usePublicFileDisplay` | hook | advanced | `@solvera/pace-core/hooks` | React hook for public file display. | `usePublicFileDisplay(fileIdOrRef: string \| FileReference \| null, bucket?: string): UsePublicFileDisplayResult` |
| `usePublicRouteParams` | hook | advanced | `@solvera/pace-core/hooks` | React hook for public route params. | `usePublicRouteParams(): PublicRouteParams` |
| `useSessionRestoration` | hook | advanced | `@solvera/pace-core/hooks` | React hook for session restoration. | `useSessionRestoration(): UseSessionRestorationReturn` |
| `useSystemStats` | hook | advanced | `@solvera/pace-core/hooks` | React hook for system stats. | `useSystemStats(): UseSystemStatsResult` |
| `useTheme` | hook | advanced | `@solvera/pace-core/hooks` | React hook for theme. | `useTheme(palette: PaletteData \| null): void` |
| `useToast` | hook | advanced | `@solvera/pace-core/hooks` | React hook for toast. | `useToast(): import("../components/forms-feedback/Toast.js").ToastContextValue` |
| `useUnifiedAuth` | hook | advanced | `@solvera/pace-core/hooks` | React hook for unified auth. | `useUnifiedAuth(): UnifiedAuthContextType` |
| `useZodForm` | hook | advanced | `@solvera/pace-core/hooks` | React hook for zod form. | `useZodForm<T extends FieldValues>(options: UseZodFormOptions<T>): UseFormReturn<T>` |

### Type exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `EventLogoReference` | type | advanced | `@solvera/pace-core/hooks` | Type export for event logo reference. | `type EventLogoReference` |
| `EventLogoScopeKey` | type | advanced | `@solvera/pace-core/hooks` | Type export for event logo scope key. | `interface EventLogoScopeKey` |
| `FormMode` | type | advanced | `@solvera/pace-core/hooks` | Type export for form mode. | `type FormMode` |
| `PublicRouteParams` | type | advanced | `@solvera/pace-core/hooks` | Type export for public route params. | `interface PublicRouteParams` |
| `UploadState` | type | advanced | `@solvera/pace-core/hooks` | Type export for upload state. | `interface UploadState` |
| `UseAllOrganisationStatsResult` | type | advanced | `@solvera/pace-core/hooks` | Result type for use all organisation stats. | `interface UseAllOrganisationStatsResult` |
| `UseConfirmationInputReturn` | type | advanced | `@solvera/pace-core/hooks` | Type export for use confirmation input return. | `interface UseConfirmationInputReturn` |
| `UseDataTableStateOptions` | type | advanced | `@solvera/pace-core/hooks` | Options type for use data table state. | `interface UseDataTableStateOptions` |
| `UseDataTableStateReturn` | type | advanced | `@solvera/pace-core/hooks` | Type export for use data table state return. | `interface UseDataTableStateReturn` |
| `UseFileDisplayOptions` | type | advanced | `@solvera/pace-core/hooks` | Options type for use file display. | `interface UseFileDisplayOptions` |
| `UseFileDisplayResult` | type | advanced | `@solvera/pace-core/hooks` | Result type for use file display. | `interface UseFileDisplayResult` |
| `UseFileUploadOptions` | type | advanced | `@solvera/pace-core/hooks` | Options type for use file upload. | `interface UseFileUploadOptions` |
| `UseFileUploadReturn` | type | advanced | `@solvera/pace-core/hooks` | Type export for use file upload return. | `interface UseFileUploadReturn` |
| `UseFormDialogOptions` | type | advanced | `@solvera/pace-core/hooks` | Options type for use form dialog. | `interface UseFormDialogOptions` |
| `UseFormDialogReturn` | type | advanced | `@solvera/pace-core/hooks` | Type export for use form dialog return. | `interface UseFormDialogReturn` |
| `UseLoginHistoryResult` | type | advanced | `@solvera/pace-core/hooks` | Result type for use login history. | `interface UseLoginHistoryResult` |
| `UseOrganisationStatsResult` | type | advanced | `@solvera/pace-core/hooks` | Result type for use organisation stats. | `interface UseOrganisationStatsResult` |
| `UsePaceMainOptions` | type | advanced | `@solvera/pace-core/hooks` | Options type for use pace main. | `type UsePaceMainOptions` |
| `UsePublicEventResult` | type | advanced | `@solvera/pace-core/hooks` | Result type for use public event. | `interface UsePublicEventResult` |
| `UsePublicFileDisplayResult` | type | advanced | `@solvera/pace-core/hooks` | Result type for use public file display. | `interface UsePublicFileDisplayResult` |
| `UseSessionRestorationReturn` | type | advanced | `@solvera/pace-core/hooks` | Type export for use session restoration return. | `interface UseSessionRestorationReturn` |
| `UseSystemStatsResult` | type | advanced | `@solvera/pace-core/hooks` | Result type for use system stats. | `interface UseSystemStatsResult` |
| `UseZodFormOptions` | type | advanced | `@solvera/pace-core/hooks` | Options type for use zod form. | `interface UseZodFormOptions` |

## `@solvera/pace-core/icons`

Declaration source: `dist/icons/index.d.ts`

### Runtime exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `ArrowDown` | component | advanced | `@solvera/pace-core/icons` | UI component for arrow down. | `ArrowDown(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `ArrowRight` | component | advanced | `@solvera/pace-core/icons` | UI component for arrow right. | `ArrowRight(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `ArrowUp` | component | advanced | `@solvera/pace-core/icons` | UI component for arrow up. | `ArrowUp(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `Building2` | component | advanced | `@solvera/pace-core/icons` | UI component for building2. | `Building2(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `Bus` | component | advanced | `@solvera/pace-core/icons` | UI component for bus. | `Bus(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `Calendar` | component | advanced | `@solvera/pace-core/icons` | UI component for calendar. | `Calendar(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `Car` | component | advanced | `@solvera/pace-core/icons` | UI component for car. | `Car(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `ChevronDown` | component | advanced | `@solvera/pace-core/icons` | UI component for chevron down. | `ChevronDown(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `ChevronLeft` | component | advanced | `@solvera/pace-core/icons` | UI component for chevron left. | `ChevronLeft(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `ChevronRight` | component | advanced | `@solvera/pace-core/icons` | UI component for chevron right. | `ChevronRight(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `ChevronsLeft` | component | advanced | `@solvera/pace-core/icons` | UI component for chevrons left. | `ChevronsLeft(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `ChevronsRight` | component | advanced | `@solvera/pace-core/icons` | UI component for chevrons right. | `ChevronsRight(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `CircleAlert` | component | advanced | `@solvera/pace-core/icons` | UI component for circle alert. | `CircleAlert(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `CircleDollarSign` | component | advanced | `@solvera/pace-core/icons` | UI component for circle dollar sign. | `CircleDollarSign(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `Columns3` | component | advanced | `@solvera/pace-core/icons` | UI component for columns3. | `Columns3(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `Copy` | component | advanced | `@solvera/pace-core/icons` | UI component for copy. | `Copy(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `Download` | component | advanced | `@solvera/pace-core/icons` | UI component for download. | `Download(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `ExternalLink` | component | advanced | `@solvera/pace-core/icons` | UI component for external link. | `ExternalLink(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `File` | component | advanced | `@solvera/pace-core/icons` | UI component for file. | `File(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `Filter` | component | advanced | `@solvera/pace-core/icons` | UI component for filter. | `Filter(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `Footprints` | component | advanced | `@solvera/pace-core/icons` | UI component for footprints. | `Footprints(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `GripVertical` | component | advanced | `@solvera/pace-core/icons` | UI component for grip vertical. | `GripVertical(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `Image` | component | advanced | `@solvera/pace-core/icons` | UI component for image. | `Image(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `KeyRound` | component | advanced | `@solvera/pace-core/icons` | UI component for key round. | `KeyRound(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `Lock` | component | advanced | `@solvera/pace-core/icons` | UI component for lock. | `Lock(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `LogOut` | component | advanced | `@solvera/pace-core/icons` | UI component for log out. | `LogOut(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `Mail` | component | advanced | `@solvera/pace-core/icons` | UI component for mail. | `Mail(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `MapPin` | component | advanced | `@solvera/pace-core/icons` | UI component for map pin. | `MapPin(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `Menu` | component | advanced | `@solvera/pace-core/icons` | UI component for menu. | `Menu(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `Phone` | component | advanced | `@solvera/pace-core/icons` | UI component for phone. | `Phone(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `Plane` | component | advanced | `@solvera/pace-core/icons` | UI component for plane. | `Plane(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `Plus` | component | advanced | `@solvera/pace-core/icons` | UI component for plus. | `Plus(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `RefreshCcw` | component | advanced | `@solvera/pace-core/icons` | UI component for refresh ccw. | `RefreshCcw(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `Search` | component | advanced | `@solvera/pace-core/icons` | UI component for search. | `Search(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `Settings` | component | advanced | `@solvera/pace-core/icons` | UI component for settings. | `Settings(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `Shield` | component | advanced | `@solvera/pace-core/icons` | UI component for shield. | `Shield(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `Ship` | component | advanced | `@solvera/pace-core/icons` | UI component for ship. | `Ship(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `SquarePen` | component | advanced | `@solvera/pace-core/icons` | UI component for square pen. | `SquarePen(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `TrainFront` | component | advanced | `@solvera/pace-core/icons` | UI component for train front. | `TrainFront(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `Trash2` | component | advanced | `@solvera/pace-core/icons` | UI component for trash2. | `Trash2(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `Upload` | component | advanced | `@solvera/pace-core/icons` | UI component for upload. | `Upload(props: Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>): react.ReactNode` |
| `X` | constant | advanced | `@solvera/pace-core/icons` | Constant value for x. | `const X: react.ForwardRefExoticComponent<Omit<LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>>` |

### Type exports

_None._

## `@solvera/pace-core/itinerary`

Declaration source: `dist/itinerary/index.d.ts`

### Runtime exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `compareItineraryEntries` | function | advanced | `@solvera/pace-core/itinerary` | Function for compare itinerary entries. | `compareItineraryEntries(left: DerivedItineraryDayEntry, right: DerivedItineraryDayEntry): number` |
| `deriveItineraryDayEntries` | function | advanced | `@solvera/pace-core/itinerary` | Function for derive itinerary day entries. | `deriveItineraryDayEntries(input: DeriveItineraryDayEntriesInput): DerivedItineraryDayEntry[]` |
| `filterItineraryForParticipant` | function | advanced | `@solvera/pace-core/itinerary` | Function for filter itinerary for participant. | `filterItineraryForParticipant(input: FilterItineraryForParticipantInput): ItineraryResourceInput[]` |
| `getItineraryVisibleDateRange` | function | advanced | `@solvera/pace-core/itinerary` | Function for get itinerary visible date range. | `getItineraryVisibleDateRange(entries: ReadonlyArray<DerivedItineraryDayEntry>): ItineraryVisibleDateRange \| null` |
| `groupItineraryEntriesByDay` | function | advanced | `@solvera/pace-core/itinerary` | Function for group itinerary entries by day. | `groupItineraryEntriesByDay(entries: ReadonlyArray<DerivedItineraryDayEntry>): ItineraryDayGroup[]` |
| `validateItineraryInputs` | function | advanced | `@solvera/pace-core/itinerary` | Function for validate itinerary inputs. | `validateItineraryInputs(input: DeriveItineraryDayEntriesInput): ItineraryValidationResult` |

### Type exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `AccommodationItineraryInput` | type | advanced | `@solvera/pace-core/itinerary` | Type export for accommodation itinerary input. | `interface AccommodationItineraryInput` |
| `ActivityItineraryInput` | type | advanced | `@solvera/pace-core/itinerary` | Type export for activity itinerary input. | `interface ActivityItineraryInput` |
| `DerivedItineraryDayEntry` | type | advanced | `@solvera/pace-core/itinerary` | Type export for derived itinerary day entry. | `interface DerivedItineraryDayEntry` |
| `DeriveItineraryDayEntriesInput` | type | advanced | `@solvera/pace-core/itinerary` | Type export for derive itinerary day entries input. | `interface DeriveItineraryDayEntriesInput` |
| `FilterItineraryForParticipantInput` | type | advanced | `@solvera/pace-core/itinerary` | Type export for filter itinerary for participant input. | `interface FilterItineraryForParticipantInput` |
| `ItineraryAssignmentInput` | type | advanced | `@solvera/pace-core/itinerary` | Type export for itinerary assignment input. | `interface ItineraryAssignmentInput` |
| `ItineraryDayGroup` | type | advanced | `@solvera/pace-core/itinerary` | Type export for itinerary day group. | `interface ItineraryDayGroup` |
| `ItineraryEntryKind` | type | advanced | `@solvera/pace-core/itinerary` | Type export for itinerary entry kind. | `type ItineraryEntryKind` |
| `ItineraryResourceInput` | type | advanced | `@solvera/pace-core/itinerary` | Type export for itinerary resource input. | `type ItineraryResourceInput` |
| `ItineraryResourceType` | type | advanced | `@solvera/pace-core/itinerary` | Type export for itinerary resource type. | `type ItineraryResourceType` |
| `ItineraryScope` | type | advanced | `@solvera/pace-core/itinerary` | Type export for itinerary scope. | `type ItineraryScope` |
| `ItineraryValidationIssue` | type | advanced | `@solvera/pace-core/itinerary` | Type export for itinerary validation issue. | `interface ItineraryValidationIssue` |
| `ItineraryValidationResult` | type | advanced | `@solvera/pace-core/itinerary` | Result type for itinerary validation. | `interface ItineraryValidationResult` |
| `ItineraryVisibleDateRange` | type | advanced | `@solvera/pace-core/itinerary` | Type export for itinerary visible date range. | `interface ItineraryVisibleDateRange` |
| `TransportItineraryInput` | type | advanced | `@solvera/pace-core/itinerary` | Type export for transport itinerary input. | `interface TransportItineraryInput` |

## `@solvera/pace-core/location`

Declaration source: `dist/location/index.d.ts`

### Runtime exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `classifyLocationAdapterError` | function | advanced | `@solvera/pace-core/location` | Function for classify location adapter error. | `classifyLocationAdapterError(error: unknown): AdapterResolutionError` |
| `createLocationCache` | function | advanced | `@solvera/pace-core/location` | Function for create location cache. | `createLocationCache<T>(): LocationCache<T>` |
| `createLocationCacheKey` | function | advanced | `@solvera/pace-core/location` | Function for create location cache key. | `createLocationCacheKey(input: LocationQueryInput \| NormalizedLocationQuery, scope?: string): string` |
| `normalizeLocationQuery` | function | advanced | `@solvera/pace-core/location` | Function for normalize location query. | `normalizeLocationQuery(input: LocationQueryInput): NormalizedLocationQuery` |
| `resolveLocationTimezone` | function | advanced | `@solvera/pace-core/location` | Function for resolve location timezone. | `resolveLocationTimezone(options: ResolveLocationTimezoneOptions): Promise<AdapterResolutionResult<LocationTimezoneResolution>>` |
| `resolveLocationTimezoneMany` | function | advanced | `@solvera/pace-core/location` | Function for resolve location timezone many. | `resolveLocationTimezoneMany(options: ResolveLocationTimezoneManyOptions): Promise<ReadonlyArray<AdapterResolutionResult<LocationTimezoneResolution>>>` |

### Type exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `AdapterResolutionError` | type | advanced | `@solvera/pace-core/location` | Type export for adapter resolution error. | `interface AdapterResolutionError` |
| `AdapterResolutionResult` | type | advanced | `@solvera/pace-core/location` | Result type for adapter resolution. | `type AdapterResolutionResult` |
| `LocationAdapter` | type | advanced | `@solvera/pace-core/location` | Type export for location adapter. | `interface LocationAdapter` |
| `LocationAdapterErrorCode` | type | advanced | `@solvera/pace-core/location` | Type export for location adapter error code. | `type LocationAdapterErrorCode` |
| `LocationCache` | type | advanced | `@solvera/pace-core/location` | Type export for location cache. | `interface LocationCache` |
| `LocationCacheEntry` | type | advanced | `@solvera/pace-core/location` | Type export for location cache entry. | `interface LocationCacheEntry` |
| `LocationCoordinates` | type | advanced | `@solvera/pace-core/location` | Type export for location coordinates. | `interface LocationCoordinates` |
| `LocationProviderChain` | type | advanced | `@solvera/pace-core/location` | Type export for location provider chain. | `interface LocationProviderChain` |
| `LocationQueryInput` | type | advanced | `@solvera/pace-core/location` | Type export for location query input. | `interface LocationQueryInput` |
| `LocationTimezoneResolution` | type | advanced | `@solvera/pace-core/location` | Type export for location timezone resolution. | `interface LocationTimezoneResolution` |
| `NormalizedLocationQuery` | type | advanced | `@solvera/pace-core/location` | Type export for normalized location query. | `interface NormalizedLocationQuery` |
| `NormalizedLocationResult` | type | advanced | `@solvera/pace-core/location` | Result type for normalized location. | `interface NormalizedLocationResult` |
| `NormalizedTimezoneResult` | type | advanced | `@solvera/pace-core/location` | Result type for normalized timezone. | `interface NormalizedTimezoneResult` |
| `ResolveLocationTimezoneManyOptions` | type | advanced | `@solvera/pace-core/location` | Options type for resolve location timezone many. | `interface ResolveLocationTimezoneManyOptions` |
| `ResolveLocationTimezoneOptions` | type | advanced | `@solvera/pace-core/location` | Options type for resolve location timezone. | `interface ResolveLocationTimezoneOptions` |
| `TimezoneAdapter` | type | advanced | `@solvera/pace-core/location` | Type export for timezone adapter. | `interface TimezoneAdapter` |

## `@solvera/pace-core/login-history`

Declaration source: `dist/login-history/index.d.ts`

### Runtime exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `RECORD_LOGIN_FUNCTION_NAME` | constant | advanced | `@solvera/pace-core/login-history` | Constant value for record login function name. | `const RECORD_LOGIN_FUNCTION_NAME: "record-login"` |
| `recordLogin` | function | advanced | `@solvera/pace-core/login-history` | Function for record login. | `recordLogin(supabase: SupabaseClientWithFunctions \| null, payload: RecordLoginPayload): Promise<ApiResult<void>>` |

### Type exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `SupabaseClientWithFunctions` | type | advanced | `@solvera/pace-core/login-history` | Type export for supabase client with functions. | `interface SupabaseClientWithFunctions` |

## `@solvera/pace-core/member-profile-launch`

Declaration source: `dist/member-profile-launch/index.d.ts`

### Runtime exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `buildMemberProfileLaunchUrl` | function | advanced | `@solvera/pace-core/member-profile-launch` | Function for build member profile launch url. | `buildMemberProfileLaunchUrl({ portalOrigin, mode, memberId, }: BuildMemberProfileLaunchUrlParams): string` |
| `isMemberProfileLaunchMode` | function | advanced | `@solvera/pace-core/member-profile-launch` | Function for is member profile launch mode. | `isMemberProfileLaunchMode(value: unknown): value is MemberProfileLaunchMode` |
| `launchMemberProfile` | function | advanced | `@solvera/pace-core/member-profile-launch` | Function for launch member profile. | `launchMemberProfile({ portalOrigin, mode, memberId, target, open, }: LaunchMemberProfileParams): Window \| null \| unknown` |

### Type exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `BuildMemberProfileLaunchUrlParams` | type | advanced | `@solvera/pace-core/member-profile-launch` | Type export for build member profile launch url params. | `interface BuildMemberProfileLaunchUrlParams` |
| `LaunchMemberProfileParams` | type | advanced | `@solvera/pace-core/member-profile-launch` | Type export for launch member profile params. | `interface LaunchMemberProfileParams` |
| `MemberProfileLaunchMode` | type | advanced | `@solvera/pace-core/member-profile-launch` | Type export for member profile launch mode. | `type MemberProfileLaunchMode` |
| `MemberProfileOpener` | type | advanced | `@solvera/pace-core/member-profile-launch` | Type export for member profile opener. | `type MemberProfileOpener` |

## `@solvera/pace-core/providers`

Declaration source: `dist/providers/index.d.ts`

### Runtime exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `EventServiceProvider` | provider | advanced | `@solvera/pace-core/providers` | React context provider for event service. | `EventServiceProvider({ children, supabaseClient, autoSelectEvent, restorePersistedSelection, }: EventServiceProviderProps): JSX.Element` |
| `InactivityServiceProvider` | provider | advanced | `@solvera/pace-core/providers` | React context provider for inactivity service. | `InactivityServiceProvider({ children }: InactivityServiceProviderProps): JSX.Element` |
| `OrganisationServiceProvider` | provider | advanced | `@solvera/pace-core/providers` | React context provider for organisation service. | `OrganisationServiceProvider({ children, supabaseClient, user, session, }: OrganisationServiceProviderProps): JSX.Element` |
| `UnifiedAuthProvider` | provider | advanced | `@solvera/pace-core/providers` | React context provider for unified auth. | `UnifiedAuthProvider(props: UnifiedAuthProviderProps): JSX.Element` |
| `useEventServiceContext` | hook | advanced | `@solvera/pace-core/providers` | React hook for event service context. | `useEventServiceContext(): EventServiceContextValue` |
| `useEventServiceContextOptional` | hook | advanced | `@solvera/pace-core/providers` | React hook for event service context optional. | `useEventServiceContextOptional(): EventServiceContextValue \| null` |
| `useInactivityServiceContext` | hook | advanced | `@solvera/pace-core/providers` | React hook for inactivity service context. | `useInactivityServiceContext(): IInactivityService \| null` |
| `useOptionalUnifiedAuthContext` | hook | advanced | `@solvera/pace-core/providers` | React hook for optional unified auth context. | `useOptionalUnifiedAuthContext(): UnifiedAuthContextValue \| null` |
| `useOrganisationsContext` | hook | advanced | `@solvera/pace-core/providers` | React hook for organisations context. | `useOrganisationsContext(): OrganisationContextType` |
| `useOrganisationsContextOptional` | hook | advanced | `@solvera/pace-core/providers` | React hook for organisations context optional. | `useOrganisationsContextOptional(): OrganisationContextType \| null` |
| `useUnifiedAuthContext` | hook | advanced | `@solvera/pace-core/providers` | React hook for unified auth context. | `useUnifiedAuthContext(): UnifiedAuthContextValue` |

### Type exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `EventServiceContextValue` | type | advanced | `@solvera/pace-core/providers` | Type export for event service context value. | `interface EventServiceContextValue` |
| `EventServiceProviderProps` | type | advanced | `@solvera/pace-core/providers` | Props type for event service provider. | `interface EventServiceProviderProps` |
| `InactivityServiceProviderProps` | type | advanced | `@solvera/pace-core/providers` | Props type for inactivity service provider. | `interface InactivityServiceProviderProps` |

## `@solvera/pace-core/rbac`

Declaration source: `dist/rbac.d.ts`

### Runtime exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `AccessDenied` | component | advanced | `@solvera/pace-core/rbac` | UI component for access denied. | `AccessDenied({ message }: AccessDeniedProps): JSX.Element` |
| `ALL_PERMISSIONS` | constant | advanced | `@solvera/pace-core/rbac` | Constant value for all permissions. | `const ALL_PERMISSIONS: { readonly PAGE_DOMAIN: { readonly BUDGET_VERSION_APPROVE: "approve:page.budget-version"; }; readonly EVENT_ACCESS: "event:access"; readonl...` |
| `createGetAppIdResolver` | function | advanced | `@solvera/pace-core/rbac` | Function for create get app id resolver. | `createGetAppIdResolver(client: RBACSupabaseClient): (normalizedAppName: string) => Promise<string \| null>` |
| `createSecureClient` | function | advanced | `@solvera/pace-core/rbac` | Function for create secure client. | `createSecureClient(supabaseUrl: string, supabaseKey: string, organisationId: OrganisationId \| string, eventId?: EventId \| string \| null, appId?: AppId \| string \| null, _isSuperAdmin?: boolean): SecureSupabaseClient` |
| `EVENT_APP_PERMISSIONS` | constant | advanced | `@solvera/pace-core/rbac` | Constant value for event app permissions. | `const EVENT_APP_PERMISSIONS: { readonly EVENT_ACCESS: "event:access"; }` |
| `fromSupabaseClient` | function | advanced | `@solvera/pace-core/rbac` | Function for from supabase client. | `fromSupabaseClient(client: RBACSupabaseClient, organisationId: OrganisationId \| string \| null, eventId?: EventId \| string \| null, appId?: AppId \| string \| null, resolveAppId?: () => Promise<string \| null> \| string \| null, _isSuperAdmin?: boolean): SecureSupabaseClient` |
| `getPermissionLevel` | function | advanced | `@solvera/pace-core/rbac` | Function for get permission level. | `getPermissionLevel(scope?: Scope \| null): Promise<ApiResult<PermissionLevel>>` |
| `getPermissionMap` | function | advanced | `@solvera/pace-core/rbac` | Function for get permission map. | `getPermissionMap(scope?: Scope \| null): Promise<ApiResult<PermissionMap>>` |
| `getRoleContext` | function | advanced | `@solvera/pace-core/rbac` | Function for get role context. | `getRoleContext(scope?: Scope \| null): Promise<ApiResult<RoleContext>>` |
| `GLOBAL_PERMISSIONS` | constant | advanced | `@solvera/pace-core/rbac` | Constant value for global permissions. | `const GLOBAL_PERMISSIONS: { readonly SUPER_ADMIN: "super_admin"; }` |
| `grantEventAppRole` | function | advanced | `@solvera/pace-core/rbac` | Function for grant event app role. | `grantEventAppRole(supabase: RBACSupabaseClient, params: GrantEventAppRoleParams, grantedBy?: string): Promise<RoleManagementResult>` |
| `isPermitted` | function | advanced | `@solvera/pace-core/rbac` | Function for is permitted. | `isPermitted(input: PermissionCheck, _appName?: string, precomputedSuperAdmin?: boolean \| null): Promise<ApiResult<boolean>>` |
| `isPermittedCached` | function | advanced | `@solvera/pace-core/rbac` | Function for is permitted cached. | `isPermittedCached(input: PermissionCheck, _appName?: string, precomputedSuperAdmin?: boolean \| null): Promise<ApiResult<boolean>>` |
| `NavigationGuard` | component | advanced | `@solvera/pace-core/rbac` | UI component for navigation guard. | `NavigationGuard({ permission, pageId, children, hideWhenDenied, disableWhenDenied, fallback, }: NavigationGuardProps): JSX.Element` |
| `ORGANISATION_PERMISSIONS` | constant | advanced | `@solvera/pace-core/rbac` | Constant value for organisation permissions. | `const ORGANISATION_PERMISSIONS: { readonly ORG_ADMIN: "org_admin"; readonly MEMBER: "member"; readonly VIEW: "view"; }` |
| `PAGE_DOMAIN_PERMISSIONS` | constant | advanced | `@solvera/pace-core/rbac` | Constant value for page domain permissions. | `const PAGE_DOMAIN_PERMISSIONS: { readonly BUDGET_VERSION_APPROVE: "approve:page.budget-version"; }` |
| `PagePermissionGuard` | component | advanced | `@solvera/pace-core/rbac` | UI component for page permission guard. | `PagePermissionGuard({ pageName, operation, children, fallback, strictMode, loading, onDenied, scope, auditLog, pageId, }: PagePermissionGuardProps): JSX.Element \| null` |
| `revokeEventAppRole` | function | advanced | `@solvera/pace-core/rbac` | Function for revoke event app role. | `revokeEventAppRole(supabase: RBACSupabaseClient, params: RevokeEventAppRoleParams, revokedBy?: string): Promise<RoleManagementResult>` |
| `SET_ORGANISATION_CONTEXT_RPC` | constant | advanced | `@solvera/pace-core/rbac` | Constant value for set organisation context rpc. | `const SET_ORGANISATION_CONTEXT_RPC: "set_organisation_context"` |
| `setupRBAC` | function | advanced | `@solvera/pace-core/rbac` | Function for setup rbac. | `setupRBAC(supabaseClient: RBACSupabaseClient, config?: Partial<RBACConfig>): void` |
| `toPagePermission` | function | advanced | `@solvera/pace-core/rbac` | Function for to page permission. | `toPagePermission(pageName: string, operation: PagePermissionOperation): Permission` |
| `useCan` | hook | advanced | `@solvera/pace-core/rbac` | React hook for can. | `useCan(permission: Permission, scope?: Scope \| null, pageId?: string \| null): { can: boolean; isLoading: boolean; }` |
| `useEventAppRole` | hook | advanced | `@solvera/pace-core/rbac` | React hook for event app role. | `useEventAppRole(scope?: Scope \| null): { role: EventAppRole \| null; isLoading: boolean; }` |
| `useMultiplePermissions` | hook | advanced | `@solvera/pace-core/rbac` | React hook for multiple permissions. | `useMultiplePermissions(permissions: Permission[], scope?: Scope \| null): { results: Record<string, boolean>; isLoading: boolean; resilienceStatus: CompositeStatus; resilienceErrors: ResilienceError[]; sourceOutcomes: Record<string, { isLoading: boolean; hasData: boolean; hasError: boolean; }>; }` |
| `usePageCan` | hook | advanced | `@solvera/pace-core/rbac` | React hook for page can. | `usePageCan(pageName: string, operation: PagePermissionOperation, scope?: Scope \| null, pageId?: string \| null): { can: boolean; isLoading: boolean; }` |
| `usePermissionLevel` | hook | advanced | `@solvera/pace-core/rbac` | React hook for permission level. | `usePermissionLevel(scope?: Scope \| null): { permissionLevel: PermissionLevel; isLoading: boolean; }` |
| `usePermissions` | hook | advanced | `@solvera/pace-core/rbac` | React hook for permissions. | `usePermissions(scope?: Scope \| null): { permissionMap: PermissionMap; isLoading: boolean; }` |
| `useRBAC` | hook | advanced | `@solvera/pace-core/rbac` | React hook for rbac. | `useRBAC(): { scope: Scope; organisationId: string \| null; eventId: string \| null; appId: string \| null; isLoading: boolean; userId: string \| null; checkPermitted: (permission: Permission, scope?: Scope \| null) => Promise<boolean>; secureClient: import("../secure-client.js").RBACSupabaseClient \| null; useCan: typeof useCan; useResolvedScope: typeof useResolvedScope; }` |
| `useResolvedScope` | hook | advanced | `@solvera/pace-core/rbac` | React hook for resolved scope. | `useResolvedScope(): ResolvedScopeResult` |
| `useResourcePermissions` | hook | advanced | `@solvera/pace-core/rbac` | React hook for resource permissions. | `useResourcePermissions(resource: string, operations?: readonly Operation[] \| null, scopeOverride?: Scope \| null): ResourcePermissionsResult` |
| `useRoleManagement` | hook | advanced | `@solvera/pace-core/rbac` | React hook for role management. | `useRoleManagement(scope?: Scope \| null): { roleContext: RoleContext \| null; isLoading: boolean; refetch: () => Promise<void>; grantEventAppRole: typeof grantEventAppRoleFn; revokeEventAppRole: typeof revokeEventAppRoleFn; }` |
| `useSecureSupabase` | hook | advanced | `@solvera/pace-core/rbac` | React hook for secure supabase. | `useSecureSupabase(baseClient?: RBACSupabaseClient \| null): RBACSupabaseClient \| null` |
| `useStorageCapableClient` | hook | advanced | `@solvera/pace-core/rbac` | React hook for storage capable client. | `useStorageCapableClient(baseClient?: RBACSupabaseClient \| null): StorageCapableRBACClient \| null` |
| `withPermissionGuard` | function | advanced | `@solvera/pace-core/rbac` | Function for with permission guard. | `withPermissionGuard<P extends object>(Wrapped: ComponentType<P>, permission: string, scope?: Scope \| null): ComponentType<P>` |
| `withPermissionLevelGuard` | function | advanced | `@solvera/pace-core/rbac` | Function for with permission level guard. | `withPermissionLevelGuard<P extends object>(Wrapped: ComponentType<P>, minLevel: PermissionLevel, scope?: Scope \| null): ComponentType<P>` |
| `withRoleGuard` | function | advanced | `@solvera/pace-core/rbac` | Function for with role guard. | `withRoleGuard<P extends object>(Wrapped: ComponentType<P>, allowedRoles: string[], scope?: Scope \| null): ComponentType<P>` |

### Type exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `AccessDeniedProps` | type | advanced | `@solvera/pace-core/rbac` | Props type for access denied. | `interface AccessDeniedProps` |
| `EventAppRole` | type | advanced | `@solvera/pace-core/rbac` | Type export for event app role. | `type EventAppRole` |
| `FunctionsInvoke` | type | advanced | `@solvera/pace-core/rbac` | Type export for functions invoke. | `interface FunctionsInvoke` |
| `GrantEventAppRoleParams` | type | advanced | `@solvera/pace-core/rbac` | Type export for grant event app role params. | `interface GrantEventAppRoleParams` |
| `NavigationGuardProps` | type | advanced | `@solvera/pace-core/rbac` | Props type for navigation guard. | `interface NavigationGuardProps` |
| `PageName` | type | advanced | `@solvera/pace-core/rbac` | Type export for page name. | `type PageName` |
| `PagePermissionGuardProps` | type | advanced | `@solvera/pace-core/rbac` | Props type for page permission guard. | `interface PagePermissionGuardProps` |
| `PagePermissionOperation` | type | advanced | `@solvera/pace-core/rbac` | Type export for page permission operation. | `type PagePermissionOperation` |
| `Permission` | type | advanced | `@solvera/pace-core/rbac` | Type export for permission. | `type Permission` |
| `PermissionCheck` | type | advanced | `@solvera/pace-core/rbac` | Type export for permission check. | `interface PermissionCheck` |
| `PermissionLevel` | type | advanced | `@solvera/pace-core/rbac` | Type export for permission level. | `type PermissionLevel` |
| `PermissionMap` | type | advanced | `@solvera/pace-core/rbac` | Type export for permission map. | `type PermissionMap` |
| `RBACConfig` | type | advanced | `@solvera/pace-core/rbac` | Type export for rbacconfig. | `interface RBACConfig` |
| `RBACSupabaseClient` | type | advanced | `@solvera/pace-core/rbac` | Type export for rbacsupabase client. | `interface RBACSupabaseClient` |
| `ResolvedScopeResult` | type | advanced | `@solvera/pace-core/rbac` | Result type for resolved scope. | `interface ResolvedScopeResult` |
| `ResourcePermissionsResult` | type | advanced | `@solvera/pace-core/rbac` | Result type for resource permissions. | `interface ResourcePermissionsResult` |
| `RevokeEventAppRoleParams` | type | advanced | `@solvera/pace-core/rbac` | Type export for revoke event app role params. | `interface RevokeEventAppRoleParams` |
| `RoleContext` | type | advanced | `@solvera/pace-core/rbac` | Type export for role context. | `interface RoleContext` |
| `RoleManagementResult` | type | advanced | `@solvera/pace-core/rbac` | Result type for role management. | `interface RoleManagementResult` |
| `Scope` | type | advanced | `@solvera/pace-core/rbac` | Type export for scope. | `interface Scope` |
| `SecureSupabaseClient` | type | advanced | `@solvera/pace-core/rbac` | Type export for secure supabase client. | `interface SecureSupabaseClient` |

## `@solvera/pace-core/reporting`

Declaration source: `dist/reporting/index.d.ts`

### Runtime exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `buildReportingQueryPlan` | function | advanced | `@solvera/pace-core/reporting` | Function for build reporting query plan. | `buildReportingQueryPlan(input: BuildReportingQueryPlanInput): BuildReportingQueryPlanResult` |
| `deserializeReportTemplateConfig` | function | advanced | `@solvera/pace-core/reporting` | Function for deserialize report template config. | `deserializeReportTemplateConfig(serialized: SerializedReportTemplateConfig): ReportTemplateConfig` |
| `getReportingExplore` | function | advanced | `@solvera/pace-core/reporting` | Function for get reporting explore. | `getReportingExplore(exploreKey: string): ReportingExplore \| null` |
| `ReportBuilder` | component | advanced | `@solvera/pace-core/reporting` | UI component for report builder. | `ReportBuilder(props: ReportBuilderProps & ReactNode` |
| `reportingExplores` | constant | advanced | `@solvera/pace-core/reporting` | Constant value for reporting explores. | `const reportingExplores: Record<`${string}.${string}`, ReportingExplore>` |
| `ReportResultsTable` | component | advanced | `@solvera/pace-core/reporting` | UI component for report results table. | `ReportResultsTable({ fields, result, isLoading, title, columnConfig, sorts, rbac, }: ReportResultsTableProps): JSX.Element` |
| `serializeReportTemplateConfig` | function | advanced | `@solvera/pace-core/reporting` | Function for serialize report template config. | `serializeReportTemplateConfig(config: ReportTemplateConfig): SerializedReportTemplateConfig` |
| `validateReportingSelection` | function | advanced | `@solvera/pace-core/reporting` | Function for validate reporting selection. | `validateReportingSelection(input: ValidateReportingSelectionInput): ReportingSelectionValidationResult` |

### Type exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `BuildReportingQueryPlanInput` | type | advanced | `@solvera/pace-core/reporting` | Type export for build reporting query plan input. | `interface BuildReportingQueryPlanInput` |
| `BuildReportingQueryPlanResult` | type | advanced | `@solvera/pace-core/reporting` | Result type for build reporting query plan. | `interface BuildReportingQueryPlanResult` |
| `ReportBuilderHandle` | type | advanced | `@solvera/pace-core/reporting` | Type export for report builder handle. | `interface ReportBuilderHandle` |
| `ReportBuilderProps` | type | advanced | `@solvera/pace-core/reporting` | Props type for report builder. | `interface ReportBuilderProps` |
| `ReportingAggregateStrategy` | type | advanced | `@solvera/pace-core/reporting` | Type export for reporting aggregate strategy. | `type ReportingAggregateStrategy` |
| `ReportingAggregationPlan` | type | advanced | `@solvera/pace-core/reporting` | Type export for reporting aggregation plan. | `interface ReportingAggregationPlan` |
| `ReportingColumnConfig` | type | advanced | `@solvera/pace-core/reporting` | Type export for reporting column config. | `interface ReportingColumnConfig` |
| `ReportingExecutionAdapter` | type | advanced | `@solvera/pace-core/reporting` | Type export for reporting execution adapter. | `interface ReportingExecutionAdapter` |
| `ReportingExecutionData` | type | advanced | `@solvera/pace-core/reporting` | Type export for reporting execution data. | `interface ReportingExecutionData` |
| `ReportingExecutionRequest` | type | advanced | `@solvera/pace-core/reporting` | Type export for reporting execution request. | `interface ReportingExecutionRequest` |
| `ReportingExecutionResult` | type | advanced | `@solvera/pace-core/reporting` | Result type for reporting execution. | `type ReportingExecutionResult` |
| `ReportingExecutionRow` | type | advanced | `@solvera/pace-core/reporting` | Type export for reporting execution row. | `type ReportingExecutionRow` |
| `ReportingExplore` | type | advanced | `@solvera/pace-core/reporting` | Type export for reporting explore. | `interface ReportingExplore` |
| `ReportingExploreKey` | type | advanced | `@solvera/pace-core/reporting` | Type export for reporting explore key. | `type ReportingExploreKey` |
| `ReportingFieldMeta` | type | advanced | `@solvera/pace-core/reporting` | Type export for reporting field meta. | `interface ReportingFieldMeta` |
| `ReportingFilter` | type | advanced | `@solvera/pace-core/reporting` | Type export for reporting filter. | `interface ReportingFilter` |
| `ReportingJoin` | type | advanced | `@solvera/pace-core/reporting` | Type export for reporting join. | `interface ReportingJoin` |
| `ReportingMetadataProvider` | type | advanced | `@solvera/pace-core/reporting` | Type export for reporting metadata provider. | `interface ReportingMetadataProvider` |
| `ReportingQueryPlan` | type | advanced | `@solvera/pace-core/reporting` | Type export for reporting query plan. | `interface ReportingQueryPlan` |
| `ReportingScopeValue` | type | advanced | `@solvera/pace-core/reporting` | Type export for reporting scope value. | `type ReportingScopeValue` |
| `ReportingSelection` | type | advanced | `@solvera/pace-core/reporting` | Type export for reporting selection. | `interface ReportingSelection` |
| `ReportingSelectionValidationError` | type | advanced | `@solvera/pace-core/reporting` | Type export for reporting selection validation error. | `interface ReportingSelectionValidationError` |
| `ReportingSelectionValidationResult` | type | advanced | `@solvera/pace-core/reporting` | Result type for reporting selection validation. | `interface ReportingSelectionValidationResult` |
| `ReportingSort` | type | advanced | `@solvera/pace-core/reporting` | Type export for reporting sort. | `interface ReportingSort` |
| `ReportingTemplateRecord` | type | advanced | `@solvera/pace-core/reporting` | Type export for reporting template record. | `interface ReportingTemplateRecord` |
| `ReportingTemplateSaveInput` | type | advanced | `@solvera/pace-core/reporting` | Type export for reporting template save input. | `interface ReportingTemplateSaveInput` |
| `ReportingTemplateStore` | type | advanced | `@solvera/pace-core/reporting` | Type export for reporting template store. | `interface ReportingTemplateStore` |
| `ReportingValidationCode` | type | advanced | `@solvera/pace-core/reporting` | Type export for reporting validation code. | `type ReportingValidationCode` |
| `ReportResultsTableProps` | type | advanced | `@solvera/pace-core/reporting` | Props type for report results table. | `interface ReportResultsTableProps` |
| `ReportTemplateConfig` | type | advanced | `@solvera/pace-core/reporting` | Type export for report template config. | `interface ReportTemplateConfig` |
| `SerializedReportTemplateConfig` | type | advanced | `@solvera/pace-core/reporting` | Type export for serialized report template config. | `interface SerializedReportTemplateConfig` |
| `ValidateReportingSelectionInput` | type | advanced | `@solvera/pace-core/reporting` | Type export for validate reporting selection input. | `interface ValidateReportingSelectionInput` |

## `@solvera/pace-core/resilience`

Declaration source: `dist/resilience/index.d.ts`

### Runtime exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `collectSourceErrors` | function | advanced | `@solvera/pace-core/resilience` | Function for collect source errors. | `collectSourceErrors<T>(sourceResults: ReadonlyArray<CompositeSourceResult<T>>, options?: CollectSourceErrorsOptions): ResilienceError[]` |
| `composeResilientState` | function | advanced | `@solvera/pace-core/resilience` | Function for compose resilient state. | `composeResilientState<T>(sourceResults: ReadonlyArray<CompositeSourceResult<T>>, options?: ComposeResilientStateOptions): CompositeResilienceState<T>` |
| `resolveWithFallback` | function | advanced | `@solvera/pace-core/resilience` | Function for resolve with fallback. | `resolveWithFallback<T>(sources: ReadonlyArray<FallbackSource<T>>): Promise<FallbackResolution<T>>` |

### Type exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `CollectSourceErrorsOptions` | type | advanced | `@solvera/pace-core/resilience` | Options type for collect source errors. | `interface CollectSourceErrorsOptions` |
| `ComposeResilientStateOptions` | type | advanced | `@solvera/pace-core/resilience` | Options type for compose resilient state. | `interface ComposeResilientStateOptions` |
| `CompositeResilienceState` | type | advanced | `@solvera/pace-core/resilience` | Type export for composite resilience state. | `interface CompositeResilienceState` |
| `CompositeSourceResult` | type | advanced | `@solvera/pace-core/resilience` | Result type for composite source. | `interface CompositeSourceResult` |
| `CompositeStatus` | type | advanced | `@solvera/pace-core/resilience` | Type export for composite status. | `type CompositeStatus` |
| `FallbackAttempt` | type | advanced | `@solvera/pace-core/resilience` | Type export for fallback attempt. | `interface FallbackAttempt` |
| `FallbackResolution` | type | advanced | `@solvera/pace-core/resilience` | Type export for fallback resolution. | `interface FallbackResolution` |
| `FallbackSource` | type | advanced | `@solvera/pace-core/resilience` | Type export for fallback source. | `interface FallbackSource` |
| `ResilienceError` | type | advanced | `@solvera/pace-core/resilience` | Type export for resilience error. | `interface ResilienceError` |

## `@solvera/pace-core/services`

Declaration source: `dist/services/index.d.ts`

### Runtime exports

_None._

### Type exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `EventsClientLike` | type | advanced | `@solvera/pace-core/services` | Type export for events client like. | `interface EventsClientLike` |
| `EventServiceOptions` | type | advanced | `@solvera/pace-core/services` | Options type for event service. | `interface EventServiceOptions` |
| `IEventService` | type | advanced | `@solvera/pace-core/services` | Type export for ievent service. | `interface IEventService` |
| `IInactivityService` | type | advanced | `@solvera/pace-core/services` | Type export for iinactivity service. | `interface IInactivityService` |
| `InactivityServiceSource` | type | advanced | `@solvera/pace-core/services` | Type export for inactivity service source. | `interface InactivityServiceSource` |
| `IOrganisationService` | type | advanced | `@solvera/pace-core/services` | Type export for iorganisation service. | `interface IOrganisationService` |

## `@solvera/pace-core/support`

Declaration source: `dist/support/index.d.ts`

### Runtime exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `APP_SUPPORT_REQUEST_FUNCTION_NAME` | constant | advanced | `@solvera/pace-core/support` | Constant value for app support request function name. | `const APP_SUPPORT_REQUEST_FUNCTION_NAME: "app-support-request"` |
| `collectSupportDiagnostics` | function | advanced | `@solvera/pace-core/support` | Function for collect support diagnostics. | `collectSupportDiagnostics(input?: CollectSupportDiagnosticsInput): SupportClientDiagnostics` |
| `formatSupportDiagnosticsPreview` | function | advanced | `@solvera/pace-core/support` | Function for format support diagnostics preview. | `formatSupportDiagnosticsPreview(input: FormatSupportDiagnosticsPreviewInput): SupportDiagnosticsPreviewRow[]` |
| `getSupportFormSchema` | function | advanced | `@solvera/pace-core/support` | Function for get support form schema. | `getSupportFormSchema(isAuthenticated: boolean): z.ZodObject<{ subject: z.ZodString; message: z.ZodString; }, z.core.$strip>` |
| `PRIVACY_POLICY_MARKDOWN` | constant | advanced | `@solvera/pace-core/support` | Constant value for privacy policy markdown. | `const PRIVACY_POLICY_MARKDOWN: "## Privacy policy\n\nThis Privacy Policy explains how Solvera Solutions Pty Ltd (ABN 53 688 130 234) collects, uses, and protects your per...` |
| `PrivacyPolicyContent` | component | advanced | `@solvera/pace-core/support` | UI component for privacy policy content. | `PrivacyPolicyContent({ markdown }: { markdown: string; }): JSX.Element` |
| `renderPrivacyPolicyMarkdown` | function | advanced | `@solvera/pace-core/support` | Function for render privacy policy markdown. | `renderPrivacyPolicyMarkdown(markdown: string): ReactNode[]` |
| `submitSupportRequest` | function | advanced | `@solvera/pace-core/support` | Function for submit support request. | `submitSupportRequest(supabase: SupabaseClientWithFunctions \| null, payload: SupportRequestPayload): Promise<ApiResult<SupportRequestResult>>` |
| `SUPPORT_MESSAGE_MAX` | constant | advanced | `@solvera/pace-core/support` | Constant value for support message max. | `const SUPPORT_MESSAGE_MAX: 5000` |
| `SUPPORT_SUBJECT_MAX` | constant | advanced | `@solvera/pace-core/support` | Constant value for support subject max. | `const SUPPORT_SUBJECT_MAX: 200` |
| `supportFormSchemaAnonymous` | constant | advanced | `@solvera/pace-core/support` | Constant value for support form schema anonymous. | `const supportFormSchemaAnonymous: z.ZodObject<{ subject: z.ZodString; message: z.ZodString; name: z.ZodString; email: z.ZodString; }, z.core.$strip>` |
| `supportFormSchemaAuthenticated` | constant | advanced | `@solvera/pace-core/support` | Constant value for support form schema authenticated. | `const supportFormSchemaAuthenticated: z.ZodObject<{ subject: z.ZodString; message: z.ZodString; }, z.core.$strip>` |

### Type exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `CollectSupportDiagnosticsInput` | type | advanced | `@solvera/pace-core/support` | Type export for collect support diagnostics input. | `interface CollectSupportDiagnosticsInput` |
| `FormatSupportDiagnosticsPreviewInput` | type | advanced | `@solvera/pace-core/support` | Type export for format support diagnostics preview input. | `interface FormatSupportDiagnosticsPreviewInput` |
| `SupportClientDiagnostics` | type | advanced | `@solvera/pace-core/support` | Type export for support client diagnostics. | `interface SupportClientDiagnostics` |
| `SupportDiagnosticsPreviewRow` | type | advanced | `@solvera/pace-core/support` | Type export for support diagnostics preview row. | `interface SupportDiagnosticsPreviewRow` |
| `SupportFormValuesAnonymous` | type | advanced | `@solvera/pace-core/support` | Type export for support form values anonymous. | `type SupportFormValuesAnonymous` |
| `SupportFormValuesAuthenticated` | type | advanced | `@solvera/pace-core/support` | Type export for support form values authenticated. | `type SupportFormValuesAuthenticated` |
| `SupportRequestPayload` | type | advanced | `@solvera/pace-core/support` | Type export for support request payload. | `interface SupportRequestPayload` |
| `SupportRequestResult` | type | advanced | `@solvera/pace-core/support` | Result type for support request. | `interface SupportRequestResult` |

## `@solvera/pace-core/theming`

Declaration source: `dist/theming/index.d.ts`

### Runtime exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `applyPalette` | function | advanced | `@solvera/pace-core/theming` | Function for apply palette. | `applyPalette(paletteData: PaletteData): void` |
| `clearPalette` | function | advanced | `@solvera/pace-core/theming` | Function for clear palette. | `clearPalette(): void` |
| `generateSSRThemeCSS` | function | advanced | `@solvera/pace-core/theming` | Function for generate ssrtheme css. | `generateSSRThemeCSS(paletteData: PaletteData): string` |
| `getCurrentThemeData` | function | advanced | `@solvera/pace-core/theming` | Function for get current theme data. | `getCurrentThemeData(): Record<string, string>` |
| `getPaletteFromEvent` | function | advanced | `@solvera/pace-core/theming` | Function for get palette from event. | `getPaletteFromEvent(event: EventReadModel \| { [key: string]: unknown; } \| null \| undefined): PaletteData \| null` |
| `getPaletteFromOrganisation` | function | advanced | `@solvera/pace-core/theming` | Function for get palette from organisation. | `getPaletteFromOrganisation(organisation: { settings?: Record<string, unknown>; } \| null \| undefined): PaletteData \| null` |
| `isDynamicThemingActive` | function | advanced | `@solvera/pace-core/theming` | Function for is dynamic theming active. | `isDynamicThemingActive(): boolean` |
| `PALETTE_SHADES` | constant | advanced | `@solvera/pace-core/theming` | Constant value for palette shades. | `const PALETTE_SHADES: readonly ["raw", "50", "100", "200", "300", "400", "500", "600", "700", "800", "900", "950"]` |

### Type exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `ApplyPaletteOptions` | type | advanced | `@solvera/pace-core/theming` | Options type for apply palette. | `interface ApplyPaletteOptions` |
| `PaletteData` | type | advanced | `@solvera/pace-core/theming` | Type export for palette data. | `interface PaletteData` |
| `PaletteShade` | type | advanced | `@solvera/pace-core/theming` | Type export for palette shade. | `type PaletteShade` |
| `PaletteShades` | type | advanced | `@solvera/pace-core/theming` | Type export for palette shades. | `interface PaletteShades` |

## `@solvera/pace-core/types`

Declaration source: `dist/types/index.d.ts`

### Runtime exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `assertAppId` | function | advanced | `@solvera/pace-core/types` | Function for assert app id. | `assertAppId(id: unknown): asserts id is AppId` |
| `assertEventId` | function | advanced | `@solvera/pace-core/types` | Function for assert event id. | `assertEventId(id: unknown): asserts id is EventId` |
| `assertOrganisationId` | function | advanced | `@solvera/pace-core/types` | Function for assert organisation id. | `assertOrganisationId(id: unknown): asserts id is OrganisationId` |
| `assertPageId` | function | advanced | `@solvera/pace-core/types` | Function for assert page id. | `assertPageId(id: unknown): asserts id is PageId` |
| `assertUserId` | function | advanced | `@solvera/pace-core/types` | Function for assert user id. | `assertUserId(id: unknown): asserts id is UserId` |
| `AUTH_ERROR_CODES` | constant | advanced | `@solvera/pace-core/types` | Constant value for auth error codes. | `const AUTH_ERROR_CODES: readonly ["invalid_credentials", "session_expired", "user_not_found", "email_not_confirmed", "invalid_token", "signup_disabled", "weak_pass...` |
| `createAppId` | function | advanced | `@solvera/pace-core/types` | Function for create app id. | `createAppId(id: string): AppId` |
| `createErrorResult` | function | advanced | `@solvera/pace-core/types` | Function for create error result. | `createErrorResult(code: string, message: string, details?: object): ApiResult<never>` |
| `createEventId` | function | advanced | `@solvera/pace-core/types` | Function for create event id. | `createEventId(id: string): EventId` |
| `createOrganisationId` | function | advanced | `@solvera/pace-core/types` | Function for create organisation id. | `createOrganisationId(id: string): OrganisationId` |
| `createPageId` | function | advanced | `@solvera/pace-core/types` | Function for create page id. | `createPageId(id: string): PageId` |
| `createSuccessResult` | function | advanced | `@solvera/pace-core/types` | Function for create success result. | `createSuccessResult<T>(data: T): ApiResult<T>` |
| `createUserId` | function | advanced | `@solvera/pace-core/types` | Function for create user id. | `createUserId(id: string): UserId` |
| `err` | function | advanced | `@solvera/pace-core/types` | Function for err. | `err(error: ApiError): ApiResult<never>` |
| `isAppId` | function | advanced | `@solvera/pace-core/types` | Function for is app id. | `isAppId(value: unknown): value is AppId` |
| `isAuthErrorCode` | function | advanced | `@solvera/pace-core/types` | Function for is auth error code. | `isAuthErrorCode(code: unknown): code is AuthErrorCode` |
| `isErr` | function | advanced | `@solvera/pace-core/types` | Function for is err. | `isErr<T>(result: ApiResult<T>): result is { ok: false; error: ApiError; }` |
| `isEventId` | function | advanced | `@solvera/pace-core/types` | Function for is event id. | `isEventId(value: unknown): value is EventId` |
| `isOk` | function | advanced | `@solvera/pace-core/types` | Function for is ok. | `isOk<T>(result: ApiResult<T>): result is { ok: true; data: T; }` |
| `isOrganisationId` | function | advanced | `@solvera/pace-core/types` | Function for is organisation id. | `isOrganisationId(value: unknown): value is OrganisationId` |
| `isPageId` | function | advanced | `@solvera/pace-core/types` | Function for is page id. | `isPageId(value: unknown): value is PageId` |
| `isSession` | function | advanced | `@solvera/pace-core/types` | Function for is session. | `isSession(obj: unknown): obj is Session` |
| `isUser` | function | advanced | `@solvera/pace-core/types` | Function for is user. | `isUser(obj: unknown): obj is User` |
| `isUserId` | function | advanced | `@solvera/pace-core/types` | Function for is user id. | `isUserId(value: unknown): value is UserId` |
| `normalizeToApiError` | function | advanced | `@solvera/pace-core/types` | Function for normalize to api error. | `normalizeToApiError(error: unknown, defaultCode?: string, defaultMessage?: string): ApiError` |
| `ok` | function | advanced | `@solvera/pace-core/types` | Function for ok. | `ok<T>(data: T): ApiResult<T>` |

### Type exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `ApiError` | type | advanced | `@solvera/pace-core/types` | Type export for api error. | `type ApiError` |
| `ApiResult` | type | advanced | `@solvera/pace-core/types` | Result type for api. | `type ApiResult` |
| `AppId` | type | advanced | `@solvera/pace-core/types` | Type export for app id. | `type AppId` |
| `AuthErrorCode` | type | advanced | `@solvera/pace-core/types` | Type export for auth error code. | `type AuthErrorCode` |
| `EventId` | type | advanced | `@solvera/pace-core/types` | Type export for event id. | `type EventId` |
| `EventStub` | type | advanced | `@solvera/pace-core/types` | Type export for event stub. | `interface EventStub` |
| `FileMetadata` | type | advanced | `@solvera/pace-core/types` | Type export for file metadata. | `interface FileMetadata` |
| `FileReference` | type | advanced | `@solvera/pace-core/types` | Type export for file reference. | `interface FileReference` |
| `FileUploadOptions` | type | advanced | `@solvera/pace-core/types` | Options type for file upload. | `interface FileUploadOptions` |
| `FileUploadResult` | type | advanced | `@solvera/pace-core/types` | Result type for file upload. | `interface FileUploadResult` |
| `InactivityWarningRenderProps` | type | advanced | `@solvera/pace-core/types` | Props type for inactivity warning render. | `interface InactivityWarningRenderProps` |
| `LoginRecord` | type | advanced | `@solvera/pace-core/types` | Type export for login record. | `interface LoginRecord` |
| `Organisation` | type | advanced | `@solvera/pace-core/types` | Type export for organisation. | `interface Organisation` |
| `OrganisationContextMethods` | type | advanced | `@solvera/pace-core/types` | Type export for organisation context methods. | `interface OrganisationContextMethods` |
| `OrganisationContextState` | type | advanced | `@solvera/pace-core/types` | Type export for organisation context state. | `interface OrganisationContextState` |
| `OrganisationContextType` | type | advanced | `@solvera/pace-core/types` | Type export for organisation context type. | `type OrganisationContextType` |
| `OrganisationId` | type | advanced | `@solvera/pace-core/types` | Type export for organisation id. | `type OrganisationId` |
| `OrganisationMembership` | type | advanced | `@solvera/pace-core/types` | Type export for organisation membership. | `interface OrganisationMembership` |
| `OrganisationMembershipRole` | type | advanced | `@solvera/pace-core/types` | Type export for organisation membership role. | `type OrganisationMembershipRole` |
| `OrganisationServiceProviderProps` | type | advanced | `@solvera/pace-core/types` | Props type for organisation service provider. | `interface OrganisationServiceProviderProps` |
| `OrganisationStats` | type | advanced | `@solvera/pace-core/types` | Type export for organisation stats. | `interface OrganisationStats` |
| `OrganisationStatsRole` | type | advanced | `@solvera/pace-core/types` | Type export for organisation stats role. | `type OrganisationStatsRole` |
| `PageId` | type | advanced | `@solvera/pace-core/types` | Type export for page id. | `type PageId` |
| `PublicEvent` | type | advanced | `@solvera/pace-core/types` | Type export for public event. | `interface PublicEvent` |
| `PublicPageContextValue` | type | advanced | `@solvera/pace-core/types` | Type export for public page context value. | `interface PublicPageContextValue` |
| `RecordLoginPayload` | type | advanced | `@solvera/pace-core/types` | Type export for record login payload. | `interface RecordLoginPayload` |
| `Session` | type | advanced | `@solvera/pace-core/types` | Type export for session. | `interface Session` |
| `SessionRestorationState` | type | advanced | `@solvera/pace-core/types` | Type export for session restoration state. | `interface SessionRestorationState` |
| `SystemStatsData` | type | advanced | `@solvera/pace-core/types` | Type export for system stats data. | `interface SystemStatsData` |
| `UnifiedAuthContextType` | type | advanced | `@solvera/pace-core/types` | Type export for unified auth context type. | `type UnifiedAuthContextType` |
| `UnifiedAuthContextValue` | type | advanced | `@solvera/pace-core/types` | Type export for unified auth context value. | `type UnifiedAuthContextValue` |
| `UnifiedAuthProviderProps` | type | advanced | `@solvera/pace-core/types` | Props type for unified auth provider. | `type UnifiedAuthProviderProps` |
| `UseLoginHistoryFilters` | type | advanced | `@solvera/pace-core/types` | Type export for use login history filters. | `interface UseLoginHistoryFilters` |
| `User` | type | advanced | `@solvera/pace-core/types` | Type export for user. | `interface User` |
| `UserId` | type | advanced | `@solvera/pace-core/types` | Type export for user id. | `type UserId` |
| `UserProfile` | type | advanced | `@solvera/pace-core/types` | Type export for user profile. | `interface UserProfile` |
| `UsersByRole` | type | advanced | `@solvera/pace-core/types` | Type export for users by role. | `interface UsersByRole` |
| `UserStats` | type | advanced | `@solvera/pace-core/types` | Type export for user stats. | `interface UserStats` |

## `@solvera/pace-core/utils`

Declaration source: `dist/utils/index.d.ts`

### Runtime exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `appPublicLogoPath` | function | advanced | `@solvera/pace-core/utils` | Function for app public logo path. | `appPublicLogoPath(appName: string, variant: AppPublicLogoVariant): string` |
| `buildCanonicalStoragePath` | function | advanced | `@solvera/pace-core/utils` | Function for build canonical storage path. | `buildCanonicalStoragePath(input: CanonicalStoragePathInput): string` |
| `buildStorageObjectName` | function | advanced | `@solvera/pace-core/utils` | Function for build storage object name. | `buildStorageObjectName(inputFileName: string, objectId?: string): string` |
| `buildStoragePath` | function | advanced | `@solvera/pace-core/utils` | Function for build storage path. | `buildStoragePath(options: Pick<FileUploadOptions, "organisation_id" \| "event_id" \| "table_name" \| "record_id">, fileName: string): string` |
| `changePasswordSchema` | constant | advanced | `@solvera/pace-core/utils` | Constant value for change password schema. | `const changePasswordSchema: z.ZodObject<{ currentPassword: z.ZodString; newPassword: z.ZodString; confirmPassword: z.ZodString; }, z.core.$strip>` |
| `cn` | function | advanced | `@solvera/pace-core/utils` | Function for cn. | `cn(...inputs: ClassValue[]): string` |
| `contactFormSchema` | constant | advanced | `@solvera/pace-core/utils` | Constant value for contact form schema. | `const contactFormSchema: z.ZodObject<{ name: z.ZodString; email: z.ZodString; message: z.ZodString; }, z.core.$strip>` |
| `createLogger` | function | advanced | `@solvera/pace-core/utils` | Function for create logger. | `createLogger(component: string): Logger` |
| `dateSchema` | constant | advanced | `@solvera/pace-core/utils` | Constant value for date schema. | `const dateSchema: z.ZodCoercedDate<unknown>` |
| `deriveEventInitials` | function | advanced | `@solvera/pace-core/utils` | Function for derive event initials. | `deriveEventInitials(code: string \| null, name: string): string` |
| `emailSchema` | constant | advanced | `@solvera/pace-core/utils` | Constant value for email schema. | `const emailSchema: z.ZodString` |
| `formatCompactNumber` | function | advanced | `@solvera/pace-core/utils` | Function for format compact number. | `formatCompactNumber(value: number, locale?: string): string` |
| `formatCurrency` | function | advanced | `@solvera/pace-core/utils` | Function for format currency. | `formatCurrency(value: number, currencyCode?: string, locale?: string): string` |
| `formatDate` | function | advanced | `@solvera/pace-core/utils` | Function for format date. | `formatDate(date: Date \| string \| number): string` |
| `formatDateTime` | function | advanced | `@solvera/pace-core/utils` | Function for format date time. | `formatDateTime(date: Date \| string \| number): string` |
| `formatEventCardMetaDate` | function | advanced | `@solvera/pace-core/utils` | Function for format event card meta date. | `formatEventCardMetaDate(dateStr: string \| null \| undefined): string \| undefined` |
| `formatFileSize` | function | advanced | `@solvera/pace-core/utils` | Function for format file size. | `formatFileSize(bytes: number): string` |
| `formatInTimeZone` | function | advanced | `@solvera/pace-core/utils` | Function for format in time zone. | `formatInTimeZone(date: Date \| string \| number, timeZone: string, formatStr: string): string` |
| `formatNumber` | function | advanced | `@solvera/pace-core/utils` | Function for format number. | `formatNumber(value: number, options?: FormatNumberOptions, locale?: string): string` |
| `formatPercent` | function | advanced | `@solvera/pace-core/utils` | Function for format percent. | `formatPercent(value: number, locale?: string, options?: Intl.NumberFormatOptions): string` |
| `formatTime` | function | advanced | `@solvera/pace-core/utils` | Function for format time. | `formatTime(date: Date \| string \| number): string` |
| `formatTimezoneLabel` | function | advanced | `@solvera/pace-core/utils` | Function for format timezone label. | `formatTimezoneLabel(timeZone: string, locale?: string): string` |
| `fromZonedTime` | function | advanced | `@solvera/pace-core/utils` | Function for from zoned time. | `fromZonedTime(localDate: Date, timezone: string): Date` |
| `generateStorageObjectId` | function | advanced | `@solvera/pace-core/utils` | Function for generate storage object id. | `generateStorageObjectId(): string` |
| `getUserTimeZone` | function | advanced | `@solvera/pace-core/utils` | Function for get user time zone. | `getUserTimeZone(): string` |
| `HandleMutationError` | function | advanced | `@solvera/pace-core/utils` | Function for handle mutation error. | `HandleMutationError(error: unknown, context: string, toast?: ToastFn): SupabaseErrorResult` |
| `HandleSupabaseError` | function | advanced | `@solvera/pace-core/utils` | Function for handle supabase error. | `HandleSupabaseError(error: unknown, context: string, toast?: ToastFn): SupabaseErrorResult` |
| `isNavItemActive` | function | advanced | `@solvera/pace-core/utils` | Function for is nav item active. | `isNavItemActive(href: string \| undefined, pathname: string, allHrefs: string[]): boolean` |
| `loginSchema` | constant | advanced | `@solvera/pace-core/utils` | Constant value for login schema. | `const loginSchema: z.ZodObject<{ email: z.ZodString; password: z.ZodString; }, z.core.$strip>` |
| `LogLevel` | enum | advanced | `@solvera/pace-core/utils` | Enum export for log level. | `enum LogLevel` |
| `MAX_PRIMARY_NAV_ITEMS` | constant | advanced | `@solvera/pace-core/utils` | Constant value for max primary nav items. | `const MAX_PRIMARY_NAV_ITEMS: 5` |
| `nameSchema` | constant | advanced | `@solvera/pace-core/utils` | Constant value for name schema. | `const nameSchema: z.ZodString` |
| `normaliseFileUploadOptions` | function | advanced | `@solvera/pace-core/utils` | Function for normalise file upload options. | `normaliseFileUploadOptions(options: Partial<FileUploadOptions> & Pick<FileUploadOptions, "bucket" \| "table_name" \| "record_id" \| "organisation_id" \| "event_id" \| "app_id" \| "category">): FileUploadOptions` |
| `NormalizeSupabaseError` | function | advanced | `@solvera/pace-core/utils` | Function for normalize supabase error. | `NormalizeSupabaseError(error: unknown, defaultMessage?: string): SupabaseErrorResult` |
| `passwordResetSchema` | constant | advanced | `@solvera/pace-core/utils` | Constant value for password reset schema. | `const passwordResetSchema: z.ZodObject<{ email: z.ZodString; }, z.core.$strip>` |
| `passwordSchema` | constant | advanced | `@solvera/pace-core/utils` | Constant value for password schema. | `const passwordSchema: z.ZodString` |
| `phoneSchema` | constant | advanced | `@solvera/pace-core/utils` | Constant value for phone schema. | `const phoneSchema: z.ZodUnion<[z.ZodOptional<z.ZodString>, z.ZodLiteral<"">]>` |
| `queryErrorHandler` | function | advanced | `@solvera/pace-core/utils` | Function for query error handler. | `queryErrorHandler(error: unknown, context: string, toast?: ToastFn): void` |
| `QueryRetryHandler` | function | advanced | `@solvera/pace-core/utils` | Function for query retry handler. | `QueryRetryHandler(failureCount: number, error: unknown): boolean` |
| `registrationSchema` | constant | advanced | `@solvera/pace-core/utils` | Constant value for registration schema. | `const registrationSchema: z.ZodObject<{ email: z.ZodString; password: z.ZodString; full_name: z.ZodOptional<z.ZodString>; }, z.core.$strip>` |
| `sanitizeFormData` | function | advanced | `@solvera/pace-core/utils` | Function for sanitize form data. | `sanitizeFormData<T extends Record<string, unknown>>(data: T): T` |
| `sanitizeHtml` | function | advanced | `@solvera/pace-core/utils` | Function for sanitize html. | `sanitizeHtml(html: string): string` |
| `sanitizeUserInput` | function | advanced | `@solvera/pace-core/utils` | Function for sanitize user input. | `sanitizeUserInput(input: string): string` |
| `secureLoginSchema` | constant | advanced | `@solvera/pace-core/utils` | Constant value for secure login schema. | `const secureLoginSchema: z.ZodObject<{ email: z.ZodString; password: z.ZodString; }, z.core.$strip>` |
| `securePasswordSchema` | constant | advanced | `@solvera/pace-core/utils` | Constant value for secure password schema. | `const securePasswordSchema: z.ZodString` |
| `setLoggerConfig` | function | advanced | `@solvera/pace-core/utils` | Function for set logger config. | `setLoggerConfig(config: Partial<LoggerConfig>): void` |
| `ShowSuccessMessage` | function | advanced | `@solvera/pace-core/utils` | Function for show success message. | `ShowSuccessMessage(message: string, toast?: ToastFn): void` |
| `slicePrimaryNavItems` | function | advanced | `@solvera/pace-core/utils` | Function for slice primary nav items. | `slicePrimaryNavItems<T>(items: T[]): T[]` |
| `toEventDateBadgeProps` | function | advanced | `@solvera/pace-core/utils` | Function for to event date badge props. | `toEventDateBadgeProps(dateStr: string \| null \| undefined): EventDateBadgeProps \| undefined` |
| `toEventDateIso` | function | advanced | `@solvera/pace-core/utils` | Function for to event date iso. | `toEventDateIso(dateStr: string \| null \| undefined): string \| undefined` |
| `toZonedTime` | function | advanced | `@solvera/pace-core/utils` | Function for to zoned time. | `toZonedTime(date: Date, timezone: string): Date` |
| `updateEventLogoPointer` | function | advanced | `@solvera/pace-core/utils` | Function for update event logo pointer. | `updateEventLogoPointer({ client, eventId, fileReferenceId, }: UpdateEventLogoPointerParams): Promise<void>` |
| `updateOrganisationLogoPointer` | function | advanced | `@solvera/pace-core/utils` | Function for update organisation logo pointer. | `updateOrganisationLogoPointer({ client, organisationId, fileReferenceId, }: UpdateOrganisationLogoPointerParams): Promise<void>` |
| `uploadFile` | function | advanced | `@solvera/pace-core/utils` | Function for upload file. | `uploadFile(params: UploadFileParams): Promise<FileUploadResult>` |
| `urlSchema` | constant | advanced | `@solvera/pace-core/utils` | Constant value for url schema. | `const urlSchema: z.ZodUnion<[z.ZodOptional<z.ZodString>, z.ZodLiteral<"">]>` |
| `userProfileSchema` | constant | advanced | `@solvera/pace-core/utils` | Constant value for user profile schema. | `const userProfileSchema: z.ZodObject<{ id: z.ZodString; email: z.ZodString; full_name: z.ZodOptional<z.ZodString>; created_at: z.ZodOptional<z.ZodString>; updated_a...` |
| `z` | function | advanced | `@solvera/pace-core/utils` | Function for z. | `z: typeof zod` |

### Type exports

| Export | Kind | Stability | Preferred import path | Description | Signature / props surface |
|---|---|---|---|---|---|
| `AppPublicLogoVariant` | type | advanced | `@solvera/pace-core/utils` | Type export for app public logo variant. | `type AppPublicLogoVariant` |
| `CanonicalStoragePathInput` | type | advanced | `@solvera/pace-core/utils` | Type export for canonical storage path input. | `interface CanonicalStoragePathInput` |
| `ChangePasswordFormValues` | type | advanced | `@solvera/pace-core/utils` | Type export for change password form values. | `type ChangePasswordFormValues` |
| `EventDateBadgeProps` | type | advanced | `@solvera/pace-core/utils` | Props type for event date badge. | `interface EventDateBadgeProps` |
| `FormatNumberOptions` | type | advanced | `@solvera/pace-core/utils` | Options type for format number. | `interface FormatNumberOptions` |
| `Logger` | type | advanced | `@solvera/pace-core/utils` | Type export for logger. | `interface Logger` |
| `LoggerConfig` | type | advanced | `@solvera/pace-core/utils` | Type export for logger config. | `interface LoggerConfig` |
| `LoginFormValues` | type | advanced | `@solvera/pace-core/utils` | Type export for login form values. | `type LoginFormValues` |
| `RegistrationFormValues` | type | advanced | `@solvera/pace-core/utils` | Type export for registration form values. | `type RegistrationFormValues` |
| `StorageBucket` | type | advanced | `@solvera/pace-core/utils` | Type export for storage bucket. | `interface StorageBucket` |
| `StorageUploadResult` | type | advanced | `@solvera/pace-core/utils` | Result type for storage upload. | `interface StorageUploadResult` |
| `SupabaseClientLike` | type | advanced | `@solvera/pace-core/utils` | Type export for supabase client like. | `interface SupabaseClientLike` |
| `SupabaseErrorResult` | type | advanced | `@solvera/pace-core/utils` | Result type for supabase error. | `type SupabaseErrorResult` |
| `ToastFn` | type | advanced | `@solvera/pace-core/utils` | Type export for toast fn. | `type ToastFn` |
| `UploadFileParams` | type | advanced | `@solvera/pace-core/utils` | Type export for upload file params. | `interface UploadFileParams` |
| `UserProfileFormValues` | type | advanced | `@solvera/pace-core/utils` | Type export for user profile form values. | `type UserProfileFormValues` |
