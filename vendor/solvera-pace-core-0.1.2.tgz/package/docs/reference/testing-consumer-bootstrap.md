# Testing consumer bootstrap

Step-by-step guide for adopting the pace-core **tiered Vitest test pattern** in a consuming app. Canonical requirements live in [Standard 8 — Testing & Documentation](../standards/8-testing-documentation-standards.md).

---

## Why tiered tests?

| Tier | Command | Environment | When to use |
|------|---------|-------------|-------------|
| Unit | `npm run test:unit` | `node` | Pure logic — utils, services, RBAC helpers (~seconds) |
| Integration | `npm run test:integration` | `happy-dom` | Components, providers, user flows |
| Full + coverage | `npm run test:coverage` | Both (via `environmentMatchGlobs`) | CI and `npm run validate` |

The pattern avoids paying DOM/React startup cost on every `.test.ts` file.

---

## 1. Scaffold config and setup files

From your consuming app root (after `@solvera/pace-core` is installed):

```bash
npm run setup -- --force
```

This copies templates from `@solvera/pace-core/templates/testing/` when missing (or overwrites scaffold files with `--force`):

**Root**

- `vitest.shared.ts` — shared includes, aliases, coverage, runtime options
- `vitest.config.ts` — full suite (`node` + `environmentMatchGlobs`)
- `vitest.unit.config.ts` — fast unit tier
- `vitest.integration.config.ts` — DOM tier

**Vitest config loader:** Each `vitest*.config.ts` **must** include top-level `configLoader: 'runner'` (see Standard 8). Add `**/*config*.timestamp-*.mjs` to `.gitignore`.

**`src/`**

- `test-setup.ts` — jest-dom, cleanup, React act flag
- `test-setup-unit.ts` — polyfills only
- `test-polyfills.ts` — in-memory `localStorage` / `sessionStorage`
- `test-utils.ts` — `setupUser()` helper

Setup also merges tier scripts into `package.json` and adds devDependencies (`happy-dom`, `@vitest/coverage-v8`, `@testing-library/jest-dom`, etc.) when absent.

---

## 2. Migrate existing tests

### File naming

| Pattern | Environment | Use for |
|---------|-------------|---------|
| `*.test.ts` | `node` | Pure logic |
| `*.test.tsx` | `happy-dom` | Component render tests |
| `*.integration.test.ts(x)` | `happy-dom` | Multi-component / provider flows |

### Hook tests in `.test.ts` that need DOM

If a file must stay as `.test.ts` but uses `renderHook` or DOM APIs, add its path to `domUnitTestTsFiles` in `vitest.shared.ts`:

```typescript
export const domUnitTestTsFiles: string[] = [
  'src/hooks/useMyHook.test.ts',
];
```

Otherwise rename to `.test.tsx` or `.integration.test.tsx`.

### Fast user interactions

Replace:

```typescript
const user = userEvent.setup();
```

With:

```typescript
import { setupUser } from '@test-utils';

const user = setupUser();
```

ESLint (`pace-core-compliance/prefer-setup-user`) and the Standard 8 audit enforce this.

---

## 3. Verify locally

```bash
npm run test:unit          # fast unit feedback
npm run test:integration   # DOM/component tests only
npm run test:coverage      # full suite + thresholds (validate gate)
npm run validate           # includes pace-core audit (Standard 8 errors)
```

Quick drift check without full audit:

```bash
node node_modules/@solvera/pace-core/scripts/check-vitest-test-pattern.cjs
```

Optional `package.json` script:

```json
"check:vitest-pattern": "node node_modules/@solvera/pace-core/scripts/check-vitest-test-pattern.cjs"
```

---

## 4. Enforcement layers

| Layer | What it checks |
|-------|----------------|
| **Standard 8 doc** | Source of truth for file list, scripts, naming |
| **`npm run setup`** | Scaffolds templates and scripts |
| **ESLint** | `prefer-setup-user`, `test-file-naming` |
| **Audit (validate)** | Tier scripts, env split, setup files, `vitest.shared.ts`, `happy-dom`, DOM-in-wrong-tier |

Audit issue types: `testTierScripts`, `vitestEnvironmentSplit`, `testSetupFiles`, `vitestSharedModule`, `happyDomDependency`, `preferSetupUser`, `domInWrongTier`.

---

## Monorepo note

If your repo contains both `@solvera/pace-core` and a demo app (like pace-core2), the **demo app root** uses the single-package templates above. The pace-core **package** directory (`packages/core`) is audited separately and skips consuming-app tier checks.

---

## Troubleshooting

| Symptom | Fix |
|---------|-----|
| Audit: missing `test:unit` | Re-run `npm run setup` or add scripts manually (see Standard 8) |
| Audit: `domInWrongTier` | Rename test to `.test.tsx` or add to `domUnitTestTsFiles` |
| ESLint: `prefer-setup-user` | Use `setupUser()` from `@test-utils` |
| Tests hang on typing | Ensure `setupUser()` (not bare `userEvent.setup()`) |
| Node 26 storage errors | Ensure `src/test-polyfills.ts` is loaded via setup files |

---

**See also:** [8-testing-documentation-standards.md](../standards/8-testing-documentation-standards.md)
