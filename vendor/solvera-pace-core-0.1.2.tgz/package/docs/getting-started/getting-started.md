# Getting started

Use this page as the single entrypoint for consuming-app setup guardrails and consumer API discovery.

## Standards and guardrails

The standards (SDLC order) are the source of truth:

| # | Standard | Location |
|---|----------|----------|
| 0 | Overview | `../standards/0-standards-overview.md` |
| 1 | Project structure | `../standards/1-project-structure-standards.md` |
| 2 | Architecture | `../standards/2-architecture-standards.md` |
| 3 | Security & RBAC | `../standards/3-security-rbac-standards.md` |
| 4 | API & tech stack | `../standards/4-api-tech-stack-standards.md` |
| 5 | pace-core compliance | `../standards/5-pace-core-compliance-standards.md` |
| 6 | Code quality | `../standards/6-code-quality-standards.md` |
| 7 | Visual | `../standards/7-visual-standards.md` |
| 8 | Testing & documentation | `../standards/8-testing-documentation-standards.md` |
| 9 | Operations | `../standards/9-operations-standards.md` |

In consuming apps, read these from:

- `node_modules/@solvera/pace-core/docs/standards/`

### Cursor rules and ESLint config

- Cursor rules are supplied by the package. Run `npm run setup` to create authoritative symlinks in `.cursor/rules/`.
- ESLint config and rules are supplied by the package. `npm run setup` wires the consuming app to `@solvera/pace-core/eslint-config`.
- Audit tool and validate script are required parts of the quality pipeline; use managed package scripts.

### Order of application

1. Project shell: use setup + standards + guardrails + Cursor rules + ESLint config to create and wire the app shell and validation pipeline.
2. Feature work: use one requirements doc at a time, plus standards/guardrails/rules, then run `npm run validate`.

Rule: no feature implementation without a requirements doc.

### Definition of done

For shell setup and each feature slice:

- `npm run validate` passes.
- Audit/lint findings are fixed at source (do not silence tools).
- Code complies with standards and requirement contract.

### Quick reference for AI agents

- Read Standards 0 first, then task-specific standards.
- Implement directly from requirements docs; do not copy from legacy code.
- Do not create or migrate schema unless explicitly required by the requirement contract.

## Consumer export index

Use the generated consumer API index as the single reference for what `@solvera/pace-core` exposes to consuming apps.

### Open the index

- [Consumer exports index](../reference/consumer-exports-index.md)

### What it includes

- All public package entrypoints from `@solvera/pace-core` `package.json` `exports`.
- Runtime exports and type exports for each entrypoint.
- Signature-level details for functions, hooks, components, providers, constants, and types.

### Keep it up to date

Regenerate after changing public exports:

```bash
npm run docs:exports-index
```

Run from repo root or from `packages/core`.
