# Visual Standards (Standard 07)

**🤖 Cursor Rule**: See [07-styling.mdc](../../packages/core/cursor-rules/07-styling.mdc) for AI-optimized directives that automatically enforce markup quality (this rule is ALWAYS APPLIED).

**🔧 ESLint:** Rule IDs, messages, and behaviour are defined in [`packages/core/eslint-rules/rules/05-styling.cjs`](../../packages/core/eslint-rules/rules/05-styling.cjs) — not duplicated here.

## Purpose

This standard is the single source of truth for **styling infrastructure** and **suite-wide visual rules** across the PACE suite. It defines:

- **Part A — Styling platform and consumption:** How `app.css` must be wired (Tailwind v4, `@source`, palettes, imports). The **canonical file** is the template; this part stays short.
- **Part B — Markup and structural constraints:** Semantic HTML, layout discipline, typography policy, and token usage that apply to pace-core and all consuming applications.
- **Part C — Global visual language:** Shared size groups, **UI attribute taxonomy**, elevation, focus, semantic colour roles, and layout patterns that apply across components.

**Component-level layout, variants, and class recipes** belong in the **Visual specification** section of the relevant [feature requirement](../requirements/0_REQUIREMENTS-TEMPLATE.md) (e.g. R05a Button/Card, R06 login and Toast, R05c app shell, R08 ContextSelector). Those docs are the contract for “how this component looks”; this standard is the contract for platform setup and global coherence.

Adhering to this standard ensures:

- pace-core components render with correct styles
- Colours, typography, and spacing stay consistent suite-wide
- Tailwind v4 content scanning works properly
- Agents and humans use this document for **platform CSS** and **global** visual rules; **per-component** appearance is specified in feature requirements (**Visual specification**)

---

## How each layer enforces this standard

- **Standards (this doc):** Parts A–C — platform, markup, global visual language. Component appearance: requirement **Visual specification** sections.
- **Cursor rule:** `07-styling.mdc` — ALWAYS APPLIED; AI guidance when editing `src/**/*.{ts,tsx,js,jsx}`; points to this doc and [`docs/templates/app.css`](../templates/app.css).
- **ESLint:** [`05-styling.cjs`](../../packages/core/eslint-rules/rules/05-styling.cjs) under plugin prefix `pace-core-compliance/` — authoritative list of rules and messages.
- **Audit tool:** Standard 7 audit runs as part of `npm run validate`; checks `app.css` against the expected shape (see template), `@source`, `@theme` palettes, and Tailwind v4 in `vite.config`. Report: `audit/<timestamp>-pace-core-audit.md`. For pace-core development, run `npm run validate` from the repository root.

See [**Enforcement reference**](#enforcement-reference) for a precise mapping of standard sections to tools.

---

## Enforcement reference {#enforcement-reference}

| Standard | Mechanical enforcement |
|----------|-------------------------|
| **Part A** — [`#part-a-styling-platform`](#part-a-styling-platform) | **Audit** (`packages/core/audit-tool/audits/05-styling.cjs`): `app.css` presence, `@import "tailwindcss"`, package `core.css` import (not `/src/styles/`), `@source` for app + pace-core, `@theme static`, main/sec/acc palette completeness, optional JS entry check for duplicate `core.css` import; Vite + `@tailwindcss/vite`. |
| **Part B** — [`#part-b-markup`](#part-b-markup) | **ESLint** (`pace-core-compliance/*` in `05-styling.cjs`): no inline `style`, typography/colour/spacing on semantic text elements, no flex layout utilities in `className`, no legacy Tailwind palette utilities, semantic HTML hints, no redundant same-type nesting, no ad-hoc `className` on pace-core components (consuming apps only; pace-core package paths excluded). |
| **Part C** — [`#part-c-global-visual`](#part-c-global-visual) | **Cursor rule** + **human review**; size groups, elevation, and roles are specified here for implementers. **ESLint** covers token usage indirectly via legacy colour ban; exact variant recipes stay in requirement **Visual specification** docs. |

Rule IDs and severity are configured in [`eslint-config-pace-core.cjs`](../../packages/core/eslint-config-pace-core.cjs) (consuming apps that extend the preset).

---

## Audit issue types and where to read

| Audit issue type | Where to fix |
|------------------|--------------|
| appCss | Part A — compare to [`docs/templates/app.css`](../templates/app.css); run `npm run validate` |
| tailwindConfig | Part A — Tailwind v4 / Vite setup; audit report links |

---

## Document outline

| Part | Anchor | Contents |
|------|--------|----------|
| A | [#part-a-styling-platform](#part-a-styling-platform) | Canonical `app.css` template, must-satisfy list, validate |
| B | [#part-b-markup](#part-b-markup) | Semantic markup, layout (grid, no flex), component principles, typography and token rules |
| C | [#part-c-global-visual](#part-c-global-visual) | UI taxonomy, size groups, canonical rules, elevation, focus, semantic colour roles, theming |

---

## Part A — Styling platform and consumption {#part-a-styling-platform}

pace-core expects a **Tailwind v4 CSS-first** entry in the consuming app. If `@source` scanning, `core.css`, or palettes are wrong, components will look broken.

### Two layers

1. **`@solvera/pace-core/styles/core.css`** — Package foundation (fonts, resets, typography, shared component styles, suite layout tokens). Loaded **through** app CSS, not double-imported from every JS entry.
2. **`src/app.css`** (typical path) — `@import "tailwindcss"`, `@source` globs, `@import` of `core.css`, and `@theme static` for **main**, **sec**, and **acc**.

### Canonical file

**Copy and adjust once:** [`docs/templates/app.css`](../templates/app.css) → your app’s `src/app.css` (or keep the same depth to `node_modules`).

That file is the **reference implementation**. All `@source` paths are **relative to the CSS file**; if you move `app.css`, update the path to `node_modules/@solvera/pace-core`.
It also includes the canonical `pace-background` helper class and palette-comment pattern (purpose + base hue) used for app-level theming clarity.

### Must satisfy

- `@import "tailwindcss";` first.
- `@source` includes your app’s sources and pace-core package sources (see template).
- `@import "@solvera/pace-core/styles/core.css";` — package path only (not `.../src/styles/...` inside the package).
- `core.css` hosts suite-wide tokens and shared/global styles only. Do not place one-off component layout math or single-instance constants in `core.css`.
- `@theme static` defines **main**, **sec**, and **acc** with **50–950** and **`-raw`** for each.
- Keep short palette comments in `app.css` that describe each palette family purpose and base hue so runtime theming and audits are easier to review.
- `core.css` includes an `@theme inline` semantic token mapping block (e.g. `--color-border`, `--color-background`, `--color-foreground`) that exposes semantic Tailwind utilities.
- Bullet mask SVG tokens (`--bullet-mask-*`) are declared in `core.css` `@theme`; component requirements (CR29, CR30, …) document which `bullet-*` utility each component uses.
- JS entry imports **`./app.css` only** (do not also import `core.css` from `main.tsx`).
- Extra entry points (Storybook, tests): same rule — one `app.css` graph per React surface; never `app.css` + `core.css` both from JS for the same tree.
- If your app uses a page-level background utility on `body`, use `pace-background`. The template ships a default diagonal gradient, and apps may replace it with any app-specific background implementation.

### CSS naming

- Entry stylesheets: **`app.css`**, **`core.css`** (lowercase fixed names; audits expect these paths).
- Custom CSS classes and custom properties: **kebab-case** (e.g. `pace-background`, `--color-main-500`, `--print-event-name`). Aligns with Tailwind v4 theme tokens in `@theme` / `@theme inline`.
- Do not introduce snake_case or PascalCase in new custom class or variable names. Standard 7 still restricts **who** may edit CSS (agents/consuming apps follow the no-edit policy); naming applies to pace-core templates and maintainers.

### Verify

Run **`npm run validate`** from the repo root and fix **Standard 7 / appCss** items in `audit/<timestamp>-pace-core-audit.md`. Compare a failing app to the template line-for-line before debugging ad hoc.

---

## Part B — Markup and structural constraints {#part-b-markup}

### Component and markup guidance

- Components should be stateless when possible, fully typed, and accessibility-first.
- Prefer semantic HTML elements (`<main>`, `<section>`, `<article>`, `<nav>`, `<header>`, `<footer>`, etc.) and React Fragments for grouping. Never use `<div>` as a layout utility wrapper, and avoid redundant wrappers even if they are semantic elements such as `<section>`.
- Native semantic/browser primitives are first preference when they satisfy the component contract (for example `<dialog>` for modals and `<output>` for user-facing status output such as toasts) before introducing custom wrapper markup or JavaScript-managed overlays.
- A document should expose only one visible `<main>` landmark. When a layout component already renders the page-level `<main>` (for example `PaceAppLayout`), nested route/page components must not render another `<main>` and should use `<section>`, `<article>`, or fragments instead.
- Never add wrapper elements for styling—use React Fragments or apply layout classes to existing semantic parents or pace-core layout components.
- In Card composition slots (`CardHeader`, `CardContent`, `CardFooter`), apply layout classes directly to the slot subcomponent and avoid single-child layout-only wrappers.
- No inline styles; rely on pace-core variants and Tailwind utilities (layout/spacing) using theme tokens only.
- **No arbitrary Tailwind colours**—use `main-*`, `sec-*`, `acc-*` (or semantic tokens like `text-foreground`) only.
- **Minimise use of arbitrary values**—avoid bracket syntax (e.g. `w-[137px]`) where a theme token or standard utility exists.
- Apply layout utilities to existing semantic parents or pace-core layout components.

### Layout

Use **grid** or **native HTML flow** for layouts; **do not use flex** (no `display: flex`, no Tailwind `flex`, `flex-row`, `flex-col`, `flex-wrap`, etc.). This keeps layout predictable and avoids unnecessary complexity.

- **inline / inline-block** — Simple single-row layouts (e.g. a row of labels or small controls).
- **Standard HTML flow** — Basic single-column layouts; block elements stack naturally.
- **Grid** — Advanced single-column or single-row control (e.g. `grid-template-columns`, `grid-template-rows`) and all multi-row / multi-column layouts.

There is no need to introduce flex when flow + inline + grid cover the same cases with simpler, more predictable markup and styling.

- **WRONG:** `className="flex items-center gap-2"`, `className="flex flex-col"`, or any `flex*` utilities.
- **CORRECT:** `className="grid grid-cols-[auto_1fr] gap-2"`, `className="contents"` with grid on parent, or inline-block / normal flow as above.

### Component principles

- Stateless when possible; keep surface area small and composable.
- Accessible by default with correct roles, keyboard support, and visible focus.
- UI primitives only; never add domain logic or data fetching inside components.
- Support controlled + uncontrolled usage where applicable.

### Testing expectations

- Use React Testing Library + userEvent.
- Test key interactions; snapshots only for simple components.
- Keep components small—move non-UI logic to hooks/services.

### Styling and markup rules

- **No inline styles:** Do not use `style={{ ... }}` except when a third-party library strictly requires it. Prefer pace-core variants + Tailwind utilities.
- **Use theme tokens only:** No arbitrary Tailwind colours—use `main-*`, `sec-*`, `acc-*`, or semantic tokens like `text-foreground` only. Minimise use of arbitrary values (bracket syntax such as `bg-[oklch(...)]` or `w-[137px]`); use theme tokens or standard utilities where possible.
- **Semantic-first markup:** Use semantic HTML elements or React fragments by default. `<div>` is acceptable only for unavoidable layout utility grouping where no semantic element applies; keep usage minimal and intentional.
- **Native-first behaviour:** Prefer semantic elements that include native browser behaviour (`<dialog>`, `<output>`, popover primitives) before building equivalent behaviour with additional wrapper nodes and JavaScript state branches.
- **Single `<main>` landmark:** Keep one visible `<main>` per document. If shell/layout already provides `<main>`, child pages must use sectioning/content roots, not a second `<main>`.
- **Page-owned shell main layout metadata:** In shell-routed pages, declare page-specific shell main metadata from the page file via `usePaceMain` (including layout classes and print metadata such as `printTitle` / `printPageOrientation`); do not move page layout/print metadata ownership into central route config solely to style/configure the shell `<main>`.
- **Never add wrapper elements:** Do not add extra elements just for styling—apply layout classes to existing semantic parents or use pace-core layout components.
- **Card slot wrapper minimisation:** If a Card slot (`CardHeader`, `CardContent`, `CardFooter`) has one child whose only purpose is layout classes, remove that child and move layout classes to the Card slot itself.
- **Card slot surface inheritance:** `CardHeader`, `CardContent`, and `CardFooter` must not set background utilities. The parent `Card` owns the panel surface (`bg-main-100` at layer 0); slots inherit it and carry layout/padding only.
- **Directory card grids:** Multi-column browse, launcher, and KPI card grids use `<section className="grid …">`, not `<ul>` or `<ol>`. Grid children must be the card surface (`Card` with `fill`, or `CardGrid` / `CardGridItem` per [CR05a-directory-card-grid](../requirements/CR05a-directory-card-grid.md)). Navigational cards wrap `<Card fill>` in a link with `className="contents no-underline"` or use `CardGridItem`. Event directory grids follow the same contract via [CR29](../requirements/CR29-event-tile.md).
- **Variant implementation markup discipline:** Do not use `group-data-[variant=...]` class patterns (or equivalent data-attribute variant hooks) as the default way to style component variants. Prefer explicit variant class maps in component logic so rendered markup does not require extra styling-only state attributes.
- **Form label structure:** Prefer nested form controls inside `Label` (`<Label>Text<Input ... /></Label>`) so association is explicit in markup. Use `htmlFor`/`id` only when label and control cannot be nested.
- **Input hints:** Input fields should include concise, helpful placeholder text that tells users what is expected (placeholder supports the label and does not replace it).
- **Select empty hints:** When a select has no value, it should show explicit context-specific hint text (for example via `SelectValue placeholder="..."`).
- **Persistence action label contract:** For persistence/edit flows, the primary submit action label must be exactly `Save`. Labels such as `Submit`, `Save changes`, or `Update` are not allowed for this contract.
- **Persistence action placement contract:** In card and dialog compositions, persistence actions belong in `CardFooter` or `DialogFooter` and must render in the bottom-right action area using grid/flow layout classes on the footer slot itself.
- **Persistence action ordering contract:** When multiple actions exist in persistence flows, order actions right-to-left as primary `Save`, then `Cancel`, then alternate actions.
- **Persistence label exceptions:** Keep intent-specific labels for non-persistence actions (for example `Delete`, `Approve`, `Publish`, `Send`).
- **Typography:** Never add text styling overrides on semantic elements (`h1`–`h6`, `p`, `a`, `label`, etc.). Rely on pace-core typography in `core.css`. Exceptions MUST be documented in the feature requirement **Visual specification** (e.g. login card header in [R06 – Forms and feedback](../requirements/implemented/R06-forms-and-feedback.md)) and implemented inside pace-core, not at arbitrary app call sites.
- **Layout:** Use grid or native HTML flow only; do not use flex. Prefer inline/inline-block for simple single rows, normal flow for basic single column, and grid for advanced or multi-axis layouts.

---

## Part C — Global visual language {#part-c-global-visual}

### Audience

- **pace-core:** Implements globals in `core.css` and component styles; **class-level recipes and variants** for each shipped component live in that feature’s requirement **Visual specification** (not in this standard).
- **Consuming apps:** Keep `app.css` and palettes per Part A; for custom pages or surfaces, use the same **size groups**, **elevation**, and **semantic colour roles** as Part C so the suite stays visually aligned. Do not override pace-core component styles at call sites except where Standard 05 documents allowed patterns.

### Styling hierarchy

1. **`core.css`** — Baseline typography, resets, and shared presentation.
2. **pace-core component styles** — Variant and structure for each primitive (implemented in the package).
3. **Instance overrides** — Only when necessary, inside the component implementation or with a documented comment; consuming apps avoid ad-hoc `className` overrides on pace-core components (see Standard 05).

### Consumer style override policy

To preserve suite-wide visual consistency, pace-core uses a constrained override model:

- **Default:** exported components should not provide unrestricted style override points.
- **Allowlist only:** free-form instance style hooks (for example `className`) are permitted only on documented layout/container components.
- **Strict primitives:** must favor built-in variants/tokens over external style composition.
- **Governance:** the allowlist is part of the public API contract and is enforced by export governance checks.

### Suite layout width token

- `--app-width` is a suite token defined in `core.css` and fixed at `90rem`.
- Consuming apps should not redefine `--app-width` in app-level CSS.

### Typography and hierarchy

Heading and body hierarchy for semantic elements is defined in **`core.css`**. Do not apply `text-*`, `font-*`, `leading-*`, `tracking-*`, or colour utilities to those elements unless a requirement’s **Visual specification** explicitly documents an exception implemented inside pace-core.

### Semantic colour roles {#semantic-colour-roles}

Use design tokens only (`main-*`, `sec-*`, `acc-*`, and semantic tokens such as `background`, `foreground`, `card`, `card-foreground`, `ring`, `border`). These semantic tokens are defined in `core.css` (`@theme inline`, including `--color-border` in the semantic token mapping block) and are available through Tailwind utilities such as `border-border`. Typical roles:

| Role | Guidance |
|------|----------|
| Primary action | Strong emphasis for default primary control (e.g. `main-800` / `main-50` text) |
| Destructive / danger | Harmful or irreversible actions (e.g. `acc-*` family for destructive emphasis) |
| Secondary / muted surface | Supporting surfaces (e.g. `sec-100`, `sec-900` text) |
| Card / layout panel surface | Card and dialog panel backgrounds use explicit palette (`bg-main-100`, `text-main-950`) per component Visual specification |
| Borders | Subtle separation (e.g. `main-300`, `border-border`) |
| Layout panel border | Default panel border for Dialog/Toast surfaces at rest uses global `--color-border` via Tailwind `border-border`; Card layer 0 uses resting `border-main-300` and hover `border-border` when linked (see [§ Layout panel hover affordance](#layout-panel-hover-affordance)); nested Card layers 1–2 per CR05a |
| Muted text | Supplementary copy (e.g. `text-muted-foreground` where defined) |

Default UI element border behaviour: interactive controls and table cells should default to semantic border token usage (`border-border`, mapped from `--color-border`) unless a requirement Visual specification explicitly documents an exception.

Exact class combinations for each **component variant** belong in the requirement **Visual specification**, not duplicated here.

### Elevation and shadow scale {#elevation-and-shadow}

Use a small, consistent set of shadows:

| Level | Typical use | Tailwind (indicative) |
|-------|-------------|------------------------|
| None | Flat controls, ghost buttons, **Card at rest** (border allowed; no shadow) | (no shadow) |
| Low | Resting inputs, subtle panels | `shadow-sm` |
| Medium | Raised controls | `shadow` |
| High | Dialog panel, Toast, prominent overlays; **linked Card on hover** | `shadow-lg` |

Choose levels per component in **Visual specification**; stay consistent within a size group.

### Focus, disabled, and interaction

- **Focus visible:** Use `focus-visible:outline-none` with `focus-visible:ring-1` (or as specified for the component) and `focus-visible:ring-ring` unless a requirement specifies otherwise.
- **Disabled:** `disabled:pointer-events-none` and `disabled:opacity-50` are the default pattern for interactive primitives.

### Layout panel hover affordance {#layout-panel-hover-affordance}

Static layout panels (primarily **Card**) use a resting border at rest. **Hover elevation** (stronger border and `shadow-lg`) is an **interactivity affordance for linked Cards only** (`link` prop set per CR05a); non-linked Cards remain static with no hover elevation. Composed components that wrap `Card` (for example **EventCard** per [CR29](../requirements/CR29-event-card.md)) inherit the same linked hover affordance when their `link` prop is set. Composed list-row panels (**AttentionItem** per [CR30](../requirements/CR30-attention-queue.md)) use the same layer-0 resting border and linked hover elevation affordance as Card when `link` or row activation (`onClick`) is set. New pace-core UI component names follow [Project Structure — pace-core UI component names](../standards/1-project-structure-standards.md#pace-core-ui-component-names) (`Card` for large card-like surfaces, `Badge` for small display-only elements, native-element names for interactive controls). Card layer 0 typical linked pattern: resting `border border-main-300`, no shadow; hover `hover:border-border hover:shadow-lg` with `transition-[box-shadow,border-color]`. Card supports optional nesting **layers** (0–2 implemented); per-layer surface, border, and radius recipes live in CR05a. Framed data tables use **Table `layer` surfaces** aligned to the same Card layer hierarchy with a **`border-separate`, decentralized cell frame** (caption top border box when present; edge cells own side borders and band/body backgrounds; footer or last tbody row corner cells own bottom radius on the same element as their background); exact recipes live in CR05a / CR07. Table does **not** inherit Card hover elevation unless explicitly documented later. Modal dialog panels and transient Toast surfaces keep always-on border and elevation at rest — see each component **Visual specification**.

### Global size groups {#global-size-groups}

UI controls and containers align to **three size groups** so radius, padding, and shadow stay consistent:

| Group | Radius | Border / density | Shadow | Typical fixed height (controls) |
|-------|--------|-------------------|--------|----------------------------------|
| **Small** | `rounded-md` | `border`, compact horizontal/vertical padding | None | e.g. `h-8` |
| **Medium** (default) | `rounded-md` | Standard padding (e.g. `px-4 py-2`) | Optional `shadow-sm` | e.g. `h-9` |
| **Large** | `rounded-2xl` | Generous padding (`p-4` / `p-6`) | `shadow-lg` where appropriate (linked Card: shadow on hover only) | e.g. `h-10` |

### UI element attribute taxonomy {#ui-element-attribute-taxonomy}

For each interactive or container **size** and **variant**, pace-core SHOULD record and keep consistent in the **requirement Visual specification** for that component: **border radius**, **border** width/style, **shadow** (elevation), **padding** / **margin**, **width** / **min-height** / **fixed height**, **text alignment** (only where not covered by `core.css` typography), and **font size/weight** only where an explicit exception is documented in that requirement. Prefer global **size groups** ([§ Global size groups](#global-size-groups)) over one-off values.

### Canonical styling rules by size group {#canonical-styling-rules-by-size-group}

When building or reviewing UI components, apply **Tailwind v4 utilities bound to theme tokens** only:

- **Small:** `rounded-md`, `border`, compact padding (`px-2` / `px-3`, `py-1` / `py-2`), **no** shadow unless an exception is documented in **Visual specification**.
- **Medium:** `rounded-md`, `px-4 py-2`, optional `shadow-sm`, fixed height `h-9` where a control has a fixed height.
- **Large:** `rounded-2xl`, `p-4` or `p-6`, `shadow-lg` for elevated surfaces where specified (linked Card uses shadow on hover only per [§ Layout panel hover affordance](#layout-panel-hover-affordance)).

Interactive components (Button, Input, etc.) should pick one group per **size** prop and stay coherent with adjacent elements on the same row or card.

- **Medium row-control radius parity:** Button, Input, Textarea, and Select trigger share the same corner radius (`rounded-xl`) when placed in shared toolbars or action rows. Exact class recipes live in [CR05a](../requirements/CR05a-primitives.md) and [CR05b](../requirements/CR05b-dialog-select-tabs.md) Visual specification.

### Width defaults

- **Inputs and text entry controls:** Default to `w-full` so they fill their container width; expose `className` so consumers can intentionally override width for special layouts.
- **Input placeholders:** Use meaningful placeholder hints in field usage (examples: `Enter email address`, `Type organisation name`), while keeping labels as the primary accessible field descriptor.
- **Select placeholders:** Provide explicit, purpose-oriented empty-state hints for each select usage instead of relying on generic fallback text.
- **Select trigger/content join:** When a select popover is visually connected to its trigger, use a shared pattern (trigger removes bottom radius while open, content has zero top radius, and no vertical gap) and keep exact class recipes in the component requirement Visual specification.
- **Select options container semantics:** For pace-core Select components, the options list parent should use `<menu role="listbox">` and option rows should continue to expose option semantics (for example `role="option"` with selection state attributes).
- **Overlay positioning primitives:** For dropdown and popover surfaces, prefer native browser overlay behaviour with Popover API and CSS Anchor Positioning instead of JavaScript coordinate calculations.
- **Overflow fallback positioning:** When an anchored overlay may collide with viewport edges, define a `position-try` strategy so the browser can automatically choose an alternate placement.
- **Toast surface semantics:** Toast message items should use semantic `<output>` roots (with explicit live-region attributes when required for announcement reliability) instead of generic wrapper elements.
- **Buttons:** Buttons should size to content by default.

### Modal dialog panel sizing {#modal-dialog-panel-sizing}

Modal dialogs should grow to fit content by default, with viewport safety caps and transform-free centering.

- **Canonical modal recipe (Tailwind utilities only):** `fixed inset-0 m-auto h-fit w-fit max-w-[90vw] max-h-[90vh] overflow-auto`
  - `fixed inset-0 m-auto` centers the panel in the viewport without transform offsets.
  - `h-fit w-fit` keeps panel size tied to content.
  - `max-w-[90vw]` caps dialog width at viewport width.
  - `max-h-[90vh]` and `overflow-auto` keep dialogs usable when content is tall.
- **Implementing components in pace-core:** use this recipe as the default in `DialogContent` ([`Dialog.tsx`](../../packages/core/src/components/Dialog.tsx)). Consuming apps should inherit this behavior and only override modal width when a requirement explicitly documents the exception.
- **Native modal primitive:** `DialogContent` should render native `<dialog>` and use the native modal lifecycle (`showModal()` / `close()`) and close/cancel events as the primary interaction contract.
- **Backdrop rendering:** Use native `<dialog>::backdrop` styling behaviour for modal backdrops instead of adding dedicated backdrop `<div>` siblings.
- **Default modal placement:** Prefer native `<dialog>` modal placement from `showModal()` for centered placement. Avoid transform-based centering (`left-1/2`, `top-1/2`, `-translate-x-1/2`, `-translate-y-1/2`) unless a feature requirement explicitly documents and justifies an exception.
- **Modal layering:** For native modal dialogs opened with `showModal()`, avoid using `z-*` classes as the primary layering mechanism; browser top-layer behaviour is the default layering contract.
- **Anchored overlay compatibility:** Dialog placement choices should preserve compatibility with browser-managed anchored overlays (for example Select popovers using Popover API + CSS Anchor Positioning) rendered inside dialog content.

The login form card is not a modal dialog panel and keeps its requirement-defined width contract in [R06 – Forms and feedback](../requirements/implemented/R06-forms-and-feedback.md).

### Layout patterns for appearance

- **Full-viewport centring:** e.g. `min-h-screen` with grid `place-items-center` or `content-center` + `justify-items-center` and vertical gap between blocks — concrete login layout is in [R06 – Forms and feedback](../requirements/implemented/R06-forms-and-feedback.md) (**Visual specification**). Page background (e.g. `pace-background` on `body`) comes from the consuming app; see R06.
- **Content width:** For app-wide max content width (e.g. reading columns), prefer documented utilities or, when justified by many call sites, a suite token in `@theme` documented in Part A. Modal dialog panels MUST follow [§ Modal dialog panel sizing](#modal-dialog-panel-sizing) and login card sizing MUST follow its requirement contract (R06), not ad hoc one-off width tokens.
- **Shell structure:** For app-shell header markup, prefer a lean structure: full-width `<header>` containing a centered `<nav>` constrained by `--app-width`, with direct nav children for shell regions. Primary navigation uses inline link pills at `lg` and above (see CR05c); compact Select below `lg`.

### Theme and CSS changes (governance) {#theme-and-css-changes-governance}

New **`@theme` variables** or **custom `@layer utilities` classes** in package or app CSS are **not** the default way to share a single size or numeric rule.

- Prefer **documented Tailwind utilities in component code** and, for components, the **Visual specification** in the relevant requirement.
- Keep styling ownership component-first and Tailwind-first. Do not introduce simple alias utility classes in `core.css` when equivalent utility classes can be written directly at the component call site.
- Add new theme tokens or shared utility classes only when the value is already used, or is clearly intended for use, **across dozens of call sites** in the same sense (palette colours and shared complex rendering effects are primary examples).
- Such additions require **explicit approval from a human developer** — not tooling-only or AI-only refactors. Until approved, keep the recipe in standards/requirements and component `className` strings.
- Coding agents must never create, edit, or delete CSS files anywhere in the PACE suite (including `app.css`, `core.css`, or any new `.css` file).
- Rationale: an extra CSS layer must earn a **clear multiplier**; one-off widths for one or two components should remain **documented classes in components**, not new package utility aliases.
- For component effects that cannot be expressed cleanly with standard utilities, prefer existing shared theme utilities already defined in `core.css` over introducing new one-off utility classes. Exact per-component usage remains documented in that component requirement Visual specification.


### Dynamic theming

Runtime palette overrides (e.g. event/org colours) apply the same token names as in `app.css` (`--color-main-*`, `--color-sec-*`, `--color-acc-*`). Behaviour, persistence contract, and API are specified in requirement **[R15 – Dynamic theming](../requirements/implemented/R15-dynamic-theming.md)**. Context-driven switching (org/event) MUST be wired per R15 together with shell and ContextSelector obligations in **[R05c – Layout and shell](../requirements/implemented/R05c-layout-and-shell.md)** and **[R08 – Advanced UI](../requirements/implemented/R08-advanced-ui.md)**. Visuals MUST still use only those tokens (no arbitrary colours).
For internal same-layout client-side route transitions, runtime palette variables should persist without transient reset. Full document loads (for example new-tab navigations) may rehydrate theme through normal app bootstrap/session-context flow.

---

## ESLint {#eslint}

Rules are implemented in **`packages/core/eslint-rules/rules/05-styling.cjs`** (plugin prefix `pace-core-compliance/`). That file is the **source of truth** for rule IDs, descriptions, messages, and scope. Structural styling rules apply to both pace-core package source and consuming app source; specific override-focused rules can retain narrower scope where documented in the rule implementation.

| Rule ID | Aligns with |
|---------|-------------|
| `no-inline-styles` | Part B — no inline styles |
| `no-typography-styling` | Part B / Part C — typography on semantic elements |
| `no-pace-core-style-override` | Part C — styling hierarchy; Standard 05 |
| `prefer-semantic-html` | Part B — semantic-first markup |
| `no-nested-same-type-tags` | Part B — structure |
| `no-redundant-card-subcomponent-wrapper` | Part B — no redundant wrapper elements around Card subcomponent content |
| `no-flex-layout-classes` | Part B — grid / flow only (no Tailwind `flex*`) |
| `no-legacy-tailwind-color-classes` | Part B / Part C — `main` / `sec` / `acc` (and semantic tokens) only |
| `persistence-save-label` | Part B — persistence primary submit action label is exactly `Save` |
| `persistence-save-placement` | Part B — persistence save actions must be in footer-right slot/action containers |
| `formfield-label-must-wrap-control` | Part B — nested Label/control association in FormField implementation |
| `login-form-hide-required-marker` | Requirement-aligned exception — login required fields hide asterisk markers |
| `no-directory-card-list-grid` | Part B — directory card grids use `section`, not `ul`/`ol` with column grids |

This standard describes intent; it does not duplicate rule messages.

---

## Related documentation

- [Standards Overview](./0-standards-overview.md) — Standards system overview
- [Requirements template](../requirements/0_REQUIREMENTS-TEMPLATE.md) — **Visual specification** for component-level class recipes and deltas
- [Project Structure](./1-project-structure-standards.md) — File organization standards
- [Architecture](./2-architecture-standards.md) — Component development standards
- [pace-core Compliance](./5-pace-core-compliance-standards.md) — Consumption patterns

---

**Last updated:** 2026-04-22  
**Version:** 3.5.0  
**Applies to:** pace-core and all consuming applications using `@solvera/pace-core`
