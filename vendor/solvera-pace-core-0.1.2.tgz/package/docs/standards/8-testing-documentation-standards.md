# Testing & Documentation Standards

**🤖 Cursor Rule**: See [08-testing-documentation.mdc](../cursor-rules/08-testing-documentation.mdc) for AI-optimized directives that automatically enforce testing and documentation standards.

**🔧 ESLint Rules**: See [08-testing.cjs](../../packages/core/eslint-rules/rules/08-testing.cjs) for mechanically checkable testing rules.

## Purpose

This standard defines testing strategies, documentation requirements, and issue reporting templates to ensure consistent quality, maintainability, and effective communication across pace-core and consuming apps.

---

## How each layer enforces this standard

- **Standards (this doc):** Source of truth; defines testing strategy (unit/integration/E2E), test structure and naming, testing tools (React Testing Library, userEvent, Vitest), test timeouts, coverage requirements, documentation requirements, and bug/feature request templates.
- **Cursor rule:** `08-testing-documentation.mdc` — AI guidance when editing test files (`**/*.{test,spec}.{ts,tsx}`) and docs (`**/*.md`, `**/*.mdx`); points to this doc.
- **ESLint:** Rules in `08-testing.cjs` (plugin prefix `pace-core-compliance/`): see ESLint Rules section below. Run via lint step in CI and locally.
- **Audit tool:** Standard 8 audit runs as part of `npm run validate`; checks test timeout configuration (vitest.config, package.json scripts), required testing tools (vitest, @testing-library/react, @testing-library/user-event), and test file structure/naming (.test vs .spec). Report: `audit/<timestamp>-pace-core-audit.md`. For pace-core development, run `npm run validate` from the repository root.

---

## Audit issue types and where to read

| Audit issue type | See section in this doc |
|------------------|--------------------------|
| testTimeout | Test Timeouts |
| testingTools | Testing Tools |
| testStructure | Test Structure; Test File Naming |
| coverageConfig | Coverage setup (Vitest) |
| testTierScripts | Test commands (tiered); Consuming app bootstrap checklist |
| vitestEnvironmentSplit | Vitest environment split (required) |
| testSetupFiles | Consuming app bootstrap checklist |
| vitestSharedModule | Consuming app bootstrap checklist |
| happyDomDependency | Vitest environment split (required) |
| preferSetupUser | Fast user interactions |
| domInWrongTier | Vitest environment split (required); domUnitTestTsFiles allowlist |

---

## Testing Strategy

### Test Types

**MUST** use this testing strategy:

- **Unit tests** - For utils & hooks (≥90% coverage)
- **Integration tests** - For components (≥70% coverage)
- **Few meaningful E2E tests** - In consuming apps only (critical user flows)

### Test Structure

**MUST** colocate tests with source files:

```
src/
├── components/
│   └── events/
│       ├── EventCard.tsx
│       └── EventCard.test.tsx        # ✅ Colocated
│
├── hooks/
│   ├── useEventData.ts
│   └── useEventData.test.ts           # ✅ Colocated
│
└── utils/
    ├── formatEvent.ts
    └── formatEvent.test.ts            # ✅ Colocated
```

### Test File Naming

- Unit tests: `*.test.ts` or `*.test.tsx`
- Integration tests: `*.integration.test.ts`
- E2E tests: Place in `tests/` directory

### pace-core package component authoring

Inside `packages/core/src/components/`:

- Every exported component `.tsx` **must** have a colocated `*.integration.test.tsx`.
- Colocated pure utilities (non-hook `.ts` files) **must** have `*.test.ts` at ≥90% coverage (`index.ts` and `types.ts` excluded; `use*.ts` hooks are covered via component integration tests).
- DOM component tests **must** use `*.integration.test.tsx` (not bare `*.test.tsx`).
- `npm run validate` runs `scripts/check-component-test-matrix.cjs` before type-check when validating `@solvera/pace-core`.

### Testing Tools

**MUST** use:

- **React Testing Library** - For component testing
- **userEvent** - For user interaction simulation (via `setupUser()` — see below)
- **Vitest** - For test runner
- **Avoid unnecessary mocks** - Prefer real implementations when possible

### Vitest environment split (required)

Consuming apps **MUST** separate pure unit tests (`node`) from DOM/component tests (`happy-dom`) using the tiered config pattern below. This keeps local feedback fast and prevents unnecessary DOM startup on logic-only tests.

#### Monorepo (pace-core2)

The repository root [`vitest.config.ts`](../../../vitest.config.ts) uses **`environment: 'node'`** for pure `*.test.ts` files and **`environmentMatchGlobs`** to run `*.test.tsx`, `*.integration.test.*`, and allowlisted hook `renderHook` tests in **happy-dom**. Shared settings live in [`vitest.shared.ts`](../../../vitest.shared.ts).

#### Consuming app (single-package)

Each consuming app **MUST** include:

| File | Purpose |
|------|---------|
| `vitest.shared.ts` | Shared includes, `@test-utils` alias, coverage, runtime options |
| `vitest.config.ts` | Full suite: `environment: 'node'` + `environmentMatchGlobs` |
| `vitest.unit.config.ts` | Fast unit tier (`node`, minimal setup) |
| `vitest.integration.config.ts` | DOM tier (`happy-dom`) |
| `src/test-setup.ts` | jest-dom, cleanup, React act flag, polyfills |
| `src/test-setup-unit.ts` | Polyfills only |
| `src/test-polyfills.ts` | In-memory web storage (Node 26+) |
| `src/test-utils.ts` | `setupUser()` helper and `settleAsyncUpdates()` for async effect flush |

Scaffold via `npm run setup -- --force` (copies from `@solvera/pace-core/templates/testing/`). See [testing-consumer-bootstrap.md](../reference/testing-consumer-bootstrap.md).

| Tier | Environment | Includes |
|------|-------------|----------|
| Unit | `node` | `*.test.ts`, `*.spec.ts` (pure logic) |
| DOM | `happy-dom` | `*.test.tsx`, `*.integration.test.*`, allowlisted hook `*.test.ts` using `renderHook` |

#### domUnitTestTsFiles allowlist

When a hook or utility test **must** remain `*.test.ts` but uses `renderHook`, `render`, or DOM APIs, add its path (relative to project root) to `domUnitTestTsFiles` in `vitest.shared.ts`. The audit reports `domInWrongTier` when a `.test.ts` file uses DOM APIs without being allowlisted.

### Consuming app bootstrap checklist

Before `npm run validate` passes in a consuming app, verify:

- [ ] Tier scripts exist: `test:unit`, `test:integration`, `test:coverage` (see [Test commands](#test-commands-tiered))
- [ ] All scaffold files from the table above exist
- [ ] `vitest.shared.ts` defines `@test-utils` → `src/test-utils.ts`
- [ ] `happy-dom` is in devDependencies
- [ ] Component/integration tests use `setupUser()` not bare `userEvent.setup()`
- [ ] DOM tests use `.test.tsx` / `.integration.test.*` unless allowlisted in `domUnitTestTsFiles`
- [ ] `configLoader: 'runner'` on all `vitest*.config.ts` files
- [ ] `.gitignore` includes `**/*config*.timestamp-*.mjs`

Quick check: `node node_modules/@solvera/pace-core/scripts/check-vitest-test-pattern.cjs`

### Vitest config loader (required)

TypeScript Vitest configs **MUST** set top-level **`configLoader: 'runner'`** on `vitest.config.ts`, `vitest.unit.config.ts`, and `vitest.integration.config.ts`. Requires Vite ≥ 6.1 (all suite apps use Vite 7–8).

Vitest’s default **`configLoader: 'bundle'`** writes ephemeral `*config*.timestamp-*.mjs` files to the repo root. Those bundles are not application source; when stale, `eslint .` reports false positives (`no-undef`, `no-unused-vars`).

```typescript
export default defineConfig({
  configLoader: 'runner',
  // ...
});
```

Scripts that spawn Vitest with `-c vitest.config.ts` inherit inline `configLoader` from that file. Do not pass `--configLoader=runner` on the Vitest 2.x CLI — that flag is not supported; inline config is sufficient.

Add **`**/*config*.timestamp-*.mjs`** to `.gitignore` as defense-in-depth for crash leftovers (shared ESLint config also ignores these paths).

Configs loaded with `runner` must be valid ESM — replace `__dirname` / `require()` with `import.meta.url` and `fileURLToPath` where needed.

### Fast user interactions

**MUST** use `setupUser()` from [`src/test-utils.ts`](../../../src/test-utils.ts) (Vitest alias `@test-utils`) instead of `userEvent.setup()` in component and integration tests. It wraps `userEvent.setup({ delay: null })` so typing delays do not slow coverage runs or cause timeouts under load.

```typescript
import { setupUser } from '@test-utils';

it('handles click', async () => {
  const user = setupUser();
  // ...
});
```

### React `act(...)` warnings (fail-fast)

`vitest.shared.ts` configures `onConsoleLog` so any stderr line matching `not wrapped in act` **fails the test run** immediately. This is intentional: integration and DOM-tier tests must flush async React updates with RTL patterns (`waitFor`, `findBy*`, `setupUser()`, `act` for unavoidable manual DOM focus/timer advances) rather than tolerating act warnings in CI output.

`IS_REACT_ACT_ENVIRONMENT = true` is set in `src/test-setup.ts`. Use `settleAsyncUpdates()` from `@test-utils` after renders that mount providers with async bootstrap (for example `UnifiedAuthProvider` session restoration).

```typescript
import { settleAsyncUpdates } from '@test-utils';

render(<Page />);
await settleAsyncUpdates();
await screen.findByRole('heading', { name: /title/i });
```

**Manual `act`:** Reserve for imperative callbacks outside RTL (auth subscription handlers, captured refs, fake timers). Prefer `await act(async () => { ... })` over sync `act(() => { ... })`.

**Expected `console.error` (ErrorBoundary):** Mock per test that intentionally throws — do not silence `console.error` globally in setup.

```typescript
beforeEach(() => {
  vi.spyOn(console, 'error').mockImplementation(() => {});
});
```

### Test commands (tiered)

| Script | Use when |
|--------|----------|
| `npm run test:unit` | Fast feedback on pure `.test.ts` logic (~seconds) |
| `npm run test:integration` | DOM/component/integration tests only |
| `npm run test` | Full suite, no coverage (~half minute locally) |
| `npm run test:watch` | Focused re-runs while editing |
| `npm run test:changed` | Pre-push check on files changed since `HEAD~1` |
| `npm run test:coverage` | Same as `test` plus v8 coverage thresholds (**used by `npm run validate`**) |

### Test Timeouts

**MUST** configure timeouts in `vitest.config.ts` for all test commands to prevent tests from hanging indefinitely. Do not rely on package.json script flags alone.

**Required configuration (in `vitest.config.ts`):**

```typescript
// vitest.config.ts
import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    testTimeout: 10000,        // 10 seconds per test
    hookTimeout: 10000,        // 10 seconds for hooks
    teardownTimeout: 5000,     // 5 seconds for cleanup
  },
});
```

**Timeout guidance:** Unit tests typically complete in &lt; 1 second; 10s is a safe default. For a single slow test, set a per-test timeout (e.g. `it('...', async () => { ... }, 15000)`). E2E or integration tests may use higher values (e.g. 30–60s) where appropriate.

### Example Test

```typescript
// src/components/events/EventCard.test.tsx
import { render, screen } from '@testing-library/react';
import { setupUser } from '@test-utils';
import { EventCard } from './EventCard';

describe('EventCard', () => {
  it('renders event title', () => {
    const event = { id: '1', name: 'Test Event', date: new Date() };
    render(<EventCard event={event} />);
    expect(screen.getByText('Test Event')).toBeInTheDocument();
  });

  it('handles click interaction', async () => {
    const user = setupUser();
    const handleClick = vi.fn();
    const event = { id: '1', name: 'Test Event', date: new Date() };
    
    render(<EventCard event={event} onClick={handleClick} />);
    await user.click(screen.getByRole('button'));
    
    expect(handleClick).toHaveBeenCalledTimes(1);
  });
});
```

### Test Coverage Requirements

- **Utils & Hooks**: ≥90% coverage (statement and line coverage)
- **Components**: ≥70% coverage (statement and line coverage)
- **Critical paths**: 100% coverage (authentication, payments, RBAC/permission checks, and any other security or money-related paths)

Coverage metrics apply to **the source code you own** and for which you enforce these thresholds—not dependencies (e.g. `node_modules`) or build output.

**By context:**

- **Library-only repo:** The code you own is the library source (e.g. `src/` or `packages/<name>/src/`). Configure coverage so the report includes only that.
- **Consuming app repo:** The code you own is the application source (e.g. `src/`). The same thresholds (utils/hooks ≥90%, components ≥70%, critical paths 100%) apply to that source.
- **Monorepo with both library and app:** You may hold both to the standard. Configure coverage so the report includes both (e.g. package source and app source); apply thresholds per glob or per-folder so library and app are each assessed. Example: the code you own might be `packages/core/src` and/or the app `src/`; configure `include`/`exclude` so the report reflects those.

**Exclusions (universal):** Always exclude from coverage collection and reporting: build output (`dist/`), tooling (`scripts/`, `audit-tool/` or equivalent), barrel/index-only files with no logic, and `node_modules`. Do not include dependency code in your aggregate.

**Which report:** Use the coverage report that includes only (or clearly segments) the code to which you apply the thresholds. That may be one combined report (e.g. package + app in one run) or separate runs per package/app; in either case, judge the overall percentage and thresholds against the code you own, not against dist, scripts, or dependencies.

**Coverage setup (Vitest)** — so the report includes only the source you own:

- **Put coverage under `test.coverage`** in `vitest.config.ts`. Vitest reads coverage options from `test.coverage`, not from a top-level `coverage` key.
- **Prefer provider `v8`** for day-to-day runs (`npm run test:coverage`, including **`npm run validate`**): it is faster than Istanbul while still respecting `include` / `exclude` when configured. Default reporters are **`text`** (terminal summary) and **`html`** (`coverage/index.html`). Use **`test:coverage:istanbul`** when you need Istanbul-specific reporting or JSON output.
- **`include`:** Only paths you own (e.g. `src/**`, or `packages/<name>/src/**` and `src/**` in a monorepo).
- **`exclude`:** Test files (`**/*.test.ts`, `**/*.integration.test.tsx`, etc.), `dist/`, `scripts/`, `audit-tool/` (or equivalent), `node_modules/`, barrel `index.ts` files, and entry points like `src/main.tsx`.

Example (monorepo with package + app, V8 + terminal and HTML reporters):

```typescript
// vitest.config.ts
export default defineConfig({
  test: {
    testTimeout: 10000,
    hookTimeout: 10000,
    teardownTimeout: 5000,
    coverage: {
      provider: 'v8',
      reporter: ['text', 'html'],
      include: ['packages/core/src/**/*.{ts,tsx}', 'src/**/*.{ts,tsx}'],
      exclude: [
        '**/*.test.{ts,tsx}', '**/*.integration.test.{ts,tsx}', '**/index.ts',
        'packages/core/audit-tool/**', 'packages/core/scripts/**', '**/dist/**', '**/node_modules/**', 'src/main.tsx',
      ],
      thresholds: { /* per-folder or per-glob */ },
    },
  },
});
```

For Istanbul and multi-format reports, use a dedicated script, for example: `vitest run -c vitest.config.ts --coverage --coverage.provider=istanbul --coverage.reporter=text --coverage.reporter=json --coverage.reporter=html`.

**Critical paths example (pace-core):** In the pace-core package, critical paths include auth (e.g. UnifiedAuthProvider, login flows) and RBAC (guards, useCan, useRBAC, ProtectedRoute, secure-client). Other repos will have their own critical paths (payments, app-specific auth, etc.). In pace-core2, `packages/core/src/rbac/secure-client.ts` and `packages/core/src/providers/UnifiedAuthProvider.tsx` are enforced at **100% statements, lines, and branches** via per-file Vitest thresholds in the repo-root `vitest.shared.ts` (`criticalPathCoverageThresholds`).

---

## Documentation

**Requirements docs are the primary documentation for features.** Each feature or slice is specified in a requirements doc (overview, acceptance criteria, API/contract, demo and testing requirements). That is enough for building and maintaining the app; no separate per-component or per-API doc is required unless stated below.

**When to add more:**
- **pace-core package**:
  - Requirements docs are maintained at repository root `docs/requirements/`.
  - Public API reference is maintained in `packages/core/docs/reference/` (legacy `docs/api-reference/` is acceptable if a repository still uses it).
  - Keep these updated so consuming apps can discover components, hooks, and utilities.
- **Non-obvious behavior**: Add short comments or a minimal doc when a decision or behavior would not be clear from the code or from the requirements doc alone (e.g. why a workaround exists, or a non-obvious contract).

### Public API reference governance

For pace-core major API changes, documentation must include:

- A generated export index that reflects the current declaration surface.
- Export metadata for consumer guidance (at minimum: stability tier and preferred import path).
- Migration documentation when exports/props are removed, moved, or reclassified.

Validation/CI should fail when generated API reference content is stale relative to declarations.

**Do not** enforce heavy documentation (e.g. mandatory Overview/API/Examples/A11y/Edge Cases for every component). Requirements docs plus clear code and types are the standard; supplement only where they add value.

---

## Bug Reports

### Bug Report Template

When a repository uses GitHub Issues (or an equivalent tracked issue workflow), use this template when reporting bugs:

```markdown
## Description
Clear description of the bug and expected vs actual behavior.

## Steps to Reproduce
1. Step one
2. Step two
3. Step three

## Minimal Reproduction
Link to CodeSandbox/StackBlitz or minimal code snippet that reproduces the issue.

## Environment
- pace-core version: X.X.X
- React version: X.X.X
- Node version: X.X.X
- Browser: Chrome/Firefox/Safari X.X
- OS: macOS/Windows/Linux

## Error Messages/Logs
```
Paste error messages or logs here
```

## Additional Context
Screenshots, videos, or other context that helps understand the issue.
```

### Bug Report Checklist

Before submitting a bug report (where issue tracking is in use), verify:

- [ ] Description clearly explains the issue
- [ ] Steps to reproduce are minimal and ordered
- [ ] Minimal reproduction provided (link or code)
- [ ] Environment information complete
- [ ] Error messages/logs included
- [ ] Additional context provided if helpful

---

## Feature Requests

### Feature Request Template

When a repository uses GitHub Issues (or an equivalent tracked issue workflow), use this template when requesting features:

```markdown
## Feature Description
Clear description of the feature and the problem it solves.

## Proposed Solution/API
Description of how the feature should work, including API design if applicable.

## Use Case
Real-world scenario where this feature would be useful.

## Alternatives Considered
Other approaches you've considered and why they don't work.

## Example Code
\`\`\`tsx
// Example of how the feature would be used
<NewComponent prop="value" />
\`\`\`

## Additional Context
Mockups, diagrams, or other context that helps understand the feature.
```

### Feature Request Checklist

Before submitting a feature request (where issue tracking is in use), verify:

- [ ] Feature description is clear
- [ ] Problem statement is well-defined
- [ ] Proposed solution/API is described
- [ ] Use case with real scenario provided
- [ ] Alternatives considered and documented
- [ ] Example code snippet included
- [ ] Additional context provided if helpful

---

## Testing Checklist

Before committing code with tests, verify:

- [ ] Tests colocated with source files
- [ ] Tiered Vitest configs and setup files present (see [testing-consumer-bootstrap.md](../reference/testing-consumer-bootstrap.md))
- [ ] `setupUser()` used instead of bare `userEvent.setup()`
- [ ] Unnecessary mocks avoided
- [ ] Coverage requirements met (≥90% utils/hooks, ≥70% components)
- [ ] Critical paths have 100% coverage
- [ ] Tests are meaningful and test behavior, not implementation

---

## Documentation Checklist

Before committing, verify:

- [ ] Feature or change is covered by a requirements doc (or existing doc is updated if behavior changed)
- [ ] For pace-core: public API reference (or equivalent) updated if you changed exported components/hooks/utils
- [ ] Non-obvious behavior has a short comment or note where it helps

---

## ESLint Rules

Rule IDs use the plugin prefix **`pace-core-compliance/`**. The following rule enforces testing standards:

- **`pace-core-compliance/test-file-naming`** — Enforce test file naming: `*.test.ts` or `*.test.tsx` (not `*.spec.ts`).
- **`pace-core-compliance/prefer-setup-user`** — Disallow bare `userEvent.setup()` in test files; use `setupUser()` from `@test-utils` (Standard 8 fast interactions).

This rule is part of the `pace-core-compliance` plugin and is enabled when extending `@solvera/pace-core/eslint-config`.

---

## Related Documentation

- [Standards Overview](./0-standards-overview.md) - Standards system overview
- [Code Quality](./6-code-quality-standards.md) - Code patterns and TypeScript
- [Architecture](./2-architecture-standards.md) - Component design principles

---

**Last Updated:** 2025-02-25  
**Version:** 2.0.0  
**Applies to:** All pace-core and consuming apps
