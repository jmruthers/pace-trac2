# API & Tech Stack Standards

**🤖 Cursor Rule**: See [04-api-tech-stack.mdc](../cursor-rules/04-api-tech-stack.mdc) for AI-optimized directives that automatically enforce tech stack compliance.

**🔧 ESLint Rules**: See [07-api-tech-stack.cjs](../../packages/core/eslint-rules/rules/07-api-tech-stack.cjs) for mechanically checkable API and tech stack rules.

## Purpose

This standard defines the required technology stack, API design patterns, and RPC conventions to ensure consistency, type safety, and maintainability across pace-core and consuming apps.

---

## How each layer enforces this standard

- **Standards (this doc):** Source of truth; defines required tech stack (React 19+, TypeScript, Vite, Tailwind v4, Supabase, TanStack Query, etc.), API/RPC naming (`data_*` / `app_*`), ApiResult shape, RPC rules, Vite/TypeScript config, and deprecation policy.
- **Cursor rule:** `04-api-tech-stack.mdc` — AI guidance when editing `src/**`, config files, and `supabase/migrations/**/*.sql`; points to this doc.
- **ESLint:** Rules in `07-api-tech-stack.cjs` (plugin prefix `pace-core-compliance/`): see ESLint Rules section below. Run via lint step in CI and locally.
- **Audit tool:** Standard 4 audit runs as part of `npm run validate`; checks RPC naming in SQL migrations, tech stack versions (package.json), and Vite configuration (optimizeDeps.exclude, resolve.dedupe). Report: `audit/<timestamp>-pace-core-audit.md`. For pace-core development, run `npm run validate` from the repository root.

---

## Audit issue types and where to read

| Audit issue type | See section in this doc |
|------------------|--------------------------|
| rpcNaming | API & RPC Naming Conventions; RPC Naming Pattern; Naming Rules |
| techStack | Required Tech Stack; Version Requirements |
| viteConfig | Tech Stack Configuration (Vite Configuration) |

---

## Required Tech Stack

### Core Technologies

**MUST** use these technologies at **minimum** the versions below. Later versions within the same major (or as noted) are supported.

- **React 19+** - Functional components only, no class components
- **TypeScript 5+** - With `strict` mode enabled
- **Vite 5+** (recommend Vite 7+) - For tooling; use `import.meta.env` for environment variables
- **Tailwind v4** - CSS-first with `app.css` scaffold (see [Visual Standards](./7-visual-standards.md))
- **Supabase** - Via secure clients/hooks (`useSecureSupabase`); never bypass RLS
- **TanStack Query 5+** - For server state management
- **React Hook Form 7+** - For forms; prefer `useZodForm` from pace-core when using Zod
- **Zod 4+** - Schema validation (forms, API boundaries)
- **React Compiler** - Use `babel-plugin-react-compiler` for automatic memoization; see [React Compiler](#react-compiler) below.

### Minimum version requirements

Use at least these versions; later versions are supported unless a major upgrade introduces a breaking change that pace-core has not yet adopted.

```json
{
  "dependencies": {
    "react": "^19.0.0",
    "react-dom": "^19.0.0",
    "@types/react": "^19.0.0",
    "@types/react-dom": "^19.0.0",
    "typescript": "^5.0.0",
    "@supabase/supabase-js": "^2.0.0",
    "@tanstack/react-query": "^5.0.0",
    "react-hook-form": "^7.0.0",
    "zod": "^4.0.0"
  },
  "devDependencies": {
    "vite": "^5.0.0",
    "@vitejs/plugin-react": "^4.0.0",
    "babel-plugin-react-compiler": "^1.0.0"
  }
}
```

### React Compiler

**SHOULD** enable the React Compiler in the shell and in consuming apps so that automatic memoization applies (see [Code Quality Standard](./6-code-quality-standards.md) – memoization section). This is the only supported optimization approach; when enabled, you must not add manual `useMemo`/`useCallback`/`React.memo` for general cases—write straightforward code and let the compiler optimize.

1. **Install** (if not already present):
   ```bash
   npm install -D babel-plugin-react-compiler
   ```

2. **Configure Vite** – pass the compiler into the React plugin:
   ```typescript
   // vite.config.ts
   import { defineConfig } from 'vite';
   import react from '@vitejs/plugin-react';

   export default defineConfig({
     plugins: [
       react({
         babel: {
           plugins: ['babel-plugin-react-compiler'],
         },
       }),
       // ... other plugins (e.g. tailwindcss)
     ],
   });
   ```

3. **Tests** – MAY add the same Babel plugin to the Vitest config so tests run with the compiler and component code is compiled consistently.

The pace-core repo uses this setup in its root `vite.config.ts` and `vitest.config.ts`; the shell and consuming apps should mirror it.

### Environment Variables

**MUST** use `import.meta.env` (Vite) for environment variables:

```typescript
// ✅ CORRECT - Vite environment variables
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;

// ❌ WRONG - Node.js process.env
const supabaseUrl = process.env.VITE_SUPABASE_URL;
```

---

## API & RPC Naming Conventions

### RPC Naming Pattern

**MUST** follow this naming pattern: `<family>_<domain>_<verb>`

- **Family**: `data` (read operations), `app` (write operations)
- **Domain**: Feature/domain name (e.g., `events`, `users`, `cake_dish`)
- **Verb**: Operation name (e.g., `list`, `get`, `create`, `update`, `delete`)

**Examples:**
```typescript
// Read operations (data_*)
data_events_list
data_events_get
data_users_list
data_cake_dish_list

// Write operations (app_*)
app_events_create
app_events_update
app_events_delete
app_cake_dish_create

// Bulk operations (use _bulk_ prefix)
app_events_bulk_create
app_cake_dish_bulk_update
```

### Naming Rules

1. **Use snake_case** for all RPC names
2. **Read operations** start with `data_`
3. **Write operations** start with `app_`
4. **Bulk operations** use `_bulk_` prefix (e.g., `app_events_bulk_create`)
5. **Domain names** should match table names where applicable
6. **Verb names** should be clear and consistent (`list`, `get`, `create`, `update`, `delete`)

### RPC Scope Classification

The `data_*` / `app_*` naming contract applies to **externally callable RPC surfaces** (PostgREST-facing functions intended for app/API use).

**Platform contract namespaces** (`base_*`, `rbac_*`, `pump_*`, and similar) are defined in pace-core / PUMP migrations and are **exempt** from the `data_*` / `app_*` lint rule. The fixed session-context RPC `set_organisation_context` is also exempt (platform session setup, not an app data surface). Consuming apps MUST still use `data_*` / `app_*` for app-owned RPCs. For direct calls to `set_organisation_context`, import `SET_ORGANISATION_CONTEXT_RPC` from `@solvera/pace-core/rbac`.

Functions are **out of RPC scope** when they are internal database primitives, including:
- Trigger functions (`RETURNS trigger`, e.g. `handle_*`, `update_*_updated_at`, `trg_*`)
- Internal helper/maintenance functions called only by other SQL objects (e.g. closure rebuild helpers, ranking helpers, retention jobs)
- One-off migration helpers (for data conversion / backfill only)

Out-of-scope functions:
- SHOULD still follow clear naming conventions by purpose
- MUST include `COMMENT ON FUNCTION` documenting internal-only intent
- SHOULD have client execute privileges revoked where practical

---

## API Result Shape

### Standard Result Type

**MUST** use this result type for all APIs:

```typescript
type ApiResult<T> =
  | { ok: true; data: T }
  | { ok: false; error: ApiError };

type ApiError = {
  code: string;        // Machine-readable error code
  message: string;     // User-friendly message
  details?: object;    // Optional additional context (non-sensitive)
};
```

### Example Usage

```typescript
// ✅ CORRECT - Using ApiResult type
async function fetchEvent(id: string): Promise<ApiResult<Event>> {
  try {
    const { data, error } = await supabase
      .from('events')
      .select('*')
      .eq('id', id)
      .single();
      
    if (error) {
      return {
        ok: false,
        error: {
          code: 'EVENT_NOT_FOUND',
          message: 'Event not found',
          details: { eventId: id },
        },
      };
    }
    
    return { ok: true, data };
  } catch (error) {
    return {
      ok: false,
      error: {
        code: 'UNKNOWN_ERROR',
        message: 'An unexpected error occurred',
      },
    };
  }
}

// Usage
const result = await fetchEvent(eventId);
if (result.ok) {
  // TypeScript knows result.data exists
  console.log(result.data.name);
} else {
  // TypeScript knows result.error exists
  toast.error(result.error.message);
}
```

### RPC Result Shape

**RPCs MUST** return data in a format that can be wrapped in `ApiResult`:

```sql
-- ✅ CORRECT - RPC returns data directly
CREATE OR REPLACE FUNCTION data_events_list(
  p_organisation_id UUID
)
RETURNS TABLE (
  id UUID,
  name TEXT,
  date TIMESTAMPTZ
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path TO public
AS $$
BEGIN
  RETURN QUERY
  SELECT e.id, e.name, e.date
  FROM events e
  WHERE e.organisation_id = p_organisation_id;
END;
$$;
```

**Client-side wrapper:**
```typescript
async function listEvents(organisationId: string): Promise<ApiResult<Event[]>> {
  const { data, error } = await supabase.rpc('data_events_list', {
    p_organisation_id: organisationId,
  });
  
  if (error) {
    return {
      ok: false,
      error: {
        code: 'LIST_FAILED',
        message: 'Failed to list events',
        details: { error: error.message },
      },
    };
  }
  
  return { ok: true, data: data ?? [] };
}
```

---

## RPC Rules

### Read RPCs Never Mutate

**Read operations MUST NOT have side effects.**

```sql
-- ❌ WRONG - Read operation with side effect
CREATE OR REPLACE FUNCTION data_events_get(p_event_id UUID)
RETURNS TABLE (...)
AS $$
BEGIN
  -- Side effect: updates last_accessed
  UPDATE events SET last_accessed = NOW() WHERE id = p_event_id;
  RETURN QUERY SELECT * FROM events WHERE id = p_event_id;
END;
$$;

-- ✅ CORRECT - Pure read operation
CREATE OR REPLACE FUNCTION data_events_get(p_event_id UUID)
RETURNS TABLE (...)
LANGUAGE plpgsql
STABLE  -- ✅ STABLE for read operations
SECURITY DEFINER
SET search_path TO public
AS $$
BEGIN
  RETURN QUERY
  SELECT * FROM events WHERE id = p_event_id;
END;
$$;
```

### Write RPCs Should Be Idempotent

**Write operations SHOULD be idempotent when possible.**

```sql
-- ✅ CORRECT - Idempotent upsert
CREATE OR REPLACE FUNCTION app_events_upsert(
  p_id UUID,
  p_name TEXT,
  p_date TIMESTAMPTZ
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO public
AS $$
DECLARE
  v_event_id UUID;
BEGIN
  INSERT INTO events (id, name, date, organisation_id)
  VALUES (p_id, p_name, p_date, get_organisation_context())
  ON CONFLICT (id) DO UPDATE
  SET name = EXCLUDED.name, date = EXCLUDED.date
  RETURNING id INTO v_event_id;
  
  RETURN v_event_id;
END;
$$;
```

### Never Accept Dynamic SQL

**NEVER accept SQL strings as parameters. Use parameterized queries or RPCs.**

```sql
-- ❌ WRONG - Dynamic SQL injection risk
CREATE OR REPLACE FUNCTION execute_query(p_sql TEXT)
RETURNS TABLE (...)
AS $$
BEGIN
  RETURN QUERY EXECUTE p_sql;  -- DANGEROUS!
END;
$$;

-- ✅ CORRECT - Parameterized query
CREATE OR REPLACE FUNCTION data_events_list(
  p_organisation_id UUID,
  p_status TEXT DEFAULT NULL,
  p_limit INTEGER DEFAULT 100
)
RETURNS TABLE (...)
AS $$
BEGIN
  RETURN QUERY
  SELECT * FROM events
  WHERE organisation_id = p_organisation_id
    AND (p_status IS NULL OR status = p_status)
  LIMIT p_limit;
END;
$$;
```

### Enforce RLS + Tenant Boundaries

**RPCs MUST enforce RLS and tenant boundaries. Never bypass security checks.**

```sql
-- ✅ CORRECT - RLS enforced via helper functions
CREATE OR REPLACE FUNCTION data_events_list(p_organisation_id UUID)
RETURNS TABLE (...)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER          -- ✅ Required: queries RLS-protected tables or needs elevated privileges
SET search_path TO public -- ✅ MANDATORY: prevents search path hijacking
AS $$
BEGIN
  -- Check organisation access
  IF NOT check_user_organisation_access(p_organisation_id) THEN
    RAISE EXCEPTION 'Access denied';
  END IF;
  
  -- ✅ Schema-qualified reference
  RETURN QUERY
  SELECT * FROM public.events
  WHERE organisation_id = p_organisation_id;
END;
$$;

-- ✅ Document why SECURITY DEFINER is needed
COMMENT ON FUNCTION data_events_list(UUID) IS 
  'Lists events for an organisation. SECURITY DEFINER required because function queries RLS-protected tables via check_user_organisation_access(). STABLE for read operation performance. SET search_path TO public prevents search path hijacking.';
```

### SECURITY DEFINER Security Requirements for RPC Functions

**RPC functions that use SECURITY DEFINER MUST follow these security requirements:**

| Requirement | Why | Example |
|------------|-----|---------|
| `SET search_path TO public` | **MANDATORY** - Prevents search path hijacking attacks | `SET search_path TO public` |
| Schema-qualify references | **MANDATORY** - Ensures objects resolve to correct schemas | `public.events` not `events` |
| `STABLE` for read operations | **REQUIRED** - Helps with query optimization | `STABLE` |
| Document rationale | **REQUIRED** - COMMENT must explain why SECURITY DEFINER is needed | See COMMENT example above |
| Least-privilege ownership | **MANDATORY** - Functions MUST be owned by appropriate roles | Not superuser unless necessary |

**When SECURITY DEFINER is needed for RPC functions:**
- Function queries RLS-protected tables (e.g., `rbac_organisation_roles`, `rbac_global_roles`)
- Function needs to bypass RLS to avoid circular dependencies
- Function performs administrative operations requiring elevated privileges

**Security Checklist for RPC Functions with SECURITY DEFINER:**
- [ ] `SET search_path TO public` is present (MANDATORY)
- [ ] All table/function references are schema-qualified (e.g., `public.table_name`)
- [ ] Function is marked `STABLE` for read operations
- [ ] Function ownership uses least-privilege role (not superuser unless necessary)
- [ ] COMMENT documents why SECURITY DEFINER is needed

**Example with all security requirements:**

```sql
-- ✅ CORRECT: All security requirements met
CREATE OR REPLACE FUNCTION data_events_list(p_organisation_id UUID)
RETURNS TABLE (id UUID, name TEXT, date TIMESTAMPTZ)
LANGUAGE plpgsql
STABLE                    -- ✅ Performance optimization
SECURITY DEFINER          -- ✅ Required: queries RLS-protected tables
SET search_path TO public -- ✅ MANDATORY: prevents search path hijacking
AS $$
BEGIN
  -- ✅ Schema-qualified reference
  IF NOT public.check_user_organisation_access(p_organisation_id) THEN
    RAISE EXCEPTION 'Access denied';
  END IF;
  
  -- ✅ Schema-qualified reference
  RETURN QUERY
  SELECT e.id, e.name, e.date
  FROM public.events e
  WHERE e.organisation_id = p_organisation_id;
END;
$$;

-- ✅ Document why SECURITY DEFINER is needed
COMMENT ON FUNCTION data_events_list(UUID) IS 
  'Lists events for an organisation. SECURITY DEFINER required because function queries public.rbac_organisation_roles (via check_user_organisation_access) which has RLS policies. Without SECURITY DEFINER, this would create circular RLS dependency. STABLE for read operation performance. SET search_path TO public prevents search path hijacking.';
```

**Security Anti-Patterns:**

```sql
-- ❌ BAD: Missing SET search_path (security risk)
CREATE OR REPLACE FUNCTION bad_rpc()
RETURNS TABLE (...)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER  -- Missing SET search_path TO public!
AS $$
BEGIN
  RETURN QUERY SELECT * FROM events;
END;
$$;

-- ❌ BAD: Unqualified reference (security risk)
CREATE OR REPLACE FUNCTION bad_rpc()
RETURNS TABLE (...)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path TO public
AS $$
BEGIN
  RETURN QUERY SELECT * FROM events;  -- Should be public.events
END;
$$;
```

**Real-World Example: Complex RPC with Multiple Security Checks**

```sql
-- Real-world example: Creating an event with attendees and permissions
CREATE OR REPLACE FUNCTION app_events_create_with_attendees(
  p_name TEXT,
  p_date TIMESTAMPTZ,
  p_organisation_id UUID,
  p_attendee_ids UUID[]
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO public
AS $$
DECLARE
  v_event_id UUID;
  v_user_id UUID;
  v_has_permission BOOLEAN;
BEGIN
  -- 1. Get current user ID
  v_user_id := safe_get_user_id_for_rls();
  
  -- 2. Check organisation access
  IF NOT check_user_organisation_access(p_organisation_id) THEN
    RAISE EXCEPTION 'You do not have access to this organisation';
  END IF;
  
  -- 3. Check create permission using RBAC
  v_has_permission := data_data_check_rbac_permission_with_context(
    'create:page.events',
    'events',
    p_organisation_id,
    NULL,
    data_get_app_id('PACE')
  );
  
  IF NOT v_has_permission THEN
    RAISE EXCEPTION 'You do not have permission to create events';
  END IF;
  
  -- 4. Validate attendee IDs belong to the same organisation
  IF array_length(p_attendee_ids, 1) > 0 THEN
    IF EXISTS (
      SELECT 1 FROM users
      WHERE id = ANY(p_attendee_ids)
      AND organisation_id != p_organisation_id
    ) THEN
      RAISE EXCEPTION 'All attendees must belong to the same organisation';
    END IF;
  END IF;
  
  -- 5. Create event
  INSERT INTO events (name, date, organisation_id, created_by)
  VALUES (p_name, p_date, p_organisation_id, v_user_id)
  RETURNING id INTO v_event_id;
  
  -- 6. Create attendee records
  IF array_length(p_attendee_ids, 1) > 0 THEN
    INSERT INTO event_attendees (event_id, user_id, organisation_id)
    SELECT v_event_id, unnest(p_attendee_ids), p_organisation_id;
  END IF;
  
  RETURN v_event_id;
END;
$$;

-- Usage in TypeScript
async function createEventWithAttendees(
  name: string,
  date: Date,
  organisationId: string,
  attendeeIds: string[]
): Promise<ApiResult<{ eventId: string }>> {
  const { data, error } = await secureSupabase.rpc('app_events_create_with_attendees', {
    p_name: name,
    p_date: date.toISOString(),
    p_organisation_id: organisationId,
    p_attendee_ids: attendeeIds,
  });
  
  if (error) {
    // Map database errors to user-friendly messages
    if (error.message.includes('access to this organisation')) {
      return {
        ok: false,
        error: {
          code: 'ORGANISATION_ACCESS_DENIED',
          message: 'You do not have access to this organisation',
        },
      };
    }
    if (error.message.includes('permission to create events')) {
      return {
        ok: false,
        error: {
          code: 'PERMISSION_DENIED',
          message: 'You do not have permission to create events',
        },
      };
    }
    if (error.message.includes('same organisation')) {
      return {
        ok: false,
        error: {
          code: 'INVALID_ATTENDEES',
          message: 'All attendees must belong to the same organisation',
        },
      };
    }
    
    return {
      ok: false,
      error: {
        code: 'CREATE_FAILED',
        message: 'Unable to create event. Please try again.',
      },
    };
  }
  
  return { ok: true, data: { eventId: data } };
}
```

### User-Safe Error Messages

**Errors MUST be user-friendly and not expose internal details.**

```sql
-- ❌ WRONG - Exposes internal details
CREATE OR REPLACE FUNCTION app_events_create(...)
AS $$
BEGIN
  IF some_condition THEN
    RAISE EXCEPTION 'SQLSTATE[23000]: Integrity constraint violation: duplicate key';
  END IF;
END;
$$;

-- ✅ CORRECT - User-friendly error
CREATE OR REPLACE FUNCTION app_events_create(...)
AS $$
BEGIN
  IF some_condition THEN
    RAISE EXCEPTION 'An event with this name already exists';
  END IF;
END;
$$;
```

---

## Deprecation Policy

### Deprecation Process

**When deprecating APIs or RPCs:**

1. **Mark with `@deprecated`** JSDoc comment
2. **Add migration notes** in documentation
3. **Retirement window** = 2 stable releases
4. **Remove after retirement window** expires

### Example Deprecation

```typescript
/**
 * @deprecated Use `data_events_list` instead. This function will be removed in v2.0.0.
 * 
 * Migration:
 * ```typescript
 * // Old
 * const events = await getEvents(orgId);
 * 
 * // New
 * const result = await listEvents(orgId);
 * if (result.ok) {
 *   const events = result.data;
 * }
 * ```
 */
async function getEvents(organisationId: string): Promise<Event[]> {
  // Implementation
}
```

---

## Tech Stack Configuration

### TypeScript Configuration

**MUST** enable strict mode:

```json
{
  "compilerOptions": {
    "strict": true,
    "noImplicitAny": true,
    "strictNullChecks": true,
    "strictFunctionTypes": true,
    "strictBindCallApply": true,
    "strictPropertyInitialization": true,
    "noImplicitThis": true,
    "alwaysStrict": true
  }
}
```

### Vite Configuration

**MUST** configure path aliases, React plugin, and dependency optimization:

```typescript
// vite.config.ts
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
    // CRITICAL: Dedupe React dependencies to prevent context mismatches
    dedupe: ['react', 'react-dom', 'react-router-dom'],
  },
  optimizeDeps: {
    include: [
      'react',
      'react-dom',
      'react/jsx-runtime',
    ],
    // CRITICAL: Exclude pace-core and react-router-dom to prevent React context mismatches
    exclude: ['@solvera/pace-core', 'react-router-dom'],
  },
  envPrefix: 'VITE_', // Only expose VITE_* env vars
});
```

**Why this configuration is required:**
- Pre-bundling `@solvera/pace-core` creates separate React instances, causing "useUnifiedAuth must be used within a UnifiedAuthProvider" errors
- Excluding it ensures pace-core uses the same React instance as your app
- `react-router-dom` must also be excluded and deduped to prevent Router context errors

**If you encounter context errors:**
1. Verify `@solvera/pace-core` is in `optimizeDeps.exclude`
2. Verify `react-router-dom` is in both `resolve.dedupe` and `optimizeDeps.exclude`
3. Clear Vite cache: `rm -rf node_modules/.vite`
4. Restart dev server

### TanStack Query Configuration

**MUST** configure appropriate cache times:

```typescript
import { QueryClient } from '@tanstack/react-query';

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000,    // 5 minutes
      gcTime: 10 * 60 * 1000,       // 10 minutes (formerly cacheTime)
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});
```

---

## Table Schema Standards

Every new database table in the public schema **MUST** follow these conventions. All existing tables have been brought into compliance.

### Table Naming

Tables **MUST** use the `{app_prefix}_{entity}` naming convention:

| App | Prefix |
|---|---|
| BASE | `base_` |
| CAKE | `cake_` |
| CORE | `core_` |
| MEDI | `medi_` |
| MINT | `mint_` |
| PUMP | `pump_` |
| RBAC | `rbac_` |
| TRAC | `trac_` |
| GEAR | `gear_` |

New app prefixes must be registered in this table before use. Entity names use `snake_case` and should be singular nouns (e.g. `core_member`, not `core_members`).

### Required Columns -- All Tables

Every table **MUST** include these columns unless it qualifies for an explicit exception:

```sql
CREATE TABLE {prefix}_{entity} (
  id            UUID          DEFAULT gen_random_uuid() PRIMARY KEY,
  organisation_id UUID        NOT NULL REFERENCES core_organisations(id),
  created_at    TIMESTAMPTZ   NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ   NOT NULL DEFAULT now(),
  created_by    UUID          REFERENCES auth.users(id),
  updated_by    UUID          REFERENCES auth.users(id)
);

ALTER TABLE {prefix}_{entity} ENABLE ROW LEVEL SECURITY;
```

| Column | Type | Nullable | Default | Purpose |
|---|---|---|---|---|
| `id` | `UUID` | NOT NULL | `gen_random_uuid()` | Primary key. Domain-specific PKs (e.g. `VARCHAR`) are permitted with documented rationale. |
| `organisation_id` | `UUID` | NOT NULL | -- | FK to `core_organisations(id)`. Required for RLS organisation scoping. |
| `created_at` | `TIMESTAMPTZ` | NOT NULL | `now()` | Record creation timestamp. |
| `updated_at` | `TIMESTAMPTZ` | NOT NULL | `now()` | Last modification timestamp. |
| `created_by` | `UUID` | NULL | -- | FK to `auth.users(id)`. The user who created the record. |
| `updated_by` | `UUID` | NULL | -- | FK to `auth.users(id)`. The user who last modified the record. |

### Required Columns -- Event-Scoped Tables

Tables that hold data created within an event context **MUST** also include:

```sql
  event_id      VARCHAR       NOT NULL REFERENCES core_events(event_id)
```

**Decision tree:** "Is this data created within an event context (e.g. a meal, a transport booking, a budget)?" If YES, add `event_id`.

Tables that are org-level (e.g. suppliers, templates, payment methods, lookup types) do **NOT** need `event_id`.

### Append-Only Log Tables

Append-only tables (audit logs, webhook logs, mandate logs) follow a reduced set:

- **MUST** have `organisation_id` (for RLS scoping)
- **MUST** have `created_at`
- **SHOULD** have a user-reference column (e.g. `user_id`, `accessed_by`, `changed_by`)
- **MAY** omit `updated_by` and `updated_at` (records are never modified)

### Exceptions to `organisation_id`

These system-level tables are exempt from requiring `organisation_id`:

| Table | Reason |
|---|---|
| `core_organisations` | IS the organisations table |
| `core_field_list` | System metadata (field definitions shared across all orgs) |
| `rbac_apps` | Global app registry |
| `rbac_app_pages` | Global page definitions (child of rbac_apps) |
| `rbac_policy_audit` | System-level policy change log |
| `rbac_policy_configs` | System-level policy configuration |
| `mint_idempotency` | System-level idempotency tracking |
| `core_person` | Cross-org entity; `organisation_id` is nullable (a person can belong to multiple orgs) |

Any new exception **MUST** be documented here with a rationale. Do not silently omit `organisation_id`.

### RLS Enablement

Every new table **MUST** have Row Level Security enabled:

```sql
ALTER TABLE {prefix}_{entity} ENABLE ROW LEVEL SECURITY;
```

This is non-negotiable. See [Security & RBAC Standards](./3-security-rbac-standards.md) for RLS policy patterns.

### Indexing

- **MUST** index `organisation_id` on every table that has it
- **MUST** index `event_id` on every event-scoped table
- **MUST NOT** index `created_by` or `updated_by` (audit found 90+ unused indexes on these columns)
- **SHOULD** index foreign key columns used in JOINs or WHERE clauses

```sql
CREATE INDEX idx_{table}_organisation_id ON {table}(organisation_id);
CREATE INDEX idx_{table}_event_id ON {table}(event_id);  -- if event-scoped
```

### New Table Checklist

Before creating a new table, verify:

- [ ] Name follows `{app_prefix}_{entity}` convention
- [ ] Has `id UUID DEFAULT gen_random_uuid() PRIMARY KEY` (or documented alternative)
- [ ] Has `organisation_id UUID NOT NULL REFERENCES core_organisations(id)` (or is in the exceptions list)
- [ ] Has `created_at TIMESTAMPTZ NOT NULL DEFAULT now()`
- [ ] Has `updated_at TIMESTAMPTZ NOT NULL DEFAULT now()`
- [ ] Has `created_by UUID REFERENCES auth.users(id)`
- [ ] Has `updated_by UUID REFERENCES auth.users(id)`
- [ ] Has `event_id VARCHAR NOT NULL REFERENCES core_events(event_id)` if event-scoped
- [ ] `ALTER TABLE ... ENABLE ROW LEVEL SECURITY` applied
- [ ] Index on `organisation_id` created
- [ ] Index on `event_id` created (if event-scoped)
- [ ] RLS policies created (see Security & RBAC standards)

---

## Trigger Function Standards

Database triggers are used for **cross-cutting concerns** that must fire consistently on every row change, regardless of which RPC, direct query, or service-role operation initiated it. Business logic belongs in RPC functions; triggers are reserved for the categories below.

### When Triggers Are Appropriate

Triggers **SHOULD** be used for:

- **Audit fields** -- automatically setting `created_by`, `updated_by` on INSERT/UPDATE
- **Timestamps** -- automatically setting `updated_at` on UPDATE
- **Data integrity** -- enforcing constraints that span multiple tables (e.g., syncing `organisation_id` from a parent record, preventing circular references)
- **Versioning** -- incrementing version counters on change (e.g., medical profile versioning)
- **Singleton enforcement** -- ensuring only one record exists per scope (e.g., one default payment method)

### When Triggers Are NOT Appropriate

Triggers **MUST NOT** be used for:

- **Business logic** -- use RPC functions (`data_*` / `app_*`) instead
- **Complex workflows** -- multi-step operations belong in RPCs where they are visible and testable
- **External side effects** -- sending notifications, calling APIs, etc. belong in Edge Functions or application code
- **Conditional logic** based on user permissions -- use RLS policies or RPC-level RBAC checks

### Required Attributes

Every trigger function **MUST** have:

| Requirement | Why | Example |
|---|---|---|
| `VOLATILE` | Required by PostgreSQL for trigger functions | `VOLATILE` |
| `SET search_path TO public` | **MANDATORY** -- prevents search-path injection | `SET search_path TO public` |
| `COMMENT ON FUNCTION` | **REQUIRED** -- documents purpose and security rationale | See example below |
| `RETURNS trigger` | Required by PostgreSQL for trigger functions | `RETURNS trigger` |

### Security Requirements

| Pattern | When to use |
|---|---|
| `SECURITY DEFINER` | When the trigger needs to access `auth.uid()` or query RLS-protected tables |
| `SECURITY INVOKER` | For pure validation triggers that only inspect the incoming row data |

### Naming Conventions

Trigger functions follow these naming patterns based on their purpose:

| Pattern | Purpose | Examples |
|---|---|---|
| `handle_*` | Audit field and user registration triggers | `handle_audit_fields`, `handle_created_by`, `handle_new_user` |
| `update_*_updated_at` | Table-specific timestamp triggers | `update_base_units_updated_at`, `update_medi_updated_at_column` |
| `validate_*` | Input validation triggers | `validate_base_question_options`, `validate_data_retention` |
| `prevent_*` | Constraint enforcement (preventing invalid state) | `prevent_created_by_modification`, `prevent_budget_circular_reference` |
| `enforce_*` | Singleton or uniqueness enforcement | `enforce_singleton_form_context` |
| `sync_*` | Cross-table data synchronisation | `sync_base_unit_roles_event_org` |
| `set_*` / `*_set_*` | Auto-populating derived columns | `set_pace_merchandise_organisation_id`, `pace_contact_set_user_id` |
| `check_*` | Referential integrity checks | `check_circular_unit_reference` |
| `ensure_*` | Business rule enforcement | `ensure_single_default_payment_method` |
| `recalculate_*` | Derived value recalculation | `recalculate_budget_totals_on_variable_change` |

### Example: Trigger Function with All Requirements

```sql
CREATE OR REPLACE FUNCTION handle_updated_by()
RETURNS trigger
LANGUAGE plpgsql
VOLATILE
SECURITY DEFINER
SET search_path TO public
AS $$
BEGIN
  NEW.updated_by := auth.uid();
  RETURN NEW;
END;
$$;

COMMENT ON FUNCTION handle_updated_by() IS
  'Trigger function: sets updated_by to current user on UPDATE. SECURITY DEFINER required to access auth.uid(). SET search_path TO public prevents search-path injection.';

CREATE TRIGGER set_updated_by
  BEFORE UPDATE ON {prefix}_{entity}
  FOR EACH ROW
  EXECUTE FUNCTION handle_updated_by();
```

### New Trigger Checklist

Before creating a new trigger function, verify:

- [ ] Purpose falls within the "appropriate" categories above
- [ ] Function is `VOLATILE` and `RETURNS trigger`
- [ ] `SET search_path TO public` is present (MANDATORY)
- [ ] Security mode is correct (`DEFINER` for `auth.uid()` access, `INVOKER` for pure validation)
- [ ] Function name follows the naming conventions above
- [ ] `COMMENT ON FUNCTION` documents purpose and security rationale
- [ ] `CREATE TRIGGER` statement binds the function to the correct table(s)
- [ ] Trigger timing is correct (`BEFORE` for value-setting, `AFTER` for side-effect triggers)

### Reference

See [triggers.md](../database/triggers.md) for the complete inventory of all 24 trigger functions in production.

---

## TypeScript Type Strategy

pace-core uses **hand-written TypeScript types** as the public API contract, not auto-generated Supabase types. This is a deliberate architectural choice for a shared UI/auth library consumed by multiple apps.

### Hand-Written Types (Public API)

Hand-written types in `packages/core/src/types/` represent the **public contract** exposed to consuming apps. They are intentionally narrower than the full database schema:

- Only columns needed by pace-core consumers are exposed
- Property names may differ from DB column names for better ergonomics (e.g. `timestamp` instead of `login_timestamp`)
- Nullable DB columns may be typed as non-nullable when defaults guarantee population

### Generated Types (Validation Reference)

The file `docs/database/generated-types.txt` contains the complete Supabase-generated schema (all tables, views, RPCs, and enums). It **MUST NOT** be imported by application code. Its purpose is:

- Verifying hand-written types stay in sync with schema changes
- Catching new columns that should be exposed
- Detecting nullability drift
- **MUST** be regenerated when the database schema changes

### Deliberate Narrowing

TS types **MAY** be non-nullable where the DB column is technically nullable but has a `DEFAULT` that guarantees population. This applies to:

- `created_at` / `updated_at` columns with `DEFAULT now()` -- TS types `string`, DB is `string | null`
- `is_active` / `is_public` columns with `DEFAULT true/false` -- TS types `boolean`, DB is `boolean | null`

This narrowing is safe in the read direction and improves developer ergonomics. The type-alignment audit documents all deliberate narrowings.

### UI boundary vs data plane naming

The database and RPC layer **MUST** stay **snake_case** (tables, columns, function names, storage path segments). Application TypeScript **MAY** expose **camelCase** (or PascalCase for components) at the UI boundary when a **mapping function** transforms rows at the query layer. Do not rename Postgres identifiers to match frontend style. Route URL segments follow [Project Structure — Naming by layer](./1-project-structure-standards.md#routes-and-browser-urls) (kebab-case), not DB naming.

### Property Renaming

When a TS property name differs from its DB column name, a **mapping function MUST exist** at the query layer that transforms DB rows to the public type shape. Examples:

- `LoginRecord.timestamp` maps from `rbac_user_login_history.login_timestamp` via `mapRawRowToLoginRecord`
- `LoginRecord.ip` maps from `rbac_user_login_history.ip_address` via `mapRawRowToLoginRecord`
- `EventStub.id` maps from `core_events.event_id` via the EventService query layer

### Branded Types

pace-core provides branded ID types for compile-time safety:

| Type | Underlying | Used For |
|---|---|---|
| `UserId` | `string & { __brand: 'UserId' }` | `auth.users.id`, FK columns |
| `OrganisationId` | `string & { __brand: 'OrganisationId' }` | `core_organisations.id`, FK columns |
| `EventId` | `string & { __brand: 'EventId' }` | `core_events.event_id`, FK columns |
| `AppId` | `string & { __brand: 'AppId' }` | `rbac_apps.id`, FK columns |
| `PageId` | `string & { __brand: 'PageId' }` | `rbac_app_pages.id`, FK columns |

Branding is erased at runtime (no serialisation impact). Use the `create*` helpers (`createUserId`, `createOrganisationId`, etc.) to construct branded values.

### App-Specific Types

Consuming apps (pace-cake, pace-trac, etc.) that work with many domain-specific tables **SHOULD** consider using Supabase-generated types directly, since they need 1:1 schema coverage and benefit from automated drift detection. pace-core's hand-written approach is optimised for its role as a narrow shared library.

### Type-Alignment Audit

The living comparison document at [docs/database/type-alignment.md](../database/type-alignment.md) tracks alignment between hand-written types and the database schema. It **SHOULD** be reviewed and updated whenever types or schema change.

---

## API Design Checklist

Before creating or updating an API/RPC, verify:

- [ ] RPC name follows naming convention (`data_*` or `app_*`)
- [ ] Uses `ApiResult<T>` type for return values
- [ ] Read RPCs are `STABLE` and have no side effects
- [ ] Write RPCs are idempotent when possible
- [ ] No dynamic SQL accepted as parameters
- [ ] RLS and tenant boundaries enforced
- [ ] Error messages are user-friendly
- [ ] TypeScript types are complete and accurate
- [ ] Deprecation process followed if removing/changing APIs

---

## ESLint Rules

Rule IDs use the plugin prefix **`pace-core-compliance/`**. The following rules enforce API and tech stack standards:

- **`pace-core-compliance/rpc-naming-pattern`** — Enforces `data_*` prefix for read operations and `app_*` prefix for write operations (excludes platform `base_*`, `rbac_*`, `pump_*` contract RPCs, and the session-context RPC `set_organisation_context`).
- **`pace-core-compliance/no-class-components`** — Disallows React class components (functional components only).
- **`pace-core-compliance/prefer-import-meta-env`** — Enforces `import.meta.env` (Vite) instead of `process.env` in client code.

These rules are part of the `pace-core-compliance` plugin and are enabled when extending `@solvera/pace-core/eslint-config`.

**Setup**: Run `npm run setup` to configure ESLint (and other pace-core tools) in your consuming app.

## Related Documentation

- [Standards Overview](./0-standards-overview.md) - Standards system overview
- [Architecture](./2-architecture-standards.md) - API design principles
- [Code Quality](./6-code-quality-standards.md) - TypeScript standards
- [Security & RBAC](./3-security-rbac-standards.md) - RLS and security requirements
- [Operations](./9-operations-standards.md) - Error handling patterns

---

**Last Updated:** 2026-03-14  
**Version:** 2.1.0  
**Applies to:** All pace-core and consuming apps
