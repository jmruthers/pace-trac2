# Pace Standards

This folder is the canonical standards source shipped with the package.

Consuming apps should read standards from:

- `node_modules/@solvera/pace-core/docs/standards/`

Before implementing features, also read:

- `node_modules/@solvera/pace-core/docs/getting-started/standards-and-guardrails.md`
