# Project Structure Standards

**🤖 Cursor Rule**: See [01-project-structure.mdc](../cursor-rules/01-project-structure.mdc) for AI-optimized directives that automatically enforce this structure.

## Purpose

This guide defines the standard project structure and file organization patterns that all apps consuming `@solvera/pace-core` **MUST** follow. Adhering to this structure ensures:

- **Consistency** across all PACE suite applications
- **Maintainability** through predictable organization
- **Developer Experience** with clear patterns and conventions
- **Compatibility** with pace-core tooling and automation
- **Scalability** as your app grows

## Table of Contents

1. [Standard Directory Structure](#standard-directory-structure)
2. [File Organization Standard](#file-organization-standard)
3. [Naming Conventions](#naming-conventions) (includes [Naming by layer](#naming-by-layer), [Legacy RBAC page names](#legacy-rbac-page-names))
4. [Import Path Configuration](#import-path-configuration)
5. [Component Organization](#component-organization)
6. [Testing Structure](#testing-structure)
7. [Database & Supabase Structure](#database--supabase-structure)
8. [Configuration Files](#configuration-files)
9. [Structure Checklist](#structure-checklist)

### How each layer enforces this standard

- **Standards (this doc):** Source of truth; defines MUST/SHOULD for structure, naming, imports, and config.
- **Cursor rule:** `01-project-structure.mdc` — AI guidance when creating or organizing files (`**/*.{ts,tsx,js,jsx,md}`, `src/**`); points to this doc.
- **ESLint:** `pace-core-compliance/rbac-page-name-convention`, `legacy-rbac-page-name`, `route-path-kebab-case`, plus import/bootstrap rules in `02-project-structure.cjs`. Shared validators: `@solvera/pace-core/naming/naming-by-layer`.
- **Audit tool:** Standard 1 audit runs as part of `npm run validate`; checks directory structure, config files, import paths (tsconfig), test colocation, feature-based organization, and **Naming by layer** (page filenames, route segments, public assets, **app public logo contract** vs `APP_NAME`, pageName/stem alignment). Report: `audit/<timestamp>-pace-core-audit.md`. Offline drift scripts: `check-rbac-page-name-drift.mjs` (pace-core2), `check-rbac-page-names.mjs` (pace-portal `validate:portal`). Consuming apps: `validate-authority` also checks required `public/logos/{appSlug}-*.svg` assets.

### Audit issue types and where to read

| Audit issue type    | See section in this doc                        |
|---------------------|------------------------------------------------|
| directoryStructure  | Standard Directory Structure                   |
| configFiles         | Configuration Files                           |
| importPaths         | Import Path Configuration                     |
| testColocation      | Testing Structure (Test Colocation)           |
| organizationPattern | Component Organization / File Organization Standard |
| namingByLayer       | Naming by layer (page files, routes, public assets, app public logos) |
| legacyPageName      | Legacy RBAC page names (pending PascalCase migration) |

---

## Standard Directory Structure

### Complete Project Structure

Every consuming app **MUST** follow this base structure. All listed paths and files are required unless marked optional.

```
your-app/
├── .cursor/
│   ├── rules/                    # Cursor rules (pace-core + local)
│   │   ├── 00-standards-overview.mdc
│   │   ├── 01-pace-core-compliance.mdc
│   │   ├── 02-project-structure.mdc
│   │   └── [local-rules].mdc
│   └── mcp.json                  # MCP server configuration (required)
│
├── .vscode/                      # VS Code settings (optional)
│   └── settings.json
│
├── public/                       # Static assets
│   ├── favicon.ico
│   ├── robots.txt
│   ├── fonts/                    # App fonts (required)
│   │   └── *.woff2
│   └── logos/                    # App logos (required)
│       └── [logo-files]
│
├── src/                          # Source code
│   ├── components/               # App-specific components
│   │   ├── [feature-name]/      # Organized by feature
│   │   └── shared/              # Shared app components
│   │
│   ├── hooks/                    # App-specific hooks
│   │   ├── [feature-name]/      # Feature-specific hooks
│   │   └── [hook-name].ts
│   │
│   ├── services/                 # App-specific services (if using service pattern)
│   │   └── [service-name].ts
│   │
│   ├── pages/                    # Page components (route components)
│   │   ├── [PageName].tsx
│   │   └── [feature]/           # Feature-based pages
│   │
│   ├── types/                    # TypeScript type definitions
│   │   ├── [domain].ts          # Domain-specific types
│   │   └── index.ts             # Re-export barrel file
│   │
│   ├── utils/                    # App-specific utility functions (required)
│   │   ├── [utility-name].ts
│   │   └── index.ts             # Re-export barrel file
│   │
│   ├── lib/                      # Base Supabase client only (required)
│   │   └── supabase.ts          # Single file; passed to UnifiedAuthProvider only
│   │
│   ├── App.tsx                   # Main app component
│   ├── main.tsx                  # Application entry point
│   └── app.css                   # Global styles (MUST follow 7-visual-standards.md)
│
├── supabase/                     # Supabase configuration (no migrations in consuming apps)
│   └── config.toml               # Supabase config
│
├── tests/                        # Integration/E2E tests (optional)
│   └── [test-files].test.ts
│
├── audit/                        # Audit reports (generated, gitignored)
│   └── audit-*.md
│
├── .env                          # Local environment variables (required; gitignored)
├── .gitignore
├── eslint.config.js              # ESLint config (flat config; or .eslintrc.js / eslint.config.cjs)
├── package.json
├── tsconfig.json                 # TypeScript config
├── tsconfig.app.json             # App-specific TS config (if needed)
├── vite.config.ts                # Vite configuration
├── vitest.config.ts              # Vitest configuration
├── README.md
└── CHANGELOG.md                  # (optional but recommended)
```

### Directory Purpose Reference

| Directory / file | Purpose | Required? |
|------------------|---------|-----------|
| `.cursor/rules/` | Cursor AI rules for code generation | ✅ Yes |
| `.cursor/mcp.json` | MCP server configuration | ✅ Yes |
| `public/` | Static assets served directly | ✅ Yes |
| `public/fonts/` | App fonts in `.woff2` format | ✅ Yes |
| `public/logos/` | App logos | ✅ Yes |
| `src/` | All source code | ✅ Yes |
| `src/components/` | App-specific React components | ✅ Yes |
| `src/hooks/` | Custom React hooks | ✅ Yes |
| `src/pages/` | Route/page components | ✅ Yes |
| `src/types/` | TypeScript type definitions | ✅ Yes |
| `src/utils/` | App-specific utility functions | ✅ Yes |
| `src/lib/` | Base Supabase client only (e.g. `supabase.ts`) | ✅ Yes |
| `supabase/` | Supabase config and Edge Functions only | ✅ Yes |
| `tests/` | Integration/E2E tests | Optional |
| `audit/` | Generated audit reports | ✅ Yes (gitignored) |
| `.env` | Local environment variables | ✅ Yes (gitignored) |

---

## File Organization Standard

### Feature-Based Organization

**MUST** organize components, hooks, and related code by feature/domain:

```
src/
├── components/
│   ├── events/
│   │   ├── EventCard.tsx
│   │   ├── EventList.tsx
│   │   └── EventForm.tsx
│   ├── users/
│   │   ├── UserProfile.tsx
│   │   └── UserList.tsx
│   └── shared/
│       ├── AppLayout.tsx
│       └── Navigation.tsx
│
├── hooks/
│   ├── events/
│   │   ├── useEventData.ts
│   │   └── useEventForm.ts
│   └── users/
│       └── useUserData.ts
│
├── pages/
│   ├── EventsPage.tsx
│   ├── EventDetailPage.tsx
│   ├── UsersPage.tsx
│   └── UserProfilePage.tsx
│
└── types/
    ├── events.ts
    └── users.ts
```

**Why feature-based?** Since pace apps are already split by domain, organizing code by feature within each app provides:
- **Clear boundaries** - Related code stays together
- **Easy navigation** - Find all code for a feature in one place
- **Simplified imports** - Consistent path structure
- **Better maintainability** - Changes to a feature are localized

### src/utils vs src/lib (prescriptive)

- **`src/lib/`** – **MUST** contain only the base Supabase client (e.g. `supabase.ts`). No other files. Used only by `main.tsx` or `App.tsx` for `UnifiedAuthProvider`.
- **`src/utils/`** – **MUST** contain app-specific utility functions (formatting, validation, helpers). Re-export via `index.ts` where useful.

Do not put app utilities in `src/lib/`. Do not put the Supabase client in `src/utils/`.

---

## Naming Conventions

### Files

| Type | Convention | Example | Notes |
|------|------------|---------|-------|
| **Components** | `PascalCase.tsx` | `EventCard.tsx` | React components — **one primary component per file** for new work; filename stem **MUST** match the exported component name |
| **Hooks** | `camelCase.ts` with `use` prefix | `useEventData.ts` | Custom hooks |
| **Utilities** | `camelCase.ts` or `camelCase.tsx` when JSX is required | `formatEvent.ts`, `columnFactory.tsx` | Helper functions, factories, HOC builders — **not** component files even when they contain JSX |
| **Types** | `camelCase.ts` or `types.ts` | `eventTypes.ts` | Type definitions |
| **Services** | `PascalCase.ts` | `EventService.ts` | Service classes |
| **Tests** | `*.test.ts` or `*.test.tsx` | `EventCard.test.tsx` | Test files |
| **Config** | `kebab-case.config.js` | `vite.config.ts` | Config files |
| **Pages** | `PascalCase.tsx` with `Page` suffix | `EventsPage.tsx` | Route components |

### Directories

| Type | Convention | Example | Notes |
|------|------------|---------|-------|
| **Feature directories** | `kebab-case` | `event-management/` | Feature/domain names |
| **Component directories** | `kebab-case` | `event-card/` | When component has multiple files |
| **Shared directories** | `kebab-case` | `shared/` | Shared across features |

### Code Naming

```typescript
// ✅ CORRECT - Components
export function EventCard() { }
export const UserProfile = () => { };

// ✅ CORRECT - Hooks
export function useEventData() { }
export function useUserProfile() { }

// ✅ CORRECT - Utilities
export function formatEvent() { }
export function validateUserInput() { }

// ✅ CORRECT - Types
export type Event = { };
export interface UserProfile { }

// ✅ CORRECT - Services
export class EventService { }
```

### pace-core UI component names {#pace-core-ui-component-names}

pace-core exported UI components **MUST** use names that signal their structural role. Full layering for filenames and exports remains in [Naming by layer](#naming-by-layer) below.

| Role | Naming rule | Examples |
|------|-------------|----------|
| Large card-like composed surfaces | **MUST** include `Card` in the component name | `Card`, `EventCard` |
| Small display-only non-interactive elements | **MUST** include `Badge` in the name | `Badge`, `DateBadge` |
| Interactive controls | **MUST** be named for the native HTML element they emulate or wrap | `Button`, `Input`, `Textarea`, `Select`, `Progress`, `Menu`, `Dialog` |
| Informal UI jargon | **MUST NOT** appear in **new** component names | Avoid `Tile`, `Chip`, `Widget`, and similar |

- Composed card variants (for example `EventCard`) **MUST** build on the `Card` primitive per their requirement Visual specification.
- Legacy exports that predate this rule (for example names containing `Chip` or `Tile`) **MAY** remain until an explicit migration; renames and new exports **MUST** follow this taxonomy.
- Structured field types tied to a parent component **SHOULD** share the parent prefix (for example `EventCardFields` with `EventCard`).

### React component module filenames {#react-component-module-filenames}

- **New** React component modules **MUST** use a **PascalCase** `.tsx` filename whose stem matches the primary exported component (for example `DateBadge.tsx` exports `DateBadge`).
- React component **exports** **MUST** use **PascalCase** identifiers (for example `export function EventCard()`).
- Utility, factory, and hook modules **MUST NOT** use PascalCase filenames — use **camelCase** (`.ts` preferred; `.tsx` only when JSX is required). Examples: `columnFactory.tsx`, `createFieldRegistry.tsx`, `adapters.tsx`.
- Enforced by ESLint: `pace-core-compliance/component-naming` (exports) and `pace-core-compliance/component-filename` (module filenames). See [Code Quality — ESLint Rules](./6-code-quality-standards.md#eslint-rules).

#### Legacy component module filenames {#legacy-component-module-filenames}

As of 2026-06-23, pace-core has **no** remaining multi-export React component module barrels. RBAC guards (`PagePermissionGuard`, `NavigationGuard`, `AccessDenied`) and comms UI (`CommComposer`, `RecipientPoolPreview`, `MergeFieldToolbar`, `MessagePreview`) each live in a PascalCase one-component-per-file module under `packages/core/src/rbac/` and `packages/core/src/comms/` respectively. **New** component modules **MUST NOT** reintroduce multi-export component barrels.

Utility modules with camelCase filenames (not component files): `packages/core/src/components/data-table/columnFactory.tsx`, `packages/core/src/forms/createFieldRegistry.tsx`, `packages/core/src/rbac/adapters.tsx`.

### Naming by layer

Different surfaces use different conventions on purpose. **Do not apply one global casing rule** across URLs, React files, RBAC catalogue keys, and Postgres identifiers.

| Layer | Convention | Examples |
|-------|------------|----------|
| React components and page modules (`src/**/*.tsx`) | **PascalCase** filename + export | `EventsPage.tsx`, `EventCard.tsx` |
| Hooks and utilities (`src/**`) | **camelCase** `.ts` | `useEventData.ts`, `formatEvent.ts` |
| Service / class modules | **PascalCase** `.ts` | `EventService.ts` |
| Feature directories | **kebab-case** | `event-management/` |
| React Router paths and nav `href` | **lowercase kebab-case** segments | `/membership-types`, `/moderation/photos` |
| Static assets (`public/**`) | **kebab-case** filenames | `org-logo.svg`, `open-sans.woff2` |
| App shell logos (`public/logos/`) | **kebab-case** `{appSlug}-{variant}.svg` per `appPublicLogoPath` | `base-logo-square.svg`, `pace-favicon.svg` — see [CR05c](./requirements/CR05c-layout-and-shell.md) / [CR06](./requirements/CR06-forms-and-feedback.md) |
| RBAC `pageName` / `rbac_app_pages.page_name` (**new** pages) | **PascalCase** (file stem without extension) | `MemberRolesPage.tsx` → `pageName="MemberRolesPage"` |
| Data plane (tables, columns, RPCs, RLS) | **snake_case** | `core_events`, `data_events_list`, `rbac_read_*` |
| Storage object keys (`file_path`) | **snake_case** path segments mirroring DB scope | See [API & Tech Stack — storage](./4-api-tech-stack-standards.md) and `buildCanonicalStoragePath` in pace-core |
| CSS entry files | **lowercase** fixed names | `app.css`, `core.css` |
| Custom CSS classes and custom properties | **kebab-case** | `pace-background`, `--color-main-500` |

**Bootstrap exceptions (fixed names — do not rename for kebab uniformity):** `main.tsx`, `App.tsx`, `app.css`.

#### Routes and browser URLs

- **MUST** use lowercase **kebab-case** for each static path segment in React Router `path` / navigation `href`.
- **MUST NOT** use `snake_case` or underscores in app route paths.
- **MUST NOT** assume `path ===` page filename or `pageName`. Maintain an explicit route table mapping `href` → page module → optional `pageName` (see pace-core2 demo `protectedRoutes` in `src/App.tsx`).
- **Dynamic segment values** (event codes, org slugs in the URL) **MAY** retain business casing (e.g. `SUMMER2026`) but **MUST** be URL-safe: no spaces; no unencoded reserved characters; use only characters your app documents for that code type (typically `A–Z`, `a–z`, `0–9`, hyphen).
- React route **param names** in code stay **camelCase** (e.g. `:eventCode` → `useParams().eventCode`). Only the **segment value** in the address bar follows business rules.

#### RBAC page catalogue vs routes

`pageName` is a **permission catalogue key**, not a URL. It is related to the page file and route, but **not identical** to either.

| Route (`href`) | Page file | `pageName` (new pages) | Permission example |
|----------------|-----------|------------------------|--------------------|
| `/member-roles` | `MemberRolesPage.tsx` | `MemberRolesPage` | `read:page.MemberRolesPage` |
| `/communications` | `CommunicationsPage.tsx` | `CommunicationsPage` | `read:page.CommunicationsPage` |

- **New pages** (from the effective date of this standard): **MUST** register `rbac_app_pages.page_name` in **PascalCase** matching the page module file stem (without `.tsx`).
- **Route paths** for those pages **MUST** remain **kebab-case** as in the table above.
- Permissions are composed at runtime as `{operation}:page.{pageName}` via `toPagePermission` — matching is **case-sensitive** in Postgres.
- **Legacy grandfathering:** Existing registry values that are lowercase, kebab-case, or mixed (e.g. `reports`, `member-roles`, `CommsLog`) remain valid until a dedicated migration renames rows and grants. See [Legacy RBAC page names](#legacy-rbac-page-names) below. **Do not** use legacy shapes for **new** pages.

#### Data plane (cross-link)

- Table, column, RPC, and RLS naming: [Security & RBAC Standards](./3-security-rbac-standards.md), [API & Tech Stack Standards](./4-api-tech-stack-standards.md).
- App TypeScript **MAY** use camelCase at the UI boundary with explicit mappers from snake_case rows; the database contract stays snake_case.

#### CSS naming (cross-link)

- Tailwind v4 tokens, custom properties, and rare custom classes: **kebab-case**. See [Visual Standards — Part A](./7-visual-standards.md#part-a-styling-platform).
- Consuming apps still follow Standard 7 policy on who may edit CSS; naming rules apply to templates and pace-core maintainers.

#### Anti-patterns

- Renaming `EventsPage.tsx` → `events-page.tsx` “to match the URL”.
- Setting `pageName="member-roles"` on a **new** page whose file is `MemberRolesPage.tsx`.
- Using `table_name` or DB column names as React Router paths.
- Mixing `_` and `-` as word separators in the same public URL surface.
- Deriving `pageName` from `location.pathname` without mapping through the canonical catalogue string.

### Legacy RBAC page names

The following `rbac_app_pages.page_name` values are **grandfathered** (seeded before PascalCase-for-new-pages). Apps **MUST** continue to use the exact string in guards and seeds until a future migration renames them.

**TEAM** (from `20260507125550_team_batch1_rbac_rls_baseline.sql`):  
`home`, `members`, `member-roles`, `approvals`, `membership-types`, `organisations`, `org-settings`, `forms`, `events`, `reports`, `moderation-photos`

**PUMP** (cross-app, same migration):  
`CommsLog`

**BASE shell** (from `20260516140100_base_shell_pages_catalogue_seed.sql`):  
`event-dashboard`, `configuration`, `forms`, `form-builder`, `registration-types`, `applications`, `communications`, `units`, `activities`, `scanning`, `reports`

**Other legacy references in migrations / slices:**  
`Reports` (renamed toward `reports` in TEAM batch migrations), `Medical`, `Emergency`, `dashboard` (MEDI consent grants), `communications` (BASE BA17), `masterplan` (TRAC architecture doc).

### Conformance backlog (documentation review)

Findings from a read-only scan of this repo (no code changes in the standards pass). Use when planning migrations or new work.

| Area | Finding | Target |
|------|---------|--------|
| pace-core2 demo `src/App.tsx` | Routes are kebab-case; several `pageName` values are lowercase/kebab (`dashboard`, `data-table-showcase`, `super-admin-test`) — legacy shape | New showcase pages: PascalCase `pageName` + registry row; existing rows grandfathered |
| TEAM slice requirements | Routes kebab-case; `pageName` mostly lowercase/kebab (`reports`, `moderation-photos`, `forms`) except `CommsLog` | Treat table in `team-architecture-requirements.md` as **legacy** until migration |
| TEAM TM13 | Route `/communications`, `pageName="CommsLog"` (PUMP registry) | Cross-app legacy; new comms page would use PascalCase on owning app registry |
| TRAC architecture | `pageName="dashboard"`, `pageName="masterplan"` | Legacy lowercase |
| Storage `file_path` | snake_case segments — correct for data plane | No change |

---

## Import Path Configuration

### Path Aliases Setup

**MUST** configure path aliases in `tsconfig.json`:

```json
{
  "compilerOptions": {
    "baseUrl": ".",
    "paths": {
      "@/*": ["./src/*"],
      "@/components/*": ["./src/components/*"],
      "@/hooks/*": ["./src/hooks/*"],
      "@/pages/*": ["./src/pages/*"],
      "@/types/*": ["./src/types/*"],
      "@/utils/*": ["./src/utils/*"],
      "@/lib/*": ["./src/lib/*"]
    }
  }
}
```

**MUST** also configure in `vite.config.ts`:

```typescript
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
      '@/components': path.resolve(__dirname, './src/components'),
      '@/hooks': path.resolve(__dirname, './src/hooks'),
      '@/pages': path.resolve(__dirname, './src/pages'),
      '@/types': path.resolve(__dirname, './src/types'),
      '@/utils': path.resolve(__dirname, './src/utils'),
      '@/lib': path.resolve(__dirname, './src/lib'),
    },
  },
});
```

### Import Patterns

```tsx
// ✅ CORRECT - Absolute imports from src
import { EventCard } from '@/components/events/EventCard';
import { useEventData } from '@/hooks/events/useEventData';
import { formatEvent } from '@/utils/formatEvent';
import type { Event } from '@/types/events';

// ✅ CORRECT - pace-core imports
import { Button, Card, DataTable } from '@solvera/pace-core';
import { useUnifiedAuth, usePermissions } from '@solvera/pace-core';
import { formatDate, formatCurrency } from '@solvera/pace-core';

// ✅ CORRECT - Relative imports for nearby files (same directory)
import { EventCardHeader } from './EventCardHeader';
import type { EventCardFields } from './eventCardFields';

// ❌ WRONG - Deep relative imports
import { EventCard } from '../../../components/events/EventCard';

// ❌ WRONG - Importing from pace-core source
import { Button } from '@solvera/pace-core/src/components/Button';
```

---

## Component Organization

### Component Structure

**MUST** organize components by feature, not by type:

```
src/components/
├── events/                    # ✅ Feature-based
│   ├── EventCard.tsx
│   ├── EventList.tsx
│   └── EventForm.tsx
│
└── shared/                    # ✅ Shared app components
    ├── AppLayout.tsx
    └── Navigation.tsx
```

```
src/components/
├── buttons/                   # ❌ WRONG - Type-based
├── inputs/                    # ❌ WRONG - Type-based
└── cards/                     # ❌ WRONG - Type-based
```

**Why?** Use pace-core components for UI primitives (Button, Input, Card, etc.). Your components should be feature-specific compositions.

### pace-core package component layout

Inside `@solvera/pace-core`, `packages/core/src/components/` **MUST** use feature folders aligned with requirement slices (CR05–CR09). The root may contain only `index.ts` and these top-level folders:

| Folder | Requirement slice | Examples |
|--------|-------------------|----------|
| `primitives/` | CR05a | Button, Input, Card, Alert |
| `overlays/` | CR05b | Dialog, Select, Tabs (`overlays/select/internal/` for non-exported listbox primitives) |
| `shell/` | CR05c | PaceHeader, PaceFooter, PaceAppLayout, ErrorBoundary |
| `forms-feedback/` | CR06 | Form, Toast, SaveActions |
| `auth/` | CR03 | PaceLoginPage, ProtectedRoute |
| `advanced-ui/` | CR08 | Calendar, FileUpload, ContextSelector |
| `data-table/` | CR07 | DataTable, column factory, import utilities |
| `public-layout/` | CR09 | PublicPageLayout, PublicPageProvider |

**MUST NOT** add new `.tsx` files directly under `components/` root. **MUST NOT** keep legacy folder names (`DataTable/`, `PublicLayout/`, `select-internal/`). Public exports surface only through `components/index.ts`.

### When to split a component into separate files

**MUST** split a component into separate files when:

- The file exceeds **approximately 1000 lines** of code, or
- A subcomponent is **complex enough** to warrant its own tests and types.

### Component File Structure

For simple components (single file):

```
src/components/events/EventCard.tsx
```

For complex components (multiple related files):

```
src/components/events/EventCard/
├── EventCard.tsx              # Main component
├── EventCardHeader.tsx        # Sub-components
├── eventCardFields.ts         # Normalised display fields
├── EventCard.test.tsx         # Tests (colocated)
├── EventCard.types.ts         # Component-specific types
└── index.ts                   # Barrel export
```

### Component Composition Example

```tsx
// ✅ CORRECT - Use pace-core components
import { Button, Card, Input } from '@solvera/pace-core';
import { useEventData } from '@/hooks/events/useEventData';

export function EventCard({ eventId }: { eventId: string }) {
  const { event } = useEventData(eventId);
  
  return (
    <Card>
      <h2>{event.title}</h2>
      <p>{event.description}</p>
      <Button>View Details</Button>
    </Card>
  );
}
```

---

## Testing Structure

### Test Colocation

**MUST** colocate tests with source files:

```
src/
├── components/
│   └── events/
│       ├── EventCard.tsx
│       └── EventCard.test.tsx        # ✅ Colocated
│
├── hooks/
│   ├── useEventData.ts
│   └── useEventData.test.ts           # ✅ Colocated
│
└── utils/
    ├── formatEvent.ts
    └── formatEvent.test.ts            # ✅ Colocated
```

### Test File Naming

- Unit tests: `*.test.ts` or `*.test.tsx`
- Integration tests: `*.integration.test.ts`
- E2E tests: Place in `tests/` directory

### Test Organization Example

```typescript
// src/components/events/EventCard.test.tsx
import { render, screen } from '@testing-library/react';
import { EventCard } from './EventCard';

describe('EventCard', () => {
  it('renders event title', () => {
    // Test implementation
  });
});
```

---

## Database & Supabase Structure

### Migrations (consuming apps)

**Consuming apps MUST NOT have `supabase/migrations/`.** All database migrations are managed only in pace-core. Consuming apps connect to an existing Supabase project and schema.

### Supabase directory in consuming apps

**MUST** have at minimum:

```
supabase/
├── config.toml                   # Supabase config
└── functions/                    # Only if the app defines Edge Functions
    └── [function-name]/
        ├── index.ts
        └── package.json
```

Do not create a `migrations/` folder in consuming apps.

### Supabase Client Setup

**MUST** place the base Supabase client in `src/lib/supabase.ts`. The base client **MUST NOT** be exported for general use; it is used only by `main.tsx` or `App.tsx` and passed to `UnifiedAuthProvider`. Components **MUST** use `useSecureSupabase()` from pace-core for queries. See [pace-core Compliance](./5-pace-core-compliance-standards.md) for security requirements.

```typescript
// src/lib/supabase.ts — base client for UnifiedAuthProvider only; DO NOT import elsewhere
import { createClient } from '@supabase/supabase-js';
import type { Database } from '@/types/database';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabasePublishableKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;

// Used only by main.tsx/App.tsx for UnifiedAuthProvider; components use useSecureSupabase()
export const supabaseClient = createClient<Database>(supabaseUrl, supabasePublishableKey);
```

---

## Configuration Files

### Required Configuration Files

**MUST** have these configuration files in the root:

| File | Purpose | Required? |
|------|---------|-----------|
| `package.json` | Dependencies and scripts | ✅ Yes |
| `tsconfig.json` | TypeScript configuration | ✅ Yes |
| `vite.config.ts` | Vite build configuration | ✅ Yes |
| `vitest.config.ts` | Vitest test configuration | ✅ Yes |
| `.gitignore` | Git ignore patterns | ✅ Yes |
| `.env` | Local environment variables (not committed) | ✅ Yes |
| `eslint.config.js` (or `.eslintrc.js` / `eslint.config.cjs`) | ESLint configuration | ✅ Yes |

For Supabase and MCP setup, see [New project setup](../NEW-PROJECT-SETUP.md) (Environment variables and MCP setup).

### Root Directory Rules

**MUST** keep root directory clean:

✅ **Allowed in root:**
- Configuration files (`package.json`, `tsconfig.json`, etc.)
- Documentation (`README.md`, `CHANGELOG.md`)
- Build tool configs (`vite.config.ts`, etc.)
- `.cursor/` directory (including `mcp.json`)
- `.gitignore`, `.env`

❌ **NOT allowed in root:**
- Source files (`*.ts`, `*.tsx`)
- Component files
- Test files
- Utility files

---

## Structure Checklist

Before committing code, verify your project structure:

### Directory Structure
- [ ] Standard directory structure followed
- [ ] Root directory contains only config files
- [ ] All source code in `src/`
- [ ] `.cursor/rules/` and `.cursor/mcp.json` present
- [ ] `public/fonts/` (`.woff2`) and `public/logos/` present
- [ ] `.env` present (`.env` gitignored)
- [ ] No `supabase/migrations/` (consuming apps; migrations only in pace-core)

### File Organization
- [ ] Components organized by feature, not type
- [ ] Tests colocated with source files
- [ ] Naming conventions followed
- [ ] No duplicate pace-core components

### Imports
- [ ] Path aliases configured (`@/` prefix)
- [ ] Absolute imports used (no deep relative paths)
- [ ] pace-core imported from package, not source
- [ ] No restricted imports (e.g., `@radix-ui/*`)

### Configuration
- [ ] `tsconfig.json` has path aliases
- [ ] `vite.config.ts` has path aliases
- [ ] ESLint configured with pace-core rules
- [ ] All required config files present

### Documentation
- [ ] `README.md` documents project structure
- [ ] Non-standard decisions documented

---

## Common Mistakes to Avoid

### ❌ Don't: Organize by Component Type

```
src/components/
├── buttons/        # ❌ Use pace-core Button instead
├── inputs/         # ❌ Use pace-core Input instead
└── cards/          # ❌ Use pace-core Card instead
```

### ❌ Don't: Create Duplicate Components

```tsx
// ❌ WRONG - Don't create local Button
// src/components/Button.tsx
export function Button() { }

// ✅ CORRECT - Use pace-core
import { Button } from '@solvera/pace-core';
```

### ❌ Don't: Use Deep Relative Imports

```tsx
// ❌ WRONG
import { EventCard } from '../../../components/events/EventCard';

// ✅ CORRECT
import { EventCard } from '@/components/events/EventCard';
```

### ❌ Don't: Place Source Files in Root

```
your-app/
├── App.tsx          # ❌ WRONG - Should be in src/
├── components/      # ❌ WRONG - Should be in src/components/
└── utils.ts         # ❌ WRONG - Should be in src/utils/
```

### ❌ Don't: Modify pace-core Code

```tsx
// ❌ WRONG - Don't import from pace-core source
import { Button } from '@solvera/pace-core/src/components/Button';

// ✅ CORRECT - Import from package
import { Button } from '@solvera/pace-core';
```

---

## Related Documentation

- [Standards Overview](./0-standards-overview.md) - Standards system overview
- [pace-core Compliance](./5-pace-core-compliance-standards.md) - pace-core usage patterns
- [Visual Standards](./7-visual-standards.md) - **CRITICAL: Required CSS configuration**
- [Code Quality](./6-code-quality-standards.md) - Code style and TypeScript standards
- [API & Tech Stack](./4-api-tech-stack-standards.md) - Tech stack requirements
- [Architecture](./2-architecture-standards.md) - Architecture principles

---

**Last Updated:** 2025-01-28  
**Version:** 2.0.0  
**Applies to:** All consuming apps using `@solvera/pace-core`
